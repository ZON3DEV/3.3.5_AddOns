﻿-- *********************************************************
-- **                                                     **
-- **               Defile Guard - Core                   **
-- **                                                     **
-- *********************************************************
--  Defile Guard is a world of warcraft addon for showing special combat situations
--  fighting against the lich king

--  This file is part of the Defile Guard Wow Addon.
--  This addon is written and copyrighted by: Wolfgang K�nig
--
--  Defile Guard is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
-- 
--  Defile Guard is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
-- 
--  You should have received a copy of the GNU General Public License
--  along with Defile Guard.  If not, see <http://www.gnu.org/licenses/>.

  DefileGuard_ShowRunAway = DG_Arrow_ShowRunAway;
  DefileGuard_ShowRunTo = DG_Arrow_ShowRunTo;
  DefileGuard_UnitDebuff = UnitDebuff;

if GetLocale() == "enGB" or 
   GetLocale() == "enUS" or 
   GetLocale() == "enEN" then
        spellName_Defile = "Defile";
        spellName_DefileDebuff = "Defile";
        spellName_TrapDebuff = "Shadow Trap";
        unitName_LK = "The Lichking";
        defileCastMsg = " casts Defile!";
        defileCountMsg = "Defile possible in ";
        defileOnYouMsg = "Defile on you - Run to throne!";
        defileNearYouMsg = "Defile near you - Run!";
        defileDebuffOnYouMsg = "Defilement on you - Run!";
        defileDebuffNearYouMsg = "Defilement near you - Run!";
        defileCastonMsg = "Defile cast on ";
        defilementTriggerMsg = "Defilement triggered by ";
        saveSpotMsg ="Defile - Save Spot";
        LKnotinFocusMsg = "Set your focus target to "..unitName_LK.."!";
        fightStartingMsg = "The fight against "..unitName_LK.." starts.";
        fightEndingMsg = "The fight against "..unitName_LK.." is over.";
        shadowTrapTriggedMsg = "Shadow trap triggered by ";
        necroticPlagueonYouMsg = "Plague on you - Run to the horror!";
        testDefileMsg = "Test Defile Test";
        skullSign = "{skull}";
end

if GetLocale() == "deDE" then
        spellName_Defile = "Entweihen";
        spellName_DefileDebuff = "Entweihen";
        spellName_TrapDebuff = "Schattenfalle";
        unitName_LK = "Der Lichk\195\182nig";
        defileCastMsg = " wirkt Entweihen!";
        defileCountMsg = "Entweihen m\195\182glich in ";
        defileOnYouMsg = "Entweihen auf Dir - Lauf zum Thron!";
        defileNearYouMsg = "Entweihen in Deiner N\195\164he - Lauf!";
        defileDebuffOnYouMsg = "Entweihung auf Dir - Lauf!"
        defileDebuffNearYouMsg = "Entweihung in Deiner N\195\164he - Lauf!"
        saveSpotMsg ="Entweihen - Save Spot";
        defileCastonMsg = "Entweihen wurde gewirkt auf ";
        defilementTriggerMsg = "Entweihung wurde ausgel\195\182st durch "
        LKnotinFocusMsg = "Setze den Lichk\195\182nig als dein Focustarget!";
        fightStartingMsg = "Der Kampf gegen den Lichk\195\182nig beginnt.";
        fightEndingMsg = "Der Kampf gegen den Lichk\195\182nig ist beendet.";
        shadowTrapTriggedMsg = "Schattenfalle wurde ausgel\195\182st von ";
        necroticPlagueonYouMsg = "Seuche auf Dir - Lauf zum Schrecken!";
        testDefileMsg = "Test Entweihen Test";
        skullSign = "{Totensch\195\164del}";
end

if GetLocale() == "frFR" then
        spellName_Defile = "Profanation";
        spellName_DefileDebuff = "Profanation";
        spellName_TrapDebuff = "Piège d'ombre";
        unitName_LK = "le Roi Liche";
        defileCastMsg = " lance Profanation!";
        defileCountMsg = "Profanation possible dans ";
        defileOnYouMsg = "Profanation sur vous - Courrez!";
        defileNearYouMsg = "Profanation prêt de vous - éloignez vous!";
        defileDebuffOnYouMsg = "Profanation sur vous - Courrez!";
        defileDebuffNearYouMsg = "Profanation prêt de vous - éloignez!";
        defileCastonMsg = "Profanation lancé sur ";
        defilementTriggerMsg = "Profanation déclenchée par ";
        saveSpotMsg ="Profanation - Vous est ok";
        LKnotinFocusMsg = "Définissez votre cible focus "..unitName_LK.."!";
        fightStartingMsg = "Le combat contre "..unitName_LK.." commence.";
        fightEndingMsg = "Le combat contre "..unitName_LK.." est terminer.";
        shadowTrapTriggedMsg = "Piège d'ombre déclenché par ";
        necroticPlagueonYouMsg = "La peste sur vous - courrez vers l'horreur!";
        testDefileMsg = "Test Profanation Test";
        skullSign = "{skull}";
end



SLASH_DGP1 = "/dgp"

local raid = {}
local addonVersions = {}
local debugmode = false;
local showArrows = false;
local loggingChannel = false;
local VariablesLoaded = nil;
local Initialized = nil;
local setPointPositionX = nil;
local setPointPositionY = nil;
local showNecroticPlagueWarn = true;
local fightRunning = false;
local logChannelName = "ddkms";
local version = GetAddOnMetadata("DefileGuard", "Version")
failLog= {};

local frame = CreateFrame("FRAME");
frame:SetAllPoints(UIParent);

local display = CreateFrame("FRAME","DefileGuard",UIParent);

display:SetWidth(1)
display:SetHeight(1)
--display:SetPoint("CENTER",UIParent,"CENTER",-1,39)
display.text = display:CreateFontString(nil, "ARTWORK")
--display.text:SetFont("Fonts\\FRIZQT__.TTF",36,"THICK")
--display.text:SetFont("Interface\\AddOns\\DefileGuard\\Fonts\\ARMY_EXPANDED.TTF",24,"THICK")
display.text:SetFont("Interface\\AddOns\\DefileGuard\\Fonts\\ARMY.TTF",36)
display.text:SetPoint("CENTER",display,"CENTER")
display.text:SetTextColor(1,0.5,0)
display.defiletime = 0
display.defiledisplayend = GetTime()+10
display.defiledebuffdisplayend = 0
display.play1sound = true;
display.play2sound = true;
display.play3sound = true;
display:SetMovable(true)
display:SetClampedToScreen(true)
display.text:SetText("Defile Guard V"..version.." chargé.")

local texture = frame:CreateTexture();
texture:SetAllPoints(frame);
texture:SetTexture(1, 0, 0, 0.3);
texture:Hide();

frame:RegisterEvent("UNIT_TARGET");
frame:RegisterEvent("UNIT_SPELLCAST_START");
frame:RegisterEvent("UNIT_AURA");
frame:RegisterEvent("PLAYER_ENTERING_WORLD");
frame:RegisterEvent("VARIABLES_LOADED");
frame:RegisterEvent("PLAYER_REGEN_DISABLED");
frame:RegisterEvent("PLAYER_REGEN_ENABLED");
frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
frame:RegisterEvent("RAID_ROSTER_UPDATE");
frame:RegisterEvent("CHAT_MSG_ADDON");
frame:RegisterEvent("CHAT_MSG_MONSTER_YELL");

frame:SetScript("OnEvent", function(self, event, ...)
  local timestamp, combatEvent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = 
   ...; -- Those arguments appear for all combat event variants.
  -- Event: UNIT_TARGET 
  if(event == "UNIT_TARGET") then
    local unit = select(1,...);
    if(UnitName(unit) == unitName_LK) then
      local spell = UnitCastingInfo(unit);	    
	  if(spell == spellName_Defile and UnitName(unit.."target") ~= nil) then
		DefileGuard:logChannel(skullSign..defileCastonMsg..UnitName(unit.."target")..skullSign);
        if (UnitName(unit.."target") == UnitName("player")) then
		  DefileGuard:Alarm(1, "player");
        else                   
          local inRange = CheckInteractDistance(unit.."target", 2) -- 2 = 11.11 yards / 3 = 9.9 yards
          if inRange then
			DefileGuard:Alarm(2, unit.."target");
		  else
            display.text:SetText(saveSpotMsg)
		    display.text:SetTextColor(0,1,0) -- the player is save / GREEN TEXT
		  end
		end	   
      end
    end
  end
    
  -- Event: UNIT_SPELLCAST_START
  if (event == "UNIT_SPELLCAST_START") then
		-- Extract this data using select as well:
        local spellUnit, spellName, spellRank, spellLineID, spellID = select(1, ...); 
		-- defile cast
		if (spellName == spellName_Defile) then
			-- show defile warning
			failLog= {};
			display.defiledisplayend = GetTime() + 3
			display.text:SetTextColor(1,0.5,0) -- ORANGE TEXT
			display.text:SetText(unitName_LK..defileCastMsg)
			-- restart defile cooldown timer
			display.defiletime = GetTime() + 32
			-- check if target suspend spelling
			if (UnitName(spellUnit.."target") ~= nil) then
			    if (UnitName(spellUnit.."target") == UnitName("player")) then
				  DefileGuard:Alarm(1, "player");
		        else                   
		          local inRange = CheckInteractDistance(spellUnit.."target", 2) -- 2 = 11.11 yards / 3 = 9.9 yards
		          if inRange then
					DefileGuard:Alarm(2, spellUnit.."target");
				  else
		            display.text:SetText(saveSpotMsg)
				    display.text:SetTextColor(0,1,0) -- the player is save / GREEN TEXT
				  end
				end			    
			end
			
		end
		
		-- quake cast
		if spellID == 72262 then
			-- start cooldown timer
			display.defiletime = GetTime() + 37
		end
		-- remorseless winter
		if spellID == 68981 or spellID == 73791 or spellID == 73792 or spellID == 73793 or
           spellID == 72259 or spellID == 74273 or spellID == 74274 or spellID == 74275 
           then
			-- clear current cooldown timer
			display.defiletime = 0
		end		
  end  
 
  
  if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
    if (combatEvent=="SPELL_AURA_APPLIED") then
       local spellId, spellName, spellSchool,auraType = select(9, ...);
       
	   if spellName == spellName_DefileDebuff then

		   if failLog[destName] == nil then
			 failLog[destName] = {};
		   end
		   if (failLog[destName][timestamp] == nil) then
		     DefileGuard:logChannel(defilementTriggerMsg..destName);
		     failLog[destName][timestamp] = true; 
		   end

		   if destName == UnitName("player") then
			 DefileGuard:Alarm(3, destName);
		   else
		     local inRange = CheckInteractDistance(destName, 2)
			 if inRange then
			   DefileGuard:Alarm(4, destName);
             end		
		   end		   		   	           	   
	   end	   	   
    end
    
    -- Necrotic Plague Warning
    if (combatEvent=="SPELL_CAST_SUCCESS") then
      local spellId, spellName, spellSchool = select(9, ...);
      if spellId == 70337 or spellId == 73912 or spellId == 73913 or spellId == 73914 then 
        if UnitName("player") == destName then
           if showNecroticPlagueWarn then DefileGuard:Alarm(5, destName); end
        end
      end
    end
  
  end

  if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
    if (combatEvent=="SPELL_DAMAGE") then       
	  local spellId, spellName, spellSchool = select(9, ...)
	  local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(12, ...);  
      if spellName == spellName_TrapDebuff then
        if (DefileGuard:GetRaidUnitId(destName)~="none") then -- only show players
          DefileGuard:logChannel(shadowTrapTriggedMsg..destName);
        end
      end
	end    
  end
  
  if (event == "PLAYER_ENTERING_WORLD") then
	DefileGuard:Initialize()    
  end

  if (event == "VARIABLES_LOADED") then
    VariablesLoaded = 1; -- Daten vollst�ndig geladen
  end

  if (event == "RAID_ROSTER_UPDATE") then
    raid = {};
    -- raidmember auslesen
	if GetNumRaidMembers() >= 1 then			
		for i = 1, GetNumRaidMembers() do
			local name, rank, subgroup, _, _, fileName = GetRaidRosterInfo(i)
			raid[name] = raid[name] or {}
			raid[name].name = name
			raid[name].rank = rank
			raid[name].subgroup = subgroup
			raid[name].class = fileName
			raid[name].id = "raid"..i
			raid[name].updated = true
			raid[name].version = "unknown"
		end
	end
		
    -- partymember auslesen
	if GetNumPartyMembers() >= 1 then
		for i = 0, GetNumPartyMembers() do
			local id
			if (i == 0) then
				id = "player"
			else
				id = "party"..i
			end
			local name, server = UnitName(id)
			local rank, _, fileName = UnitIsPartyLeader(id), UnitClass(id)
			if server and server ~= ""  then
				name = name.."-"..server
			end
			raid[name] = raid[name] or {}
			raid[name].name = name
			if rank then
				raid[name].rank = 2
			else
				raid[name].rank = 0
			end
			raid[name].class = fileName
			raid[name].id = id
			raid[name].updated = true
			raid[name].version = "unknown"
	    end
    end    

    SendAddonMessage("DefileGuard", "update", "RAID");
  end

  if (event == "CHAT_MSG_ADDON") then
    DefileGuard:CHAT_MSG_ADDON(...);
  end
 
  if (event == "PLAYER_REGEN_DISABLED") then
    local focusName = UnitName("focus");
	local targetName = UnitName("target");
	if (focusName and focusName == unitName_LK) or
	   (targetName and targetName == unitName_LK) then
	  fightRunning = true
      DefileGuard:logChannel(fightStartingMsg,1)
      DefileGuard:logChannel("-----------------------------------------------------------------",1)
	end
  end
  		
  if (event == "PLAYER_REGEN_ENABLED") then
    if (fightRunning) then
      DefileGuard:logChannel(fightEndingMsg,1)
      fightRunning = false
	end
  end
  
  if (event == "CHAT_MSG_MONSTER_YELL") then
    msg, npcName = select(1, ...); 
    if msg ~= nil and npcName ~= nil then
      if npcName == unitName_LK then
        if (UnitName("focus") == nil or UnitName("focus") ~= unitName_LK) then
          display.defiledisplayend = GetTime()+10;
          display.text:SetTextColor(1,0.5,0)
          display.text:SetText(LKnotinFocusMsg);
         end
      end
    end
  end

end);

display:SetScript("OnUpdate",function(self,elapsedtime)
	-- while not displaying defile message
    if self.defiledisplayend < (GetTime() + 2) and
       self.defiledisplayend > (GetTime() + 1)
	then
      if self.play2sound then
	    PlaySoundFile ("Interface\\AddOns\\DefileGuard\\Sounds\\2.mp3")
        self.play2sound = false;
	  end
    end

    if self.defiledisplayend < (GetTime() + 1) and
       self.defiledisplayend > GetTime()
	then
      if self.play1sound then
        PlaySoundFile ("Interface\\AddOns\\DefileGuard\\Sounds\\1.mp3")
        self.play1sound = false;
	  end
    end

	if self.defiledisplayend < GetTime() and self.defiledebuffdisplayend < GetTime() then
        self.play1sound = true;
		self.play2sound = true;
		-- ensure white text
		self.text:SetTextColor(1,0.5,0) -- WHITE TEXT
		-- display timer value when close enough
		if self.defiletime < (GetTime() + 4) and self.defiletime > (GetTime() + 3) then
		  if self.play3sound then
		    PlaySoundFile("Sound\\Character\\Human\\HumanVocalFemale\\HumanFemaleIncoming02.wav")
		    self.play3sound = false;
		  end
		end
		if self.defiletime < GetTime() + 4 and self.defiletime > GetTime() then
			self.text:SetText(defileCountMsg..string.format("%.1f", self.defiletime - GetTime()))
		else
			self.play3sound = true;
			self.text:SetText("")
		end
	end
end);

local movableFrame = CreateFrame("Frame","DefileGuardMovable",UIParent)
movableFrame:EnableMouse(true)
movableFrame:RegisterForDrag("LeftButton")
movableFrame:SetHeight(30)
movableFrame:SetWidth(30)
movableFrame:SetPoint("CENTER",display,"CENTER")
movableFrame.texture = movableFrame:CreateTexture()
movableFrame.texture:SetAllPoints(movableFrame)
movableFrame.texture:SetTexture(1,1,0,.5)
movableFrame:SetScript("OnDragStart",function(self)
	display:StartMoving()
end)
movableFrame:SetScript("OnDragStop",function(self)
	display:StopMovingOrSizing()
end)
movableFrame:Hide()

SlashCmdList["DGP"] = function(msg)
    if (msg == "aide") then
      DefileGuard:print("/dgp : Active ou désactive le mode fenêtre mobile ou enregistre la position.");
      DefileGuard:print("/dgp chef : Active l'utilisation du canal "..logChannelName..".");
      DefileGuard:print("/dgp version : Effectue une vérification de version raid entier.");
      DefileGuard:print("/dgp test : Active le mode de test dans Quel'Danas.");
      DefileGuard:print("/dgp live : Désactive le mode test.");
      DefileGuard:print("/dgp aide : Donne la descriptions des commandes.");
      return
    end
    
    if (msg == "chef") then
	  if (loggingChannel == false) then
	    DefileGuard:print("Canal mode activé.");				
	    loggingChannel = true;
	  else
	    DefileGuard:print("Mode Canal désactivé.");				
        loggingChannel = false;
	  end
	  return
	end
	
    if (msg == "version") then
        local playersnoVersion="";
        local playersInstalled=0;
        DefileGuard:print("DefileGuard - Versions");				
        DefileGuard:logChannel("DefileGuard - versions",1);
        if type(addonVersions)=="table" then
          for k,v in pairs(addonVersions) do 
            playersInstalled = playersInstalled+1;
            DefileGuard:print(k..": "..v);				
            DefileGuard:logChannel(k..": "..v,1)
          end        
        end
        
        if type(raid)=="table" then         
          for k,v in pairs(raid) do 
            if v.version=="unknown" then
              if playersnoVersion~="" then
                playersnoVersion= playersnoVersion..", "..v.name
              else
                playersnoVersion= v.name
              end
            end
          end          
          DefileGuard:print("Les joueurs sans DefileGuard ou avant la version 1.8: "..playersnoVersion);				
          DefileGuard:logChannel("Players without DefileGuard or prior version 1.8: "..playersnoVersion,1);          
        end
    DefileGuard:print("Trouvé "..playersInstalled.." joueurs avec DefileGuard installé.");
    DefileGuard:logChannel("Found "..playersInstalled.." players with DefileGuard installed.",1);
	return
    end
	
    if (msg == "test") then
      DefileGuard:print("Mode test activé.");	
      if GetLocale() == "enGB" or 
         GetLocale() == "enUS" or 
         GetLocale() == "enEN" then
        spellName_Defile = "Incinerate";
	    spellName_DefileDebuff = "Immolate"
	    unitName_LK = "Dawnblade Summoner";
      end
      if GetLocale() == "deDE" then
        spellName_Defile = "Verbrennen";
	    spellName_DefileDebuff = "Feuerbrand"
	    unitName_LK = "Beschw\195\182rer der D\195\164mmerklingen";
      end
      if GetLocale() == "frFR" then
        spellName_Defile = "Incinérer";
	    spellName_DefileDebuff = "Immolation"
	    unitName_LK = "Invocateur de la Lame de l'aube";
      end
      
      DefileGuard_UnitDebuff = UnitDebuff;
      DefileGuard_ShowRunAway = DG_Arrow_ShowRunAway;
      DefileGuard_ShowRunTo = DG_Arrow_ShowRunTo;
      return
    end

    if (msg == "live") then      
      DefileGuard:print("Le mode Live activé.");
      if GetLocale() == "deDE" then
        spellName_Defile = "Entweihen";
        spellName_DefileDebuff = "Entweihen";
        unitName_LK = "Der Lichk\195\182nig";
      end
      
      if GetLocale() == "frFR" then
        spellName_Defile = "Profanation";
	    spellName_DefileDebuff = "Profanation"
	    unitName_LK = "Le roi Liche";
      end
      
      if GetLocale() == "enGB" or 
         GetLocale() == "enUS" or 
         GetLocale() == "enEN" then
        spellName_Defile = "Defile";
	    spellName_DefileDebuff = "Defile"
	    unitName_LK = "The Lichking";
      end

      DefileGuard_UnitDebuff = UnitDebuff;
      DefileGuard_ShowRunAway = DG_Arrow_ShowRunAway;
      DefileGuard_ShowRunTo = DG_Arrow_ShowRunTo;
            return
    end

	if movableFrame:IsVisible() then
		DefileGuard:print("Position de la fenêtre sauvegardé.");
		movableFrame:Hide()
		point, relativeTo, relativePoint, xOfs, yOfs = display:GetPoint()
		setPointPositionX = xOfs;
        setPointPositionY = yOfs;
        DefileGuard:SaveData();
	else
		movableFrame:Show()
		DefileGuard:print("Tapper /dgp pour finir le déplacement de la fenêtre.");
        display.defiledisplayend = GetTime()+10
		display.text:SetText(testDefileMsg)
		display.defiletime = GetTime() + 15
	end
end

function DefileGuard:LoadData()
	setPointPositionX = DefileGuard_Options[UnitName("player")]["setPointPositionX"];
    setPointPositionY = DefileGuard_Options[UnitName("player")]["setPointPositionY"];
    showNecroticPlagueWarn = DefileGuard_Options[UnitName("player")]["showNecroticPlagueWarn"];
end

function DefileGuard_SetDisplay()
  DefileGuard:LoadData()
  display:SetPoint("CENTER",UIParent,"CENTER",setPointPositionX,setPointPositionY)
end

function DefileGuard:SaveData()
  DefileGuard_Options[UnitName("player")]["setPointPositionX"] = setPointPositionX;
  DefileGuard_Options[UnitName("player")]["setPointPositionY"] = setPointPositionY;
  DefileGuard_Options[UnitName("player")]["showNecroticPlagueWarn"] = showNecroticPlagueWarn;
end

function DefileGuard:Initialize()
  if(Initialized or (not VariablesLoaded)) then
    return;
  end
  if(DefileGuard_Options ~= nil and DefileGuard_Options[UnitName("player")] ~= nil
  and DefileGuard_Options[UnitName("player")]["setPointPositionX"] ~= nil)  then
    -- variables added after version 1.8
    if DefileGuard_Options[UnitName("player")]["showNecroticPlagueWarn"] == nil then
      DefileGuard_Options[UnitName("player")]["showNecroticPlagueWarn"]= showNecroticPlagueWarn;
    end
    -- globale Daten sind g�ltig Laden
	DefileGuard:LoadData()
  else
  -- Standardwerte verwenden
    DefileGuard_Options= {};
    DefileGuard_Options[UnitName("player")]={};
	setPointPositionX =  -1;
    setPointPositionY =  -39;
    showNecroticPlagueWarn = true;
	DefileGuard_Options[UnitName("player")]["setPointPositionX"] = setPointPositionX;
	DefileGuard_Options[UnitName("player")]["setPointPositionY"] = setPointPositionY;
	DefileGuard_Options[UnitName("player")]["showNecroticPlagueWarn"]= showNecroticPlagueWarn;
    DefileGuard:SaveData()
  end
  Initialized = 1;
  DefileGuardSettingsGUI:init()
  DefileGuard_SetDisplay()
end

function DefileGuard:Alarm(type, unit)
  display.text:SetTextColor(1,0,0) -- RED TEXT

  if (debugmode) then
    DefileGuard:logChannel("ShowRunAway with type: "..type.." unit:"..unit.." invoked.");
  end

  if type == 1 then
    PlaySoundFile("Sound\\Creature\\HoodWolf\\HoodWolfTransformPlayer01.wav");
	display.text:SetText(defileOnYouMsg)
	if (showArrows) then
      local x, y = GetPlayerMapPosition(unit);
      if x == 0 and y == 0 then
	    WorldMapFrame:Show(); -- show map to load player coordinates
        WorldMapFrame:Hide(); 
		x, y = GetPlayerMapPosition(unit)
	  end
      DefileGuard_ShowRunTo(x+(0.49231386184692-x)*2,y+(0.7638236284256-y)*2,1,5) -- run to the Frozen Thron
     end
  end

  if type == 2 then
    PlaySoundFile("Sound\\Character\\Human\\HumanVocalFemale\\HumanFemaleFlee01.wav")		  
	display.text:SetText(defileNearYouMsg)
	if (showArrows) then
      local x, y = GetPlayerMapPosition(DefileGuard:GetRaidUnitId(UnitName(unit)))
      if x == 0 and y == 0 then
        WorldMapFrame:Show(); -- show map to load player coordinates
        WorldMapFrame:Hide();
        x, y = GetPlayerMapPosition(DefileGuard:GetRaidUnitId(UnitName(unit)))
      end
      DefileGuard_ShowRunAway(x, y, 15, 5)
	end
  end
  
  if type == 3 then
    if (display.defiledebuffdisplayend < GetTime()) then
	  PlaySoundFile("Sound\\Character\\Human\\HumanVocalFemale\\HumanFemaleFlee01.wav")		  
	  display.text:SetText(defileDebuffOnYouMsg)
      display.defiledebuffdisplayend = GetTime() + 2
      if (showArrows) then
        local x, y = GetPlayerMapPosition(DefileGuard:GetRaidUnitId(unit))
        if x == 0 and y == 0 then
	      WorldMapFrame:Show(); -- show map to load player coordinates
          WorldMapFrame:Hide();
	      x, y = GetPlayerMapPosition(DefileGuard:GetRaidUnitId(unit))
        end
	    DefileGuard_ShowRunAway(x, y, 15, 5)
      end
    end
  end

  if type == 4 then
    if (display.defiledebuffdisplayend < GetTime()) then
	  PlaySoundFile("Sound\\Character\\Human\\HumanVocalFemale\\HumanFemaleFlee01.wav")		  
	  display.text:SetText(defileDebuffNearYouMsg)
      display.defiledebuffdisplayend = GetTime() + 2
    end
  end

  if type == 5 then
	  PlaySoundFile("Sound\\Creature\\HoodWolf\\HoodWolfTransformPlayer01.wav");
	  display.text:SetText(necroticPlagueonYouMsg)
      display.defiledisplayend = GetTime() + 5
  end
      
  texture:Show();
  texture:SetAlpha(1);
  frame.elapsed = 0;
  frame:SetScript("OnUpdate", function(self, elapsed)
    frame.elapsed = frame.elapsed + elapsed;
    texture:SetAlpha(1 - frame.elapsed);
    if(frame.elapsed > 1) then
      texture:Hide();
      frame:SetScript("OnUpdate", nil);
    end
  end);
end

function DefileGuard:GetRaidUnitId(name)
  name = name or UnitName("player")
  return (raid[name] and raid[name].id) or "none"
end

function DefileGuard:print(text)
	prefix = "DefileGuard"
	DEFAULT_CHAT_FRAME:AddMessage(("|cffff7d0a<|r|cffffd200%s|r|cffff7d0a>|r %s"):format(tostring(prefix), tostring(text)), 0.41, 0.8, 0.94)
end

function DefileGuard:logChannel(msg, option)
  if loggingChannel then 
    local index = GetChannelName(logChannelName) -- finds the channel named logChannelName
    if (index~=nil) then 
	  if (option and option == 1) then
          SendChatMessage(msg , "CHANNEL", nil, index);
		else
          SendChatMessage(GetTime() ..": " .. msg , "CHANNEL", nil, index);
	  end
    end
  end
end


function DefileGuard:CHAT_MSG_ADDON(addon, msg, dest, who)
    --print(addon, msg, dest, who);
    local msgtype = "unknown";
    local msgcontent = "unknown";
    local msgcontentspecial = "unknown";

    if addon ~= "DefileGuard" then return end
    msgtype,msgcontent,msgcontentspecial = strsplit(":", msg) -- attempt to split message to determine info sent
    
    -- UPDATE REQUESTED
    if msg == "update" then
      SendAddonMessage("DefileGuard", "version"..":"..UnitName("player")..":"..version, "RAID")
    end

    -- UPDATE RECEIVED
    if msgtype=="version" then
      addonVersions[msgcontent] = msgcontentspecial;
      if raid[msgcontent]~=nil then -- catch possible error
        raid[msgcontent].version = msgcontentspecial; 
      end
    end    
end										

DefileGuard:print("Defile Guard V"..version.." chargé. Tapper /dgp pour le déplacement de la fenêtre.");