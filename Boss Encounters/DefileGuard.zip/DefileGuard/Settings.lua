﻿-- *********************************************************
-- **                                                     **
-- **               Defile Guard - Settings               **
-- **                                                     **
-- *********************************************************
--  Defile Guard is a world of warcraft addon for showing special combat situations
--  fighting against the lich king

--  This file is part of the Defile Guard Wow Addon.
--  This addon is written and copyrighted by: Wolfgang K�nig
--
--  Defile Guard is free software: you can redistribute it and/or modify
--  it under the terms of the GNU General Public License as published by
--  the Free Software Foundation, either version 3 of the License, or
--  (at your option) any later version.
--
--  Defile Guard is distributed in the hope that it will be useful,
--  but WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--  GNU General Public License for more details.
--
--  You should have received a copy of the GNU General Public License
--  along with Defile Guard.  If not, see <http://www.gnu.org/licenses/>.


DefileGuardSettingsGUI = { 
						font = STANDARD_TEXT_FONT,--"Fonts\\FRIZQT__.ttf",
						fontsize = 12,
						fontcolour = NORMAL_FONT_COLOR,
						info = {}
						};
						
---------------------------------------
-- DefileGuardSettingsGUI:init() ------
---------------------------------------
function DefileGuardSettingsGUI:init()
	local x,y
	-------------------------------------
	------------ Main Panel -------------
	-------------------------------------
    -- build option panel
    self.mainPanel = CreateFrame( "Frame", "DefileGuardPanel", UIParent );
    self.mainPanel.name = "DefileGuard V"..tostring(GetAddOnMetadata("DefileGuard", "Version"))
	self.mainPanel.title = FrameTitle(self.mainPanel.name,self.mainPanel)

  	x = 135;y = -80

	y = self:createSlider("setPointPositionX","Displayposition X", self.mainPanel, -35, 35, 0.5,x,y, DefileGuard_SetDisplay)
	y = self:createSlider("setPointPositionY","Displayposition Y", self.mainPanel, -35, 35, 0.5,x,y, DefileGuard_SetDisplay)
    y = self:createChkBox("showNecroticPlagueWarn","Activer l'avertissement de peste Neocrotique",x,y,self.mainPanel)
    
    --[[ make a child panel
    options.childpanel = CreateFrame( "Frame", "DefileGuardChild", options.panel);
    options.childpanel.name = "DefileGuardSubTab";
    options.childpanel.parent = options.panel.name;
    InterfaceOptions_AddCategory(options.childpanel);]]--
    
    InterfaceOptions_AddCategory(self.mainPanel);
end


-------------------------------------
----------- FrameTitle --------------
-------------------------------------
function FrameTitle(text,frame)
	local fontsting = frame:CreateFontString(nil, 'ARTWORK', 'GameFontNormalLarge')
	fontsting:SetJustifyH("MIDDLE")
	fontsting:SetPoint('TOPLEFT', 0, -20)
	fontsting:SetPoint('TOPRIGHT', 0, -20)
	fontsting:SetText(text)
	return fontstring
end

-----------------------------------------
-- DefileGuardSettingsGUI:createChkBox --
-----------------------------------------
function DefileGuardSettingsGUI:createChkBox(name,title,x,y,frame,func)
	local checkbox = 
		CreateFrame( "CheckButton", "chkButton"..name,frame,"OptionsCheckButtonTemplate" );
	frame["chkButton"..name] = checkbox
	checkbox:SetPoint("TOPLEFT", frame, "TOPLEFT", x,y)
	checkbox:SetScript("OnClick", 
		function(self)
			if ( self:GetChecked() ) then
				PlaySound("igMainMenuOptionCheckBoxOn");
			else
				PlaySound("igMainMenuOptionCheckBoxOff");
			end
			DefileGuard_Options[UnitName("player")][name] = (checkbox:GetChecked()==1 and "true" or "false")
            if func then func() end
		end)
	checkbox:SetScript("OnShow", 
		function(self) 
             self:SetChecked(DefileGuard_Options[UnitName("player")][name])
		end)
	getglobal("chkButton"..name.."Text"):SetText(title);
	checkbox:SetChecked(DefileGuard_Options[UnitName("player")][name])
	return (y-20)
end

-----------------------------------------
-- DefileGuardSettingsGUI:createSlider --
-----------------------------------------
function DefileGuardSettingsGUI:createSlider(variable,title, parent, low, high, step, x, y , func)
	local name = parent:GetName() .. variable
	local slider = CreateFrame('Slider', name, parent, 'OptionsSliderTemplate')
	slider:SetScript('OnValueChanged', 
		function(self)
			DefileGuard_Options[UnitName("player")][variable] = math.floor((self:GetValue()*1000)+0.55)/100
			getglobal(name .. 'Text'):SetText(title.." "..math.floor((self:GetValue()*1000)+0.55)/100)
            if func then func() end
		end)
	slider:SetScript("OnShow", 
		function(self) 
			self:SetValue(DefileGuard_Options[UnitName("player")][variable]/10) 
		end)
	slider:SetMinMaxValues(low, high)
	slider:SetValueStep(step)
	slider:SetPoint("TOPLEFT", parent, "TOPLEFT",x,y)
	slider:SetValue(DefileGuard_Options[UnitName("player")][variable]/10)
	getglobal(name .. 'Text'):SetText(title.." "..slider:GetValue())
	getglobal(name .. 'Low'):SetText("less")
	getglobal(name .. 'High'):SetText("more")
	BlizzardOptionsPanel_Slider_Enable(slider) --colors the slider properly
	return (y-45)
end
              