**********************************************************************************************************
** This addon provides several special warning messages for The Lich King's defile in 25er hard mode.   **
**                                                                                                      **
** The messages are displayed in green, red or orange colored text.                                     **
** Additional Sounds are played to support the player.                                                  **
**********************************************************************************************************

Features:
=========
- Tracking of important combat events (= fails) to the predefined log channel "dgkms" (see /dg lead):
- Which player stepped into the Shadow Trap
- Which player was the defile spell target and who stepped in the puddle (triggered defilement)
- Shows the defile spell cast of the LK and starts a 2 second countdown (text + sound)
- Shows the defile cooldown in orange text z.B. "Defile in 3 seconds"...
- Monitors the target of the defile, if on the player: Flashes the screen + red text message "Defile on you - Run to throne!" + sound "Run away little girl!"
- Monitors the defile distance: "Defile is near you - Run!" + sound "Run away!"
- Monitors the defile debuff: "Defile is on you - Run!" + sound "Run away!"
- Monitors the distance to the defile debuff (11 yards): "Defilement near you - Run!" + sound
- Shows a green text message if your position is safe: "Defile - Save Spot"
- Minimal cpu impacts (no in fight scanning or chat spamming)

Important:
==========
The Lich King must be in your focus target to track the defile cast correctly.

Slash Commands:
===============
/dg : Toggles the window moving mode or saves the position.
/dg lead: Activates the usage of the "..logChannelName.." channel.
/dg version: Performs a raid-wide version check.
/dg test: Activates the test mode in Quel'Danas.
/dg live: Deactivates the test mode.
/dg help: Shows slash command descriptions.
   

Sinn und Zweck des Addons:
==========================
Das Addon wurde speziell f�r den Lich King Hero Mode entwickelt. Es hilft den Spielern im Raid die optimale Position vor und nach dem Entweihen-Cast des Lichkings einzunehmen. Zus�tzlich loggt es wichtige Informationen zum Kampf in den Channel "dgkms". z.b. Ausl�ser der Schattenfalle / Entweihen und Entweihung.

Bedienung:
==========
Ganz wichtig: LK immer im Focus Target halten!

Das Wichtigste zuerst, im Prinzip muss man nichts einstellen, alles sollte so passen wie es ist. Sobald die Meldung "Defile Guard V1.8 loaded" erscheint ist das Addon aktiviert und einsatzbereit. Wenn jemandem allerdings die Anzeige �ber dem Kopf st�rt, so kann er sie verschieben (siehe Befehle...). Ich empfehle aber sie dort zu lassen.

Befehl: /dg help
Zeigt Hilfe zu den Slashkommandos.

Befehl: /dg version
F�hrt einen raidweiten Versionscheck durch.

Befehl: /dg
Mit /dg kann man die Fensterposition f�r die Alarmanzeige frei verschieben und schon mal einen Blick auf eine Testmeldung werfen... zudem sollte man ein wenig Sound h�ren... Noch einmal /dg speichert die neue Position ab.

Befehl: /dg test
Aktiviert den Testmodus, welcher nur auf der Insel Quel'Danas mit den Beschw�rern der D�mmerklingen funktioniert.

Befehl: /dg live
Deaktiviert den Testmodus

Befehl: /dg lead
(De)aktiviert den Channel-Lead, sollte aber immer nur eine Person im Raid verwenden! Der derzeit fest eingestellte Chat-Kanal hierf�r lautet (mit Befehl): /join dgkms

Features:
=========
Schreibt wichtige Kampfereignisse (Fails) in den vordefinierten Logchannel "dgkms":
Wer l�ste die Schattenfalle aus
Auf wen wurde Entweihen gewirkt und wer l�ste Entweihung aus (+ Zeitangabe)
Zeigt den Spellcast vom LK an und startet einen 2 Sekunden Countdown (Sound)
Zeigt den Cooldownablauf von Entweihen an: z.B. "Entweihen m�glich in 3 Sekunden"...
Pr�ft ob man Ziel des Castes ist, wenn ja Flash Bildschirm + rote Textmeldung "Entweihen auf Dir - Lauf zum Thron!" + Sound "Renn weg"
Pr�ft ob Entweihen in der N�he ist: "Entweihen in Deiner N�he - Lauf!" + Sound
Pr�ft man Entweihung (Debuff) hat: "Entweihung auf Dir - Lauf!" + Sound
Pr�ft ob ein Spieler in der N�he Entweihung (Debuff) hat (11 Meter): "Entweihung in Deiner N�he - Lauf!" + Sound
Steht man nach dem Entweihen sicher: gr�ne Textmeldung "Entweihen - Save Spot"