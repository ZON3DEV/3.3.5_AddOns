--Timers
Q. Why are some timers off? I seem to have timers like the Maiden of Virtue's Repentance innacurate.
A. A lot of bosses have what we call 'Cooldown Abilities', what we are timing is the cooldown of the ability, 
so the boss can use the ability any time after the cooldown is over.

Q. Is there an easy way to recognise these cooldowns?
A. Usually we use a '~' on front of timers that are not exact(approximations), or we will specify it's a cooldown 
in the bar/warning.


--PVP
Q. Why is there not some kind of pvp timers in Big Wigs?
A. Simple, we don't believe pvp timers belong in a boss mod, we encourage users that want pvp timers to try a pvp
mod, there are many out there.


--Trash
Q. Can we get some kind of respawn timers in Big Wigs?
A. No, there are separate mods that handle respawn timers.
