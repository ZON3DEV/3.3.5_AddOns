local ADDON_NAME = "OPie";
local assert = OneRingLib.xlu.assert;

local lockedLocales, desiredLocale, localeTables, localeCache, lang = {}, GetLocale(), {}, {}, {};
function lang:GetLocale()
	return desiredLocale;
end
function lang:SetLocale(locale)
	assert(type(locale) == "string", "Использование: OneRingLang:SetLocale(\"locale\");", 2);
	if desiredLocale ~= locale then
		desiredLocale, OPie_Locale, localeCache = locale, locale, {};
	end
end
function lang:GetString(token, format)
	assert(type(token) == "string" and (format == nil or type(format) == "string"), "Использование: OneRingLang:GetString(\"token\"[, \"format\"]);", 2);
	if not localeCache[token] then
		localeCache[token] = localeTables[desiredLocale] and localeTables[desiredLocale][token] or localeTables.enUS[token] or ("#" .. token .. "#");
	end
	return format and format:format(localeCache[token]) or localeCache[token];
end
function lang:AddLocalization(lang, data, lock)
	assert(type(lang) == "string" and type(data) == "table", "Использование: OneRingLang:AddLocalization(\"locale\", localizationTable)", 2);
	assert(not lockedLocales[lang], "Локализация %q уже активна.", 2, lang);
	localeTables[lang], lockedLocales[lang] = data, lock == true;
end
EC_Register("ADDON_LOADED", "OPie.Locale.Loaded", function(e, a)
	if a == ADDON_NAME and type(OPie_Locale) == "string" and localeTables[OPie_Locale] then
		lang:SetLocale(OPie_Locale);
	end
end);
setmetatable(lang, {__call=lang.GetString});
OneRingLib.lang = lang;

--[[
	Official enUS locale follows.

	Localization should be handled through downloadable, third-party plug-ins.
	If you're a localization author, see http://www.go-hero.net/opie/api/localize for a description and instructions.
]]
lang:AddLocalization("enUS", {
	title="OPie",
	locale="Русская",
	BindingName="An OPie ring",

	cfgMainIntro="Различные индикаторы настроек; правый клик на отметке что бы поставить стандартным на глобальном уровне.",
	cfgGlobalDomain="Стандартно для всех колец",
	cfgDomain="Аль настройки для:",
	cfgRingDomain="Кольцо: |cffaaffff%s|r (%d входов)",
	cfgProfile="Профиль: %s",
	cfgProfileNew="Создать новый профиль",
	cfgProfileDel="Удалить текущий профиль",
	cfgProfileName="Новое имя профиля:",
	cfgRingAtMouse="Центрировать кольца на мышке",
	cfgHeaderBehavior="Поведение колец",
	cfgHeaderIndication="Индикаторы элементов",
	cfgHeaderAnimation="Анимация",
	cfgShowCenterIcon="Центральная иконка",
	cfgShowCenterCaption="Центральный заголовок",
	cfgShowCooldowns="Цифровая перезарядка",
	cfgMultiIndication="Частичные иконки",
	cfgIndication="Индикаторы элементов",
	cfgClickActivation="Активация при левом клике",
	cfgHideStanceBar="Спрятать панель стоек",
	cfgIndicationOffset="Место положения:",
	cfgRingScale="Размер |cffffd500(%0.1f)|r",
	cfgUseGameTooltip="Показать подсказки",
	cfgClickPriority="Кольца выше всех",
	cfgGhostMIRings="Вложеные кольца",
	cfgMouseBucket="Чуствительность к колесику прокручивания",
	cfgNoClose="Оставить открытыми после использования",
	cfgSliceBinding="Назначить клавиши для частей",
	cfgShowKeys="Показать назначения",
	cfgUseBF="Использовать аддон ButtonFacade",
	cfgColorBF="Цвет BF частичек",

	cfgMIScale="Размер анимации частей",
	cfgMIDisjoint="Отдельный размер анимации",
	cfgXTScaleSpeed="Скорость размера анимации",
	cfgXTPointerSpeed="Скорость ротации указателя",
	cfgXTZoomTime="Увеличение/Уменьшение со времени |cffffd500(%.1f сек)|r",
	cfgCenterAction="Быстрое дейстиве на центре кольца",

	cfgBindingTitle="Назначения Кольца",
	cfgBindingIntro="Назначте OPie назначения клавишь ниже. |cffa0a0a0Серые|r и |cffFA2800красные|r назначения конфликтируют с другими и не корректно назначены. " ..
		"Alt+Левый клик на кнопке что бы назначить условное назначение, указано |cff4CFF40[+]|r.",
	cfgBinding="Назначение",
	cfgNoBinding="Не назначено",
	cfgBindingCond="|cff4CFF40[+] |r%s%s",
	cfgBindingMacro="Используйте следущую команду что бы открыть |cffFFD029%s|r кольцо в макросе:",
	cfgBindingThis="это",
	cfgName="Кольцо",
	bndRingName="%s |cffa0a0a0(%d)|r",
	cfgUnbind="Раззначить Кольцо",
	cfgBindConditionalExplain="F.ex. |cff4CFF40[combat] ALT-C; CTRL-F|r. Нажмите ENTER что бы сохранить.",

	cfgRKTitle="Отдельные Кольца",
	cfgRKIntro="Создавайте, модифицируйте и обменивайтесь кольцами содержащие заклинания, вещи и макросы.",
	cfgRKSelectARing="Выбирите Кольцо",
	cfgRKNewRing="Создайте новое кольцо",
	cfgRKNewName="Новое имя Кольца:",
	cfgRKDRemove="Удалить кусочек",
	cfgRKDRemoveRing="Удалить Кольцо",
	cfgRKDUprankSingle="Заклинание: |cff0077ff%s|r",
	cfgRKDUprankDouble="Заклинание: |cff0077ff%s|r или |cff0077ff%s|r",
	cfgRKDItem="Вещь: %s",
	cfgRKDMacro="Макро: %s",
	cfgRKDCompanion="Компаньён: |cff77aaff%s|r",
	cfgRKDCustomMacro="Добавить отдельный макро кусочек",
	cfgRKDCMacro="Отдельный Макро",
	cfgRKDEquipSet="Сэт одежды: |cffe040ff%s|r",
	cfgRKDropInstructions="Ложите вещи, заклинания, макросы сюда что бы добавить их в Кольцо.",
	cfgRKDByName="Также используйте вещи с таким же именем",
	cfgRKDExactRank="Используйте нужный ранг вместо максимального",
	cfgRKRotate="Ротация Кольца |cffffd500(%d\194\176)|r:",
	cfgRKScope="Дать возможность этому кольцу:",
	cfgRKScopeAll="Все персонажи",
	cfgRKScopeClass="Все %s персонажи",
	cfgRKScopeMe="Только %s",
	cfgRKSliceCaption="Заголовок кусочка:",
	cfgRKModifyHint="Устновить текст/иконку",
	cfgRKBackToDetail="Показать деталь кусочка",
	cfgRKDWhilePresent="Показать этот кусочек только пока этот обьект присутствует",
	cfgRKFastClickSlice="Позволить этому кусочку быть использованным как быстрое действие Кольца",
	cfgRKSubring="Добавить кусочек суб-кольцо",
	cfgRKDRing="Суб-кольцо: |cffD278FF%2$s|r",
	cfgRKDRingUnknown="Неизвестное суб-кольцо: |cffD278FF%s|r",
	cfgRKDefaultBinding="Стандартные назначения Кольца:",
	cfgRKClickToEdit="(Кликните что бы изменить)",
	cfgRKGhostOffset="Стандартный кусочек |cffffd500(%d)|r",
	cfgRKOpenStuff="Открыть Панели Интерфейса",
	cfgRKOpenSpellBook="Книга Заклинаний",
	cfgRKOpenMacros="Макро редактор",
	cfgRKOpenBags="Сумки",
	cfgRKEquipmentSets="Добавить кусочек сэта вещей",
	cfgRKSliceIcon="Иконка КУсочка: |cffffffff(основан на действии кусочка когда ничего не выбранно)|r",
}, true);