﻿--------------------------------------------------------------------------------
--  GUI Configuration Panel
--
--  Open directly:
--  InterfaceOptionsFrame_OpenToCategory(panel);
--  or
--  InterfaceOptionsFrame_OpenToCategory(panel.name);
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Config.lua loaded."); end

local yellow,green,blue,white = "|cFFFFFF00","|cFF00FF00","|cFF00CCFF","|cFFFFFFFF";


FI_HELP_TEXT = [[FarmIt offers "set it and forget it" farming objectives. 
Current item count is displayed in the bottom-right corner of each slot, and your objective in the top-left corner. Optionally, you will be notified each time you loot an item that you are tracking.

You can set a farming objective for each item slot. When you reach your farming objective for a given item, the goal amount turns green and you will receive an on-screen notification similar to WoW quest tracking. You can hide all the buttons in a group, leaving only the bar anchor showing- and your farming progress will still be tracked.

FarmIt is able to include your current bank inventory at any time, without needing to visit the bank! Item search also includes the keyring. (Great for items like Etherium Prison keys, Relic Coffer keys, etc.)

Bar orientation can be switched between vertical and horizontal modes. The direction the bar "grows" (up, down, left, right) can also be changed.

|cFF00FF00---==( Item Buttons )==---|cFFFFFFFF

Place any item from your inventory into one of the bar slots to keep track of how many you have.

Click on an occupied slot to select its contents and move them to another button. If the destination slot has an item in it already, the button contents will trade places.

Right-Click a slot to "use" the item. (For combining motes into primals, etc.)

Shift+Right-Click a slot to clear it.

Shift+Click the slot to have it include your bank inventory in the item count. You do *not* need to be at the bank for this to work! Item counts turn yellow when 'include bank' is enabled.

Ctrl+Click a slot to set an item objective. This works similar to WoW quest tracking. The item objective number will turn green when it has been reached, and (optionally) display notifications on-screen upon objective progress and success.

|cFF00FF00---==( Bars )==---|cFFFFFFFF

To move a bar, click and drag the anchor (small numbered tab) at the end of the bar.

Right-Click the anchor of an item bar to open the GUI configuration panel. NOTE: The config window is not finished in the v2.0 beta. There will be an all new GUI options panel included once the addon reaches a more stable build.

Shift+Right-Click the bar anchor to go directly to the commands page of the configuration panel.

To grow/shrink the number of *visible* slots on a bar, click the 'quick size' buttons (-/+). To permanently add or remove buttons, see '/farmit size' on the Commands help page.

|cFF00FF00---==( Templates )==---|cFFFFFFFF

You can save all the items on a FarmIt bar as a "farming template" to easily use again later. 

Templates can be loaded onto any FarmIt bar. If there is a difference between the amount of items in the template, and the size of the bar- the bar will automatically adjust to accomodate the template. 

For details on how to save/load your own templates, please refer to the "Commands" page of FarmIt's in-game help.

]];


FI_COMMANDS_TEXT = [[
|cFFFFFF00help|cFFFFFFFF

  Show the help window.

|cFFFFFF00options|cFFFFFFFF

  Show the configuration window.

|cFFFFFF00reset|cFFFFFFFF

  Reset the mod to default settings.

|cFFFFFF00rebuild|cFFFFFFFF

  Rebuilds ALL data tables and reloads the UI. Only use 
  this if you are having problems with saved data like 
  templates, etc. WARNING: This will wipe out all your 
  saved items!

|cFFFFFF00toggle|cFF00FF00 {bar#}|cFFFFFFFF

  Toggle visibility of a bar, by bar number.
  Toggles all bars at once if no number given.


|cFFFFFF00lock|cFF00FF00 {bar#}|cFFFFFFFF

  Prevent a bar from being moved, by bar number.
  Lock position of the whole addon if no bar number given.


|cFFFFFF00scale|cFF00FF00 {%} {bar#}|cFFFFFFFF

  Change the visual scale of the addon, in decimal format:
  1.25 = 125%. If a bar number is given, only that bar 
  will be scaled.


|cFFFFFF00alpha|cFF00FF00 {#} {bar#}|cFFFFFFFF

  Change the opacity of the addon in decimal format, from 
  0 (invisible) to 1.0 (opaque). If a bar number is given, 
  only that bar will be changed.


|cFFFFFF00notify|cFF00FF00 {progress|objective}|cFFFFFFFF

  Toggle on-screen notifications ON/OFF by event type. For
  example: '/farmit notify progress' will toggle the 
  display of farming progress notifications, but you would
  still see an announcement when you reach an objective.


|cFFFFFF00group|cFF00FF00 {add||remove}|cFFFFFFFF

  |cFF00FF00add|cFFFFFFFF
    Adds a new bar. New bars start with 12 buttons (4 of 
    them showing). Note: There is a limit of 12 bars total.

  |cFF00FF00remove|cFF00CCFF {bar#}|cFFFFFFFF
    Include the bar number of the button group you wish 
    to delete. This permanently destroys the group and 
    all of its buttons!


|cFFFFFF00size|cFF00FF00 {bar#} {#}|cFFFFFFFF

  Set the total number of buttons available on a given bar.
  There is a limit of 48 slots per bar. For example: 
  '/farmit size 1 10' would configure bar number one to 
  have ten total buttons available on it. Setting a bar 
  to a smaller size will permanently delete any extra 
  buttons. To simply hide some button spaces without 
  destroying them, click the 'quick size' buttons (-/+).


|cFFFFFF00grow|cFF00FF00 {bar#} {L||R|U|D}|cFFFFFFFF

  Controls the direction that a button group grows- 
  (L)eft, (R)ight, (U)p, (D)own. For example: 
  '/farmit grow 1 R' sets bar #1 to horizontal mode, 
  growing to the right.


|cFFFFFF00style|cFF00FF00 {default|minimal}|cFFFFFFFF

  Choose a visual style:
    |cFF00FF00default|cFFFFFFFF
      Meant to match the stock WoW interface.
    |cFF00FF00minimal|cFFFFFFFF
      Goes better with addons like Bartender.

  If you feel adventurous, you can edit FarmIt2_Style.lua 
  to add your own visual themes.


|cFFFFFF00tpl|cFF00FF00 {save|load|delete|list}|cFFFFFFFF

  |cFF00FF00save|cFF00CCFF {bar#} {name}|cFFFFFFFF
    Saves all the items in a given bar as a farming 
    template for use again later. Specify the bar number 
    you want to save, followed by a template name. 
    Template names are case sensitive, must be at least 
    3 characters, and have no spaces.

  |cFF00FF00load|cFF00CCFF {bar#} {category} {name}|cFFFFFFFF
    Loads a saved item set (template) into the specified 
    bar, by name (case sensitive). The category can be 
    omitted when loading user created templates. 
    For example:  /farmit tpl load MyTemplate

  |cFF00FF00delete|cFF00CCFF {name}|cFFFFFFFF
    Deletes a user created template, by name.
    To show all user templates, type: '/farmit tpl list'

  |cFF00FF00list|cFF00CCFF {category}|cFFFFFFFF
    Specify a category to list the available bar templates 
    it contains. Categories are: WOW, TBC, WOTLK, CATA.
    If no category is given, the list will show all the 
    user created templates.
]];


--------------------------------------------------------------------------------
--  SETUP CONFIG PANELS
--------------------------------------------------------------------------------

-- panel construction
FI_CONFIG.Panel = CreateFrame("Frame", "FI_Panel", UIParent);
FI_CONFIG.Panel.name = "FarmIt";
InterfaceOptions_AddCategory(FI_CONFIG.Panel);

FI_CONFIG.Pages = {
	CreateFrame("Frame", "FI_Panel_1", FI_CONFIG.Panel),
	CreateFrame("Frame", "FI_Panel_2", FI_CONFIG.Panel),
	CreateFrame("Frame", "FI_Panel_3", FI_CONFIG.Panel),
	CreateFrame("Frame", "FI_Panel_4", FI_CONFIG.Panel),
};

FI_CONFIG.Pages[1]["name"] = "Help";
FI_CONFIG.Pages[1]["parent"] = FI_CONFIG.Panel.name;
InterfaceOptions_AddCategory(FI_CONFIG.Pages[1]);

FI_CONFIG.Pages[2]["name"] = "Commands";
FI_CONFIG.Pages[2]["parent"] = FI_CONFIG.Panel.name;
InterfaceOptions_AddCategory(FI_CONFIG.Pages[2]);

FI_CONFIG.Pages[3]["name"] = "Bar Settings";
FI_CONFIG.Pages[3]["parent"] = FI_CONFIG.Panel.name;
--InterfaceOptions_AddCategory(FI_CONFIG.Pages[3]);

FI_CONFIG.Pages[4]["name"] = "Visual Options";
FI_CONFIG.Pages[4]["parent"] = FI_CONFIG.Panel.name;
--InterfaceOptions_AddCategory(FI_CONFIG.Pages[4]);


--------------------------------------------------------------------------------
--  CONFIGURATION FUNCTIONS
--------------------------------------------------------------------------------
function FI_CONFIG.Load( self )
end

function FI_CONFIG.Show( self )
end

function FI_CONFIG.Get()
end

function FI_CONFIG.Set()
end

function FI_ToggleNotify( arg )
	local result,msg;
	
	if (arg == "progress") then
		FI_SV_CONFIG.Progress.notify = FI_Toggle( FI_SV_CONFIG.Progress.notify );
		
		if FI_SV_CONFIG.Progress.notify then result = "ON"; else result = "OFF"; end
		msg = "Progress notifications:  "..result;
	elseif (arg == "objective") then
		FI_SV_CONFIG.Objective.notify = FI_Toggle( FI_SV_CONFIG.Objective.notify );
		
		if FI_SV_CONFIG.Objective.notify then result = "ON"; else result = "OFF"; end
		msg = "Objective notifications:  "..result;
	else
		msg = "Invalid input. Options for 'notify' are:  progress, objective";
	end

	DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  "..msg);
end
