﻿--------------------------------------------------------------------------------
--  CORE FUNCTIONS
--[[
	'bar' = Bar Number
		The dynamic table index of a group's record in: FI_SVPC_DATA["Groups"]
		This is a user interface convention to provide the appearance of sequential bar numbers regardless of the actual group ID.
		
	'gid' = Group ID
		The numeric primary key of a group as found in its data "record" stored at FI_SVPC_DATA.Groups
		
	'bid' = Button ID
		The numeric primary key of a button as found in its data "record" stored at FI_SVPC_DATA.Buttons
]]--
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Core.lua loaded."); end


--------------------------------------------------------------------------------
--  STARTUP
--------------------------------------------------------------------------------
function FI_Init()
	-- determine load status
	if (FI_SV_CONFIG == nil) 
		or (FI_SVPC_CONFIG == nil) 
		or (FI_SVPC_STYLE == nil) 
		or (FI_SV_DATA == nil) 
		or (FI_SVPC_DATA == nil) 
	then
		-- new install or something wrong with saved vars
		FI_STATUS = 1;
	elseif (FI_VERSION > FI_SV_CONFIG.version) then
		-- addon updated since last run
		FI_STATUS = 2;
	else
		-- normal startup
		FI_STATUS = 3;
	end

	-- status responses
	if (FI_STATUS == 1) then
		FI_DB.rebuild("data");
		FI_Reset();
	elseif (FI_STATUS == 2) then
		if FI_REQUIRES_REBUILD then
			FI_DB.rebuild("data");
		elseif FI_REQUIRES_RESET then
			FI_Reset();
		else
			-- if no reset is happening, just update the version
			FI_SV_CONFIG.version = FI_VERSION;
		end
	elseif (FI_STATUS == 3) then
		-- all clear
	end
end

----->>  FRAME CREATION  <<-----
function FI_Frames()
	-- loop through groups and build buttons
	for i,group in ipairs(FI_SVPC_DATA.Groups) do
		FI_GroupFrames( group.id );
	end
	FI_Scale();

	-----  SKIN  -----
	FI_Style();

	-----  SHOW  -----
	if FI_SVPC_CONFIG.show then _G["FI_PARENT"]:Show(); else _G["FI_PARENT"]:Hide(); end
end

----->>  LOAD DATA  <<-----
function FI_Load()
	for i,button in ipairs(FI_SVPC_DATA.Buttons) do
		if button.item then
			FI_SetButton(button.id);
		end
	end
		
	-- G2G, BUFF AND PULL!  =P
	DEFAULT_CHAT_FRAME:AddMessage(
		"|cFF33CCFF".."FarmIt v"..FI_VERSION.." "..FI_RELEASE.." "..FI_LOAD_STATES[FI_STATUS]..".  By CHiLLZ (aka Somnifer)\n"..
		"|cFFFFFFFF".."Type /farmit for a list of available commands."
	);
end

function FI_Reset()
	if FI_DEBUG then print("[FarmIt]  RESET CALLED!"); end

	FI_DB.rebuild("config");
	FI_DB.rebuild("style");
	FI_DB.rebuild("frames");

	-- User initiated reset?
	if (FI_LOADING == false) then
		ReloadUI();
	end

	if FI_DEBUG then print("[FarmIt]  RESET COMPLETE."); end
end

--------------------------------------------------------------------------------

function FI_Notify( message, color, sound, bid, bypass )
	-- control when displaying a notification is allowed
	if (FI_LOADING == false) and (FI_MOVING == false) then
		local R,G,B = color[1],color[2],color[3];
		local allow = true;

		-- spam filter override
		if bypass then filter = false; else filter = true; end
		
		-- spam blockers, biatch! (obscure Chappelle's Show reference ftw)
		if bid and filter then
			local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
			local lastlog = FI_DB.last(FI_SV_DATA.Log, {item = button.item}, "timestamp");
			
			
			if lastlog then
				-- skip if less than 2 seconds since last log entry for this item
				local diff = time() - lastlog.timestamp;
				if (diff < 2) then
					allow = false;
				end
			else
				if FI_DEBUG then print("FI_Notify:  No log entries found for ItemID "..button.item); end
			end
		end

		if allow then 
			if sound then PlaySound(sound); end
			UIErrorsFrame:AddMessage(message, R,G,B);
		end
	end
end

-- global update wrapper
function FI_Update( event_args )
	-- mass update all populated buttons on all bars
	for i,button in ipairs(FI_SVPC_DATA.Buttons) do
		if button.item then
			FI_UpdateButton(nil, button);
		end
	end
end

----->>  UPDATE  <<-----
function FI_UpdateButton( bid, bdata )
	local button = {};
	-- streamline button data access when we are doing a global update
	if bdata then
		button = bdata;
	else
		button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	end

	if button.item then
		if FI_DEBUG and (FI_LOADING == false) then
			--print("Update running on ButtonID: "..button.id.." (ItemID: "..button.item..")");
		end
		local f_name = "FI_Button_"..button.id;

		--------------------------------------------------------------------------------
		--  CHECK FOR FAILED SERVER QUERIES
		--------------------------------------------------------------------------------
		-- attempt to fix missing icons
		if not _G[f_name.."_Icon"]:GetTexture() then
			if FI_DEBUG then print("Update found a missing texture on BID "..button.id); end
			
			_G[f_name.."_Icon"]:SetTexture( GetItemIcon(button.item) );
		end
		
		-- make sure the secure template action was set successfully
		if not _G[f_name]:GetAttribute("macrotext") then
			if FI_DEBUG then print("Update found missing macrotext on BID "..button.id); end
			
			local itemName = GetItemInfo(button.item);
			if itemName then
				_G[f_name]:SetAttribute("macrotext", "/use "..itemName);
			end
		end
		--------------------------------------------------------------------------------

		-- GET NEW ITEM COUNT
		local newcount = GetItemCount(button.item, button.bank);
		
		-- only proceed if something has changed
		if (newcount ~= button.count) then
			-- SAVE NEW COUNT
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {count = newcount});
			
			-- UPDATE GRAPHICAL ELEMENTS
			_G[f_name.."_Count"]:SetText(newcount);
			
			-- UPDATE LOG
			local log_entry = {
				["item"] = button.item, --PK
				["timestamp"] = time(),
				["count"] = newcount,
			}
			table.insert(FI_SV_DATA.Log, log_entry);

			--------------------------------------------------------------------------------
			--  PROGRESS TRACKING
			--------------------------------------------------------------------------------
			if (FI_LOADING == false) and not CursorHasItem() then
				if FI_DEBUG then print("Progress tracking triggered on ButtonID: "..button.id.." (previous count: "..button.count..", new count: "..newcount..")"); end
				
				-- this slot have an objective?
				if (button.objective > 0) then
					-- let objective tracking handle this
					FI_Objective(button.id, button.count);
					
				elseif FI_SV_CONFIG.Progress.notify and (newcount > button.count) then
					-- standard progress notification
					local itemName, itemLink = GetItemInfo(button.item);
					if itemLink then
						local message = "Farming progress:  "..itemLink.."x"..newcount;
						FI_Notify(message, FI_SV_CONFIG.Progress.color, nil, button.id);
					elseif FI_DEBUG then
						print("Progress notification FAILED on BID "..button.id.." due to missing itemLink!");
					end
				end
			end
		end
	else
		-- no item, zero the counter
		_G["FI_Button_"..button.id.."_Count"]:SetText(0);
	end
end


--------------------------------------------------------------------------------
--  FRAME CREATION
--------------------------------------------------------------------------------
function FI_GroupFrames( gid )
	if FI_DEBUG then print("Load routine running for Group ID: "..gid); end
	
	-- retrieve group data
	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);
	-- define frame name
	local f_name = "FI_Group_"..group.id;

	-- check if frame already exists
	if (_G[f_name] == nil) then
		-- create the base "anchor" frame for the bar
		local f = CreateFrame("Button", f_name, _G["FI_PARENT"], "FI_TPL_Group");
		f:SetFrameStrata("LOW");
		f:SetPoint("CENTER"); --improve this? maybe some form of smart snapping so the bars dont pile up on top of each other
		f:SetScale(group.scale);
		f:Show(group.show);

		f:EnableMouse(true);
		f:SetMovable(true);
		f:SetClampedToScreen(true);
		f:RegisterForClicks("LeftButtonDown","LeftButtonUp","RightButtonUp");
		f:SetScript("OnClick", FI_Click_Group);
		
		
		-- set graphical bar number
		_G[f_name.."_Label"]:SetText( FI_DB.find(FI_SVPC_DATA.Groups, {id = group.id}, true) );

		-- handle orientation related requirements
		local horizontal = {"L","R"};
		local a_size_x,a_size_y = 0,0;
		
		if tContains(horizontal, group.grow) then
			-- horizontal anchor frame dimensions
			a_size_x,a_size_y = 32,30;
		else
			-- default anchor frame dimensions (vertical bar)
			a_size_x,a_size_y = 32,28;
		end
		
		-- mighty morphin' group anchors! lawl
		f:SetSize(a_size_x, a_size_y);
		_G[f_name.."_Background"]:SetSize(a_size_x, a_size_y);
		
		-----  POPULATE THE GROUP  ---------------------------------------------
		FI_ButtonFrames(group.id);
		------------------------------------------------------------------------

		-- apply quicksize
		FI_ButtonVis(group.id);

	else
		if FI_DEBUG then print("WARNING: Frame '"..f_name.."' already exists!"); end
	end
end

-- button, button, who's got the button...
function FI_ButtonFrames( gid )
	if FI_DEBUG then print("...loading buttons for Group ID: "..gid); end

	-- group frame is the first thing we anchor to
	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);
	local parent = _G["FI_Group_"..group.id];
	local last_frame = parent;

	for i,button in ipairs(FI_SVPC_DATA.Buttons) do
		-- group filter
		if (button.group == group.id) then
			-- define the frame name
			local f_name = "FI_Button_"..button.id;

			-- skip creation if frame exists (ie- adding buttons to an existing bar)
			if (_G[f_name] == nil) then
				local f = CreateFrame("Button", f_name, parent, "FI_TPL_Button");
				f:SetFrameStrata("LOW");
				f:Show(true);
				f:SetClampedToScreen(false);
				f:RegisterForClicks("LeftButtonUp","RightButtonUp");
				f:SetScript("OnMouseUp", FI_Click);
				-- secure template attributes
				f:SetAttribute("type2", "macro");
				f:SetAttribute("macro", false);
				
				-- no padding for first button so it sits against the anchor
				if (last_frame == parent) then pad = 0; else pad = group.pad; end
				
				-- determine orientation
				local a1,a2,x,y;
				if (group.grow == "U") then
					-- bar grows up
					a1,a2,x,y = "BOTTOM","TOP",0,pad;
				elseif (group.grow == "D") then
					-- bar grows down
					a1,a2,x,y = "TOP","BOTTOM",0,-pad;
				elseif (group.grow == "L") then
					-- bar grows left
					a1,a2,x,y = "RIGHT","LEFT",-pad,0;
				elseif (group.grow == "R") then
					-- bar grows right
					a1,a2,x,y = "LEFT","RIGHT",pad,0;
				end

				-- position the frame
				f:SetPoint(a1, last_frame, a2, x, y);

				--if FI_DEBUG then print("Button ID: "..button.id.." (Group ID: "..group.id..")"); end
			else
				if FI_DEBUG then print("Frame '"..f_name.."' already exists... skipping. (Group ID: "..group.id..")"); end
			end

			-- dynamic relative anchoringggggggggggg
			last_frame = f_name;
		end
	end
end

-- wrapper
function FI_Style( newstyle )
	if newstyle then
		-- validate input
		if FI_STYLES[newstyle] then
			-- update style data
			FI_SVPC_STYLE = table.copy(FI_STYLES[newstyle]);

			-- user feedback
			if (FI_LOADING == false) then
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  '"..newstyle.."' visual style applied.");
			end
		else
			-- error message
			local list = "";
			for key,val in pairs(FI_STYLES) do list = list.."  "..key; end
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Style '"..newstyle.."' not found. Available options are: "..list);
			return;
		end
	end

	-- apply visual theme to all bars
	for i,group in ipairs(FI_SVPC_DATA.Groups) do
		FI_GroupStyle(group.id);
	end
end

-- apply visual theme settings to a bar
function FI_GroupStyle( gid )
	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);

	-- [anchor] --------------------------------------------------
	local a = FI_SVPC_STYLE.anchor;
	local f_name = "FI_Group_"..group.id;

	-- background
	if (type(a.background.texture) == "table") then
		_G[f_name.."_Background"]:SetVertexColor(a.background.texture[1], a.background.texture[2], a.background.texture[3]);
	else
		_G[f_name.."_Background"]:SetTexture(a.background.texture);
	end
	
	_G[f_name.."_Background"]:SetAlpha(a.background.alpha);

	-- border

	-- label
	_G[f_name.."_Label"]:SetFont(a.text.font, a.text.size, a.text.flags);
	_G[f_name.."_Label"]:SetVertexColor(a.text.color[1], a.text.color[2], a.text.color[3]);
	_G[f_name.."_Label"]:SetAlpha(a.text.alpha);


	-- [button] --------------------------------------------------
	local b = FI_SVPC_STYLE.button;
	for i,bid in ipairs(FI_GroupMembers(group.id)) do
		local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
		f_name = "FI_Button_"..button.id;

		-- background
		if (type(b.background.texture) == "table") then
			_G[f_name.."_Background"]:SetVertexColor(b.background.texture[1], b.background.texture[2], b.background.texture[3]);
		else
			_G[f_name.."_Background"]:SetTexture(b.background.texture);
		end
		_G[f_name.."_Background"]:SetAlpha(b.background.alpha);

		-- border
		
		-- icon

		-- glow
		_G[f_name.."_Glow"]:SetTexture(b.glow.texture);
		_G[f_name.."_Glow"]:SetVertexColor(b.glow.color[1], b.glow.color[2], b.glow.color[3]);
		_G[f_name.."_Glow"]:SetAlpha(b.glow.alpha);

		-- numbers
		_G[f_name.."_Count"]:SetFont(b.number.font, b.number.size, b.number.flags);
		_G[f_name.."_Count"]:SetVertexColor(b.number.color[1], b.number.color[2], b.number.color[3]);
		_G[f_name.."_Count"]:SetAlpha(b.number.alpha);

		_G[f_name.."_Objective"]:SetFont(b.number.font, b.number.size, b.number.flags);
		_G[f_name.."_Objective"]:SetVertexColor(b.number.color[1], b.number.color[2], b.number.color[3]);
		_G[f_name.."_Objective"]:SetAlpha(b.number.alpha);

		-- [text]
	end
end

function FI_Template( action, arg, val, val2 )
	-- incase we have something to say... cause sometimes we do. (unless we dont, then we wont)
	local output = "";

	--------------------------------------------------
	--  SAVE
	--------------------------------------------------
	if (action == "save") then
		if arg then
			local bar = tonumber(arg);

			-- map bar number to group id
			local group = FI_SVPC_DATA.Groups[bar];
			
			if group then
				-- check template name
				if val then
					local name = tostring(val);

					-- build list of all items on the bar
					local items = {};
					for i,bid in ipairs(FI_GroupMembers(group.id)) do
						local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
						if button.item then
							table.insert(items, button.item);
						end
					end
					
					-- validate input
					if(string.len(name) > 2) then
						----->>  CREATE TEMPLATE  <<-----
						FI_SV_DATA.Templates[name] = table.copy(items);
						DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  All items on bar "..bar.." saved as farming template:  "..name);
					else
						-- error message
						DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Template names must be at least 3 characters, and have no spaces.");
					end
				else
					-- error message
					DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please provide a template name when saving an item bar:    /farmit template save 1 MyTemplate");
				end 
			else
				-- error message
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Invalid bar number.");
			end
		else
			-- error message
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please specify the bar number you wish to save. Also, be sure to include a template name:  /farmit template save 1 MyTemplate");
		end

	--------------------------------------------------
	--  LOAD
	--------------------------------------------------
	elseif (action == "load") then
		if arg then
			local bar = tonumber(arg);
			
			-- map bar number to group id
			local group = FI_SVPC_DATA.Groups[bar];
			
			if group then
				-- check input
				if val then
					local category,name,items;

					-- parse arguments
					if val2 then
						category = strupper(val);
						name = val2;
						items = FI_TPL[category][name];
					else
						category = "USER";
						name = val;
						items = FI_SV_DATA.Templates[name]
					end

					----->>  check template path  <<-----
					if items then
						----->>  check bar size  <<-----
						if (#items > #FI_GroupMembers(group.id)) then
							FI_Group("size", group.id, #items);
						end

						----->>  apply template to bar  <<-----
						local bids = FI_GroupMembers(group.id);
						FI_LOADING = true;
						for i,itemID in ipairs(items) do
							FI_SetButton(bids[i], itemID);
						end
						FI_LOADING = false;
						
						-- check visibility
						if (#items > group.size) then
							FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {size = #items});
							FI_ButtonVis(group.id);
						end

						-- done!
						DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Template '"..category.."\\"..name.."' loaded on bar "..bar..".");
					else
						-- error message
						DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Error finding template:  "..category.."\\"..name.."\n  To see a list of valid options, type:  /farmit tpl list");
					end
				else
					-- error message
					DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please specify a template to load.");
				end 
			else
				-- error message
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Invalid bar number.");
			end
		else
			-- error message
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please specify the bar number you wish to load a template on.");
		end

	--------------------------------------------------
	--  DELETE
	--------------------------------------------------
	elseif (action == "delete") then
		if arg then
			local name = tostring(arg);
			
			-- check path
			if FI_SV_DATA.Templates[name] then
				-- bye bye!
				FI_SV_DATA.Templates[name] = nil;
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  User template '"..name.."' deleted.");
			else
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Error finding user template:  "..name.."\n  To see a list of valid options, type:  /farmit tpl list");
			end
		else
			-- error message
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please specify the name of the template you wish to delete. To see a list of valid options, type:  /farmit tpl list");
		end
	
	--------------------------------------------------
	--  LIST
	--------------------------------------------------
	elseif (action == "list") then
		if arg then
			------------------------------------------
			-- show built-in templates
			------------------------------------------
			local cat = strupper(arg);

			-- validate input
			if FI_TPL[cat] then
				-- start building output
				output = "[FarmIt]  "..cat.." farming templates:\n";
				
				for name,items in pairs(FI_TPL[cat]) do
					output = output.." "..name;
				end
			else
				-- error message
				output = "[FarmIt]  Template category '"..cat.."' not found, valid options are:  WOW,TBC,WOTLK,CATA";
			end
		else
			------------------------------------------
			-- show user templates
			------------------------------------------
			output = "[FarmIt]  User created templates:\n";

			for name,items in pairs(FI_SV_DATA.Templates) do
				output = output.." "..name;
			end
		end
		
		DEFAULT_CHAT_FRAME:AddMessage( output );
	else
		-- error message
		DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Invalid template action. Valid options are:  save,load,delete,list");
	end
end
