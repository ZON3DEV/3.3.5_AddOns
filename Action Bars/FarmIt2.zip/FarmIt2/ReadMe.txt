﻿Title: FarmIt
Description: A customizable inventory tracker for World of Warcraft.
Author: CHiLLZ <chillz@gmail.com>
License: Copyright 2006-2011, Chillz Media. All rights reserved.
Website: http://wow.curse.com/downloads/wow-addons/details/farm-it.aspx

----------------------------------------------------------------------------------------------------
 Summary
----------------------------------------------------------------------------------------------------

FarmIt helps WoW players to actively monitor how much they have of ANY ITEM. This is especially helpful when farming for items that cannot be placed on the standard action bars. For example: I use FarmIt while farming elementals, so I know how many crystals I have without having to dig through my bags and count them every time I loot one.

This addon has been written to be as light and fast as possible. FarmIt employs optimized item count methods via effective use of the World of Warcraft API, this allows for many powerful and convenient features while remaining a small and simple addon. 

Please submit bugs and feature requests on CurseForge:  http://wow.curseforge.com/addons/farm-it/


----------------------------------------------------------------------------------------------------
 About FarmIt
----------------------------------------------------------------------------------------------------

FarmIt offers "set it and forget it" farming objectives. 
Current item count is displayed in the bottom-right corner of each slot, and your objective in the top-left corner. 
Optionally, you will be notified each time you loot an item that you are tracking. 

You can set a farming objective for each item slot. 
When you reach your farming objective for a given item, the goal amount turns green and you will receive an on-screen notification similar to WoW quest tracking. 
You can hide all the buttons in a group, leaving only the bar anchor showing- and your farming progress will still be tracked. 

FarmIt is able to include your current bank inventory at any time, without needing to visit the bank! 
Item search also includes the keyring. (Great for items like Etherium Prison Keys, Relic Coffer Keys, etc.) 

Bar orientation can be switched between vertical and horizontal modes. 
The direction the bar "grows" (up, down, left, right) can also be changed. 


----------------------------------------------------------------------------------------------------
 User Guide
----------------------------------------------------------------------------------------------------

Command line reference:  http://wow.curseforge.com/addons/farm-it/pages/commands/
For an in-game list of available commands, type: /farmit

Due to the nature of FarmIt's purpose, most settings are saved on a per-character basis since different character will have different professions, etc. 
Statistical data and item related information such as farming templates (saved sets of items) are shared between characters. 


[ Item Buttons ]

Place any item from your inventory into one of the bar slots to keep track of how many you have.

Click on an occupied slot to select its contents and move them to another button.
If the destination slot has an item in it already, the button contents will trade places.

Right-Click a slot to "use" the item. (For combining motes into primals, etc.)

Shift+Right-Click a slot to clear it.

Shift+Click the slot to have it include your bank inventory in the item count. (per slot)
You do *not* need to be at the bank for this to work! :)
Item counts turn yellow when 'include bank' is enabled.

Ctrl+Click a slot to set an item objective. This works similar to WoW quest tracking.
The item objective number will turn green when it has been reached, and (optionally) display notifications on-screen upon objective progress and success.


[ Bars ]

To move a bar, click and drag the anchor (small numbered tab) at the end of the bar.

Right-Click the anchor of an item bar to open the GUI configuration panel. NOTE: The config window is not finished in the v2.0 beta. There will be an all new GUI options panel included once FarmIt2 reaches a stable build.

Shift+Right-Click the bar anchor to go directly to the commands page of the configuration panel.

To grow/shrink the number of *visible* slots on a bar, click the 'quick size' buttons (-/+). To permanently add or remove buttons, see '/farmit size' on the Commands help page.


[ Templates ]

You can save all the items on a FarmIt bar as a "farming template" to easily use again later. 

Templates can be loaded onto any FarmIt bar. If there is a difference between the amount of items in the template, and the size of the bar- the bar will automatically adjust to accomodate the template. 

For details on how to save/load your own templates, please refer to the "Commands" page of FarmIt's in-game help.


----------------------------------------------------------------------------------------------------
 Credits
----------------------------------------------------------------------------------------------------

Designed and developed by CHiLLZ (aka: Somnifer). All RIGHTS RESERVED.

Many thanks to my testers-- Herababe/Angeleyez, Jessielynn, and Posidion.
FarmIt has evolved a lot over the years through great feedback from its users. Thanks everyone!  :)

