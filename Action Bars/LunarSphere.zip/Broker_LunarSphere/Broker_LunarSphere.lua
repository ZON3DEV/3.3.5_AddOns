local L = LibStub("AceLocale-3.0"):GetLocale("Broker_LunarSphere",true)

LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("Broker_LunarSphere", {
	type = "launcher",
	text = "Lunar Sphere",
	OnClick = function(_, msg)
		if msg == "LeftButton" then
			if Lunar.Settings.Frame:IsVisible() then
				Lunar.Settings.Frame:Hide()
			else
				Lunar.Settings.Frame:Show()
			end
		end
	end,
	icon = "Interface\\AddOns\\LunarSphere\\Art\\logo.blp",
	OnTooltipShow = function(tooltip)
		if not tooltip or not tooltip.AddLine then return end
		tooltip:AddLine("LunarSphere")
		tooltip:AddLine("|cffffff00" .. L["Click|r to toggle LunarSphere"])
	end,
})
