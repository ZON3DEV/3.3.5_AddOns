﻿if GetLocale() == "frFR" then

function psealocaleuldaboss()

pseaauriayaadd				= "Factionnaire du sanctum"
pseamimironadd				= "Robo-bombe"
pseahodiradds				={"Tor Nuage-gris",
					  "Kar Nuage-gris",
					  "Eivi Plumenuit",
					  "Ellie Plumenuit",
					  "Marcheuse des esprits Tara",
					  "Marcheuse des esprits Yona",
					  "Elémentaliste Mahfuun",
					  "Elémentaliste Avuun",
					  "Amira Tissebrasier",
					  "Veesha Tissebrasier",
					  "Missy Crispeflamme",
					  "Sissy Crispeflamme",
					  "Prêtresse de bataille Eliza",
					  "Prêtresse de bataille Gina",
					  "Infirmière militaire Penny",
					  "Infirmière militaire Jessi"}

end



end