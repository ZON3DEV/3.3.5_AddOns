﻿

function psealocaleuldaboss()

pseaauriayaadd				= "Sanctum Sentry"
pseamimironadd				= "Bomb Bot"
pseahodiradds				={"Tor Greycloud",
					  "Kar Greycloud",
					  "Eivi Nightfeather",
					  "Ellie Nightfeather",
					  "Spiritwalker Tara",
					  "Spiritwalker Yona",
					  "Elementalist Mahfuun",
					  "Elementalist Avuun",
					  "Amira Blazeweaver",
					  "Veesha Blazeweaver",
					  "Missy Flamecuffs",
					  "Sissy Flamecuffs",
					  "Battle-Priest Eliza",
					  "Battle-Priest Gina",
					  "Field Medic Penny",
					  "Field Medic Jessi"}

end



function psealocaleulduar()

pseaulduarkolf1				= "Add was killed!"
pseaulduarkolf2				= "will not be complete if you kill boss now!"
pseamimifailloc1			= "Bombot!"
pseamimifailloc2			= "Rocket strike!"
pseamimifailloc3			= "Mine!"
pseamimifailloc5			= "part is failed!"
pseatrebulda2				= "Kill last add and then kill boss!"

end



function psealocaleulduarui()

pseaulduartitle				= "    Ulduar"



end