﻿if GetLocale() == "deDE" then

function psealocaleuldaboss()

pseaauriayaadd				= "Sp\195\164her des Sanktums"
pseamimironadd				= "Bombenbot"
pseahodiradds				={"Tor Grauwolke",
					  "Kar Grauwolke",
					  "Eivi Nachtfeder",
					  "Ellie Nachtfeder",
					  "Geistwandlerin Tara",
					  "Geistwandlerin Yona",
					  "Elementarist Mahfuun",
					  "Elementarist Avuun",
					  "Amira Lohenweber",
					  "Veesha Lohenweber",
					  "Missy Flammenfessel",
					  "Sissy Flammenfessel",
					  "Schlachtpriesterin Eliza",
					  "Schlachtpriesterin Gina",
					  "Feldsanit\195\164terin Penny",
					  "Feldsanit\195\164terin Jessi",}

end



function psealocaleulduar()

pseaulduarkolf1				= "Mob ist vernichtet!"
pseaulduarkolf2				= "Es wird nicht erfuellt, wenn der Boss vernichtet wird!"
pseamimifailloc1			= "Bomb Bots!"
pseamimifailloc2			= "Rocket Strike!"
pseamimifailloc3			= "Proximity Mines!"
pseamimifailloc5			= "Teil ist durchgefallen!"
pseatrebulda2				= "Toetet den letzten Monster und danach den Boss!"

end



function psealocaleulduarui()

pseaulduartitle				= "    Ulduar"



end


end