﻿if GetLocale() == "koKR" then

function icralocaleboss()

icracouncilboss1			= "공작 발라나르"
icracouncilboss2			= "공작 탈다람"
icracouncilboss3			= "공작 켈레세스"
icravalitriayell1			= "에메랄드의 꿈으로 가는 차원문을 열어두었다. 너희의 구원은 그 안에 있다..."
icravalitriayell2			= "다시 힘을 얻었다! 이세라여, 더러운 생명들에 안식을 내릴 수 있도록 은혜를 베푸소서!"

end



end