﻿

function icralocaleboss()

icracouncilboss1			= "Prince Valanar"
icracouncilboss2			= "Prince Taldaram"
icracouncilboss3			= "Prince Keleseth"
icravalitriayell1			= "I have opened a portal into the Dream. Your salvation lies within, heroes..."
icravalitriayell2			= "I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"

end



function icralocale()


end



function icralocaleui()

icratitle				= "    Icecrown"
raiccof					= "of"
raiccused				= "used"



end