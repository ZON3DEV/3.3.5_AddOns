﻿if GetLocale() == "ruRU" then 

function icralocaleboss()

icracouncilboss1			= "Принц Валанар"
icracouncilboss2			= "Принц Талдарам"
icracouncilboss3			= "Принц Келесет"
icravalitriayell1			= "Я открыла портал в Изумрудный Сон. Там вы найдете спасение, герои..."
icravalitriayell2			= "Я ИЗЛЕЧИЛАСЬ! Изера, даруй мне силу покончить с этими нечестивыми тварями."

end



function icralocale()


end



function icralocaleui()

icratitle				= "    Цитадель Ледяной Короны"
raiccof					= "из"
raiccused				= "использовано"



end




end