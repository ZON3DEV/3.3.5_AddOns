﻿if GetLocale() == "esES" then

function icralocaleboss()

icracouncilboss1			= "Príncipe Valanar"
icracouncilboss2			= "Príncipe Taldaram"
icracouncilboss3			= "Príncipe Keleseth"
icravalitriayell1			= "He abierto un portal al Sueño. Vuestra salvación está dentro, héroes..."
icravalitriayell2			= "¡ESTOY RENOVADA! Ysera haz que estas asquerosas criaturas descansen"

end



end