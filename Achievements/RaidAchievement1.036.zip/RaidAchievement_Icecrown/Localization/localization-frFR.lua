﻿if GetLocale() == "frFR" then

function icralocaleboss()

icracouncilboss1			= "Prince Valanar"
icracouncilboss2			= "Prince Taldaram"
icracouncilboss3			= "Prince Keleseth"
icravalitriayell1			= "Vous y trouverez votre salut"
icravalitriayell2			= "JE REVIS"

end



end