﻿if GetLocale() == "koKR" then

function nxralocaleboss()

nxraloatheb				= "로데브"
nxraspore				= "포자"
nxraanubrekan				= "아눕레칸"
nxrameksna				= "맥스나"
nxrafaerlin				= "귀부인 팰리나"
nxrakeladd				= "무시무시한 누더기골렘"
nxraonyxiab				= "오닉시아"
nxraonyemote				= "takes in a deep breath"

end



end