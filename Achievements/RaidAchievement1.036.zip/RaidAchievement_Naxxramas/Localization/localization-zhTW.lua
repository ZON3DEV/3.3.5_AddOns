﻿if GetLocale() == "zhTW" then

function nxralocaleboss()

nxraloatheb				= "憎恨者"
nxraspore				= "孢子"
nxraanubrekan				= "阿努比瑞克漢"
nxrameksna				= "怪物查詢"
nxrafaerlin				= "大寡婦費琳娜"
nxrakeladd				= "無法阻止的憎惡體"
nxraonyxiab				= "奧妮克希亞"
nxraonyemote				= "takes in a deep breath"

end

function nxralocaleui()

nxratitle				= "    納克薩瑪斯 + 其他巫妖王團隊"



end

end