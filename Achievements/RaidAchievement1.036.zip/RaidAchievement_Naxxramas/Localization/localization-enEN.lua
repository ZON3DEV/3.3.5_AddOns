﻿

function nxralocaleboss()

nxraloatheb				= "Loatheb"
nxraspore				= "Spore"
nxraanubrekan				= "Anub'Rekhan"
nxrameksna				= "Maexxna"
nxrafaerlin				= "Grand Widow Faerlina"
nxrakeladd				= "Unstoppable Abomination"
nxraonyxiab				= "Onyxia"
nxraonyemote				= "takes in a deep breath"

end



function nxralocale()


end



function nxralocaleui()

nxratitle				= "    Naxxramas + other mini WotLK raids"



end