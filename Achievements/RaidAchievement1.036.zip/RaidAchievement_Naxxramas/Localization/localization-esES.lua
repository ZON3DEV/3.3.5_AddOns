﻿if GetLocale() == "esES" then

function nxralocaleboss()

nxraloatheb				= "Loatheb"
nxraspore				= "Espora"
nxraanubrekan				= "Anub'Rekhan"
nxrameksna				= "Maexxna"
nxrafaerlin				= "Gran Viuda Faerlina"
nxrakeladd				= "Abominación imparable"
nxraonyxiab				= "Onyxia"
nxraonyemote				= "takes in a deep breath"

end



end