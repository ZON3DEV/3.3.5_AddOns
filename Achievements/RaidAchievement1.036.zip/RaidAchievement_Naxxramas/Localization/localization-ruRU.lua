﻿if GetLocale() == "ruRU" then 

function nxralocaleboss()

nxraloatheb				= "Лотхиб"
nxraspore				= "Спора"
nxraanubrekan				= "Ануб'Рекан"
nxrameksna				= "Мексна"
nxrafaerlin				= "Великая вдова Фарлина"
nxrakeladd				= "Неудержимое поганище"
nxraonyxiab				= "Ониксия"
nxraonyemote				= "делает глубокий вдох"


end



function nxralocale()



end



function nxralocaleui()

nxratitle				= "    Наксрамас + остальные мини рейды WotLK"



end




end