﻿if GetLocale() == "frFR" then

function nxralocaleboss()

nxraloatheb				= "Horreb"
nxraspore				= "Spore"
nxraanubrekan				= "Anub'Rekhan"
nxrameksna				= "Maexxna"
nxrafaerlin				= "Grande veuve Faerlina"
nxrakeladd				= "Abomination irrésistible"
nxraonyxiab				= "Onyxia"
nxraonyemote				= "takes in a deep breath"

end



end