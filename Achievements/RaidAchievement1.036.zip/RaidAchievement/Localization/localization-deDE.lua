﻿if GetLocale() == "deDE" then

function psealocalezone()
pseaheroicslist				= "Ahn'kahet: Das Alte K\195\182nigreich,Feste Drak'Tharon,Gundrak,Die Hallen der Blitze,Die Hallen des Steins,Der Nexus,Turm Utgarde,Die Violette Festung,Pr\195\188fung des Champions,Die Seelenschmiede,Grube von Saron,Hallen der Reflexion"
pseaheroicslist2			= "Azjol-Nerub"
pseazoneulduar				= "Ulduar"
pseazonenax				= "Naxxramas"
pseazonesart				= "Das Obsidiansanktum"
pseazoneonya				= "Onyxias Hort"
pseazoneic				= "Eiskronenzitadelle"

end


function psealocale()


pseachatlist1				= "raid"
pseachatlist2				= "raid warnung"
pseachatlist3				= "offizier"
pseachatlist4				= "gruppe"
pseachatlist5				= "gilde"
pseachatlist6				= "sagen"
pseachatlist7				= "schreien"
pseachatlist8				= "an sich selbst"
pseaaddonmy				= "AddOn"
pseaaddonon2				= "AN"
pseaaddonoff				= "AUS"
pseamoduleload				= "Geladene Module"
pseamodulenotload			= "Fehler beim Laden der Module"
pseaaddonon				= "Addon aktivieren"
pseaaddonok				= "Okay"
pseatreb2				= "Anforderungen erf\195\188llt! Jetzt vernichtet den Boss!"
pseatreb4				= "Durchgefallen!"
ranewversfound				= "|cff00ff00Warnung!|r In Ihrem Schlachtzug wurde eine ne\195\188re Version des AddOns |cff00ff00'RaidAchievement'|r gefunden. Es wird empfohlen das AddOn von curse.com oder wowinterface.com zu aktualisieren."


end



function psealocaleui()

psealeftmenu1				= "AddOn"
psealeftmenu3				= "Naxxramas"
psealeftmenu31				= "Naxxramas + andere Minischlachtz\195\188ge WotLk"
psealeftmenu4				= "Wotlk Instanzen"
psealeftmenu5				= "Ulduar"
psealeftmenu6				= "Eiskronenzitadelle"
pseareports				= "- Berichtkanal"
PSFeaserver				= "ru-Gordunni"
pseauinomodule1				= "    Fehler! Modul ist nicht installiert!"
pseauinomodule2				= "Fehler! Ausgewaehltes Modul ist nicht installiert!"
pseauierror				= "    Fehler!"
pseauierroraddonoff			= "Fehler! Addon ist deaktiviert - dieses Modul ist nicht geladen!"
pseapsaddonanet				= "Fehler! Das Addon 'PhoenixStyle' ist nicht installiert."
pseapsaddonanet2			= "Sie koennen es auf curse.com oder wowinterface.com runterladen."
pseaenableall				= "Alles aktivieren"
pseadisableall				= "Alles deaktivieren"
pseachangeall				= "Umschalten"
pseawebsite				= " "
pseashownames				= "Anzeigen den Spielernamen, wer zu dem Misserfolg beigetragen hat"
pseashowveren				= "Berichten, wenn eine akt\195\188llere Version in Party/Schlachtzug gefunden wurde"
psealeftmenu11				= "Track after fail"
pseamanyachtitle			= "    Weitere Verfolgung der Erfolgsvoraussetzungen nach dem  Fehlschlag"
ramanyachtitinfo			= "Wenn Erfolg fehlgeschlagen ist, wird seine Verfolgung deaktiviert. Dieses Modul setzt diese Deaktivierung zur\195\188ck. Die Zur\195\188cksetzung erfolgt in "
ramanyachtitinfo2			= "nachdem Fehlschlagbericht. Gebt die Zahl der Zur\195\188cksetzungen ein, um zu sehen wie oft in dem Kampf der Erfolg fehlgeschlagen ist. Dieses Modul wird nach dem Ausloggen ausgeschaltet."
psbuttonon				= "Start"
psbuttonoff				= "Stop"
psmoduletxton				= "Modul ist aktiviert"
psmoduletxtoff				= "Modul ist deaktiviert"
pssec					= "sek."
ramanyachtitinfoq			= "Zur\195\188cksetzung erfolgt "
ramanyachtitinfoq2			= "Mal in dem Kampf. \195\164ndern:"
ramodulnotblock				= "die \195\156berpr\195\188fung wird nicht geblockt"
psoldvertxt				= "(veraltet)"


end





end