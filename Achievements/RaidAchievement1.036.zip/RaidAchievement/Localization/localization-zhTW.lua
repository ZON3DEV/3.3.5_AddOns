﻿if GetLocale() == "zhTW" then

function psealocalezone()
pseaheroicslist				= "安卡罕特:古王國,德拉克薩隆要塞,剛德拉克,雷光大廳,石之大廳,奧核之心,俄特加德之巔,紫羅蘭堡,勇士試煉,眾魂熔爐,薩倫之淵,倒影大廳"
pseaheroicslist2			= "阿茲歐-奈幽"
pseazoneulduar				= "奧杜亞"
pseazonenax				= "納克薩瑪斯"
pseazonesart				= "黑曜聖所"
pseazoneonya				= "奧妮克希亞的巢穴"
pseazoneic				= "冰冠城塞"

end


function psealocale()


pseachatlist1				= "團隊"
pseachatlist2				= "團隊警告"
pseachatlist3				= "幹部"
pseachatlist4				= "小隊"
pseachatlist5				= "公會"
pseachatlist6				= "說"
pseachatlist7				= "大喊"
pseachatlist8				= "使用者"
pseaaddonmy				= "插件"
pseaaddonon2				= "開啟"
pseaaddonoff				= "關閉"
pseamoduleload				= "載入模組:"
pseamodulenotload			= "載入模組時發生錯誤:"
pseaaddonon				= "啟用插件"
pseaaddonok				= "確定"
pseatreb2				= "完成成就需求! 現在將首領擊殺!"
pseatreb4				= "失敗!"
ranewversfound				= "|cff00ff00注意!|r 在小隊或公會中找到 |cff00ff00'RaidAchievement'|r 插件的新版本, 建議從 curse.com 或 wowinterface.com 取得更新"


end



function psealocaleui()

psealeftmenu1				= "插件"
psealeftmenu3				= "納克薩瑪斯"
psealeftmenu31				= "納克薩瑪斯 + 其他巫妖王團隊"
psealeftmenu4				= "巫妖王之怒英雄"
psealeftmenu5				= "奧杜亞"
psealeftmenu6				= "冰冠城塞"
pseareports				= "- 在此頻道中公布警告"
PSFeaserver				= "ru-Azuregos"
pseauinomodule1				= "    錯誤! 未安裝模組!"
pseauinomodule2				= "錯誤! 未安裝該模組!"
pseauierror				= "    錯誤!"
pseauierroraddonoff			= "錯誤! 插件已關閉 - this module is not loaded!"
pseapsaddonanet				= "錯誤! 未安裝PhoenixStyle插件"
pseapsaddonanet2			= "你可以在 curse.com 或 wowinterface.com 下載此插件"
pseaenableall				= "全部關閉"
pseadisableall				= "全部開啟"
pseachangeall				= "反向選擇"
pseawebsite				= " "
pseashownames				= "顯示成就失敗的原因(名字或其他)"
pseashowveren				= "顯示更新通知"
psealeftmenu11				= "失敗後追蹤"
pseamanyachtitle			= "     失敗後繼續追蹤成就"
ramanyachtitinfo			= "當成就失敗時，當前的戰鬥中將會停止繼續追蹤。這個模組重啟這個功能，在'失敗訊息'出現後的 "
ramanyachtitinfo2			= "後繼續追蹤。下面可設定戰鬥中你想重啟幾次追蹤，並按下'開始'模組。這個模組會在登出後自動關閉。"
psbuttonon				= "開始"
psbuttonoff				= "停止"
psmoduletxton				= "模組開啟"
psmoduletxtoff				= "模組關閉"
pssec					= "秒."
ramanyachtitinfoq			= "戰鬥中將會重啟 "
ramanyachtitinfoq2			= "次追蹤。下面可修改次數："
ramodulnotblock				= "追蹤將不會停止"
psoldvertxt				= "(舊版本)"


end


end