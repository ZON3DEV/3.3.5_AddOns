﻿if GetLocale() == "esES" then

function whralocaleboss()

whraanka1				= "Guardián Ahn'kahar"
whraanka2				= "Voluntario Crepuscular"
whradeathkn				= "El Caballero Negro"
whrabrann				= "Brann Barbabronce"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "Centinela del vacío"
whradred				= "Rey Dred"
whralit					= "Sjonnir el Afilador"
whradredadd1				= "Segador Drakkari"
whradredadd2				= "Arrancatripas Drakkari"
whralitadd				= "Lodoferro"
whranexadd1				= "Falla caótica"
whrabronjaadd				= "Trozo de alma corrupto"
whrabronjahm				= "Bronjahm"


end



end