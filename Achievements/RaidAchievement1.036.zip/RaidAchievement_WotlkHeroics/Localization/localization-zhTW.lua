﻿if GetLocale() == "zhTW" then

function whralocaleboss()

whraanka1				= "安卡哈守護者"
whraanka2				= "暮光志願者"
whradeathkn				= "黑騎士"
whrabrann				= "布萊恩·銅鬚"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "虛無哨衛"
whradred				= "崔德王"
whralit					= "『塑鐵者』斯雍尼爾"
whradredadd1				= "德拉克瑞鐮爪龍"
whradredadd2				= "德拉克瑞撕腸者"
whralitadd				= "鐵淤泥怪"
whranexadd1				= "混沌裂隙"
whrabronjaadd				= "腐化的殘缺之魂"
whrabronjahm				= "布朗吉姆"


end


function whralocale()

whraaddkilled1				= "小怪已被擊殺!"
whraaddkilled2				= "成就將因首領被擊殺而無法達成!"

end


end