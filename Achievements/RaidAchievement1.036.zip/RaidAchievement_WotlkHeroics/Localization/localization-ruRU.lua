﻿if GetLocale() == "ruRU" then 

function whralocaleboss()

whraanka1				= "Ан'кахарский страж"
whraanka2				= "Доброволец культа Сумеречного Молота"
whradeathkn				= "Черный рыцарь"
whrabrann				= "Бранн Бронзобород"
whrabrannemo				= "значит, играем по"
whrabrannemo2				= "меры предосторожности деактивированы"
whragundemo				= "Я вытащу ваши кишки, твари"
whravioletadd				= "Караульный Бездны"
whradred				= "Король Дред"
whralit					= "Сьоннир Литейщик"
whradredadd1				= "Смертехват Драккари"
whradredadd2				= "Потрошитель Драккари"
whralitadd				= "Железный слякоч"
whranexadd1				= "Хаотический разлом"
whrabronjaadd				= "Оскверненная часть души"
whrabronjahm				= "Броньям"


end



function whralocale()

whraaddkilled1				= "Адд убит!"
whraaddkilled2				= "не будет выполнено, если убьете босса!"

end



function whralocaleui()

whratitle				= "    Wotlk Подземелья"



end




end