local core = LibStub("AceAddon-3.0"):GetAddon("SilverDragon")
local module = core:NewModule("Config", "AceConsole-3.0")

local db

local function toggle(name, desc, order)
	return {type = "toggle", name = name, desc = desc, order=order,}
end

local options = {
	type = "group",
	name = "SilverDragon",
	get = function(info) return db[info[#info]] end,
	set = function(info, v) db[info[#info]] = v end,
	args = {
		general = {
			type = "group",
			name = "Основные",
			order = 10,
			args = {
				scan = {
					type = "range",
					name = "Чистота сканирования",
					desc = "Как часто сканировать ближайших редких мобов(0 выключить сканирование)",
					min = 0, max = 10, step = 0.1,
					order = 10,
				},
				delay = {
					type = "range",
					name = "Отсрочка записи",
					desc = "Как долго ждать перед тем как записовать того же редкого моба снова",
					min = 30, max = (60 * 60), step = 10,
					order = 20,
				},
				methods = {
					type = "group",
					name = "Метод сканирования",
					desc = "Который используется для сканирования.",
					order = 30,
					inline = true,
					args = {
						about = {
							type = "description",
							name = "Выбирите нужный который будет использоватся в поиске новых редких мобов. Если вы их всех выключите, этот аддон станет бесполезным...",
							order = 0,
						},
						mouseover = toggle("Мышкой", "Проверяет мобов на которых вы наводите указатель.", 10),
						targets = toggle("Цели", "Проверяет цели людей в вашей группе.", 20),
						nameplates = toggle("Панельки имен", "Проверяет панельки имен мобов когда вы подходите близко к ним", 30),
						cache = toggle("Кэш", "Сканировать кэш моба для прежде не найденых мобов.", 40),
					},
				},
				cache_tameable = {
					type = "toggle",
					name = "Пред. Кэша: Упрощение",
					desc = "У кеш-метода нет способа сказать что моб, это питомец игрока-охотника. Поэтому, что бы убрать спам, вам нужно отключить оповещения о мобах наденых этим способом.",
					order = 40,
				},
				instances = {
					type = "toggle",
					name = "Сканирование в подземельях",
					desc = "Не так много настоящих редких мобов в подземельях, и сканирование может замедлить производительность игры.",
					order = 50,
				},
				clear = {
					type = "execute",
					name = "Очистить все",
					desc = "Забывает всех видимых элиток.",
					order = 60,
					func = function() core:DeleteAllMobs() end,
				},
			},
		},
		import = {
			type = "group",
			name = "Добавить данные",
			hidden = function()
				return not ( core:GetModule("Data", true) or select(5, GetAddOnInfo("SilverDragon_Data")) )
			end,
			order = 10,
			args = {
				desc = {
					order = 0,
					type = "description",
					name = "SilverDragon идет с уже включенной базой данных известных местоположений мобов. Кликните на кнопку ниже что бы добавить эти данные.",
				},
				load = {
					order = 10,
					type = "execute",
					name = "Import Data",
					func = function()
						LoadAddOn("SilverDragon_Data")
						local Data = core:GetModule("Data", true)
						if not Data then
							module:Print("База данных не найдена. Отменить добавление.") -- safety check, just in case.
							return
						end
						local count = Data:Import()
						core.events:Fire("Import")
						module:Print(("Добавлено %d редких мобов."):format(count))
					end,
				},
			},
		},
	},
	plugins = {
	},
}
module.options = options

function module:OnInitialize()
	db = core.db.profile

	options.plugins["profiles"] = {
		profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(core.db)
	}

	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("SilverDragon", options)
	LibStub("AceConfigDialog-3.0"):AddToBlizOptions("SilverDragon", "SilverDragon")
	self:RegisterChatCommand("silverdragon", function() LibStub("AceConfigDialog-3.0"):Open("SilverDragon") end)
end

function module:ShowConfig()
	LibStub("AceConfigDialog-3.0"):Open("SilverDragon")
end
