﻿-- Local stuff

if (GetLocale() == "deDE") then
	XPERL_MONITOR_INNERVATE		= "Anregen"
	XPERL_MONITOR_MANATIDE		= "Totem der Manaflut"
end
