﻿local L =  LibStub:GetLibrary("AceLocale-3.0"):NewLocale("Grid2Options", "ruRU")
if not L then return end

L["raid-debuffs"] = "Дебаффы-рейда"
