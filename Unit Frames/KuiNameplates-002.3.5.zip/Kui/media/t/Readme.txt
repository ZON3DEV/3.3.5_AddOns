
	The following files are custom made for Kui
	by Kesava at wowinterface.com, or on Auchindoun-EU.
	
	I don't mind if you re-use them, but I'd appreciate it if you could
	give credit to me.
	
	bar.tga
	barSmall.tga
	
	-------------------------------------------------------------------
	I don't mind if you don't credit me for the following files:
	
	solid.tga
	innerShade.tga
	shadowBorder.tga
	solidRoundedBorder.tga 
	
	simpleSquare.tga
	-	This is a modified version of cyCircled_SimpleSquare by ScythXIII. It
		is darker, and now usable as an edgeFile in SetBackdrop.