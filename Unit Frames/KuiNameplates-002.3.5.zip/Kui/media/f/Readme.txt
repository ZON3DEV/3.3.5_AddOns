
	The following files are released under licenses which allow
	redistribution for at least non-commercial purposes.
	
	yanone.ttf, or Yanone Kaffeesatz Bold
	By Yanone, downloaded from http://www.yanone.de/
	
	accid.ttf, or Accidental Presidency
	By Tepid Monkey, downloaded from http://www.tepidmonkey.net/

	-------------------------------------------------------------------
	These are the only font files included in the download for Kui.