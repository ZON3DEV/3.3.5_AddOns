--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: colors.lua
	Description: oUF Colors Module
	Version....: 1.0
	Rev Date...: 10/10/2010
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local module = LUI:NewModule("oUF_Colors")

local defaults = {
	Colors = {
		Class = {
			Warrior = {
				r = "1",
				g = "0.78",
				b = "0.55",
			},
			Priest = {
				r = "0.9",
				g = "0.9",
				b = "0.9",
			},
			Druid = {
				r = "1",
				g = "0.44",
				b = "0.15",
			},
			Hunter = {
				r = "0.22",
				g = "0.91",
				b = "0.18",
			},
			Mage = {
				r = "0.12",
				g = "0.58",
				b = "0.89",
			},
			Paladin = {
				r = "0.96",
				g = "0.21",
				b = "0.73",
			},
			Shaman = {
				r = "0.04",
				g = "0.39",
				b = "0.98",
			},
			Warlock = {
				r = "0.57",
				g = "0.22",
				b = "1",
			},
			Rogue = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
			DeathKnight = {
				r = "0.8",
				g = "0.1",
				b = "0.1",
			},
		},
		Power = {
			Mana = {
				r = "0.31",
				g = "0.45",
				b = "0.63",
			},
			Rage = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Focus = {
				r = "0.71",
				g = "0.43",
				b = "0.27",
			},
			Energy = {
				r = "0.65",
				g = "0.63",
				b = "0.35",
			},
			Runes = {
				r = "0.55",
				g = "0.57",
				b = "0.61",
			},
			RunicPower = {
				r = "0",
				g = "0.82",
				b = "1",
			},
			AmmoSlot = {
				r = "0.8",
				g = "0.6",
				b = "0",
			},
			Fuel = {
				r = "0",
				g = "0.55",
				b = "0.5",
			},
		},
		Holypowerbar = {
			Holy1 = {
				r = "0.90",
				g = "0.88",
				b = "0.06",
			},
			Holy2 = {
				r = "0.90",
				g = "0.88",
				b = "0.06",
			},
			Holy3 = {
				r = "0.90",
				g = "0.88",
				b = "0.06",
			},
		},
		Soulshardbar = {
			Shard1 = {
				r = "0.93",
				g = "0.93",
				b = "0.93",
			},
			Shard2 = {
				r = "0.93",
				g = "0.93",
				b = "0.93",
			},
			Shard3 = {
				r = "0.93",
				g = "0.93",
				b = "0.93",
			},
		},
		Eclipsebar = {
			Lunar = {
				r = "0.3",
				g = "0.52",
				b = "0.9",
			},
			Solar = {
				r = "0.8",
				g = "0.82",
				b = "0.6",
			},
			LunarBG = {
				r = "0.15",
				g = "0.26",
				b = "0.45",
			},
			SolarBG = {
				r = "0.36",
				g = "0.36",
				b = "0.27",
			},
		},
		Runes = {
			Rune1 = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Rune2 = {
				r = "0.33",
				g = "0.59",
				b = "0.33",
			},
			Rune3 = {
				r = "0.31",
				g = "0.45",
				b = "0.63",
			},
			Rune4 = {
				r = "0.84",
				g = "0.75",
				b = "0.65",
			},
		},
		Happiness = {
			Happiness1 = {
				r = "0.8",
				g = "0.05",
				b = "0.05",
			},
			Happiness2 = {
				r = "0.85",
				g = "0.80",
				b = "0.30",
			},
			Happiness3 = {
				r = "0.05",
				g = "0.95",
				b = "0.05",
			},
		},
		Tapped = {
			r = "0.55",
			g = "0.57",
			b = "0.61",
		},
		Smooth = {
			Smooth1 = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Smooth2 = {
				r = "0.69",
				g = "0.69",
				b = "0.31",
			},
			Smooth3 = {
				r = "0.31",
				g = "0.69",
				b = "0.31",
			},
		},
		Runebar = {
			Rune1 = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Rune2 = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Rune3 = {
				r = "0.33",
				g = "0.59",
				b = "0.33",
			},
			Rune4 = {
				r = "0.33",
				g = "0.59",
				b = "0.33",
			},
			Rune5 = {
				r = "0.31",
				g = "0.45",
				b = "0.63",
			},
			Rune6 = {
				r = "0.31",
				g = "0.45",
				b = "0.63",
			},
		},
		ComboPoints = {
			Combo1 = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
			Combo2 = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
			Combo3 = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
			Combo4 = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
			Combo5 = {
				r = "0.95",
				g = "0.86",
				b = "0.16",
			},
		},
		Diff = {
			Diff1 = {
				r = "0.69",
				g = "0.31",
				b = "0.31",
			},
			Diff2 = {
				r = "0.71",
				g = "0.43",
				b = "0.27",
			},
			Diff3 = {
				r = "0.84",
				g = "0.75",
				b = "0.65",
			},
			Diff4 = {
				r = "0.33",
				g = "0.59",
				b = "0.33",
			},
			Diff5 = {
				r = "0.55",
				g = "0.57",
				b = "0.61",
			},
		},
		Totems = {
			Fire = {
				r = "0.752",
				g = "0.172",
				b = "0.02",
			},
			Earth = {
				r = "0.741",
				g = "0.580",
				b = "0.04",
			},
			Water = {
				r = "0",
				g = "0.443",
				b = "0.631",
			},
			Air = {
				r = "0.6",
				g = "1.0",
				b = "0.945",
			},
		},
	},
}

function module:LoadOptions()
	local options = {
		Colors = {
			name = "Colors",
			type = "group",
			childGroups = "tab",
			disabled = function() return not db.oUF.Settings.Enable end,
			order = 3,
			args = {
				ClassColors = {
					name = "Class",
					type = "group",
					order = 1,
					args = {
						header1 = {
							name = "Class Colors",
							type = "header",
							order = 1,
						},
						Warrior = {
							name = "Warrior",
							desc = "Choose an individual Color for Warriors.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Warrior.r, db.oUF.Colors.Class.Warrior.g, db.oUF.Colors.Class.Warrior.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Warrior.r = r
									db.oUF.Colors.Class.Warrior.g = g
									db.oUF.Colors.Class.Warrior.b = b
								end,
							order = 2,
						},
						Priest = {
							name = "Priest",
							desc = "Choose an individual Color for Priests.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Priest.r, db.oUF.Colors.Class.Priest.g, db.oUF.Colors.Class.Priest.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Priest.r = r
									db.oUF.Colors.Class.Priest.g = g
									db.oUF.Colors.Class.Priest.b = b
								end,
							order = 3,
						},
						Druid = {
							name = "Druid",
							desc = "Choose an individual Color for Druids.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Druid.r, db.oUF.Colors.Class.Druid.g, db.oUF.Colors.Class.Druid.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Druid.r = r
									db.oUF.Colors.Class.Druid.g = g
									db.oUF.Colors.Class.Druid.b = b
								end,
							order = 4,
						},
						Hunter = {
							name = "Hunter",
							desc = "Choose an individual Color for Hunters.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Hunter.r, db.oUF.Colors.Class.Hunter.g, db.oUF.Colors.Class.Hunter.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Hunter.r = r
									db.oUF.Colors.Class.Hunter.g = g
									db.oUF.Colors.Class.Hunter.b = b
								end,
							order = 5,
						},
						Mage = {
							name = "Mage",
							desc = "Choose an individual Color for Mages.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Mage.r, db.oUF.Colors.Class.Mage.g, db.oUF.Colors.Class.Mage.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Mage.r = r
									db.oUF.Colors.Class.Mage.g = g
									db.oUF.Colors.Class.Mage.b = b
								end,
							order = 6,
						},
						Paladin = {
							name = "Paladin",
							desc = "Choose an individual Color for Paladins.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Paladin.r, db.oUF.Colors.Class.Paladin.g, db.oUF.Colors.Class.Paladin.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Paladin.r = r
									db.oUF.Colors.Class.Paladin.g = g
									db.oUF.Colors.Class.Paladin.b = b
								end,
							order = 7,
						},
						Shaman = {
							name = "Shaman",
							desc = "Choose an individual Color for Shamans.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Shaman.r, db.oUF.Colors.Class.Shaman.g, db.oUF.Colors.Class.Shaman.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Shaman.r = r
									db.oUF.Colors.Class.Shaman.g = g
									db.oUF.Colors.Class.Shaman.b = b
								end,
							order = 8,
						},
						Warlock = {
							name = "Warlock",
							desc = "Choose an individual Color for Warlocks.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Warlock.r, db.oUF.Colors.Class.Warlock.g, db.oUF.Colors.Class.Warlock.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Warlock.r = r
									db.oUF.Colors.Class.Warlock.g = g
									db.oUF.Colors.Class.Warlock.b = b
								end,
							order = 9,
						},
						Rogue = {
							name = "Rogue",
							desc = "Choose an individual Color for Rogues.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.Rogue.r, db.oUF.Colors.Class.Rogue.g, db.oUF.Colors.Class.Rogue.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.Rogue.r = r
									db.oUF.Colors.Class.Rogue.g = g
									db.oUF.Colors.Class.Rogue.b = b
								end,
							order = 10,
						},
						DeathKnight = {
							name = "Death Knight",
							desc = "Choose an individual Color for Death Knights.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Class.DeathKnight.r, db.oUF.Colors.Class.DeathKnight.g, db.oUF.Colors.Class.DeathKnight.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Class.DeathKnight.r = r
									db.oUF.Colors.Class.DeathKnight.g = g
									db.oUF.Colors.Class.DeathKnight.b = b
								end,
							order = 11,
						},
						empty = {
							name = "   ",
							type = "description",
							order = 12,
							width = "full",
						},
						Reset = {
							order = 13,
							type = "execute",
							name = "Restore Defaults",
							func = function()
								db.oUF.Colors.Class.Warrior.r = defaults.profile.oUF.Colors.Class.Warrior.r
								db.oUF.Colors.Class.Warrior.g = defaults.profile.oUF.Colors.Class.Warrior.g
								db.oUF.Colors.Class.Warrior.b = defaults.profile.oUF.Colors.Class.Warrior.b
								
								db.oUF.Colors.Class.Priest.r = defaults.profile.oUF.Colors.Class.Priest.r
								db.oUF.Colors.Class.Priest.g = defaults.profile.oUF.Colors.Class.Priest.g
								db.oUF.Colors.Class.Priest.b = defaults.profile.oUF.Colors.Class.Priest.b
								
								db.oUF.Colors.Class.Druid.r = defaults.profile.oUF.Colors.Class.Druid.r
								db.oUF.Colors.Class.Druid.g = defaults.profile.oUF.Colors.Class.Druid.g
								db.oUF.Colors.Class.Druid.b = defaults.profile.oUF.Colors.Class.Druid.b
								
								db.oUF.Colors.Class.Hunter.r = defaults.profile.oUF.Colors.Class.Hunter.r
								db.oUF.Colors.Class.Hunter.g = defaults.profile.oUF.Colors.Class.Hunter.g
								db.oUF.Colors.Class.Hunter.b = defaults.profile.oUF.Colors.Class.Hunter.b
								
								db.oUF.Colors.Class.Mage.r = defaults.profile.oUF.Colors.Class.Mage.r
								db.oUF.Colors.Class.Mage.g = defaults.profile.oUF.Colors.Class.Mage.g
								db.oUF.Colors.Class.Mage.b = defaults.profile.oUF.Colors.Class.Mage.b
								
								db.oUF.Colors.Class.Paladin.r = defaults.profile.oUF.Colors.Class.Paladin.r
								db.oUF.Colors.Class.Paladin.g = defaults.profile.oUF.Colors.Class.Paladin.g
								db.oUF.Colors.Class.Paladin.b = defaults.profile.oUF.Colors.Class.Paladin.b
								
								db.oUF.Colors.Class.Shaman.r = defaults.profile.oUF.Colors.Class.Shaman.r
								db.oUF.Colors.Class.Shaman.g = defaults.profile.oUF.Colors.Class.Shaman.g
								db.oUF.Colors.Class.Shaman.b = defaults.profile.oUF.Colors.Class.Shaman.b
								
								db.oUF.Colors.Class.Warlock.r = defaults.profile.oUF.Colors.Class.Warlock.r
								db.oUF.Colors.Class.Warlock.g = defaults.profile.oUF.Colors.Class.Warlock.g
								db.oUF.Colors.Class.Warlock.b = defaults.profile.oUF.Colors.Class.Warlock.b
								
								db.oUF.Colors.Class.Rogue.r = defaults.profile.oUF.Colors.Class.Rogue.r
								db.oUF.Colors.Class.Rogue.g = defaults.profile.oUF.Colors.Class.Rogue.g
								db.oUF.Colors.Class.Rogue.b = defaults.profile.oUF.Colors.Class.Rogue.b
								
								db.oUF.Colors.Class.DeathKnight.r = defaults.profile.oUF.Colors.Class.DeathKnight.r
								db.oUF.Colors.Class.DeathKnight.g = defaults.profile.oUF.Colors.Class.DeathKnight.g
								db.oUF.Colors.Class.DeathKnight.b = defaults.profile.oUF.Colors.Class.DeathKnight.b
								
								StaticPopup_Show("RELOAD_UI")
							end,
						},
					},
				},
				PowerType = {
					name = "Power",
					type = "group",
					order = 2,
					args = {
						header1 = {
							name = "Power Colors",
							type = "header",
							order = 1,
						},
						Mana = {
							name = "Mana",
							desc = "Choose an individual Color for Mana.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Mana.r, db.oUF.Colors.Power.Mana.g, db.oUF.Colors.Power.Mana.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Mana.r = r
									db.oUF.Colors.Power.Mana.g = g
									db.oUF.Colors.Power.Mana.b = b
								end,
							order = 2,
						},
						Rage = {
							name = "Rage",
							desc = "Choose an individual Color for Rage.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Rage.r, db.oUF.Colors.Power.Rage.g, db.oUF.Colors.Power.Rage.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Rage.r = r
									db.oUF.Colors.Power.Rage.g = g
									db.oUF.Colors.Power.Rage.b = b
								end,
							order = 3,
						},
						Focus = {
							name = "Focus",
							desc = "Choose an individual Color for Focus.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Focus.r, db.oUF.Colors.Power.Focus.g, db.oUF.Colors.Power.Focus.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Focus.r = r
									db.oUF.Colors.Power.Focus.g = g
									db.oUF.Colors.Power.Focus.b = b
								end,
							order = 4,
						},
						Energy = {
							name = "Energy",
							desc = "Choose an individual Color for Energy.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Energy.r, db.oUF.Colors.Power.Energy.g, db.oUF.Colors.Power.Energy.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Energy.r = r
									db.oUF.Colors.Power.Energy.g = g
									db.oUF.Colors.Power.Energy.b = b
								end,
							order = 5,
						},
						Runes = {
							name = "Runes",
							desc = "Choose an individual Color for Runes.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Runes.r, db.oUF.Colors.Power.Runes.g, db.oUF.Colors.Power.Runes.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Runes.r = r
									db.oUF.Colors.Power.Runes.g = g
									db.oUF.Colors.Power.Runes.b = b
								end,
							order = 6,
						},
						RunicPower = {
							name = "Runic Power",
							desc = "Choose an individual Color for Runic Power.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.RunicPower.r, db.oUF.Colors.Power.RunicPower.g, db.oUF.Colors.Power.RunicPower.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.RunicPower.r = r
									db.oUF.Colors.Power.RunicPower.g = g
									db.oUF.Colors.Power.RunicPower.b = b
								end,
							order = 7,
						},
						AmmoSlot = {
							name = "Ammo Slot",
							desc = "Choose an individual Color for Ammo Slot.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.AmmoSlot.r, db.oUF.Colors.Power.AmmoSlot.g, db.oUF.Colors.Power.AmmoSlot.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.AmmoSlot.r = r
									db.oUF.Colors.Power.AmmoSlot.g = g
									db.oUF.Colors.Power.AmmoSlot.b = b
								end,
							order = 8,
						},
						Fuel = {
							name = "Fuel",
							desc = "Choose an individual Color for Fuel.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Power.Fuel.r, db.oUF.Colors.Power.Fuel.g, db.oUF.Colors.Power.Fuel.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Power.Fuel.r = r
									db.oUF.Colors.Power.Fuel.g = g
									db.oUF.Colors.Power.Fuel.b = b
								end,
							order = 9,
						},
						empty = {
							name = "   ",
							type = "description",
							order = 10,
							width = "full",
						},
						Reset = {
							order = 11,
							type = "execute",
							name = "Restore Defaults",
							func = function()
								db.oUF.Colors.Power.Mana.r = defaults.profile.oUF.Colors.Power.Mana.r
								db.oUF.Colors.Power.Mana.g = defaults.profile.oUF.Colors.Power.Mana.g
								db.oUF.Colors.Power.Mana.b = defaults.profile.oUF.Colors.Power.Mana.b
								
								db.oUF.Colors.Power.Rage.r = defaults.profile.oUF.Colors.Power.Rage.r
								db.oUF.Colors.Power.Rage.g = defaults.profile.oUF.Colors.Power.Rage.g
								db.oUF.Colors.Power.Rage.b = defaults.profile.oUF.Colors.Power.Rage.b
								
								db.oUF.Colors.Power.Focus.r = defaults.profile.oUF.Colors.Power.Focus.r
								db.oUF.Colors.Power.Focus.g = defaults.profile.oUF.Colors.Power.Focus.g
								db.oUF.Colors.Power.Focus.b = defaults.profile.oUF.Colors.Power.Focus.b
								
								db.oUF.Colors.Power.Energy.r = defaults.profile.oUF.Colors.Power.Energy.r
								db.oUF.Colors.Power.Energy.g = defaults.profile.oUF.Colors.Power.Energy.g
								db.oUF.Colors.Power.Energy.b = defaults.profile.oUF.Colors.Power.Energy.b
								
								db.oUF.Colors.Power.Runes.r = defaults.profile.oUF.Colors.Power.Runes.r
								db.oUF.Colors.Power.Runes.g = defaults.profile.oUF.Colors.Power.Runes.g
								db.oUF.Colors.Power.Runes.b = defaults.profile.oUF.Colors.Power.Runes.b
								
								db.oUF.Colors.Power.RunicPower.r = defaults.profile.oUF.Colors.Power.RunicPower.r
								db.oUF.Colors.Power.RunicPower.g = defaults.profile.oUF.Colors.Power.RunicPower.g
								db.oUF.Colors.Power.RunicPower.b = defaults.profile.oUF.Colors.Power.RunicPower.b
								
								db.oUF.Colors.Power.AmmoSlot.r = defaults.profile.oUF.Colors.Power.AmmoSlot.r
								db.oUF.Colors.Power.AmmoSlot.g = defaults.profile.oUF.Colors.Power.AmmoSlot.g
								db.oUF.Colors.Power.AmmoSlot.b = defaults.profile.oUF.Colors.Power.AmmoSlot.b
								
								db.oUF.Colors.Power.Fuel.r = defaults.profile.oUF.Colors.Power.Fuel.r
								db.oUF.Colors.Power.Fuel.g = defaults.profile.oUF.Colors.Power.Fuel.g
								db.oUF.Colors.Power.Fuel.b = defaults.profile.oUF.Colors.Power.Fuel.b
								
								StaticPopup_Show("RELOAD_UI")
							end,
						},
					},
				},
				HealthGradient = {
					name = "Health Gradient",
					type = "group",
					order = 3,
					args = {
						header1 = {
							name = "Health Gradient Colors",
							type = "header",
							order = 1,
						},
						EmptyHP = {
							name = "Empty (Bad!)",
							desc = "Choose an individual Color for Empty HP.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Smooth.Smooth1.r, db.oUF.Colors.Smooth.Smooth1.g, db.oUF.Colors.Smooth.Smooth1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Smooth.Smooth1.r = r
									db.oUF.Colors.Smooth.Smooth1.g = g
									db.oUF.Colors.Smooth.Smooth1.b = b
								end,
							order = 2,
						},
						OKHP = {
							name = "Half (OK!)",
							desc = "Choose an individual Color for Half HP.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Smooth.Smooth2.r, db.oUF.Colors.Smooth.Smooth2.g, db.oUF.Colors.Smooth.Smooth2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Smooth.Smooth2.r = r
									db.oUF.Colors.Smooth.Smooth2.g = g
									db.oUF.Colors.Smooth.Smooth2.b = b
								end,
							order = 3,
						},
						FullHP = {
							name = "Full (Good!)",
							desc = "Choose an individual Color for Full HP.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Smooth.Smooth3.r, db.oUF.Colors.Smooth.Smooth3.g, db.oUF.Colors.Smooth.Smooth3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Smooth.Smooth3.r = r
									db.oUF.Colors.Smooth.Smooth3.g = g
									db.oUF.Colors.Smooth.Smooth3.b = b
								end,
							order = 4,
						},
						empty = {
							name = "   ",
							type = "description",
							order = 5,
							width = "full",
						},
						Reset = {
							order = 6,
							type = "execute",
							name = "Restore Defaults",
							func = function()
								db.oUF.Colors.Smooth.Smooth1.r = defaults.profile.oUF.Colors.Smooth.Smooth1.r
								db.oUF.Colors.Smooth.Smooth1.g = defaults.profile.oUF.Colors.Smooth.Smooth1.g
								db.oUF.Colors.Smooth.Smooth1.b = defaults.profile.oUF.Colors.Smooth.Smooth1.b
								
								db.oUF.Colors.Smooth.Smooth2.r = defaults.profile.oUF.Colors.Smooth.Smooth2.r
								db.oUF.Colors.Smooth.Smooth2.g = defaults.profile.oUF.Colors.Smooth.Smooth2.g
								db.oUF.Colors.Smooth.Smooth2.b = defaults.profile.oUF.Colors.Smooth.Smooth2.b
								
								db.oUF.Colors.Smooth.Smooth3.r = defaults.profile.oUF.Colors.Smooth.Smooth3.r
								db.oUF.Colors.Smooth.Smooth3.g = defaults.profile.oUF.Colors.Smooth.Smooth3.g
								db.oUF.Colors.Smooth.Smooth3.b = defaults.profile.oUF.Colors.Smooth.Smooth3.b
								
								StaticPopup_Show("RELOAD_UI")
							end,
						},
					},
				},
				Other = {
					name = "Other",
					type = "group",
					order = 4,
					args = {
						header1 = {
							name = "Happyness Colors",
							type = "header",
							order = 1,
						},
						Happy = {
							name = "Happy",
							desc = "Choose an individual Color for Happy.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Happiness.Happiness3.r, db.oUF.Colors.Happiness.Happiness3.g, db.oUF.Colors.Happiness.Happiness3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Happiness.Happiness3.r = r
									db.oUF.Colors.Happiness.Happiness3.g = g
									db.oUF.Colors.Happiness.Happiness3.b = b
								end,
							order = 2,
						},
						Normal = {
							name = "Normal",
							desc = "Choose an individual Color for Normal.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Happiness.Happiness2.r, db.oUF.Colors.Happiness.Happiness2.g, db.oUF.Colors.Happiness.Happiness2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Happiness.Happiness2.r = r
									db.oUF.Colors.Happiness.Happiness2.g = g
									db.oUF.Colors.Happiness.Happiness2.b = b
								end,
							order = 3,
						},
						Unhappy = {
							name = "Unhappy",
							desc = "Choose an individual Color for Unhappy.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Happiness.Happiness1.r, db.oUF.Colors.Happiness.Happiness1.g, db.oUF.Colors.Happiness.Happiness1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Happiness.Happiness1.r = r
									db.oUF.Colors.Happiness.Happiness1.g = g
									db.oUF.Colors.Happiness.Happiness1.b = b
								end,
							order = 4,
						},
						header2 = {
							name = "Rune Colors",
							type = "header",
							order = 5,
						},
						Blood = {
							name = "Blood",
							desc = "Choose an individual Color for Blood.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runes.Rune1.r, db.oUF.Colors.Runes.Rune1.g, db.oUF.Colors.Runes.Rune1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runes.Rune1.r = r
									db.oUF.Colors.Runes.Rune1.g = g
									db.oUF.Colors.Runes.Rune1.b = b
								end,
							order = 6,
						},
						Unholy = {
							name = "Unholy",
							desc = "Choose an individual Color for Unholy.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runes.Rune2.r, db.oUF.Colors.Runes.Rune2.g, db.oUF.Colors.Runes.Rune2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runes.Rune2.r = r
									db.oUF.Colors.Runes.Rune2.g = g
									db.oUF.Colors.Runes.Rune2.b = b
								end,
							order = 7,
						},
						Frost = {
							name = "Frost",
							desc = "Choose an individual Color for Frost.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runes.Rune3.r, db.oUF.Colors.Runes.Rune3.g, db.oUF.Colors.Runes.Rune3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runes.Rune3.r = r
									db.oUF.Colors.Runes.Rune3.g = g
									db.oUF.Colors.Runes.Rune3.b = b
								end,
							order = 8,
						},
						Death = {
							name = "Death",
							desc = "Choose an individual Color for Death.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runes.Rune4.r, db.oUF.Colors.Runes.Rune4.g, db.oUF.Colors.Runes.Rune4.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runes.Rune4.r = r
									db.oUF.Colors.Runes.Rune4.g = g
									db.oUF.Colors.Runes.Rune4.b = b
								end,
							order = 9,
						},
						header3 = {
							name = "Rogue ComboPoint Colors",
							type = "header",
							order = 10,
						},
						Combo1 = {
							name = "1 CP",
							desc = "Choose an individual Color for your 1st ComboPoint.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.ComboPoints.Combo1.r, db.oUF.Colors.ComboPoints.Combo1.g, db.oUF.Colors.ComboPoints.Combo1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.ComboPoints.Combo1.r = r
									db.oUF.Colors.ComboPoints.Combo1.g = g
									db.oUF.Colors.ComboPoints.Combo1.b = b
								end,
							order = 11,
						},
						Combo2 = {
							name = "2 CP",
							desc = "Choose an individual Color for your 2nd ComboPoint.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.ComboPoints.Combo2.r, db.oUF.Colors.ComboPoints.Combo2.g, db.oUF.Colors.ComboPoints.Combo2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.ComboPoints.Combo2.r = r
									db.oUF.Colors.ComboPoints.Combo2.g = g
									db.oUF.Colors.ComboPoints.Combo2.b = b
								end,
							order = 12,
						},
						Combo3 = {
							name = "3 CP",
							desc = "Choose an individual Color for your 3rd ComboPoint.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.ComboPoints.Combo3.r, db.oUF.Colors.ComboPoints.Combo3.g, db.oUF.Colors.ComboPoints.Combo3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.ComboPoints.Combo3.r = r
									db.oUF.Colors.ComboPoints.Combo3.g = g
									db.oUF.Colors.ComboPoints.Combo3.b = b
								end,
							order = 13,
						},
						Combo4 = {
							name = "4 CP",
							desc = "Choose an individual Color for your 4rd ComboPoint.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.ComboPoints.Combo4.r, db.oUF.Colors.ComboPoints.Combo4.g, db.oUF.Colors.ComboPoints.Combo4.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.ComboPoints.Combo4.r = r
									db.oUF.Colors.ComboPoints.Combo4.g = g
									db.oUF.Colors.ComboPoints.Combo4.b = b
								end,
							order = 14,
						},
						Combo5 = {
							name = "5 CP",
							desc = "Choose an individual Color for your 5th ComboPoint.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.ComboPoints.Combo5.r, db.oUF.Colors.ComboPoints.Combo5.g, db.oUF.Colors.ComboPoints.Combo5.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.ComboPoints.Combo5.r = r
									db.oUF.Colors.ComboPoints.Combo5.g = g
									db.oUF.Colors.ComboPoints.Combo5.b = b
								end,
							order = 15,
						},
						header4 = {
							name = "DK Runebar Colors",
							type = "header",
							order = 16,
						},
						Runebar1 = {
							name = "Blood Rune1",
							desc = "Choose an individual Color for Blood Rune1.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune1.r, db.oUF.Colors.Runebar.Rune1.g, db.oUF.Colors.Runebar.Rune1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune1.r = r
									db.oUF.Colors.Runebar.Rune1.g = g
									db.oUF.Colors.Runebar.Rune1.b = b
								end,
							order = 17,
						},
						Runebar2 = {
							name = "Blood Rune2",
							desc = "Choose an individual Color for Blood Rune2.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune2.r, db.oUF.Colors.Runebar.Rune2.g, db.oUF.Colors.Runebar.Rune2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune2.r = r
									db.oUF.Colors.Runebar.Rune2.g = g
									db.oUF.Colors.Runebar.Rune2.b = b
								end,
							order = 18,
						},
						Runebar3 = {
							name = "Unholy Rune1",
							desc = "Choose an individual Color for Unholy Rune1.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune3.r, db.oUF.Colors.Runebar.Rune3.g, db.oUF.Colors.Runebar.Rune3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune3.r = r
									db.oUF.Colors.Runebar.Rune3.g = g
									db.oUF.Colors.Runebar.Rune3.b = b
								end,
							order = 19,
						},
						Runebar4 = {
							name = "Unholy Rune2",
							desc = "Choose an individual Color for Unholy Rune2.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune4.r, db.oUF.Colors.Runebar.Rune4.g, db.oUF.Colors.Runebar.Rune4.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune4.r = r
									db.oUF.Colors.Runebar.Rune4.g = g
									db.oUF.Colors.Runebar.Rune4.b = b
								end,
							order = 20,
						},
						Runebar5 = {
							name = "Frost Rune1",
							desc = "Choose an individual Color for Frost Rune1.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune5.r, db.oUF.Colors.Runebar.Rune5.g, db.oUF.Colors.Runebar.Rune5.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune5.r = r
									db.oUF.Colors.Runebar.Rune5.g = g
									db.oUF.Colors.Runebar.Rune5.b = b
								end,
							order = 21,
						},
						Runebar6 = {
							name = "Frost Rune2",
							desc = "Choose an individual Color for Frost Rune2.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Runebar.Rune6.r, db.oUF.Colors.Runebar.Rune6.g, db.oUF.Colors.Runebar.Rune6.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Runebar.Rune6.r = r
									db.oUF.Colors.Runebar.Rune6.g = g
									db.oUF.Colors.Runebar.Rune6.b = b
								end,
							order = 22,
						},
						header5 = {
							name = "Shaman Totembar Colors",
							type = "header",
							order = 23,
						},
						TotemFire = {
							name = "Fire",
							desc = "Choose an individual Color for your Fire Totems.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Totems.Fire.r, db.oUF.Colors.Totems.Fire.g, db.oUF.Colors.Totems.Fire.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Totems.Fire.r = r
									db.oUF.Colors.Totems.Fire.g = g
									db.oUF.Colors.Totems.Fire.b = b
								end,
							order = 24,
						},
						TotemEarth = {
							name = "Earth",
							desc = "Choose an individual Color for your Earth Totems.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Totems.Earth.r, db.oUF.Colors.Totems.Earth.g, db.oUF.Colors.Totems.Earth.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Totems.Earth.r = r
									db.oUF.Colors.Totems.Earth.g = g
									db.oUF.Colors.Totems.Earth.b = b
								end,
							order = 25,
						},
						TotemWater = {
							name = "Water",
							desc = "Choose an individual Color for your Water Totems.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Totems.Water.r, db.oUF.Colors.Totems.Water.g, db.oUF.Colors.Totems.Water.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Totems.Water.r = r
									db.oUF.Colors.Totems.Water.g = g
									db.oUF.Colors.Totems.Water.b = b
								end,
							order = 26,
						},
						TotemAir = {
							name = "Air",
							desc = "Choose an individual Color for your Air Totems.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Totems.Air.r, db.oUF.Colors.Totems.Air.g, db.oUF.Colors.Totems.Air.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Totems.Air.r = r
									db.oUF.Colors.Totems.Air.g = g
									db.oUF.Colors.Totems.Air.b = b
								end,
							order = 27,
						},
						header6 = {
							name = "Level Difficulty Colors",
							type = "header",
							order = 28,
						},
						LevelDiff1 = {
							name = "Difference >= 5",
							desc = "Level Difference between your Level and your Target's Level greater or equal 5.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Diff.Diff1.r, db.oUF.Colors.Diff.Diff1.g, db.oUF.Colors.Diff.Diff1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Diff.Diff1.r = r
									db.oUF.Colors.Diff.Diff1.g = g
									db.oUF.Colors.Diff.Diff1.b = b
								end,
							order = 29,
						},
						LevelDiff2 = {
							name = "Difference >= 3",
							desc = "Level Difference between your Level and your Target's Level greater or equal 3.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Diff.Diff2.r, db.oUF.Colors.Diff.Diff2.g, db.oUF.Colors.Diff.Diff2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Diff.Diff2.r = r
									db.oUF.Colors.Diff.Diff2.g = g
									db.oUF.Colors.Diff.Diff2.b = b
								end,
							order = 30,
						},
						LevelDiff3 = {
							name = "Difference >= -2",
							desc = "Level Difference between your Level and your Target's Level greater or equal -2.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Diff.Diff3.r, db.oUF.Colors.Diff.Diff3.g, db.oUF.Colors.Diff.Diff3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Diff.Diff3.r = r
									db.oUF.Colors.Diff.Diff3.g = g
									db.oUF.Colors.Diff.Diff3.b = b
								end,
							order = 31,
						},
						LevelDiff4 = {
							name = "Difference is in Green QuestRange",
							desc = "Level Difference between your Level and your Target's Level is in Green QuestRange.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Diff.Diff4.r, db.oUF.Colors.Diff.Diff4.g, db.oUF.Colors.Diff.Diff4.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Diff.Diff4.r = r
									db.oUF.Colors.Diff.Diff4.g = g
									db.oUF.Colors.Diff.Diff4.b = b
								end,
							order = 32,
						},
						LevelDiff5 = {
							name = "Default",
							desc = "Level Difference between your Level and your Target's Level greater is 0.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Diff.Diff5.r, db.oUF.Colors.Diff.Diff5.g, db.oUF.Colors.Diff.Diff5.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Diff.Diff5.r = r
									db.oUF.Colors.Diff.Diff5.g = g
									db.oUF.Colors.Diff.Diff5.b = b
								end,
							order = 33,
						},
						header7 = {
							name = "Tapped Colors",
							type = "header",
							order = 34,
						},
						Tapped = {
							name = "Tapped",
							desc = "Choose an individual Color for Tapped Mobs.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Tapped.r, db.oUF.Colors.Tapped.g, db.oUF.Colors.Tapped.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Tapped.r = r
									db.oUF.Colors.Tapped.g = g
									db.oUF.Colors.Tapped.b = b
								end,
							order = 35,
						},
						header8 = {
							name = "Holy Power",
							type = "header",
							order = 36,
						},
						HolyPower1 = {
							name = "Part 1",
							desc = "Choose any color for the first part of your Holy Power Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Holypowerbar.Holy1.r, db.oUF.Colors.Holypowerbar.Holy1.g, db.oUF.Colors.Holypowerbar.Holy1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Holypowerbar.Holy1.r = r
									db.oUF.Colors.Holypowerbar.Holy1.g = g
									db.oUF.Colors.Holypowerbar.Holy1.b = b
								end,
							order = 37,
						},
						HolyPower2 = {
							name = "Part 2",
							desc = "Choose any color for the second part of your Holy Power Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Holypowerbar.Holy2.r, db.oUF.Colors.Holypowerbar.Holy2.g, db.oUF.Colors.Holypowerbar.Holy2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Holypowerbar.Holy2.r = r
									db.oUF.Colors.Holypowerbar.Holy2.g = g
									db.oUF.Colors.Holypowerbar.Holy2.b = b
								end,
							order = 38,
						},
						HolyPower3 = {
							name = "Part 3",
							desc = "Choose any color for the third part of your Holy Power Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Holypowerbar.Holy3.r, db.oUF.Colors.Holypowerbar.Holy3.g, db.oUF.Colors.Holypowerbar.Holy3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Holypowerbar.Holy3.r = r
									db.oUF.Colors.Holypowerbar.Holy3.g = g
									db.oUF.Colors.Holypowerbar.Holy3.b = b
								end,
							order = 39,
						},
						header9 = {
							name = "Soul Shards",
							type = "header",
							order = 40,
						},
						SoulShard1 = {
							name = "Shard 1",
							desc = "Choose any color for the first Part of your Sould Shard Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Soulshardbar.Shard1.r, db.oUF.Colors.Soulshardbar.Shard1.g, db.oUF.Colors.Soulshardbar.Shard1.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Soulshardbar.Shard1.r = r
									db.oUF.Colors.Soulshardbar.Shard1.g = g
									db.oUF.Colors.Soulshardbar.Shard1.b = b
								end,
							order = 41,
						},
						SoulShard2 = {
							name = "Shard 2",
							desc = "Choose any color for the second Part of your Sould Shard Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Soulshardbar.Shard2.r, db.oUF.Colors.Soulshardbar.Shard2.g, db.oUF.Colors.Soulshardbar.Shard2.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Soulshardbar.Shard2.r = r
									db.oUF.Colors.Soulshardbar.Shard2.g = g
									db.oUF.Colors.Soulshardbar.Shard2.b = b
								end,
							order = 42,
						},
						SoulShard3 = {
							name = "Shard 3",
							desc = "Choose any color for the third Part of your Sould Shard Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Soulshardbar.Shard3.r, db.oUF.Colors.Soulshardbar.Shard3.g, db.oUF.Colors.Soulshardbar.Shard3.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Soulshardbar.Shard3.r = r
									db.oUF.Colors.Soulshardbar.Shard3.g = g
									db.oUF.Colors.Soulshardbar.Shard3.b = b
								end,
							order = 43,
						},
						header10 = {
							name = "Eclipse",
							type = "header",
							order = 44,
						},
						EclipseLunar = {
							name = "Lunar",
							desc = "Choose any color for the Lunar Part of your Eclipse Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Eclipsebar.Lunar.r, db.oUF.Colors.Eclipsebar.Lunar.g, db.oUF.Colors.Eclipsebar.Lunar.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Eclipsebar.Lunar.r = r
									db.oUF.Colors.Eclipsebar.Lunar.g = g
									db.oUF.Colors.Eclipsebar.Lunar.b = b
								end,
							order = 45,
						},
						EclipseLunarBG = {
							name = "Lunar BG",
							desc = "Choose any background color for the Lunar Part of your Eclipse Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Eclipsebar.LunarBG.r, db.oUF.Colors.Eclipsebar.LunarBG.g, db.oUF.Colors.Eclipsebar.LunarBG.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Eclipsebar.LunarBG.r = r
									db.oUF.Colors.Eclipsebar.LunarBG.g = g
									db.oUF.Colors.Eclipsebar.LunarBG.b = b
								end,
							order = 46,
						},
						EclipseSolar = {
							name = "Solar",
							desc = "Choose any color for the Solar Part of your Eclipse Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Eclipsebar.Solar.r, db.oUF.Colors.Eclipsebar.Solar.g, db.oUF.Colors.Eclipsebar.Solar.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Eclipsebar.Solar.r = r
									db.oUF.Colors.Eclipsebar.Solar.g = g
									db.oUF.Colors.Eclipsebar.Solar.b = b
								end,
							order = 46,
						},
						EclipseSolarBG = {
							name = "Solar BG",
							desc = "Choose any background color for the Solar Part of your Eclipse Bar.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "color",
							width = "full",
							hasAlpha = false,
							get = function() return db.oUF.Colors.Eclipsebar.SolarBG.r, db.oUF.Colors.Eclipsebar.SolarBG.g, db.oUF.Colors.Eclipsebar.SolarBG.b end,
							set = function(_,r,g,b)
									db.oUF.Colors.Eclipsebar.SolarBG.r = r
									db.oUF.Colors.Eclipsebar.SolarBG.g = g
									db.oUF.Colors.Eclipsebar.SolarBG.b = b
								end,
							order = 47,
						},
						empty = {
							name = "   ",
							type = "description",
							order = 48,
							width = "full",
						},
						Reset = {
							order = 49,
							type = "execute",
							name = "Restore Defaults",
							func = function()
								db.oUF.Colors.Happiness.Happiness1.r = defaults.profile.oUF.Colors.Happiness.Happiness1.r
								db.oUF.Colors.Happiness.Happiness1.g = defaults.profile.oUF.Colors.Happiness.Happiness1.g
								db.oUF.Colors.Happiness.Happiness1.b = defaults.profile.oUF.Colors.Happiness.Happiness1.b
								
								db.oUF.Colors.Happiness.Happiness2.r = defaults.profile.oUF.Colors.Happiness.Happiness2.r
								db.oUF.Colors.Happiness.Happiness2.g = defaults.profile.oUF.Colors.Happiness.Happiness2.g
								db.oUF.Colors.Happiness.Happiness2.b = defaults.profile.oUF.Colors.Happiness.Happiness2.b
								
								db.oUF.Colors.Happiness.Happiness3.r = defaults.profile.oUF.Colors.Happiness.Happiness3.r
								db.oUF.Colors.Happiness.Happiness3.g = defaults.profile.oUF.Colors.Happiness.Happiness3.g
								db.oUF.Colors.Happiness.Happiness3.b = defaults.profile.oUF.Colors.Happiness.Happiness3.b
								
								db.oUF.Colors.Runes.Rune1.r = defaults.profile.oUF.Colors.Runes.Rune1.r
								db.oUF.Colors.Runes.Rune1.g = defaults.profile.oUF.Colors.Runes.Rune1.g
								db.oUF.Colors.Runes.Rune1.b = defaults.profile.oUF.Colors.Runes.Rune1.b
								
								db.oUF.Colors.Runes.Rune2.r = defaults.profile.oUF.Colors.Runes.Rune2.r
								db.oUF.Colors.Runes.Rune2.g = defaults.profile.oUF.Colors.Runes.Rune2.g
								db.oUF.Colors.Runes.Rune2.b = defaults.profile.oUF.Colors.Runes.Rune2.b
								
								db.oUF.Colors.Runes.Rune3.r = defaults.profile.oUF.Colors.Runes.Rune3.r
								db.oUF.Colors.Runes.Rune3.g = defaults.profile.oUF.Colors.Runes.Rune3.g
								db.oUF.Colors.Runes.Rune3.b = defaults.profile.oUF.Colors.Runes.Rune3.b
								
								db.oUF.Colors.Runes.Rune4.r = defaults.profile.oUF.Colors.Runes.Rune4.r
								db.oUF.Colors.Runes.Rune4.g = defaults.profile.oUF.Colors.Runes.Rune4.g
								db.oUF.Colors.Runes.Rune4.b = defaults.profile.oUF.Colors.Runes.Rune4.b
								
								db.oUF.Colors.ComboPoints.Combo1.r = defaults.profile.oUF.Colors.ComboPoints.Combo1.r
								db.oUF.Colors.ComboPoints.Combo1.g = defaults.profile.oUF.Colors.ComboPoints.Combo1.g
								db.oUF.Colors.ComboPoints.Combo1.b = defaults.profile.oUF.Colors.ComboPoints.Combo1.b
								
								db.oUF.Colors.ComboPoints.Combo2.r = defaults.profile.oUF.Colors.ComboPoints.Combo2.r
								db.oUF.Colors.ComboPoints.Combo2.g = defaults.profile.oUF.Colors.ComboPoints.Combo2.g
								db.oUF.Colors.ComboPoints.Combo2.b = defaults.profile.oUF.Colors.ComboPoints.Combo2.b
								
								db.oUF.Colors.ComboPoints.Combo3.r = defaults.profile.oUF.Colors.ComboPoints.Combo3.r
								db.oUF.Colors.ComboPoints.Combo3.g = defaults.profile.oUF.Colors.ComboPoints.Combo3.g
								db.oUF.Colors.ComboPoints.Combo3.b = defaults.profile.oUF.Colors.ComboPoints.Combo3.b
								
								db.oUF.Colors.ComboPoints.Combo4.r = defaults.profile.oUF.Colors.ComboPoints.Combo4.r
								db.oUF.Colors.ComboPoints.Combo4.g = defaults.profile.oUF.Colors.ComboPoints.Combo4.g
								db.oUF.Colors.ComboPoints.Combo4.b = defaults.profile.oUF.Colors.ComboPoints.Combo4.b
								
								db.oUF.Colors.ComboPoints.Combo5.r = defaults.profile.oUF.Colors.ComboPoints.Combo5.r
								db.oUF.Colors.ComboPoints.Combo5.g = defaults.profile.oUF.Colors.ComboPoints.Combo5.g
								db.oUF.Colors.ComboPoints.Combo5.b = defaults.profile.oUF.Colors.ComboPoints.Combo5.b
								
								db.oUF.Colors.Runebar.Rune1.r = defaults.profile.oUF.Colors.Runebar.Rune1.r
								db.oUF.Colors.Runebar.Rune1.g = defaults.profile.oUF.Colors.Runebar.Rune1.g
								db.oUF.Colors.Runebar.Rune1.b = defaults.profile.oUF.Colors.Runebar.Rune1.b
								
								db.oUF.Colors.Runebar.Rune2.r = defaults.profile.oUF.Colors.Runebar.Rune2.r
								db.oUF.Colors.Runebar.Rune2.g = defaults.profile.oUF.Colors.Runebar.Rune2.g
								db.oUF.Colors.Runebar.Rune2.b = defaults.profile.oUF.Colors.Runebar.Rune2.b
								
								db.oUF.Colors.Runebar.Rune3.r = defaults.profile.oUF.Colors.Runebar.Rune3.r
								db.oUF.Colors.Runebar.Rune3.g = defaults.profile.oUF.Colors.Runebar.Rune3.g
								db.oUF.Colors.Runebar.Rune3.b = defaults.profile.oUF.Colors.Runebar.Rune3.b
								
								db.oUF.Colors.Runebar.Rune4.r = defaults.profile.oUF.Colors.Runebar.Rune4.r
								db.oUF.Colors.Runebar.Rune4.g = defaults.profile.oUF.Colors.Runebar.Rune4.g
								db.oUF.Colors.Runebar.Rune4.b = defaults.profile.oUF.Colors.Runebar.Rune4.b
								
								db.oUF.Colors.Runebar.Rune5.r = defaults.profile.oUF.Colors.Runebar.Rune5.r
								db.oUF.Colors.Runebar.Rune5.g = defaults.profile.oUF.Colors.Runebar.Rune5.g
								db.oUF.Colors.Runebar.Rune5.b = defaults.profile.oUF.Colors.Runebar.Rune5.b
								
								db.oUF.Colors.Runebar.Rune6.r = defaults.profile.oUF.Colors.Runebar.Rune6.r
								db.oUF.Colors.Runebar.Rune6.g = defaults.profile.oUF.Colors.Runebar.Rune6.g
								db.oUF.Colors.Runebar.Rune6.b = defaults.profile.oUF.Colors.Runebar.Rune6.b
								
								db.oUF.Colors.Totems.Fire.r = defaults.profile.oUF.Colors.Totems.Fire.r
								db.oUF.Colors.Totems.Fire.g = defaults.profile.oUF.Colors.Totems.Fire.g
								db.oUF.Colors.Totems.Fire.b = defaults.profile.oUF.Colors.Totems.Fire.b
								
								db.oUF.Colors.Totems.Earth.r = defaults.profile.oUF.Colors.Totems.Earth.r
								db.oUF.Colors.Totems.Earth.g = defaults.profile.oUF.Colors.Totems.Earth.g
								db.oUF.Colors.Totems.Earth.b = defaults.profile.oUF.Colors.Totems.Earth.b
								
								db.oUF.Colors.Totems.Water.r = defaults.profile.oUF.Colors.Totems.Water.r
								db.oUF.Colors.Totems.Water.g = defaults.profile.oUF.Colors.Totems.Water.g
								db.oUF.Colors.Totems.Water.b = defaults.profile.oUF.Colors.Totems.Water.b
								
								db.oUF.Colors.Totems.Air.r = defaults.profile.oUF.Colors.Totems.Air.r
								db.oUF.Colors.Totems.Air.g = defaults.profile.oUF.Colors.Totems.Air.g
								db.oUF.Colors.Totems.Air.b = defaults.profile.oUF.Colors.Totems.Air.b
								
								db.oUF.Colors.Diff.Diff1.r = defaults.profile.oUF.Colors.Diff.Diff1.r
								db.oUF.Colors.Diff.Diff1.g = defaults.profile.oUF.Colors.Diff.Diff1.g
								db.oUF.Colors.Diff.Diff1.b = defaults.profile.oUF.Colors.Diff.Diff1.b
								
								db.oUF.Colors.Diff.Diff2.r = defaults.profile.oUF.Colors.Diff.Diff2.r
								db.oUF.Colors.Diff.Diff2.g = defaults.profile.oUF.Colors.Diff.Diff2.g
								db.oUF.Colors.Diff.Diff2.b = defaults.profile.oUF.Colors.Diff.Diff2.b
								
								db.oUF.Colors.Diff.Diff3.r = defaults.profile.oUF.Colors.Diff.Diff3.r
								db.oUF.Colors.Diff.Diff3.g = defaults.profile.oUF.Colors.Diff.Diff3.g
								db.oUF.Colors.Diff.Diff3.b = defaults.profile.oUF.Colors.Diff.Diff3.b
								
								db.oUF.Colors.Diff.Diff4.r = defaults.profile.oUF.Colors.Diff.Diff4.r
								db.oUF.Colors.Diff.Diff4.g = defaults.profile.oUF.Colors.Diff.Diff4.g
								db.oUF.Colors.Diff.Diff4.b = defaults.profile.oUF.Colors.Diff.Diff4.b
								
								db.oUF.Colors.Diff.Diff5.r = defaults.profile.oUF.Colors.Diff.Diff5.r
								db.oUF.Colors.Diff.Diff5.g = defaults.profile.oUF.Colors.Diff.Diff5.g
								db.oUF.Colors.Diff.Diff5.b = defaults.profile.oUF.Colors.Diff.Diff5.b
								
								db.oUF.Colors.Tapped.r = defaults.profile.oUF.Colors.Tapped.r
								db.oUF.Colors.Tapped.g = defaults.profile.oUF.Colors.Tapped.g
								db.oUF.Colors.Tapped.b = defaults.profile.oUF.Colors.Tapped.b
								
								db.oUF.Colors.Holypowerbar.Holy1.r = defaults.profile.oUF.Colors.Holypowerbar.Holy1.r
								db.oUF.Colors.Holypowerbar.Holy1.g = defaults.profile.oUF.Colors.Holypowerbar.Holy1.g
								db.oUF.Colors.Holypowerbar.Holy1.b = defaults.profile.oUF.Colors.Holypowerbar.Holy1.b
									
								db.oUF.Colors.Holypowerbar.Holy2.r = defaults.profile.oUF.Colors.Holypowerbar.Holy2.r
								db.oUF.Colors.Holypowerbar.Holy2.g = defaults.profile.oUF.Colors.Holypowerbar.Holy2.g
								db.oUF.Colors.Holypowerbar.Holy2.b = defaults.profile.oUF.Colors.Holypowerbar.Holy2.b
									
								db.oUF.Colors.Holypowerbar.Holy3.r = defaults.profile.oUF.Colors.Holypowerbar.Holy3.r
								db.oUF.Colors.Holypowerbar.Holy3.g = defaults.profile.oUF.Colors.Holypowerbar.Holy3.g
								db.oUF.Colors.Holypowerbar.Holy3.b = defaults.profile.oUF.Colors.Holypowerbar.Holy3.b
								
								db.oUF.Colors.Soulshardbar.Shard1.r = defaults.profile.oUF.Colors.Soulshardbar.Shard1.r
								db.oUF.Colors.Soulshardbar.Shard1.g = defaults.profile.oUF.Colors.Soulshardbar.Shard1.g
								db.oUF.Colors.Soulshardbar.Shard1.b = defaults.profile.oUF.Colors.Soulshardbar.Shard1.b
								
								db.oUF.Colors.Soulshardbar.Shard2.r = defaults.profile.oUF.Colors.Soulshardbar.Shard2.r
								db.oUF.Colors.Soulshardbar.Shard2.g = defaults.profile.oUF.Colors.Soulshardbar.Shard2.g
								db.oUF.Colors.Soulshardbar.Shard2.b = defaults.profile.oUF.Colors.Soulshardbar.Shard2.b
								
								db.oUF.Colors.Soulshardbar.Shard3.r = defaults.profile.oUF.Colors.Soulshardbar.Shard3.r
								db.oUF.Colors.Soulshardbar.Shard3.g = defaults.profile.oUF.Colors.Soulshardbar.Shard3.g
								db.oUF.Colors.Soulshardbar.Shard3.b = defaults.profile.oUF.Colors.Soulshardbar.Shard3.b
								
								db.oUF.Colors.Eclipsebar.Lunar.r = defaults.profile.oUF.Colors.Eclipsebar.Lunar.r
								db.oUF.Colors.Eclipsebar.Lunar.g = defaults.profile.oUF.Colors.Eclipsebar.Lunar.g
								db.oUF.Colors.Eclipsebar.Lunar.b = defaults.profile.oUF.Colors.Eclipsebar.Lunar.b
								
								db.oUF.Colors.Eclipsebar.LunarBG.r = defaults.profile.oUF.Colors.Eclipsebar.LunarBG.r
								db.oUF.Colors.Eclipsebar.LunarBG.g = defaults.profile.oUF.Colors.Eclipsebar.LunarBG.g
								db.oUF.Colors.Eclipsebar.LunarBG.b = defaults.profile.oUF.Colors.Eclipsebar.LunarBG.b
								
								db.oUF.Colors.Eclipsebar.Solar.r = defaults.profile.oUF.Colors.Eclipsebar.Solar.r
								db.oUF.Colors.Eclipsebar.Solar.g = defaults.profile.oUF.Colors.Eclipsebar.Solar.g
								db.oUF.Colors.Eclipsebar.Solar.b = defaults.profile.oUF.Colors.Eclipsebar.Solar.b
								
								db.oUF.Colors.Eclipsebar.SolarBG.r = defaults.profile.oUF.Colors.Eclipsebar.SolarBG.r
								db.oUF.Colors.Eclipsebar.SolarBG.g = defaults.profile.oUF.Colors.Eclipsebar.SolarBG.g
								db.oUF.Colors.Eclipsebar.SolarBG.b = defaults.profile.oUF.Colors.Eclipsebar.SolarBG.b
								
								StaticPopup_Show("RELOAD_UI")
							end,
						},
					},
				},
			},
		},
	}
	
	return options
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile.oUF, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterUnitFrame(self:LoadOptions())
end