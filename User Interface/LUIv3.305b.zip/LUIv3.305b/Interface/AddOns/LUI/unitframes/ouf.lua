--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: ouf.lua
	Description: oUF Module
	Version....: 1.0
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local module = LUI:NewModule("oUF")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists

local fontflags = {'OUTLINE', 'THICKOUTLINE', 'MONOCHROME', 'NONE'}

local defaults = {
	oUF = {
		Settings = {
			Enable = true,
			show_v2_textures = true,
			Castbars = true,
			Auras = {
				auratimer_font = "Prototype",
				auratimer_size = 12,
				auratimer_flag = "OUTLINE",
			},
		},
	}
}

function module:LoadOptions()
	local options = {
		UnitFrames = {
			name = "UnitFrames",
			type = "group",
			order = 20,
			disabled = function()
					if IsAddOnLoaded("oUF") then
						return false
					else
						return true
					end
				end,
			args = {
				header7 = {
					name = "UnitFrames",
					type = "header",
					order = 1,
				},
				Settings = {
					name = "Settings",
					type = "group",
					guiInline = true,
					order = 2,
					args = {
						Enable = {
							name = "Enable oUF LUI",
							desc = "Wether you want to use LUI UnitFrames or not.",
							type = "toggle",
							width = "full",
							get = function() return db.oUF.Settings.Enable end,
							set = function(self,Enable)
										db.oUF.Settings.Enable = not db.oUF.Settings.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 1,
						},
						ShowV2Textures = {
							name = "Show LUI v2 Connector Frames",
							desc = "Wether you want to show LUI v2 Frames or not.",
							disabled = function() return not db.oUF.Settings.Enable end,
							type = "toggle",
							width = "full",
							get = function() return db.oUF.Settings.show_v2_textures end,
							set = function(self,ShowV2Textures)
										db.oUF.Settings.show_v2_textures = not db.oUF.Settings.show_v2_textures
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						CastbarSettings = {
							name = "Castbars",
							type = "group",
							guiInline = true,
							order = 3,
							args = {
								CBEnable = {
									name = "Enable Castbars",
									desc = "Wether you want to use oUF Castbars or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Settings.Castbars end,
									set = function(self,CBEnable)
												db.oUF.Settings.Castbars = not db.oUF.Settings.Castbars
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								CBLatency = {
									name = "Castbar Latency",
									disabled = function() return not db.oUF.Settings.Castbars end,
									desc = "Wether you want to show your Castbar Latency or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.Player.Castbar.Latency end,
									set = function(self,CBLatency)
												db.oUF.Player.Castbar.Latency = not db.oUF.Player.Castbar.Latency
												if CBLatency == true then
													oUF_LUI_player.Castbar.SafeZone:Show()
												else
													oUF_LUI_player.Castbar.SafeZone:Hide()
												end
											end,
									order = 2,
								},
								CBIcons = {
									name = "Castbar Icons",
									desc = "Wether you want to show Icons on Player/Target Castbar or not.\n\nNote:\nYou have to reload the UI.\nType /rl",
									type = "toggle",
									disabled = function() return not db.oUF.Settings.Castbars end,
									width = "full",
									get = function() return db.oUF.Player.Castbar.Icon end,
									set = function(self,CBIcons)
												db.oUF.Player.Castbar.Icon = not db.oUF.Player.Castbar.Icon
												db.oUF.Target.Castbar.Icon = not db.oUF.Target.Castbar.Icon
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 3,
								},
								CBIconsTTFT = {
									name = "Castbar Icons FocusTarget",
									desc = "Wether you want to show Icons on Focus Castbar or not.\n\nNote:\nYou have to reload the UI.\nType /rl",
									type = "toggle",
									disabled = function() return not db.oUF.Settings.Castbars end,
									width = "full",
									get = function() return db.oUF.Focus.Castbar.Icon end,
									set = function(self,CBIconsTTFT)
												db.oUF.Focus.Castbar.Icon = not db.oUF.Focus.Castbar.Icon
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 4,
								},
							},
						},
						AuraSettings = {
							name = "Auras",
							type = "group",
							guiInline = true,
							order = 4,
							args = {
								AuratimerFont = {
									name = "Auratimers Font",
									desc = "Choose your Font for Auratimers!\n\nDefault: Prototype",
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.oUF.Settings.Auras.auratimer_font end,
									set = function(self, AuratimerFont)
											db.oUF.Settings.Auras.auratimer_font = AuratimerFont
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 1,
								},
								AuratimerFontSize = {
									name = "Size",
									desc = "Choose your Auratimers Fontsize!\n Default: 12",
									type = "range",
									min = 5,
									max = 20,
									step = 1,
									get = function() return db.oUF.Settings.Auras.auratimer_size end,
									set = function(_, AuratimerFontSize) 
											db.oUF.Settings.Auras.auratimer_size = AuratimerFontSize
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 2,
								},
								AuratimerFontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Auratimers.\nDefault: OUTLINE",
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.oUF.Settings.Auras.auratimer_flag == v then
													return k
												end
											end
										end,
									set = function(self, AuratimerFontFlag)
											db.oUF.Settings.Auras.auratimer_flag = fontflags[AuratimerFontFlag]
											StaticPopup_Show("RELOAD_UI")
										end,
									order = 3,
								},
							},
						},
					},
				},
			},
		},
	}
	
	return options
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterOptions(self:LoadOptions())
end