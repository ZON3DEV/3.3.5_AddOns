--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: focustarget.lua
	Description: oUF Focus Target Module
	Version....: 1.0
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local module = LUI:NewModule("oUF_FocusTarget")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists

local positions = {"TOP", "TOPRIGHT", "TOPLEFT","BOTTOM", "BOTTOMRIGHT", "BOTTOMLEFT","RIGHT", "LEFT", "CENTER"}
local fontflags = {'OUTLINE', 'THICKOUTLINE', 'MONOCHROME', 'NONE'}
local valueFormat = {'Absolut', 'Absolut & Percent', 'Absolut Short', 'Absolut Short & Percent', 'Standard', 'Standard Short'}
local nameFormat = {'Name', 'Name + Level', 'Name + Level + Class', 'Name + Level + Race + Class', 'Level + Name', 'Level + Name + Class', 'Level + Class + Name', 'Level + Name + Race + Class', 'Level + Race + Class + Name'}
local nameLenghts = {'Short', 'Medium', 'Long'}

local defaults = {
	FocusTarget = {
		Enable = false,
		Height = "24",
		Width = "200",
		X = "-465",
		Y = "-285",
		Border = {
			EdgeFile = "glow",
			EdgeSize = 5,
			Insets = {
				Left = "3",
				Right = "3",
				Top = "3",
				Bottom = "3",
			},
			Color = {
				r = "0",
				g = "0",
				b = "0",
				a = "1",
			},
		},
		Backdrop = {
			Texture = "Blizzard Tooltip",
			Padding = {
				Left = "-4",
				Right = "4",
				Top = "4",
				Bottom = "-4",
			},
			Color = {
				r = 0,
				g = 0,
				b = 0,
				a = 1,
			},
		},
		Health = {
			Height = "24",
			Padding = "0",
			ColorClass = true,
			ColorGradient = false,
			Texture = "LUI_Gradient",
			TextureBG = "LUI_Gradient",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			IndividualColor = {
				Enable = false,
				r = 0.3,
				g = 0.3,
				b = 0.3,
			},
		},
		Power = {
			Enable = false,
			Height = "10",
			Padding = "-2",
			ColorClass = true,
			ColorType = false,
			Texture = "LUI_Minimalist",
			TextureBG = "LUI_Minimalist",
			BGAlpha = 1,
			BGMultiplier = 0.4,
			Smooth = true,
			IndividualColor = {
				Enable = false,
				r = 0.8,
				g = 0.8,
				b = 0.8,
			},
		},
		Full = {
			Enable = false,
			Height = "14",
			Texture = "LUI_Minimalist",
			Padding = "-12",
			Alpha = 1,
			Color = {
				r = "0.11",
				g = "0.11",
				b = "0.11",
				a = "1",
			},
		},
		Portrait = {
			Enable = false,
			Height = "43",
			Width = "90",
			X = "0",
			Y = "0",
		},
		Icons = {
			Lootmaster = {
				Enable = false,
				Size = 15,
				X = "16",
				Y = "0",
				Point = "TOPLEFT",
			},
			Leader = {
				Enable = false,
				Size = 17,
				X = "0",
				Y = "0",
				Point = "TOPLEFT",
			},
			Role = {
				Enable = false,
				Size = 22,
				X = "15",
				Y = "10",
				Point = "TOPRIGHT",
			},
			Raid = {
				Enable = true,
				Size = 55,
				X = "0",
				Y = "0",
				Point = "CENTER",
			},
			Resting = {
				Enable = false,
				Size = 27,
				X = "-12",
				Y = "13",
				Point = "TOPLEFT",
			},
			Combat = {
				Enable = false,
				Size = 27,
				X = "-15",
				Y = "-30",
				Point = "BOTTOMLEFT",
			},
			PvP = {
				Enable = false,
				Size = 35,
				X = "-12",
				Y = "10",
				Point = "TOPLEFT",
			},
		},
		Texts = {
			Name = {
				Enable = true,
				Font = "Prototype",
				Size = 15,
				X = "5",
				Y = "0",
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "LEFT",
				RelativePoint = "LEFT",
				Format = "Name",
				Length = "Medium",
				ColorNameByClass = false,
				ColorClassByClass = false,
				ColorLevelByDifficulty = false,
				ShowClassification = false,
				ShortClassification = false,
			},
			Health = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "-43",
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMRIGHT",
				Format = "Absolut Short",
				ShowDead = false,
			},
			Power = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "-66",
				ColorClass = true,
				ColorType = false,
				IndividualColor = {
					Enable = false,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "BOTTOMLEFT",
				RelativePoint = "BOTTOMRIGHT",
				Format = "Absolut Short",
			},
			HealthPercent = {
				Enable = true,
				Font = "Prototype",
				Size = 14,
				X = "-5",
				Y = "0",
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "1",
					g = "1",
					b = "1",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
				ShowDead = false,
			},
			PowerPercent = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "CENTER",
				RelativePoint = "CENTER",
			},
			HealthMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorGradient = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
			PowerMissing = {
				Enable = false,
				Font = "Prototype",
				Size = 24,
				X = "0",
				Y = "0",
				ShortValue = true,
				ShowAlways = false,
				ColorClass = false,
				ColorType = false,
				IndividualColor = {
					Enable = true,
					r = "0",
					g = "0",
					b = "0",
				},
				Outline = "NONE",
				Point = "RIGHT",
				RelativePoint = "RIGHT",
			},
		},
	},	
}

function module:LoadOptions()
	local options = {
		FocusTarget = {
			name = "Focus Target",
			type = "group",
			disabled = function() return not db.oUF.Settings.Enable end,
			order = 9,
			childGroups = "tab",
			args = {
				header1 = {
					name = "Focus Target",
					type = "header",
					order = 1,
				},
				General = {
					name = "General",
					type = "group",
					childGroups = "tab",
					order = 2,
					args = {
						General = {
							name = "General",
							type = "group",
							order = 0,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to use a FocusTarget Frame or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Enable end,
									set = function(self,Enable)
												db.oUF.FocusTarget.Enable = not db.oUF.FocusTarget.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
							},
						},
						Positioning = {
							name = "Positioning",
							type = "group",
							disabled = function() return not db.oUF.FocusTarget.Enable end,
							order = 1,
							args = {
								header1 = {
									name = "Frame Position",
									type = "header",
									order = 1,
								},
								FocusTargetX = {
									name = "X Value",
									desc = "X Value for your FocusTarget Frame.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.X,
									type = "input",
									get = function() return db.oUF.FocusTarget.X end,
									set = function(self,FocusTargetX)
												if FocusTargetX == nil or FocusTargetX == "" then
													FocusTargetX = "0"
												end
												db.oUF.FocusTarget.X = FocusTargetX
												oUF_LUI_focustarget:SetPoint("CENTER", UIParent, "CENTER", tonumber(FocusTargetX), tonumber(db.oUF.FocusTarget.Y))
											end,
									order = 2,
								},
								FocusTargetY = {
									name = "Y Value",
									desc = "Y Value for your FocusTarget Frame.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Y,
									type = "input",
									get = function() return db.oUF.FocusTarget.Y end,
									set = function(self,FocusTargetY)
												if FocusTargetY == nil or FocusTargetY == "" then
													FocusTargetY = "0"
												end
												db.oUF.FocusTarget.Y = FocusTargetY
												oUF_LUI_focustarget:SetPoint("CENTER", UIParent, "CENTER", tonumber(db.oUF.FocusTarget.X), tonumber(FocusTargetY))
											end,
									order = 3,
								},
							},
						},
						Size = {
							name = "Size",
							type = "group",
							disabled = function() return not db.oUF.FocusTarget.Enable end,
							order = 2,
							args = {
								header1 = {
									name = "Frame Height/Width",
									type = "header",
									order = 1,
								},
								FocusTargetHeight = {
									name = "Height",
									desc = "Decide the Height of your FocusTarget Frame.\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Height,
									type = "input",
									get = function() return db.oUF.FocusTarget.Height end,
									set = function(self,FocusTargetHeight)
												if FocusTargetHeight == nil or FocusTargetHeight == "" then
													FocusTargetHeight = "0"
												end
												db.oUF.FocusTarget.Height = FocusTargetHeight
												oUF_LUI_focustarget:SetHeight(tonumber(FocusTargetHeight))
											end,
									order = 2,
								},
								FocusTargetWidth = {
									name = "Width",
									desc = "Decide the Width of your FocusTarget Frame.\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Width,
									type = "input",
									get = function() return db.oUF.FocusTarget.Width end,
									set = function(self,FocusTargetWidth)
												if FocusTargetWidth == nil or FocusTargetWidth == "" then
													FocusTargetWidth = "0"
												end
												db.oUF.FocusTarget.Width = FocusTargetWidth
												oUF_LUI_focustarget:SetWidth(tonumber(FocusTargetWidth))
											end,
									order = 3,
								},
							},
						},
						Appearance = {
							name = "Appearance",
							type = "group",
							disabled = function() return not db.oUF.FocusTarget.Enable end,
							order = 3,
							args = {
								header1 = {
									name = "Backdrop Colors",
									type = "header",
									order = 1,
								},
								BackdropColor = {
									name = "Color",
									desc = "Choose a Backdrop Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.FocusTarget.Backdrop.Color.r, db.oUF.FocusTarget.Backdrop.Color.g, db.oUF.FocusTarget.Backdrop.Color.b, db.oUF.FocusTarget.Backdrop.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.FocusTarget.Backdrop.Color.r = r
											db.oUF.FocusTarget.Backdrop.Color.g = g
											db.oUF.FocusTarget.Backdrop.Color.b = b
											db.oUF.FocusTarget.Backdrop.Color.a = a

											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(r,g,b,a)
										end,
									order = 2,
								},
								BackdropBorderColor = {
									name = "Border Color",
									desc = "Choose a Backdrop Border Color.",
									type = "color",
									width = "full",
									hasAlpha = true,
									get = function() return db.oUF.FocusTarget.Border.Color.r, db.oUF.FocusTarget.Border.Color.g, db.oUF.FocusTarget.Border.Color.b, db.oUF.FocusTarget.Border.Color.a end,
									set = function(_,r,g,b,a)
											db.oUF.FocusTarget.Border.Color.r = r
											db.oUF.FocusTarget.Border.Color.g = g
											db.oUF.FocusTarget.Border.Color.b = b
											db.oUF.FocusTarget.Border.Color.a = a
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
										end,
									order = 3,
								},
								header2 = {
									name = "Backdrop Settings",
									type = "header",
									order = 4,
								},
								BackdropTexture = {
									name = "Backdrop Texture",
									desc = "Choose your Backdrop Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Backdrop.Texture,
									type = "select",
									dialogControl = "LSM30_Background",
									values = widgetLists.background,
									get = function() return db.oUF.FocusTarget.Backdrop.Texture end,
									set = function(self, BackdropTexture)
											db.oUF.FocusTarget.Backdrop.Texture = BackdropTexture
											oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
										end,
									order = 5,
								},
								BorderTexture = {
									name = "Border Texture",
									desc = "Choose your Border Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.EdgeFile,
									type = "select",
									dialogControl = "LSM30_Border",
									values = widgetLists.border,
									get = function() return db.oUF.FocusTarget.Border.EdgeFile end,
									set = function(self, BorderTexture)
											db.oUF.FocusTarget.Border.EdgeFile = BorderTexture
											oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
										end,
									order = 6,
								},
								BorderSize = {
									name = "Edge Size",
									desc = "Choose the Edge Size for your Frame Border.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.EdgeSize,
									type = "range",
									min = 1,
									max = 50,
									step = 1,
									get = function() return db.oUF.FocusTarget.Border.EdgeSize end,
									set = function(_, BorderSize) 
											db.oUF.FocusTarget.Border.EdgeSize = BorderSize
											oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
										end,
									order = 7,
								},
								header3 = {
									name = "Backdrop Padding",
									type = "header",
									order = 8,
								},
								PaddingLeft = {
									name = "Left",
									desc = "Value for the Left Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Backdrop.Padding.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Backdrop.Padding.Left end,
									set = function(self,PaddingLeft)
										if PaddingLeft == nil or PaddingLeft == "" then
											PaddingLeft = "0"
										end
										db.oUF.FocusTarget.Backdrop.Padding.Left = PaddingLeft
										oUF_LUI_focustarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_focustarget, "TOPLEFT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Left), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Top))
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_focustarget, "BOTTOMRIGHT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Right), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Bottom))
									end,
									order = 9,
								},
								PaddingRight = {
									name = "Right",
									desc = "Value for the Right Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Backdrop.Padding.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Backdrop.Padding.Right end,
									set = function(self,PaddingRight)
										if PaddingRight == nil or PaddingRight == "" then
											PaddingRight = "0"
										end
										db.oUF.FocusTarget.Backdrop.Padding.Right = PaddingRight
										oUF_LUI_focustarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_focustarget, "TOPLEFT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Left), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Top))
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_focustarget, "BOTTOMRIGHT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Right), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Bottom))
									end,
									order = 10,
								},
								PaddingTop = {
									name = "Top",
									desc = "Value for the Top Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Backdrop.Padding.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Backdrop.Padding.Top end,
									set = function(self,PaddingTop)
										if PaddingTop == nil or PaddingTop == "" then
											PaddingTop = "0"
										end
										db.oUF.FocusTarget.Backdrop.Padding.Top = PaddingTop
										oUF_LUI_focustarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_focustarget, "TOPLEFT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Left), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Top))
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_focustarget, "BOTTOMRIGHT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Right), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Bottom))
									end,
									order = 11,
								},
								PaddingBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Backdrop Padding\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Backdrop.Padding.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Backdrop.Padding.Bottom end,
									set = function(self,PaddingBottom)
										if PaddingBottom == nil or PaddingBottom == "" then
											PaddingBottom = "0"
										end
										db.oUF.FocusTarget.Backdrop.Padding.Bottom = PaddingBottom
										oUF_LUI_focustarget.FrameBackdrop:ClearAllPoints()
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("TOPLEFT", oUF_LUI_focustarget, "TOPLEFT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Left), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Top))
										oUF_LUI_focustarget.FrameBackdrop:SetPoint("BOTTOMRIGHT", oUF_LUI_focustarget, "BOTTOMRIGHT", tonumber(db.oUF.FocusTarget.Backdrop.Padding.Right), tonumber(db.oUF.FocusTarget.Backdrop.Padding.Bottom))
									end,
									order = 12,
								},
								header4 = {
									name = "Boder Insets",
									type = "header",
									order = 13,
								},
								InsetLeft = {
									name = "Left",
									desc = "Value for the Left Border Inset\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.Insets.Left,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Border.Insets.Left end,
									set = function(self,InsetLeft)
										if InsetLeft == nil or InsetLeft == "" then
											InsetLeft = "0"
										end
										db.oUF.FocusTarget.Border.Insets.Left = InsetLeft
										oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
											end,
									order = 14,
								},
								InsetRight = {
									name = "Right",
									desc = "Value for the Right Border Inset\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.Insets.Right,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Border.Insets.Right end,
									set = function(self,InsetRight)
										if InsetRight == nil or InsetRight == "" then
											InsetRight = "0"
										end
										db.oUF.FocusTarget.Border.Insets.Right = InsetRight
										oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
											end,
									order = 15,
								},
								InsetTop = {
									name = "Top",
									desc = "Value for the Top Border Inset\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.Insets.Top,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Border.Insets.Top end,
									set = function(self,InsetTop)
										if InsetTop == nil or InsetTop == "" then
											InsetTop = "0"
										end
										db.oUF.FocusTarget.Border.Insets.Top = InsetTop
										oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
											end,
									order = 16,
								},
								InsetBottom = {
									name = "Bottom",
									desc = "Value for the Bottom Border Inset\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Border.Insets.Bottom,
									type = "input",
									width = "half",
									get = function() return db.oUF.FocusTarget.Border.Insets.Bottom end,
									set = function(self,InsetBottom)
										if InsetBottom == nil or InsetBottom == "" then
											InsetBottom = "0"
										end
										db.oUF.FocusTarget.Border.Insets.Bottom = InsetBottom
										oUF_LUI_focustarget.FrameBackdrop:SetBackdrop({
												bgFile = LSM:Fetch("background", db.oUF.FocusTarget.Backdrop.Texture),
												edgeFile = LSM:Fetch("border", db.oUF.FocusTarget.Border.EdgeFile), edgeSize = tonumber(db.oUF.FocusTarget.Border.EdgeSize),
												insets = {left = tonumber(db.oUF.FocusTarget.Border.Insets.Left), right = tonumber(db.oUF.FocusTarget.Border.Insets.Right), top = tonumber(db.oUF.FocusTarget.Border.Insets.Top), bottom = tonumber(db.oUF.FocusTarget.Border.Insets.Bottom)}
											})
											
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropColor(tonumber(db.oUF.FocusTarget.Backdrop.Color.r), tonumber(db.oUF.FocusTarget.Backdrop.Color.g), tonumber(db.oUF.FocusTarget.Backdrop.Color.b), tonumber(db.oUF.FocusTarget.Backdrop.Color.a))
											oUF_LUI_focustarget.FrameBackdrop:SetBackdropBorderColor(tonumber(db.oUF.FocusTarget.Border.Color.r), tonumber(db.oUF.FocusTarget.Border.Color.g), tonumber(db.oUF.FocusTarget.Border.Color.b), tonumber(db.oUF.FocusTarget.Border.Color.a))
											end,
									order = 17,
								},
							},
						},
						AlphaFader = {
							name = "Fader",
							type = "group",
							disabled = function() return not db.oUF.FocusTarget.Enable end,
							order = 4,
							args = {
								empty = {
									order = 1,
									width = "full",
									type = "description",
									name = "\n\n    coming soon...",
								},
							},
						},
					},
				},
				Bars = {
					name = "Bars",
					type = "group",
					childGroups = "tab",
					disabled = function() return not db.oUF.FocusTarget.Enable end,
					order = 3,
					args = {
						Health = {
							name = "Health",
							type = "group",
							order = 1,
							args = {
								General = {
									name = "General Settings",
									type = "group",
									guiInline = true,
									order = 1,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your FocusTarget Health.\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.Height,
											type = "input",
											get = function() return db.oUF.FocusTarget.Health.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.FocusTarget.Health.Height = Height
														oUF_LUI_focustarget.Health:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.Padding,
											type = "input",
											get = function() return db.oUF.FocusTarget.Health.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.FocusTarget.Health.Padding = Padding
														oUF_LUI_focustarget.Health:ClearAllPoints()
														oUF_LUI_focustarget.Health:SetPoint("TOPLEFT", oUF_LUI_focustarget, "TOPLEFT", 0, tonumber(Padding))
														oUF_LUI_focustarget.Health:SetPoint("TOPRIGHT", oUF_LUI_focustarget, "TOPRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.FocusTarget.Health.Smooth end,
											set = function(self,Smooth)
														db.oUF.FocusTarget.Health.Smooth = not db.oUF.FocusTarget.Health.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									guiInline = true,
									order = 2,
									args = {
										HealthClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Health.ColorClass end,
											set = function(self,HealthClassColor)
														db.oUF.FocusTarget.Health.ColorClass = not db.oUF.FocusTarget.Health.ColorClass
														if HealthClassColor == true then
															db.oUF.FocusTarget.Health.ColorGradient = false
															db.oUF.FocusTarget.Health.IndividualColor.Enable = false
															
															print("FocusTarget Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 1,
										},
										HealthGradientColor = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthBars or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Health.ColorGradient end,
											set = function(self,HealthGradientColor)
														db.oUF.FocusTarget.Health.ColorGradient = not db.oUF.FocusTarget.Health.ColorGradient
														if HealthGradientColor == true then
															db.oUF.FocusTarget.Health.ColorClass = false
															db.oUF.FocusTarget.Health.IndividualColor.Enable = false
															
															print("FocusTarget Healthbar Color will change once you gain/lose HP")
														end
													end,
											order = 2,
										},
										IndividualHealthColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual HealthBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Health.IndividualColor.Enable end,
											set = function(self,IndividualHealthColor)
														db.oUF.FocusTarget.Health.IndividualColor.Enable = not db.oUF.FocusTarget.Health.IndividualColor.Enable
														if IndividualHealthColor == true then
															db.oUF.FocusTarget.Health.ColorClass = false
															db.oUF.FocusTarget.Health.ColorGradient = false
															
															oUF_LUI_focustarget.Health:SetStatusBarColor(db.oUF.FocusTarget.Health.IndividualColor.r, db.oUF.FocusTarget.Health.IndividualColor.g, db.oUF.FocusTarget.Health.IndividualColor.b)
															oUF_LUI_focustarget.Health.bg:SetVertexColor(db.oUF.FocusTarget.Health.IndividualColor.r*tonumber(db.oUF.FocusTarget.Health.BGMultiplier), db.oUF.FocusTarget.Health.IndividualColor.g*tonumber(db.oUF.FocusTarget.Health.BGMultiplier), db.oUF.FocusTarget.Health.IndividualColor.b*tonumber(db.oUF.FocusTarget.Health.BGMultiplier))
														end
													end,
											order = 3,
										},
										HealthColor = {
											name = "Individual Color",
											desc = "Choose an individual Healthbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Health.IndividualColor.r, db.oUF.FocusTarget.Health.IndividualColor.g, db.oUF.FocusTarget.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Health.IndividualColor.r = r
													db.oUF.FocusTarget.Health.IndividualColor.g = g
													db.oUF.FocusTarget.Health.IndividualColor.b = b
													
													oUF_LUI_focustarget.Health:SetStatusBarColor(r, g, b)
													oUF_LUI_focustarget.Health.bg:SetVertexColor(r*tonumber(db.oUF.FocusTarget.Health.BGMultiplier), g*tonumber(db.oUF.FocusTarget.Health.BGMultiplier), b*tonumber(db.oUF.FocusTarget.Health.BGMultiplier))
												end,
											order = 4,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										HealthTex = {
											name = "Texture",
											desc = "Choose your Health Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.FocusTarget.Health.Texture
												end,
											set = function(self, HealthTex)
													db.oUF.FocusTarget.Health.Texture = HealthTex
													oUF_LUI_focustarget.Health:SetStatusBarTexture(LSM:Fetch("statusbar", HealthTex))
												end,
											order = 1,
										},
										HealthTexBG = {
											name = "Background Texture",
											desc = "Choose your Health Background Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.FocusTarget.Health.TextureBG
												end,
											set = function(self, HealthTexBG)
													db.oUF.FocusTarget.Health.TextureBG = HealthTexBG
													oUF_LUI_focustarget.Health.bg:SetTexture(LSM:Fetch("statusbar", HealthTexBG))
												end,
											order = 2,
										},
										HealthTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Health Background.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.FocusTarget.Health.BGAlpha end,
											set = function(_, HealthTexBGAlpha) 
													db.oUF.FocusTarget.Health.BGAlpha  = HealthTexBGAlpha
													oUF_LUI_focustarget.Health.bg:SetAlpha(tonumber(HealthTexBGAlpha))
												end,
											order = 3,
										},
										HealthTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Health.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.FocusTarget.Health.BGMultiplier end,
											set = function(_, HealthTexBGMultiplier) 
													db.oUF.FocusTarget.Health.BGMultiplier  = HealthTexBGMultiplier
													oUF_LUI_focustarget.Health.bg.multiplier = tonumber(HealthTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 2,
							args = {
								EnablePower = {
									name = "Enable",
									desc = "Wether you want to use a Powerbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Power.Enable end,
									set = function(self,EnablePower)
												db.oUF.FocusTarget.Power.Enable = not db.oUF.FocusTarget.Power.Enable
												if EnablePower == true then
													oUF_LUI_focustarget.Power:Show()
												else
													oUF_LUI_focustarget.Power:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "General Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Power.Enable end,
									guiInline = true,

									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your FocusTarget Power.\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.Height,
											type = "input",
											get = function() return db.oUF.FocusTarget.Power.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.FocusTarget.Power.Height = Height
														oUF_LUI_focustarget.Power:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Powerbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.Padding,
											type = "input",
											get = function() return db.oUF.FocusTarget.Power.Padding end,
											set = function(self,Padding)
														if Padding == nil or Padding == "" then
															Padding = "0"
														end
														db.oUF.FocusTarget.Power.Padding = Padding
														oUF_LUI_focustarget.Power:ClearAllPoints()
														oUF_LUI_focustarget.Power:SetPoint("TOPLEFT", oUF_LUI_focustarget.Health, "BOTTOMLEFT", 0, tonumber(Padding))
														oUF_LUI_focustarget.Power:SetPoint("TOPRIGHT", oUF_LUI_focustarget.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
													end,
											order = 2,
										},
										Smooth = {
											name = "Enable Smooth Bar Animation",
											desc = "Wether you want to use Smooth Animations or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.FocusTarget.Power.Smooth end,
											set = function(self,Smooth)
														db.oUF.FocusTarget.Power.Smooth = not db.oUF.FocusTarget.Power.Smooth
														StaticPopup_Show("RELOAD_UI")
													end,
											order = 3,
										},
									}
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Power.Enable end,
									guiInline = true,
									order = 3,
									args = {
										PowerClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Power.ColorClass end,
											set = function(self,PowerClassColor)
														db.oUF.FocusTarget.Power.ColorClass = not db.oUF.FocusTarget.Power.ColorClass
														if PowerClassColor == true then
															db.oUF.FocusTarget.Power.ColorType = false
															db.oUF.FocusTarget.Power.IndividualColor.Enable = false
															
															print("FocusTarget Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										PowerColorByType = {
											name = "Color by Type",
											desc = "Wether you want to use Power Type colored PowerBars or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Power.ColorType end,
											set = function(self,PowerColorByType)
														db.oUF.FocusTarget.Power.ColorType = not db.oUF.FocusTarget.Power.ColorType
														if PowerColorByType == true then
															db.oUF.FocusTarget.Power.ColorClass = false
															db.oUF.FocusTarget.Power.IndividualColor.Enable = false
															
															print("FocusTarget Powerbar Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualPowerColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual PowerBar Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Power.IndividualColor.Enable end,
											set = function(self,IndividualPowerColor)
														db.oUF.FocusTarget.Power.IndividualColor.Enable = not db.oUF.FocusTarget.Power.IndividualColor.Enable
														if IndividualPowerColor == true then
															db.oUF.FocusTarget.Power.ColorType = false
															db.oUF.FocusTarget.Power.ColorClass = false
															
															oUF_LUI_focustarget.Power:SetStatusBarColor(db.oUF.FocusTarget.Power.IndividualColor.r, db.oUF.FocusTarget.Power.IndividualColor.g, db.oUF.FocusTarget.Power.IndividualColor.b)
															oUF_LUI_focustarget.Power.bg:SetVertexColor(db.oUF.FocusTarget.Power.IndividualColor.r*tonumber(db.oUF.FocusTarget.Power.BGMultiplier), db.oUF.FocusTarget.Power.IndividualColor.g*tonumber(db.oUF.FocusTarget.Power.BGMultiplier), db.oUF.FocusTarget.Power.IndividualColor.b*tonumber(db.oUF.FocusTarget.Power.BGMultiplier))
														end
													end,
											order = 3,
										},
										PowerColor = {
											name = "Individual Color",
											desc = "Choose an individual Powerbar Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Power.IndividualColor.r, db.oUF.FocusTarget.Power.IndividualColor.g, db.oUF.FocusTarget.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Power.IndividualColor.r = r
													db.oUF.FocusTarget.Power.IndividualColor.g = g
													db.oUF.FocusTarget.Power.IndividualColor.b = b
													
													oUF_LUI_focustarget.Power:SetStatusBarColor(r, g, b)
													oUF_LUI_focustarget.Power.bg:SetVertexColor(r*tonumber(db.oUF.FocusTarget.Power.BGMultiplier), g*tonumber(db.oUF.FocusTarget.Power.BGMultiplier), b*tonumber(db.oUF.FocusTarget.Power.BGMultiplier))
												end,
											order = 4,
										},
									},
								},
								Textures = {
									name = "Texture Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Power.Enable end,
									guiInline = true,
									order = 4,
									args = {
										PowerTex = {
											name = "Texture",
											desc = "Choose your Power Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.FocusTarget.Power.Texture
												end,
											set = function(self, PowerTex)
													db.oUF.FocusTarget.Power.Texture = PowerTex
													oUF_LUI_focustarget.Power:SetStatusBarTexture(LSM:Fetch("statusbar", PowerTex))
												end,
											order = 1,
										},
										PowerTexBG = {
											name = "Background Texture",
											desc = "Choose your Power Background Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.TextureBG,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.FocusTarget.Power.TextureBG
												end,

											set = function(self, PowerTexBG)
													db.oUF.FocusTarget.Power.TextureBG = PowerTexBG
													oUF_LUI_focustarget.Power.bg:SetTexture(LSM:Fetch("statusbar", PowerTexBG))
												end,
											order = 2,
										},
										PowerTexBGAlpha = {
											name = "Background Alpha",
											desc = "Choose the Alpha Value for your Power Background.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.BGAlpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.FocusTarget.Power.BGAlpha end,
											set = function(_, PowerTexBGAlpha) 
													db.oUF.FocusTarget.Power.BGAlpha  = PowerTexBGAlpha
													oUF_LUI_focustarget.Power.bg:SetAlpha(tonumber(PowerTexBGAlpha))
												end,
											order = 3,
										},
										PowerTexBGMultiplier = {
											name = "Background Muliplier",
											desc = "Choose the Multiplier which will be used to generate the BackgroundColor.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Power.BGMultiplier,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.FocusTarget.Power.BGMultiplier end,
											set = function(_, PowerTexBGMultiplier) 
													db.oUF.FocusTarget.Power.BGMultiplier  = PowerTexBGMultiplier
													oUF_LUI_focustarget.Power.bg.multiplier = tonumber(PowerTexBGMultiplier)
												end,
											order = 4,
										},
									},
								},
							},
						},
						Full = {
							name = "Fullbar",
							type = "group",
							order = 3,
							args = {
								EnableFullbar = {
									name = "Enable",
									desc = "Wether you want to use a Fullbar or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Full.Enable end,
									set = function(self,EnableFullbar)
												db.oUF.FocusTarget.Full.Enable = not db.oUF.FocusTarget.Full.Enable
												if EnableFullbar == true then
													oUF_LUI_focustarget.Full:Show()
												else
													oUF_LUI_focustarget.Full:Hide()
												end
											end,
									order = 1,
								},
								General = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Full.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Height = {
											name = "Height",
											desc = "Decide the Height of your Fullbar.\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Full.Height,
											type = "input",
											get = function() return db.oUF.FocusTarget.Full.Height end,
											set = function(self,Height)
														if Height == nil or Height == "" then
															Height = "0"
														end
														db.oUF.FocusTarget.Full.Height = Height
														oUF_LUI_focustarget.Full:SetHeight(tonumber(Height))
													end,
											order = 1,
										},
										Padding = {
											name = "Padding",
											desc = "Choose the Padding between Health & Fullbar.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Full.Padding,
											type = "input",
											get = function() return db.oUF.FocusTarget.Full.Padding end,
											set = function(self,Padding)
													if Padding == nil or Padding == "" then
														Padding = "0"
													end
													db.oUF.FocusTarget.Full.Padding = Padding
													oUF_LUI_focustarget.Full:ClearAllPoints()
													oUF_LUI_focustarget.Full:SetPoint("TOPLEFT", oUF_LUI_focustarget.Health, "BOTTOMLEFT", 0, tonumber(Padding))
													oUF_LUI_focustarget.Full:SetPoint("TOPRIGHT", oUF_LUI_focustarget.Health, "BOTTOMRIGHT", 0, tonumber(Padding))
												end,
											order = 2,
										},
										FullTex = {
											name = "Texture",
											desc = "Choose your Fullbar Texture!\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Full.Texture,
											type = "select",
											dialogControl = "LSM30_Statusbar",
											values = widgetLists.statusbar,
											get = function()
													return db.oUF.FocusTarget.Full.Texture
												end,
											set = function(self, FullTex)
													db.oUF.FocusTarget.Full.Texture = FullTex
													oUF_LUI_focustarget.Full:SetStatusBarTexture(LSM:Fetch("statusbar", FullTex))
												end,
											order = 3,
										},
										FullAlpha = {
											name = "Alpha",
											desc = "Choose the Alpha Value for your Fullbar!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Full.Alpha,
											type = "range",
											min = 0,
											max = 1,
											step = 0.05,
											get = function() return db.oUF.FocusTarget.Full.Alpha end,
											set = function(_, FullAlpha)
													db.oUF.FocusTarget.Full.Alpha = FullAlpha
													oUF_LUI_focustarget.Full:SetAlpha(FullAlpha)
												end,
											order = 4,
										},
										Color = {
											name = "Color",
											desc = "Choose your Fullbar Color.",
											type = "color",
											hasAlpha = true,
											get = function() return db.oUF.FocusTarget.Full.Color.r, db.oUF.FocusTarget.Full.Color.g, db.oUF.FocusTarget.Full.Color.b, db.oUF.FocusTarget.Full.Color.a end,
											set = function(_,r,g,b,a)
													db.oUF.FocusTarget.Full.Color.r = r
													db.oUF.FocusTarget.Full.Color.g = g
													db.oUF.FocusTarget.Full.Color.b = b
													db.oUF.FocusTarget.Full.Color.a = a
													
													oUF_LUI_focustarget.Full:SetStatusBarColor(r, g, b, a)
												end,
											order = 5,
										},
									},
								},
							},
						},
					},
				},
				Texts = {
					name = "Texts",
					type = "group",
					childGroups = "tab",
					disabled = function() return not db.oUF.FocusTarget.Enable end,
					order = 6,
					args = {
						Name = {
							name = "Name",
							type = "group",
							order = 1,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget Name or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.Name.Enable end,
									set = function(self,Enable)
												db.oUF.FocusTarget.Texts.Name.Enable = not db.oUF.FocusTarget.Texts.Name.Enable
												if Enable == true then
													oUF_LUI_focustarget.Info:Show()
												else
													oUF_LUI_focustarget.Info:Hide()
												end
											end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget Name Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.Name.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.Name.Size = FontSize
													oUF_LUI_focustarget.Info:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Name.Font),db.oUF.FocusTarget.Texts.Name.Size,db.oUF.FocusTarget.Texts.Name.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget Name!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.Name.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.Name.Font = Font
													oUF_LUI_focustarget.Info:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Name.Font),db.oUF.FocusTarget.Texts.Name.Size,db.oUF.FocusTarget.Texts.Name.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget Name.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.Name.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.Name.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Info:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Name.Font),db.oUF.FocusTarget.Texts.Name.Size,db.oUF.FocusTarget.Texts.Name.Outline)
												end,
											order = 4,
										},
										NameX = {
											name = "X Value",
											desc = "X Value for your FocusTarget Name.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.X end,
											set = function(self,NameX)
														if NameX == nil or NameX == "" then
															NameX = "0"
														end
														db.oUF.FocusTarget.Texts.Name.X = NameX
														oUF_LUI_focustarget.Info:ClearAllPoints()
														oUF_LUI_focustarget.Info:SetPoint(db.oUF.FocusTarget.Texts.Name.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Name.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Name.X), tonumber(db.oUF.FocusTarget.Texts.Name.Y))
													end,
											order = 5,
										},
										NameY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget Name.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.Y end,
											set = function(self,NameY)
														if NameY == nil or NameY == "" then
															NameY = "0"
														end
														db.oUF.FocusTarget.Texts.Name.Y = NameY
														oUF_LUI_focustarget.Info:ClearAllPoints()
														oUF_LUI_focustarget.Info:SetPoint(db.oUF.FocusTarget.Texts.Name.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Name.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Name.X), tonumber(db.oUF.FocusTarget.Texts.Name.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget Name.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Name.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.Name.Point = positions[Point]
													oUF_LUI_focustarget.Info:ClearAllPoints()
													oUF_LUI_focustarget.Info:SetPoint(db.oUF.FocusTarget.Texts.Name.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Name.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Name.X), tonumber(db.oUF.FocusTarget.Texts.Name.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget Name.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Name.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.Name.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Info:ClearAllPoints()
													oUF_LUI_focustarget.Info:SetPoint(db.oUF.FocusTarget.Texts.Name.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Name.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Name.X), tonumber(db.oUF.FocusTarget.Texts.Name.Y))
												end,
											order = 8,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
									guiInline = true,
									order = 2,
									args = {
										Format = {
											name = "Format",
											desc = "Choose the Format for your FocusTarget Name.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Format,
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											type = "select",
											width = "full",
											values = nameFormat,
											get = function()
													for k, v in pairs(nameFormat) do
														if db.oUF.FocusTarget.Texts.Name.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.FocusTarget.Texts.Name.Format = nameFormat[Format]
												end,
											order = 1,
										},
										Length = {
											name = "Length",
											desc = "Choose the Length of your FocusTarget Name.\n\nShort = 6 Letters\nMedium = 18 Letters\nLong = 36 Letters\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Name.Length,
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											type = "select",
											values = nameLenghts,
											get = function()
													for k, v in pairs(nameLenghts) do
														if db.oUF.FocusTarget.Texts.Name.Length == v then
															return k
														end
													end
												end,
											set = function(self, Length)
													db.oUF.FocusTarget.Texts.Name.Length = nameLenghts[Length]
												end,
											order = 2,
										},
										empty = {
											order = 3,
											width = "full",
											type = "description",
											name = " ",
										},
										ColorNameByClass = {
											name = "Color Name by Class",
											desc = "Wether you want to color the FocusTarget Name by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.ColorNameByClass end,
											set = function(self,ColorNameByClass)
														db.oUF.FocusTarget.Texts.Name.ColorNameByClass = not db.oUF.FocusTarget.Texts.Name.ColorNameByClass
													end,
											order = 4,
										},
										ColorClassByClass = {
											name = "Color Class by Class",
											desc = "Wether you want to color the FocusTarget Class by Class or not.",
											type = "toggle",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.ColorClassByClass end,
											set = function(self,ColorClassByClass)
														db.oUF.FocusTarget.Texts.Name.ColorClassByClass = not db.oUF.FocusTarget.Texts.Name.ColorClassByClass
													end,
											order = 5,
										},
										ColorLevelByDifficulty = {
											name = "Color Level by Difficulty",
											desc = "Wether you want to color the Level by Difficulty or not.",
											type = "toggle",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.ColorLevelByDifficulty end,
											set = function(self,ColorLevelByDifficulty)
														db.oUF.FocusTarget.Texts.Name.ColorLevelByDifficulty = not db.oUF.FocusTarget.Texts.Name.ColorLevelByDifficulty
													end,
											order = 6,
										},
										ShowClassification = {
											name = "Show Classification",
											desc = "Wether you want to show Classifications like Elite, Boss, Rar or not.",
											type = "toggle",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Name.ShowClassification end,
											set = function(self,ShowClassification)
														db.oUF.FocusTarget.Texts.Name.ShowClassification = not db.oUF.FocusTarget.Texts.Name.ShowClassification
													end,
											order = 7,
										},
										ShortClassification = {
											name = "Enable Short Classification",
											desc = "Wether you want to show short Classifications or not.",
											type = "toggle",
											width = "full",
											disabled = function() return not db.oUF.FocusTarget.Texts.Name.ShowClassification end,
											get = function() return db.oUF.FocusTarget.Texts.Name.ShortClassification end,
											set = function(self,ShortClassification)
														db.oUF.FocusTarget.Texts.Name.ShortClassification = not db.oUF.FocusTarget.Texts.Name.ShortClassification
													end,
											order = 8,
										},
									},
								},
							},
						},
						Health = {
							name = "Health",
							type = "group",
							order = 2,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget Health or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.Health.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.Health.Enable = not db.oUF.FocusTarget.Texts.Health.Enable
											if Enable == true then
												oUF_LUI_focustarget.Health.value:Show()
											else
												oUF_LUI_focustarget.Health.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget Health Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.Health.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.Health.Size = FontSize
													oUF_LUI_focustarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Health.Font),db.oUF.FocusTarget.Texts.Health.Size,db.oUF.FocusTarget.Texts.Health.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your FocusTarget Health.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Format,
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.FocusTarget.Texts.Health.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.FocusTarget.Texts.Health.Format = valueFormat[Format]
													print("FocusTarget Health Value Format will change once you gain/lose Health")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget Health!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.Health.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.Health.Font = Font
													oUF_LUI_focustarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Health.Font),db.oUF.FocusTarget.Texts.Health.Size,db.oUF.FocusTarget.Texts.Health.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget Health.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.Health.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.Health.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Health.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Health.Font),db.oUF.FocusTarget.Texts.Health.Size,db.oUF.FocusTarget.Texts.Health.Outline)
												end,
											order = 4,
										},
										HealthX = {
											name = "X Value",
											desc = "X Value for your FocusTarget Health.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Health.X end,
											set = function(self,HealthX)
														if HealthX == nil or HealthX == "" then
															HealthX = "0"
														end
														db.oUF.FocusTarget.Texts.Health.X = HealthX
														oUF_LUI_focustarget.Health.value:ClearAllPoints()
														oUF_LUI_focustarget.Health.value:SetPoint(db.oUF.FocusTarget.Texts.Health.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Health.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Health.X), tonumber(db.oUF.FocusTarget.Texts.Health.Y))
													end,
											order = 5,
										},
										HealthY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget Health.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Health.Y end,
											set = function(self,HealthY)
														if HealthY == nil or HealthY == "" then
															HealthY = "0"
														end
														db.oUF.FocusTarget.Texts.Health.Y = HealthY
														oUF_LUI_focustarget.Health.value:ClearAllPoints()
														oUF_LUI_focustarget.Health.value:SetPoint(db.oUF.FocusTarget.Texts.Health.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Health.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Health.X), tonumber(db.oUF.FocusTarget.Texts.Health.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget Health.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Health.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.Health.Point = positions[Point]
													oUF_LUI_focustarget.Health.value:ClearAllPoints()
													oUF_LUI_focustarget.Health.value:SetPoint(db.oUF.FocusTarget.Texts.Health.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Health.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Health.X), tonumber(db.oUF.FocusTarget.Texts.Health.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget Health.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Health.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Health.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.Health.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Health.value:ClearAllPoints()
													oUF_LUI_focustarget.Health.value:SetPoint(db.oUF.FocusTarget.Texts.Health.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Health.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Health.X), tonumber(db.oUF.FocusTarget.Texts.Health.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Health.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Health.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.Health.ColorClass = not db.oUF.FocusTarget.Texts.Health.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.Health.ColorGradient = false
															db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable = false
															
															print("FocusTarget Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored Health Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Health.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.FocusTarget.Texts.Health.ColorGradient = not db.oUF.FocusTarget.Texts.Health.ColorGradient
														if ColorGradient == true then
															db.oUF.FocusTarget.Texts.Health.ColorClass = false
															db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable = false
															
															print("FocusTarget Health Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget Health Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.Health.ColorClass = false
															db.oUF.FocusTarget.Texts.Health.ColorGradient = false
															
															oUF_LUI_focustarget.Health.value:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.Health.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.Health.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.Health.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget Health Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.Health.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.Health.IndividualColor.r, db.oUF.FocusTarget.Texts.Health.IndividualColor.g, db.oUF.FocusTarget.Texts.Health.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.Health.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.Health.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.Health.IndividualColor.b = b
													
													oUF_LUI_focustarget.Health.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the Health Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.FocusTarget.Texts.Health.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.FocusTarget.Texts.Health.ShowDead = not db.oUF.FocusTarget.Texts.Health.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						Power = {
							name = "Power",
							type = "group",
							order = 3,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget Power or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.Power.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.Power.Enable = not db.oUF.FocusTarget.Texts.Power.Enable
											if Enable == true then
												oUF_LUI_focustarget.Power.value:Show()
											else
												oUF_LUI_focustarget.Power.value:Hide()
											end
										end,
									order = 0,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget Power Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.Power.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.Power.Size = FontSize
													oUF_LUI_focustarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Power.Font),db.oUF.FocusTarget.Texts.Power.Size,db.oUF.FocusTarget.Texts.Power.Outline)
												end,
											order = 1,
										},
										Format = {
											name = "Format",
											desc = "Choose the Format for your FocusTarget Power.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Format,
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											type = "select",
											values = valueFormat,
											get = function()
													for k, v in pairs(valueFormat) do
														if db.oUF.FocusTarget.Texts.Power.Format == v then
															return k
														end
													end
												end,
											set = function(self, Format)
													db.oUF.FocusTarget.Texts.Power.Format = valueFormat[Format]
													print("FocusTarget Power Value Format will change once you gain/lose Power")
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget Power!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.Power.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.Power.Font = Font
													oUF_LUI_focustarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Power.Font),db.oUF.FocusTarget.Texts.Power.Size,db.oUF.FocusTarget.Texts.Power.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget Power.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.Power.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.Power.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Power.value:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.Power.Font),db.oUF.FocusTarget.Texts.Power.Size,db.oUF.FocusTarget.Texts.Power.Outline)
												end,
											order = 4,
										},
										PowerX = {
											name = "X Value",
											desc = "X Value for your FocusTarget Power.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Power.X end,
											set = function(self,PowerX)
														if PowerX == nil or PowerX == "" then
															PowerX = "0"
														end
														db.oUF.FocusTarget.Texts.Power.X = PowerX
														oUF_LUI_focustarget.Power.value:ClearAllPoints()
														oUF_LUI_focustarget.Power.value:SetPoint(db.oUF.FocusTarget.Texts.Power.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Power.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Power.X), tonumber(db.oUF.FocusTarget.Texts.Power.Y))
													end,
											order = 5,
										},
										PowerY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget Power.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.Power.Y end,
											set = function(self,PowerY)
														if PowerY == nil or PowerY == "" then
															PowerY = "0"
														end
														db.oUF.FocusTarget.Texts.Power.Y = PowerY
														oUF_LUI_focustarget.Power.value:ClearAllPoints()
														oUF_LUI_focustarget.Power.value:SetPoint(db.oUF.FocusTarget.Texts.Power.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Power.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Power.X), tonumber(db.oUF.FocusTarget.Texts.Power.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget Power.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Power.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.Power.Point = positions[Point]
													oUF_LUI_focustarget.Power.value:ClearAllPoints()
													oUF_LUI_focustarget.Power.value:SetPoint(db.oUF.FocusTarget.Texts.Power.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Power.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Power.X), tonumber(db.oUF.FocusTarget.Texts.Power.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget Power.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.Power.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.Power.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.Power.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Power.value:ClearAllPoints()
													oUF_LUI_focustarget.Power.value:SetPoint(db.oUF.FocusTarget.Texts.Power.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.Power.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.Power.X), tonumber(db.oUF.FocusTarget.Texts.Power.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.Power.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Power.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.Power.ColorClass = not db.oUF.FocusTarget.Texts.Power.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.Power.ColorType = false
															db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable = false
															
															print("FocusTarget Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Powertype colored Power Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Power.ColorType end,
											set = function(self,ColorType)
														db.oUF.FocusTarget.Texts.Power.ColorType = not db.oUF.FocusTarget.Texts.Power.ColorType
														if ColorType == true then
															db.oUF.FocusTarget.Texts.Power.ColorClass = false
															db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable = false
															
															print("FocusTarget Power Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget Power Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.Power.ColorClass = false
															db.oUF.FocusTarget.Texts.Power.ColorType = false
															
															oUF_LUI_focustarget.Power.value:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.Power.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.Power.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.Power.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget Power Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.Power.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.Power.IndividualColor.r, db.oUF.FocusTarget.Texts.Power.IndividualColor.g, db.oUF.FocusTarget.Texts.Power.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.Power.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.Power.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.Power.IndividualColor.b = b
													
													oUF_LUI_focustarget.Power.value:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthPercent = {
							name = "HealthPercent",
							type = "group",
							order = 4,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget HealthPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.HealthPercent.Enable = not db.oUF.FocusTarget.Texts.HealthPercent.Enable
											if Enable == true then
												oUF_LUI_focustarget.Health.valuePercent:Show()
											else
												oUF_LUI_focustarget.Health.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget HealthPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.HealthPercent.Size = FontSize
													oUF_LUI_focustarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthPercent.Font),db.oUF.FocusTarget.Texts.HealthPercent.Size,db.oUF.FocusTarget.Texts.HealthPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show FocusTarget HealthPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.FocusTarget.Texts.HealthPercent.ShowAlways = not db.oUF.FocusTarget.Texts.HealthPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget HealthPercent!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.HealthPercent.Font = Font
													oUF_LUI_focustarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthPercent.Font),db.oUF.FocusTarget.Texts.HealthPercent.Size,db.oUF.FocusTarget.Texts.HealthPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.HealthPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.HealthPercent.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Health.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthPercent.Font),db.oUF.FocusTarget.Texts.HealthPercent.Size,db.oUF.FocusTarget.Texts.HealthPercent.Outline)
												end,
											order = 4,
										},
										HealthPercentX = {
											name = "X Value",
											desc = "X Value for your FocusTarget HealthPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.X end,
											set = function(self,HealthPercentX)
														if HealthPercentX == nil or HealthPercentX == "" then
															HealthPercentX = "0"
														end
														db.oUF.FocusTarget.Texts.HealthPercent.X = HealthPercentX
														oUF_LUI_focustarget.Health.valuePercent:ClearAllPoints()
														oUF_LUI_focustarget.Health.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.HealthPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthPercent.X), tonumber(db.oUF.FocusTarget.Texts.HealthPercent.Y))
													end,
											order = 5,
										},
										HealthPercentY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget HealthPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.Y end,
											set = function(self,HealthPercentY)
														if HealthPercentY == nil or HealthPercentY == "" then
															HealthPercentY = "0"
														end
														db.oUF.FocusTarget.Texts.HealthPercent.Y = HealthPercentY
														oUF_LUI_focustarget.Health.valuePercent:ClearAllPoints()
														oUF_LUI_focustarget.Health.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.HealthPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthPercent.X), tonumber(db.oUF.FocusTarget.Texts.HealthPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.HealthPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.HealthPercent.Point = positions[Point]
													oUF_LUI_focustarget.Health.valuePercent:ClearAllPoints()
													oUF_LUI_focustarget.Health.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.HealthPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthPercent.X), tonumber(db.oUF.FocusTarget.Texts.HealthPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget HealthPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Health.valuePercent:ClearAllPoints()
													oUF_LUI_focustarget.Health.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.HealthPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthPercent.X), tonumber(db.oUF.FocusTarget.Texts.HealthPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.HealthPercent.ColorClass = not db.oUF.FocusTarget.Texts.HealthPercent.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.HealthPercent.ColorGradient = false
															db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("FocusTarget HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.FocusTarget.Texts.HealthPercent.ColorGradient = not db.oUF.FocusTarget.Texts.HealthPercent.ColorGradient
														if ColorGradient == true then
															db.oUF.FocusTarget.Texts.HealthPercent.ColorClass = false
															db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable = false
															
															print("FocusTarget HealthPercent Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget HealthPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.HealthPercent.ColorClass = false
															db.oUF.FocusTarget.Texts.HealthPercent.ColorGradient = false
															
															oUF_LUI_focustarget.Health.valuePercent:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget HealthPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.r, db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.g, db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.HealthPercent.IndividualColor.b = b
													
													oUF_LUI_focustarget.Health.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
								Settings = {
									name = "Settings",
									type = "group",
									guiInline = true,
									order = 3,
									args = {
										ShowDead = {
											name = "Show Dead/AFK/Disconnected Information",
											desc = "Wether you want to switch the HealthPercent Value to Dead/AFK/Disconnected or not.",
											type = "toggle",
											width = "full",
											get = function() return db.oUF.FocusTarget.Texts.HealthPercent.ShowDead end,
											set = function(self,ShowDead)
														db.oUF.FocusTarget.Texts.HealthPercent.ShowDead = not db.oUF.FocusTarget.Texts.HealthPercent.ShowDead
													end,
											order = 1,
										},
									},
								},
							},
						},
						PowerPercent = {
							name = "PowerPercent",
							type = "group",
							order = 5,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget PowerPercent or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.PowerPercent.Enable = not db.oUF.FocusTarget.Texts.PowerPercent.Enable
											if Enable == true then
												oUF_LUI_focustarget.Power.valuePercent:Show()
											else
												oUF_LUI_focustarget.Power.valuePercent:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget PowerPercent Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.PowerPercent.Size = FontSize
													oUF_LUI_focustarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerPercent.Font),db.oUF.FocusTarget.Texts.PowerPercent.Size,db.oUF.FocusTarget.Texts.PowerPercent.Outline)
												end,
											order = 1,
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show FocusTarget PowerPercent or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.FocusTarget.Texts.PowerPercent.ShowAlways = not db.oUF.FocusTarget.Texts.PowerPercent.ShowAlways
												end,
											order = 2,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget PowerPercent!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.PowerPercent.Font = Font
													oUF_LUI_focustarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerPercent.Font),db.oUF.FocusTarget.Texts.PowerPercent.Size,db.oUF.FocusTarget.Texts.PowerPercent.Outline)
												end,
											order = 3,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.PowerPercent.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.PowerPercent.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Power.valuePercent:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerPercent.Font),db.oUF.FocusTarget.Texts.PowerPercent.Size,db.oUF.FocusTarget.Texts.PowerPercent.Outline)
												end,
											order = 4,
										},
										PowerPercentX = {
											name = "X Value",
											desc = "X Value for your FocusTarget PowerPercent.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.X end,
											set = function(self,PowerPercentX)
														if PowerPercentX == nil or PowerPercentX == "" then
															PowerPercentX = "0"
														end
														db.oUF.FocusTarget.Texts.PowerPercent.X = PowerPercentX
														oUF_LUI_focustarget.Power.valuePercent:ClearAllPoints()
														oUF_LUI_focustarget.Power.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.PowerPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerPercent.X), tonumber(db.oUF.FocusTarget.Texts.PowerPercent.Y))
													end,
											order = 5,

										},
										PowerPercentY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget PowerPercent.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.Y end,
											set = function(self,PowerPercentY)
														if PowerPercentY == nil or PowerPercentY == "" then
															PowerPercentY = "0"
														end
														db.oUF.FocusTarget.Texts.PowerPercent.Y = PowerPercentY
														oUF_LUI_focustarget.Power.valuePercent:ClearAllPoints()
														oUF_LUI_focustarget.Power.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.PowerPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerPercent.X), tonumber(db.oUF.FocusTarget.Texts.PowerPercent.Y))
													end,
											order = 6,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.PowerPercent.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.PowerPercent.Point = positions[Point]
													oUF_LUI_focustarget.Power.valuePercent:ClearAllPoints()
													oUF_LUI_focustarget.Power.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.PowerPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerPercent.X), tonumber(db.oUF.FocusTarget.Texts.PowerPercent.Y))
												end,
											order = 7,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget PowerPercent.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerPercent.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Power.valuePercent:ClearAllPoints()
													oUF_LUI_focustarget.Power.valuePercent:SetPoint(db.oUF.FocusTarget.Texts.PowerPercent.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerPercent.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerPercent.X), tonumber(db.oUF.FocusTarget.Texts.PowerPercent.Y))
												end,
											order = 8,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.PowerPercent.ColorClass = not db.oUF.FocusTarget.Texts.PowerPercent.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.PowerPercent.ColorType = false
															db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("FocusTarget PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerPercent Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.ColorType end,
											set = function(self,ColorType)
														db.oUF.FocusTarget.Texts.PowerPercent.ColorType = not db.oUF.FocusTarget.Texts.PowerPercent.ColorType
														if ColorType == true then
															db.oUF.FocusTarget.Texts.PowerPercent.ColorClass = false
															db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable = false
															
															print("FocusTarget PowerPercent Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget PowerPercent Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.PowerPercent.ColorClass = false
															db.oUF.FocusTarget.Texts.PowerPercent.ColorType = false
															
															oUF_LUI_focustarget.Power.valuePercent:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget PowerPercent Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.r, db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.g, db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.PowerPercent.IndividualColor.b = b
													
													oUF_LUI_focustarget.Power.valuePercent:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						HealthMissing = {
							name = "HealthMissing",
							type = "group",
							order = 6,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget HealthMissing or not.",
									type = "toggle",

									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.HealthMissing.Enable = not db.oUF.FocusTarget.Texts.HealthMissing.Enable
											if Enable == true then
												oUF_LUI_focustarget.Health.valueMissing:Show()
											else
												oUF_LUI_focustarget.Health.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget HealthMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.HealthMissing.Size = FontSize
													oUF_LUI_focustarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthMissing.Font),db.oUF.FocusTarget.Texts.HealthMissing.Size,db.oUF.FocusTarget.Texts.HealthMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",
											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show FocusTarget HealthMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.FocusTarget.Texts.HealthMissing.ShowAlways = not db.oUF.FocusTarget.Texts.HealthMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.FocusTarget.Texts.HealthMissing.ShortValue = not db.oUF.FocusTarget.Texts.HealthMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget HealthMissing!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.HealthMissing.Font = Font
													oUF_LUI_focustarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthMissing.Font),db.oUF.FocusTarget.Texts.HealthMissing.Size,db.oUF.FocusTarget.Texts.HealthMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.HealthMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.HealthMissing.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Health.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.HealthMissing.Font),db.oUF.FocusTarget.Texts.HealthMissing.Size,db.oUF.FocusTarget.Texts.HealthMissing.Outline)
												end,
											order = 6,
										},
										HealthMissingX = {
											name = "X Value",
											desc = "X Value for your FocusTarget HealthMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.X end,
											set = function(self,HealthMissingX)
														if HealthMissingX == nil or HealthMissingX == "" then
															HealthMissingX = "0"
														end
														db.oUF.FocusTarget.Texts.HealthMissing.X = HealthMissingX
														oUF_LUI_focustarget.Health.valueMissing:ClearAllPoints()
														oUF_LUI_focustarget.Health.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.HealthMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthMissing.X), tonumber(db.oUF.FocusTarget.Texts.HealthMissing.Y))
													end,
											order = 7,
										},
										HealthMissingY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget HealthMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.Y end,
											set = function(self,HealthMissingY)
														if HealthMissingY == nil or HealthMissingY == "" then
															HealthMissingY = "0"
														end
														db.oUF.FocusTarget.Texts.HealthMissing.Y = HealthMissingY
														oUF_LUI_focustarget.Health.valueMissing:ClearAllPoints()
														oUF_LUI_focustarget.Health.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.HealthMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthMissing.X), tonumber(db.oUF.FocusTarget.Texts.HealthMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.HealthMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.HealthMissing.Point = positions[Point]
													oUF_LUI_focustarget.Health.valueMissing:ClearAllPoints()
													oUF_LUI_focustarget.Health.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.HealthMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthMissing.X), tonumber(db.oUF.FocusTarget.Texts.HealthMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget HealthMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.HealthMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Health.valueMissing:ClearAllPoints()
													oUF_LUI_focustarget.Health.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.HealthMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.HealthMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.HealthMissing.X), tonumber(db.oUF.FocusTarget.Texts.HealthMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.HealthMissing.ColorClass = not db.oUF.FocusTarget.Texts.HealthMissing.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.HealthMissing.ColorGradient = false
															db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("FocusTarget HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 1,
										},
										ColorGradient = {
											name = "Color Gradient",
											desc = "Wether you want to use Gradient colored HealthMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.ColorGradient end,
											set = function(self,ColorGradient)
														db.oUF.FocusTarget.Texts.HealthMissing.ColorGradient = not db.oUF.FocusTarget.Texts.HealthMissing.ColorGradient
														if ColorGradient == true then
															db.oUF.FocusTarget.Texts.HealthMissing.ColorClass = false
															db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable = false
															
															print("FocusTarget HealthMissing Value Color will change once you gain/lose Health")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget HealthMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.HealthMissing.ColorClass = false
															db.oUF.FocusTarget.Texts.HealthMissing.ColorGradient = false
															
															oUF_LUI_focustarget.Health.valueMissing:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget HealthMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.r, db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.g, db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.HealthMissing.IndividualColor.b = b
													
													oUF_LUI_focustarget.Health.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
						PowerMissing = {
							name = "PowerMissing",
							type = "group",
							order = 7,
							args = {
								Enable = {
									name = "Enable",
									desc = "Wether you want to show the FocusTarget PowerMissing or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
									set = function(self,Enable)
											db.oUF.FocusTarget.Texts.PowerMissing.Enable = not db.oUF.FocusTarget.Texts.PowerMissing.Enable
											if Enable == true then
												oUF_LUI_focustarget.Power.valueMissing:Show()
											else
												oUF_LUI_focustarget.Power.valueMissing:Hide()
											end
										end,
									order = 1,
								},
								FontSettings = {
									name = "Font Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 1,
									args = {
										FontSize = {
											name = "Size",
											desc = "Choose your FocusTarget PowerMissing Fontsize!\n Default: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.Size,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											type = "range",
											min = 1,
											max = 40,
											step = 1,
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.Size end,
											set = function(_, FontSize)
													db.oUF.FocusTarget.Texts.PowerMissing.Size = FontSize
													oUF_LUI_focustarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerMissing.Font),db.oUF.FocusTarget.Texts.PowerMissing.Size,db.oUF.FocusTarget.Texts.PowerMissing.Outline)
												end,
											order = 1,
										},
										empty = {
											order = 2,
											width = "full",

											type = "description",
											name = " ",
										},
										ShowAlways = {
											name = "Show Always",
											desc = "Always show FocusTarget PowerMissing or just if the Unit has no MaxHP.",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.ShowAlways end,
											set = function(self,ShowAlways)
													db.oUF.FocusTarget.Texts.PowerMissing.ShowAlways = not db.oUF.FocusTarget.Texts.PowerMissing.ShowAlways
												end,
											order = 3,
										},
										ShortValue = {
											name = "Short Value",
											desc = "Show a Short or the Normal Value of the Missing HP",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.ShortValue end,
											set = function(self,ShortValue)
													db.oUF.FocusTarget.Texts.PowerMissing.ShortValue = not db.oUF.FocusTarget.Texts.PowerMissing.ShortValue
												end,
											order = 4,
										},
										Font = {
											name = "Font",
											desc = "Choose your Font for FocusTarget PowerMissing!\n\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.Font,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											type = "select",
											dialogControl = "LSM30_Font",
											values = widgetLists.font,
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.Font end,
											set = function(self, Font)
													db.oUF.FocusTarget.Texts.PowerMissing.Font = Font
													oUF_LUI_focustarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerMissing.Font),db.oUF.FocusTarget.Texts.PowerMissing.Size,db.oUF.FocusTarget.Texts.PowerMissing.Outline)
												end,
											order = 5,
										},
										FontFlag = {
											name = "Font Flag",
											desc = "Choose the Font Flag for your FocusTarget PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.Outline,
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											type = "select",
											values = fontflags,
											get = function()
													for k, v in pairs(fontflags) do
														if db.oUF.FocusTarget.Texts.PowerMissing.Outline == v then
															return k
														end
													end
												end,
											set = function(self, FontFlag)
													db.oUF.FocusTarget.Texts.PowerMissing.Outline = fontflags[FontFlag]
													oUF_LUI_focustarget.Power.valueMissing:SetFont(LSM:Fetch("font", db.oUF.FocusTarget.Texts.PowerMissing.Font),db.oUF.FocusTarget.Texts.PowerMissing.Size,db.oUF.FocusTarget.Texts.PowerMissing.Outline)
												end,
											order = 6,
										},
										PowerMissingX = {
											name = "X Value",
											desc = "X Value for your FocusTarget PowerMissing.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.X,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.X end,
											set = function(self,PowerMissingX)
														if PowerMissingX == nil or PowerMissingX == "" then
															PowerMissingX = "0"
														end
														db.oUF.FocusTarget.Texts.PowerMissing.X = PowerMissingX
														oUF_LUI_focustarget.Power.valueMissing:ClearAllPoints()
														oUF_LUI_focustarget.Power.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.PowerMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerMissing.X), tonumber(db.oUF.FocusTarget.Texts.PowerMissing.Y))
													end,
											order = 7,
										},
										PowerMissingY = {
											name = "Y Value",
											desc = "Y Value for your FocusTarget PowerMissing.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.Y,
											type = "input",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.Y end,
											set = function(self,PowerMissingY)
														if PowerMissingY == nil or PowerMissingY == "" then
															PowerMissingY = "0"
														end
														db.oUF.FocusTarget.Texts.PowerMissing.Y = PowerMissingY
														oUF_LUI_focustarget.Power.valueMissing:ClearAllPoints()
														oUF_LUI_focustarget.Power.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.PowerMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerMissing.X), tonumber(db.oUF.FocusTarget.Texts.PowerMissing.Y))
													end,
											order = 8,
										},
										Point = {
											name = "Point",
											desc = "Choose the Position for your FocusTarget PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.Point,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.PowerMissing.Point == v then
															return k
														end
													end
												end,
											set = function(self, Point)
													db.oUF.FocusTarget.Texts.PowerMissing.Point = positions[Point]
													oUF_LUI_focustarget.Power.valueMissing:ClearAllPoints()
													oUF_LUI_focustarget.Power.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.PowerMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerMissing.X), tonumber(db.oUF.FocusTarget.Texts.PowerMissing.Y))
												end,
											order = 9,
										},
										RelativePoint = {
											name = "RelativePoint",
											desc = "Choose the RelativePoint for your FocusTarget PowerMissing.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Texts.PowerMissing.RelativePoint,
											type = "select",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
											values = positions,
											get = function()
													for k, v in pairs(positions) do
														if db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint == v then
															return k
														end
													end
												end,
											set = function(self, RelativePoint)
													db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint = positions[RelativePoint]
													oUF_LUI_focustarget.Power.valueMissing:ClearAllPoints()
													oUF_LUI_focustarget.Power.valueMissing:SetPoint(db.oUF.FocusTarget.Texts.PowerMissing.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Texts.PowerMissing.RelativePoint, tonumber(db.oUF.FocusTarget.Texts.PowerMissing.X), tonumber(db.oUF.FocusTarget.Texts.PowerMissing.Y))
												end,
											order = 10,
										},
									},
								},
								Colors = {
									name = "Color Settings",
									type = "group",
									disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.Enable end,
									guiInline = true,
									order = 2,
									args = {
										ClassColor = {
											name = "Color by Class",
											desc = "Wether you want to use class colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.ColorClass end,
											set = function(self,ClassColor)
														db.oUF.FocusTarget.Texts.PowerMissing.ColorClass = not db.oUF.FocusTarget.Texts.PowerMissing.ColorClass
														if ClassColor == true then
															db.oUF.FocusTarget.Texts.PowerMissing.ColorType = false
															db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("FocusTarget PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 1,
										},
										ColorType = {
											name = "Color by Type",
											desc = "Wether you want to use Type colored PowerMissing Value or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.ColorType end,
											set = function(self,ColorType)
														db.oUF.FocusTarget.Texts.PowerMissing.ColorType = not db.oUF.FocusTarget.Texts.PowerMissing.ColorType
														if ColorType == true then
															db.oUF.FocusTarget.Texts.PowerMissing.ColorClass = false
															db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable = false
															
															print("FocusTarget PowerMissing Value Color will change once you gain/lose Power")
														end
													end,
											order = 2,
										},
										IndividualColor = {
											name = "Individual Color",
											desc = "Wether you want to use an individual FocusTarget PowerMissing Value Color or not.",
											type = "toggle",
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable end,
											set = function(self,IndividualColor)
														db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable = not db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable
														if IndividualColor == true then
															db.oUF.FocusTarget.Texts.PowerMissing.ColorClass = false
															db.oUF.FocusTarget.Texts.PowerMissing.ColorType = false
															
															oUF_LUI_focustarget.Power.valueMissing:SetTextColor(tonumber(db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.r),tonumber(db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.g),tonumber(db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.b))
														end
													end,
											order = 3,
										},
										Color = {
											name = "Individual Color",
											desc = "Choose an individual FocusTarget PowerMissing Value Color.\n\nNote:\nYou have to reload the UI.\nType /rl",
											type = "color",
											disabled = function() return not db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.Enable end,
											hasAlpha = false,
											get = function() return db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.r, db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.g, db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.b end,
											set = function(_,r,g,b)
													db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.r = r
													db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.g = g
													db.oUF.FocusTarget.Texts.PowerMissing.IndividualColor.b = b
													
													oUF_LUI_focustarget.Power.valueMissing:SetTextColor(r,g,b)
												end,
											order = 4,
										},
									},
								},
							},
						},
					},
				},
				Portrait = {
					name = "Portrait",
					type = "group",
					disabled = function() return not db.oUF.FocusTarget.Enable end,
					order = 7,
					args = {
						EnablePortrait = {
							name = "Enable",
							desc = "Wether you want to show the Portrait or not.",
							type = "toggle",
							width = "full",
							get = function() return db.oUF.FocusTarget.Portrait.Enable end,
							set = function(self,EnablePortrait)
										db.oUF.FocusTarget.Portrait.Enable = not db.oUF.FocusTarget.Portrait.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 1,
						},
						PortraitWidth = {
							name = "Width",
							desc = "Choose the Width for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.FocusTarget.Portrait.Enable end,
							get = function() return db.oUF.FocusTarget.Portrait.Width end,
							set = function(self,PortraitWidth)
										if PortraitWidth == nil or PortraitWidth == "" then
											PortraitWidth = "0"
										end
										db.oUF.FocusTarget.Portrait.Width = PortraitWidth
										oUF_LUI_focustarget.Portrait:SetWidth(tonumber(PortraitWidth))
									end,
							order = 2,
						},
						PortraitHeight = {
							name = "Height",
							desc = "Choose the Height for your Portrait.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Portrait.Width,
							type = "input",
							disabled = function() return not db.oUF.FocusTarget.Portrait.Enable end,
							get = function() return db.oUF.FocusTarget.Portrait.Height end,
							set = function(self,PortraitHeight)
										if PortraitHeight == nil or PortraitHeight == "" then
											PortraitHeight = "0"
										end
										db.oUF.FocusTarget.Portrait.Height = PortraitHeight
										oUF_LUI_focustarget.Portrait:SetHeight(tonumber(PortraitHeight))
									end,
							order = 3,
						},
						PortraitX = {
							name = "X Value",
							desc = "X Value for your Portrait.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Portrait.X,
							type = "input",
							disabled = function() return not db.oUF.FocusTarget.Portrait.Enable end,
							get = function() return db.oUF.FocusTarget.Portrait.X end,
							set = function(self,PortraitX)
										if PortraitX == nil or PortraitX == "" then
											PortraitX = "0"
										end
										db.oUF.FocusTarget.Portrait.X = PortraitX
										oUF_LUI_focustarget.Portrait:SetPoint("TOPLEFT", oUF_LUI_focustarget.Health, "TOPLEFT", PortraitX, db.oUF.FocusTarget.Portrait.Y)
									end,
							order = 4,
						},
						PortraitY = {
							name = "Y Value",
							desc = "Y Value for your Portrait.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Portrait.Y,
							type = "input",
							disabled = function() return not db.oUF.FocusTarget.Portrait.Enable end,
							get = function() return db.oUF.FocusTarget.Portrait.Y end,
							set = function(self,PortraitY)
										if PortraitY == nil or PortraitY == "" then
											PortraitY = "0"
										end
										db.oUF.FocusTarget.Portrait.Y = PortraitY
										oUF_LUI_focustarget.Portrait:SetPoint("TOPLEFT", oUF_LUI_focustarget.Health, "TOPLEFT", db.oUF.FocusTarget.Portrait.X, PortraitY)
									end,
							order = 5,
						},
					},
				},
				Icons = {
					name = "Icons",
					type = "group",
					disabled = function() return not db.oUF.FocusTarget.Enable end,
					order = 8,
					childGroups = "tab",
					args = {
						Lootmaster = {
							name = "Lootmaster",
							type = "group",
							order = 1,
							args = {
								LootMasterEnable = {
									name = "Enable",
									desc = "Wether you want to show the LootMaster Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									set = function(self,LootMasterEnable)
												db.oUF.FocusTarget.Icons.Lootmaster.Enable = not db.oUF.FocusTarget.Icons.Lootmaster.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LootMasterX = {
									name = "X Value",
									desc = "X Value for your LootMaster Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Lootmaster.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Lootmaster.X end,
									set = function(self,LootMasterX)
												if LootMasterX == nil or LootMasterX == "" then
													LootMasterX = "0"
												end
												db.oUF.FocusTarget.Icons.Lootmaster.X = LootMasterX
												oUF_LUI_focustarget.MasterLooter:ClearAllPoints()
												oUF_LUI_focustarget.MasterLooter:SetPoint(db.oUF.FocusTarget.Icons.Lootmaster.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Lootmaster, tonumber(LootMasterX), tonumber(db.oUF.FocusTarget.Icons.Lootmaster.Y))
											end,
									order = 2,
								},
								LootMasterY = {
									name = "Y Value",
									desc = "Y Value for your LootMaster Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Lootmaster.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Lootmaster.Y end,
									set = function(self,LootMasterY)
												if LootMasterY == nil or LootMasterY == "" then
													LootMasterY = "0"
												end
												db.oUF.FocusTarget.Icons.Lootmaster.Y = LootMasterY
												oUF_LUI_focustarget.MasterLooter:ClearAllPoints()
												oUF_LUI_focustarget.MasterLooter:SetPoint(db.oUF.FocusTarget.Icons.Lootmaster.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Lootmaster, tonumber(db.oUF.FocusTarget.Icons.Lootmaster.X), tonumber(LootMasterY))
											end,
									order = 3,
								},
								LootMasterPoint = {
									name = "Position",
									desc = "Choose the Position for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Lootmaster.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Lootmaster.Point == v then
													return k
												end
											end
										end,
									set = function(self, LootMasterPoint)
											db.oUF.FocusTarget.Icons.Lootmaster.Point = positions[LootMasterPoint]
											oUF_LUI_focustarget.MasterLooter:ClearAllPoints()
											oUF_LUI_focustarget.MasterLooter:SetPoint(db.oUF.FocusTarget.Icons.Lootmaster.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Lootmaster.Point, tonumber(db.oUF.FocusTarget.Icons.Lootmaster.X), tonumber(db.oUF.FocusTarget.Icons.Lootmaster.X))
										end,
									order = 4,
								},
								LootMasterSize = {
									name = "Size",
									desc = "Choose a size for your LootMaster Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Lootmaster.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Lootmaster.Size end,
									set = function(_, LootMasterSize) 
											db.oUF.FocusTarget.Icons.Lootmaster.Size = LootMasterSize
											oUF_LUI_focustarget.MasterLooter:SetHeight(LootMasterSize)
											oUF_LUI_focustarget.MasterLooter:SetWidth(LootMasterSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.Lootmaster.Enable end,
									desc = "Toggles the LootMaster Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.MasterLooter:IsShown() then oUF_LUI_focustarget.MasterLooter:Hide() else oUF_LUI_focustarget.MasterLooter:Show() end end
								},
							},
						},
						Leader = {
							name = "Leader",
							type = "group",
							order = 2,
							args = {
								LeaderEnable = {
									name = "Enable",
									desc = "Wether you want to show the Leader Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Leader.Enable end,
									set = function(self,LeaderEnable)
												db.oUF.FocusTarget.Icons.Leader.Enable = not db.oUF.FocusTarget.Icons.Leader.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								LeaderX = {
									name = "X Value",
									desc = "X Value for your Leader Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Leader.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Leader.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Leader.X end,
									set = function(self,LeaderX)
												if LeaderX == nil or LeaderX == "" then
													LeaderX = "0"
												end
												db.oUF.FocusTarget.Icons.Leader.X = LeaderX
												oUF_LUI_focustarget.Leader:ClearAllPoints()
												oUF_LUI_focustarget.Leader:SetPoint(db.oUF.FocusTarget.Icons.Leader.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Leader.Point, tonumber(LeaderX), tonumber(db.oUF.FocusTarget.Icons.Leader.Y))
											end,
									order = 2,
								},
								LeaderY = {
									name = "Y Value",
									desc = "Y Value for your Leader Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Leader.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Leader.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Leader.Y end,
									set = function(self,LeaderY)
												if LeaderY == nil or LeaderY == "" then
													LeaderY = "0"
												end
												db.oUF.FocusTarget.Icons.Leader.Y = LeaderY
												oUF_LUI_focustarget.Leader:ClearAllPoints()
												oUF_LUI_focustarget.Leader:SetPoint(db.oUF.FocusTarget.Icons.Leader.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Leader.Point, tonumber(db.oUF.FocusTarget.Icons.Leader.X), tonumber(LeaderY))
											end,
									order = 3,
								},
								LeaderPoint = {
									name = "Position",
									desc = "Choose the Position for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Leader.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Leader.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Leader.Point == v then
													return k
												end
											end
										end,
									set = function(self, LeaderPoint)
											db.oUF.FocusTarget.Icons.Leader.Point = positions[LeaderPoint]
											oUF_LUI_focustarget.Leader:ClearAllPoints()
											oUF_LUI_focustarget.Leader:SetPoint(db.oUF.FocusTarget.Icons.Leader.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Leader.Point, tonumber(db.oUF.FocusTarget.Icons.Leader.X), tonumber(db.oUF.FocusTarget.Icons.Leader.X))
										end,
									order = 4,
								},
								LeaderSize = {
									name = "Size",
									desc = "Choose your Size for your Leader Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Leader.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.Leader.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Leader.Size end,
									set = function(_, LeaderSize) 
											db.oUF.FocusTarget.Icons.Leader.Size = LeaderSize
											oUF_LUI_focustarget.Leader:SetHeight(LeaderSize)
											oUF_LUI_focustarget.Leader:SetWidth(LeaderSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.Leader.Enable end,
									desc = "Toggles the Leader Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.Leader:IsShown() then oUF_LUI_focustarget.Leader:Hide() else oUF_LUI_focustarget.Leader:Show() end end
								},
							},
						},
						LFDRole = {
							name = "LFDRole",
							type = "group",
							order = 3,
							args = {
								RoleEnable = {
									name = "Enable",
									desc = "Wether you want to show the Group Role Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Role.Enable end,
									set = function(self,RoleEnable)
												db.oUF.FocusTarget.Icons.Role.Enable = not db.oUF.FocusTarget.Icons.Role.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RoleX = {
									name = "X Value",
									desc = "X Value for your Group Role Icon Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Role.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Role.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Role.X end,
									set = function(self,RoleX)
												if RoleX == nil or RoleX == "" then
													RoleX = "0"
												end
												db.oUF.FocusTarget.Icons.Role.X = RoleX
												oUF_LUI_focustarget.LFDRole:ClearAllPoints()
												oUF_LUI_focustarget.LFDRole:SetPoint(db.oUF.FocusTarget.Icons.Role.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Role.Point, tonumber(RoleX), tonumber(db.oUF.FocusTarget.Icons.Role.Y))
											end,
									order = 2,
								},
								RoleY = {
									name = "Y Value",
									desc = "Y Value for your Role Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Role.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Role.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Role.Y end,
									set = function(self,RoleY)
												if RoleY == nil or RoleY == "" then
													RoleY = "0"
												end
												db.oUF.FocusTarget.Icons.Role.Y = RoleY
												oUF_LUI_focustarget.LFDRole:ClearAllPoints()
												oUF_LUI_focustarget.LFDRole:SetPoint(db.oUF.FocusTarget.Icons.Role.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Role.Point, tonumber(db.oUF.FocusTarget.Icons.Role.X), tonumber(RoleY))
											end,
									order = 3,
								},
								RolePoint = {
									name = "Position",
									desc = "Choose the Position for your Role Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Role.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Role.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Role.Point == v then
													return k
												end
											end
										end,
									set = function(self, RolePoint)
											db.oUF.FocusTarget.Icons.Role.Point = positions[RolePoint]
											oUF_LUI_focustarget.LFDRole:ClearAllPoints()
											oUF_LUI_focustarget.LFDRole:SetPoint(db.oUF.FocusTarget.Icons.Role.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Role.Point, tonumber(db.oUF.FocusTarget.Icons.Role.X), tonumber(db.oUF.FocusTarget.Icons.Role.X))
										end,
									order = 4,
								},
								RoleSize = {
									name = "Size",
									desc = "Choose a Size for your Group Role Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Role.Size,
									type = "range",
									min = 5,
									max = 100,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.Role.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Role.Size end,
									set = function(_, RoleSize) 
											db.oUF.FocusTarget.Icons.Role.Size = RoleSize
											oUF_LUI_focustarget.LFDRole:SetHeight(RoleSize)
											oUF_LUI_focustarget.LFDRole:SetWidth(RoleSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.Role.Enable end,
									desc = "Toggles the LFDRole Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.LFDRole:IsShown() then oUF_LUI_focustarget.LFDRole:Hide() else oUF_LUI_focustarget.LFDRole:Show() end end
								},
							},
						},
						Raid = {
							name = "RaidIcon",
							type = "group",
							order = 4,
							args = {
								RaidEnable = {
									name = "Enable",
									desc = "Wether you want to show the Raid Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Raid.Enable end,
									set = function(self,RaidEnable)
												db.oUF.FocusTarget.Icons.Raid.Enable = not db.oUF.FocusTarget.Icons.Raid.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RaidX = {
									name = "X Value",
									desc = "X Value for your Raid Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Raid.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Raid.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Raid.X end,
									set = function(self,RaidX)
												if RaidX == nil or RaidX == "" then
													RaidX = "0"
												end
												db.oUF.FocusTarget.Icons.Raid.X = RaidX
												oUF_LUI_focustarget.RaidIcon:ClearAllPoints()
												oUF_LUI_focustarget.RaidIcon:SetPoint(db.oUF.FocusTarget.Icons.Raid.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Raid.Point, tonumber(RaidX), tonumber(db.oUF.FocusTarget.Icons.Raid.Y))
											end,
									order = 2,
								},
								RaidY = {
									name = "Y Value",
									desc = "Y Value for your Raid Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Raid.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Raid.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Raid.Y end,
									set = function(self,RaidY)
												if RaidY == nil or RaidY == "" then
													RaidY = "0"
												end
												db.oUF.FocusTarget.Icons.Raid.Y = RaidY
												oUF_LUI_focustarget.RaidIcon:ClearAllPoints()
												oUF_LUI_focustarget.RaidIcon:SetPoint(db.oUF.FocusTarget.Icons.Raid.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Raid.Point, tonumber(db.oUF.FocusTarget.Icons.Raid.X), tonumber(RaidY))
											end,
									order = 3,
								},
								RaidPoint = {
									name = "Position",
									desc = "Choose the Position for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Raid.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Raid.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Raid.Point == v then
													return k
												end
											end
										end,
									set = function(self, RaidPoint)
											db.oUF.FocusTarget.Icons.Raid.Point = positions[RaidPoint]
											oUF_LUI_focustarget.RaidIcon:ClearAllPoints()
											oUF_LUI_focustarget.RaidIcon:SetPoint(db.oUF.FocusTarget.Icons.Raid.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Raid.Point, tonumber(db.oUF.FocusTarget.Icons.Raid.X), tonumber(db.oUF.FocusTarget.Icons.Raid.X))
										end,
									order = 4,
								},
								RaidSize = {
									name = "Size",
									desc = "Choose a Size for your Raid Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Raid.Size,
									type = "range",
									min = 5,
									max = 200,
									step = 5,
									disabled = function() return not db.oUF.FocusTarget.Icons.Raid.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Raid.Size end,
									set = function(_, RaidSize) 
											db.oUF.FocusTarget.Icons.Raid.Size = RaidSize
											oUF_LUI_focustarget.RaidIcon:SetHeight(RaidSize)
											oUF_LUI_focustarget.RaidIcon:SetWidth(RaidSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.Raid.Enable end,
									desc = "Toggles the RaidIcon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.RaidIcon:IsShown() then oUF_LUI_focustarget.RaidIcon:Hide() else oUF_LUI_focustarget.RaidIcon:Show() end end
								},
							},
						},
						Resting = {
							name = "Resting",
							type = "group",
							order = 5,
							args = {
								RestingEnable = {
									name = "Enable",
									desc = "Wether you want to show the Resting Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Resting.Enable end,
									set = function(self,RestingEnable)
												db.oUF.FocusTarget.Icons.Resting.Enable = not db.oUF.FocusTarget.Icons.Resting.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								RestingX = {
									name = "X Value",
									desc = "X Value for your Resting Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Resting.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Resting.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Resting.X end,
									set = function(self,RestingX)
												if RestingX == nil or RestingX == "" then
													RestingX = "0"
												end
												db.oUF.FocusTarget.Icons.Resting.X = RestingX
												oUF_LUI_focustarget.Resting:ClearAllPoints()
												oUF_LUI_focustarget.Resting:SetPoint(db.oUF.FocusTarget.Icons.Resting.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Resting.Point, tonumber(RestingX), tonumber(db.oUF.FocusTarget.Icons.Resting.Y))
											end,
									order = 2,
								},
								RestingY = {
									name = "Y Value",
									desc = "Y Value for your Resting Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Resting.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Resting.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Resting.Y end,
									set = function(self,RestingY)
												if RestingY == nil or RestingY == "" then
													RestingY = "0"
												end
												db.oUF.FocusTarget.Icons.Resting.Y = RestingY
												oUF_LUI_focustarget.Resting:ClearAllPoints()
												oUF_LUI_focustarget.Resting:SetPoint(db.oUF.FocusTarget.Icons.Resting.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Resting.Point, tonumber(db.oUF.FocusTarget.Icons.Resting.X), tonumber(RestingY))
											end,
									order = 3,
								},
								RestingPoint = {
									name = "Position",
									desc = "Choose the Position for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Resting.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Resting.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Resting.Point == v then
													return k
												end
											end
										end,
									set = function(self, RestingPoint)
											db.oUF.FocusTarget.Icons.Resting.Point = positions[RestingPoint]
											oUF_LUI_focustarget.Resting:ClearAllPoints()
											oUF_LUI_focustarget.Resting:SetPoint(db.oUF.FocusTarget.Icons.Resting.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Resting.Point, tonumber(db.oUF.FocusTarget.Icons.Resting.X), tonumber(db.oUF.FocusTarget.Icons.Resting.X))
										end,
									order = 4,
								},
								RestingSize = {
									name = "Size",
									desc = "Choose a Size for your Resting Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Resting.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.Resting.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Resting.Size end,
									set = function(_, RestingSize) 
											db.oUF.FocusTarget.Icons.Resting.Size = RestingSize
											oUF_LUI_focustarget.Resting:SetHeight(RestingSize)
											oUF_LUI_focustarget.Resting:SetWidth(RestingSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.Resting.Enable end,
									desc = "Toggles the Resting Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.Resting:IsShown() then oUF_LUI_focustarget.Resting:Hide() else oUF_LUI_focustarget.Resting:Show() end end
								},
							},
						},
						Combat = {
							name = "Combat",
							type = "group",
							order = 5,
							args = {
								CombatEnable = {
									name = "Enable",
									desc = "Wether you want to show the Combat Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.Combat.Enable end,
									set = function(self,CombatEnable)
												db.oUF.FocusTarget.Icons.Combat.Enable = not db.oUF.FocusTarget.Icons.Combat.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								CombatX = {
									name = "X Value",
									desc = "X Value for your Combat Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Combat.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Combat.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Combat.X end,
									set = function(self,CombatX)
												if CombatX == nil or CombatX == "" then
													CombatX = "0"
												end
												db.oUF.FocusTarget.Icons.Combat.X = CombatX
												oUF_LUI_focustarget.Combat:ClearAllPoints()
												oUF_LUI_focustarget.Combat:SetPoint(db.oUF.FocusTarget.Icons.Combat.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Combat.Point, tonumber(CombatX), tonumber(db.oUF.FocusTarget.Icons.Combat.Y))
											end,
									order = 2,
								},
								CombatY = {
									name = "Y Value",
									desc = "Y Value for your Combat Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Combat.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.Combat.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Combat.Y end,
									set = function(self,CombatY)
												if CombatY == nil or CombatY == "" then
													CombatY = "0"
												end
												db.oUF.FocusTarget.Icons.Combat.Y = CombatY
												oUF_LUI_focustarget.Combat:ClearAllPoints()
												oUF_LUI_focustarget.Combat:SetPoint(db.oUF.FocusTarget.Icons.Combat.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Combat.Point, tonumber(db.oUF.FocusTarget.Icons.Combat.X), tonumber(CombatY))
											end,
									order = 3,
								},
								CombatPoint = {
									name = "Position",
									desc = "Choose the Position for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Combat.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.Combat.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.Combat.Point == v then
													return k
												end
											end
										end,
									set = function(self, CombatPoint)
											db.oUF.FocusTarget.Icons.Combat.Point = positions[CombatPoint]
											oUF_LUI_focustarget.Combat:ClearAllPoints()
											oUF_LUI_focustarget.Combat:SetPoint(db.oUF.FocusTarget.Icons.Combat.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.Combat.Point, tonumber(db.oUF.FocusTarget.Icons.Combat.X), tonumber(db.oUF.FocusTarget.Icons.Combat.X))
										end,
									order = 4,
								},
								CombatSize = {
									name = "Size",
									desc = "Choose a Size for your Combat Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.Combat.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.Combat.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.Combat.Size end,
									set = function(_, CombatSize) 
											db.oUF.FocusTarget.Icons.Combat.Size = CombatSize
											oUF_LUI_focustarget.Combat:SetHeight(CombatSize)
											oUF_LUI_focustarget.Combat:SetWidth(CombatSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									disabled = function() return not db.oUF.FocusTarget.Icons.Combat.Enable end,
									name = "Show/Hide",
									desc = "Toggles the Combat Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.Combat:IsShown() then oUF_LUI_focustarget.Combat:Hide() else oUF_LUI_focustarget.Combat:Show() end end
								},
							},
						},
						PvP = {
							name = "PvP",
							type = "group",
							order = 5,
							args = {
								PvPEnable = {
									name = "Enable",
									desc = "Wether you want to show the PvP Icon or not.",
									type = "toggle",
									width = "full",
									get = function() return db.oUF.FocusTarget.Icons.PvP.Enable end,
									set = function(self,PvPEnable)
												db.oUF.FocusTarget.Icons.PvP.Enable = not db.oUF.FocusTarget.Icons.PvP.Enable
												StaticPopup_Show("RELOAD_UI")
											end,
									order = 1,
								},
								PvPX = {
									name = "X Value",
									desc = "X Value for your PvP Icon.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.PvP.X,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.PvP.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.PvP.X end,
									set = function(self,PvPX)
												if PvPX == nil or PvPX == "" then
													PvPX = "0"
												end
												db.oUF.FocusTarget.Icons.PvP.X = PvPX
												oUF_LUI_focustarget.PvP:ClearAllPoints()
												oUF_LUI_focustarget.PvP:SetPoint(db.oUF.FocusTarget.Icons.PvP.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.PvP.Point, tonumber(PvPX), tonumber(db.oUF.FocusTarget.Icons.PvP.Y))
											end,
									order = 2,
								},
								PvPY = {
									name = "Y Value",
									desc = "Y Value for your PvP Icon.\n\nNote:\nPositive values = up\nNegativ values = down\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.PvP.Y,
									type = "input",
									disabled = function() return not db.oUF.FocusTarget.Icons.PvP.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.PvP.Y end,
									set = function(self,PvPY)
												if PvPY == nil or PvPY == "" then
													PvPY = "0"
												end
												db.oUF.FocusTarget.Icons.PvP.Y = PvPY
												oUF_LUI_focustarget.PvP:ClearAllPoints()
												oUF_LUI_focustarget.PvP:SetPoint(db.oUF.FocusTarget.Icons.PvP.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.PvP.Point, tonumber(db.oUF.FocusTarget.Icons.PvP.X), tonumber(PvPY))
											end,
									order = 3,
								},
								PvPPoint = {
									name = "Position",
									desc = "Choose the Position for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.PvP.Point,
									type = "select",
									disabled = function() return not db.oUF.FocusTarget.Icons.PvP.Enable end,
									values = positions,
									get = function()
											for k, v in pairs(positions) do
												if db.oUF.FocusTarget.Icons.PvP.Point == v then
													return k
												end
											end
										end,
									set = function(self, PvPPoint)
											db.oUF.FocusTarget.Icons.PvP.Point = positions[PvPPoint]
											oUF_LUI_focustarget.PvP:ClearAllPoints()
											oUF_LUI_focustarget.PvP:SetPoint(db.oUF.FocusTarget.Icons.PvP.Point, oUF_LUI_focustarget, db.oUF.FocusTarget.Icons.PvP.Point, tonumber(db.oUF.FocusTarget.Icons.PvP.X), tonumber(db.oUF.FocusTarget.Icons.PvP.X))
										end,
									order = 4,
								},
								PvPSize = {
									name = "Size",
									desc = "Choose a Size for your PvP Icon.\nDefault: "..LUI.defaults.profile.oUF.FocusTarget.Icons.PvP.Size,
									type = "range",
									min = 5,
									max = 40,
									step = 1,
									disabled = function() return not db.oUF.FocusTarget.Icons.PvP.Enable end,
									get = function() return db.oUF.FocusTarget.Icons.PvP.Size end,
									set = function(_, PvPSize) 
											db.oUF.FocusTarget.Icons.PvP.Size = PvPSize
											oUF_LUI_focustarget.PvP:SetHeight(PvPSize)
											oUF_LUI_focustarget.PvP:SetWidth(PvPSize)
										end,
									order = 5,
								},
								toggle = {
									order = 6,
									name = "Show/Hide",
									disabled = function() return not db.oUF.FocusTarget.Icons.PvP.Enable end,
									desc = "Toggles the PvP Icon",
									type = 'execute',
									func = function() if oUF_LUI_focustarget.PvP:IsShown() then oUF_LUI_focustarget.PvP:Hide() else oUF_LUI_focustarget.PvP:Show() end end
								},
							},
						},
					},
				},
			},
		},
	}
	
	return options
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile.oUF, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterUnitFrame(self:LoadOptions())
end