--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: datatext.lua
	Description: Datatext Molule for Durability, Gold, Latency, Fps, MS, Friends, Guild, Clock, Bags...
	Version....: 1.0
	Rev Date...: 10/10/2010
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists
local LUIHook = LUI:GetModule("LUIHook")
local module = LUI:NewModule("Datatext", "AceHook-3.0")

local fontflags = {'OUTLINE', 'THICKOUTLINE', 'MONOCHROME', 'NONE'}

function module:SetDataTextFrames()
	local infos_left = LUI:CreateMeAFrame("FRAME","infos_left",UIParent,100,20,1,"HIGH",0,"TOPLEFT",UIParent,"TOPLEFT",200,3,1)
	infos_left:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", tile=0, tileSize=0, edgeSize=1, insets={left=0, right=0, top=0, bottom=0}})
	infos_left:SetBackdropColor(0,0,0,0)
	infos_left:SetBackdropBorderColor(0,0,0,0)
	infos_left:SetAlpha(1)
	infos_left:Show()
	
	local infos_right = LUI:CreateMeAFrame("FRAME","infos_right",UIParent,100,20,1,"HIGH",0,"TOPRIGHT",UIParent,"TOPRIGHT",0,3,1)
	infos_right:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", tile=0, tileSize=0, edgeSize=1, insets={left=0, right=0, top=0, bottom=0}})
	infos_right:SetBackdropColor(0,0,0,0)
	infos_right:SetBackdropBorderColor(0,0,0,0)
	infos_right:SetAlpha(1)
	infos_right:Show()
end

------------------------------------------------------
-- / FPS & MS / --
------------------------------------------------------

function module:SetFPS()
	if db.Info.Fps.Enable == false then return end
	
	local Stat1 = CreateFrame("Frame")
	Text_fps  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_fps:SetFont(LSM:Fetch("font", db.Info.Fps.Font), db.Info.Fps.Size, db.Info.Fps.Outline)
	Text_fps:SetPoint("CENTER", infos_left, "CENTER", db.Info.Fps.X, db.Info.Fps.Y)
	Text_fps:SetHeight(db.Info.Fps.Size)
	Text_fps:SetTextColor(db.Info.Fps.Color.r, db.Info.Fps.Color.g, db.Info.Fps.Color.b, db.Info.Fps.Color.a)
	
	-- RGBToHex(db.InfoColor.r, db.InfoColor.g, db.InfoColor.b)
									
	local int = 1
	local function Update(self, t)
		int = int - t
		if int < 0 then
			--Text_fps:SetText(floor(GetFramerate()).."|cfffffffffps     |r"..select(3, GetNetStats()).."|cffffffffms|r")
			Text_fps:SetText(floor(GetFramerate()).."fps   "..select(3, GetNetStats()).."ms")
			int = 1
		end
		
	end

	Stat1:SetScript("OnUpdate", Update) 
	Update(Stat1, 10)
end

------------------------------------------------------
-- / MEMORY USAGE / --
------------------------------------------------------

function module:SetMemoryUsage()
	if db.Info.Memory.Enable == false then return end
	
	local Stat2 = CreateFrame("Frame")
	Stat2:EnableMouse(true)

	Text_mb  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_mb:SetFont(LSM:Fetch("font", db.Info.Memory.Font), db.Info.Memory.Size, db.Info.Memory.Outline)
	Text_mb:SetPoint("CENTER", infos_left, "CENTER", db.Info.Memory.X, db.Info.Memory.Y)
	Text_mb:SetHeight(db.Info.Memory.Size)
	Text_mb:SetTextColor(db.Info.Memory.Color.r, db.Info.Memory.Color.g, db.Info.Memory.Color.b, db.Info.Memory.Color.a)
									
	local function formatMem(memory, color)
		if color then
			statColor = { "", "" }
		else
			statColor = { "", "" }
		end

		local mult = 10^1
		if memory > 999 then
			local mem = floor((memory/1024) * mult + 0.5) / mult
			if mem % 1 == 0 then
				return mem..string.format(".0%smb%s", unpack(statColor))
			else
				return mem..string.format("%smb%s", unpack(statColor))
			end
		else
			local mem = floor(memory * mult + 0.5) / mult
			if mem % 1 == 0 then
				return mem..string.format(".0 %skb%s", unpack(statColor))
			else
				return mem..string.format(" %skb%s", unpack(statColor))
			end
		end

	end

	local Total, Mem, MEMORY_TEXT, LATENCY_TEXT, Memory
	local function RefreshMem(self)
		Memory = {}
		collectgarbage("collect")
		UpdateAddOnMemoryUsage()
		Total = 0
		for i = 1, GetNumAddOns() do
			Mem = GetAddOnMemoryUsage(i)
			Memory[i] = { select(2, GetAddOnInfo(i)), Mem, IsAddOnLoaded(i) }
			Total = Total + Mem
		end
		
		MEMORY_TEXT = formatMem(Total, true)
		table.sort(Memory, function(a, b)
			if a and b then
				return a[2] > b[2]
			end
		end)
		
		self:SetAllPoints(Text_mb)
	end
		
	local int, int2 = 10, 1
	local function Update(self, t)
		int = int - t
		int2 = int2 - t
		if int < 0 then
			RefreshMem(self)
			int = 10
		end
		if int2 < 0 then
			Text_mb:SetText(MEMORY_TEXT)
			int2 = 1
		end
	end

	Stat2:SetScript("OnMouseDown", function() collectgarbage("collect") Update(Stat2, 10) end)
	Stat2:SetScript("OnUpdate", Update) 
	Stat2:SetScript("OnEnter", function(self)
		if not InCombatLockdown() then
			GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, LUI:Scale(6));
			GameTooltip:ClearAllPoints()
			GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, LUI.mult)
			GameTooltip:ClearLines()
			for i = 1, #Memory do
				if Memory[i][3] then 
					local red = Memory[i][2]/Total*2
					local green = 1 - red
					GameTooltip:AddDoubleLine(Memory[i][1], formatMem(Memory[i][2], false), 1, 1, 1, red, green+1, 0)						
				end
			end
			GameTooltip:AddLine(" ")
			GameTooltip:AddDoubleLine("Total Memory Usage:",formatMem(Total), 1, 1, 1,0.80, 0.8, 0.8)
			GameTooltip:Show()
		end
	end)
	Stat2:SetScript("OnLeave", function() GameTooltip:Hide() end)
	
	Update(Stat2, 20)
end

------------------------------------------------------
-- / BAGS / --
------------------------------------------------------

function module:SetBags()
	if db.Info.Bags.Enable == false then return end
	
	local Stat4 = CreateFrame("Frame")
	Stat4:EnableMouse(true)

	Text_bags  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_bags:SetFont(LSM:Fetch("font", db.Info.Bags.Font), db.Info.Bags.Size, db.Info.Bags.Outline)
	Text_bags:SetPoint("CENTER", infos_left, "CENTER", db.Info.Bags.X, db.Info.Bags.Y)
	Text_bags:SetHeight(db.Info.Bags.Size)
	Text_bags:SetTextColor(db.Info.Bags.Color.r, db.Info.Bags.Color.g, db.Info.Bags.Color.b, db.Info.Bags.Color.a)
	
	local function OnEvent(self, event, ...)
		local free, total,used = 0, 0, 0
		for i = 0, NUM_BAG_SLOTS do
			free, total = free + GetContainerNumFreeSlots(i), total + GetContainerNumSlots(i)
		end
		used = total - free
		Text_bags:SetText("Bags: "..used.."/"..total)
		self:SetAllPoints(Text_bags)
	end
		
	Stat4:RegisterEvent("PLAYER_LOGIN")
	Stat4:RegisterEvent("BAG_UPDATE")
	Stat4:SetScript("OnEvent", OnEvent)
	Stat4:SetScript("OnMouseDown", function() OpenAllBags() end)
end

------------------------------------------------------
-- / DURABILITY / --
------------------------------------------------------

function module:SetDurability()
	if db.Info.Armor.Enable == false then return end
	
	local Stat6 = CreateFrame("Frame")
	Stat6:EnableMouse(true)

	Text_dura  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_dura:SetFont(LSM:Fetch("font", db.Info.Armor.Font), db.Info.Armor.Size, db.Info.Armor.Outline)
	Text_dura:SetPoint("CENTER", infos_left, "CENTER", db.Info.Armor.X, db.Info.Armor.Y)
	Text_dura:SetHeight(db.Info.Armor.Size)
	Text_dura:SetTextColor(db.Info.Armor.Color.r, db.Info.Armor.Color.g, db.Info.Armor.Color.b, db.Info.Armor.Color.a)

	local Total = 0
	local current, max
	
	Slots = {
		[1] = {1, "Head", 1000},
		[2] = {3, "Shoulder", 1000},
		[3] = {5, "Chest", 1000},
		[4] = {6, "Waist", 1000},
		[5] = {9, "Wrist", 1000},
		[6] = {10, "Hands", 1000},
		[7] = {7, "Legs", 1000},
		[8] = {8, "Feet", 1000},
		[9] = {16, "Main Hand", 1000},
		[10] = {17, "Off Hand", 1000},
		[11] = {18, "Ranged", 1000}
	}

	local function OnEvent(self)
		for i = 1, 11 do
			if GetInventoryItemLink("player", Slots[i][1]) ~= nil then
				current, max = GetInventoryItemDurability(Slots[i][1])
				if current then 
					Slots[i][3] = current/max
					Total = Total + 1
				end
			end
		end
		table.sort(Slots, function(a, b) return a[3] < b[3] end)
		
		if Total > 0 then
			Text_dura:SetText("Armor: "..floor(Slots[1][3]*100).."% |cffffffff|r")
		else
			Text_dura:SetText("Armor: 100%")
		end
		
		-- Setup Durability Tooltip
		self:SetAllPoints(Text_dura)
		Total = 0
	end

	Stat6:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
	Stat6:RegisterEvent("MERCHANT_SHOW")
	Stat6:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat6:SetScript("OnMouseDown", function() ToggleCharacter("PaperDollFrame") end)
	Stat6:SetScript("OnEvent", OnEvent)
	Stat6:SetScript("OnEnter", function(self)
		if not InCombatLockdown() then
			GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, LUI:Scale(6));
			GameTooltip:ClearAllPoints()
			GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, LUI.mult)
			GameTooltip:ClearLines()
			for i = 1, 11 do
				if Slots[i][3] ~= 1000 then
					green = Slots[i][3]*2
					red = 1 - green
					GameTooltip:AddDoubleLine(Slots[i][2], floor(Slots[i][3]*100).."%",1 ,1 , 1, red + 1, green, 0)
				end
			end
			GameTooltip:Show()
		end
	end)
end

------------------------------------------------------
-- / GOLD / --
------------------------------------------------------

function module:SetGold()
	if db.Info.Gold.Enable == false then return end
	
	local Stat7 = CreateFrame("Frame")
	Stat7:EnableMouse(true)

	Text_gold  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_gold:SetFont(LSM:Fetch("font", db.Info.Gold.Font), db.Info.Gold.Size, db.Info.Gold.Outline)
	Text_gold:SetPoint("CENTER", infos_left, "CENTER", db.Info.Gold.X, db.Info.Gold.Y)
	Text_gold:SetHeight(db.Info.Gold.Size)
	Text_gold:SetTextColor(db.Info.Gold.Color.r, db.Info.Gold.Color.g, db.Info.Gold.Color.b, db.Info.Gold.Color.a)

	local Profit	= 0
	local Spent		= 0
	local OldMoney	= 0
	local myPlayerRealm = GetCVar("realmName");

	local function formatMoney(money)
		local gold = floor(math.abs(money) / 10000)
		local silver = mod(floor(math.abs(money) / 100), 100)
		local copper = mod(floor(math.abs(money)), 100)
		if gold ~= 0 then
			--return format("%s|cffffd700g|r %s|cffc7c7cfs|r", gold, silver)
			return format("%sg %ss", gold, silver)
		elseif silver ~= 0 then
			--return format("%s|cffc7c7cfs|r %s|cffeda55fc|r", silver, copper)
			return format("%ss %sc", silver, copper)
		else
			--return format("%s|cffeda55f c|r", copper)
			return format("%sc", copper)
		end
	end
	
	local function FormatTooltipMoney(money)
		local gold, silver, copper = abs(money / 10000), abs(mod(money / 100, 100)), abs(mod(money, 100))
		local cash = ""
		cash = format("%d|cffffd700g|r %d|cffc7c7cfs|r %d|cffeda55fc|r", gold, silver, copper)		
		return cash
	end	

	local function OnEvent(self, event)
		if event == "PLAYER_ENTERING_WORLD" then
			OldMoney = GetMoney()
		end
		
		local NewMoney = GetMoney()
		local Change = NewMoney-OldMoney -- Positive if we gain money
		
		if OldMoney>NewMoney then		-- Lost Money
			Spent = Spent - Change
		else							-- Gained Moeny
			Profit = Profit + Change
		end

		Text_gold:SetText(formatMoney(NewMoney))
		-- Setup Money Tooltip
		self:SetAllPoints(Text_gold)
		
		local myPlayerName  = UnitName("player");
		if (LUIGold == nil) then LUIGold = {}; end			
		if (LUIGold.gold == nil) then LUIGold.gold = {}; end
		if (LUIGold.gold[myPlayerRealm]==nil) then LUIGold.gold[myPlayerRealm]={}; end
		LUIGold.gold[myPlayerRealm][myPlayerName] = GetMoney();
		
		OldMoney = NewMoney
	end

	Stat7:RegisterEvent("PLAYER_MONEY")
	Stat7:RegisterEvent("SEND_MAIL_MONEY_CHANGED")
	Stat7:RegisterEvent("SEND_MAIL_COD_CHANGED")
	Stat7:RegisterEvent("PLAYER_TRADE_MONEY")
	Stat7:RegisterEvent("TRADE_MONEY_CHANGED")
	Stat7:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat7:SetScript("OnMouseDown", function() OpenAllBags() end)
	Stat7:SetScript("OnEvent", OnEvent)
	Stat7:SetScript("OnEnter", function(self)
		if not InCombatLockdown() then
			self.hovered = true 
			GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, LUI:Scale(6));
			GameTooltip:ClearAllPoints()
			GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, LUI.mult)
			GameTooltip:ClearLines()
			GameTooltip:AddLine("Session:")
			GameTooltip:AddDoubleLine("Earned:", formatMoney(Profit), 1, 1, 1, 1, 1, 1)
			GameTooltip:AddDoubleLine("Spent:", formatMoney(Spent), 1, 1, 1, 1, 1, 1)
			if Profit < Spent then
				GameTooltip:AddDoubleLine("Deficit:", formatMoney(Profit-Spent), 1, 0, 0, 1, 1, 1)
			elseif (Profit-Spent)>0 then
				GameTooltip:AddDoubleLine("Profit:", formatMoney(Profit-Spent), 0, 1, 0, 1, 1, 1)
			end				
			GameTooltip:AddLine' '
		
			local totalGold = 0
			GameTooltip:AddLine("Character: ")
			local thisRealmList = LUIGold.gold[myPlayerRealm];
			for k,v in pairs(thisRealmList) do
				GameTooltip:AddDoubleLine(k, FormatTooltipMoney(v), 1, 1, 1, 1, 1, 1)
				totalGold=totalGold+v;
			end 
			GameTooltip:AddLine' '
			GameTooltip:AddLine("Server: ")
			GameTooltip:AddDoubleLine("Total: ", FormatTooltipMoney(totalGold), 1, 1, 1, 1, 1, 1)
			
			for i = 1, MAX_WATCHED_TOKENS do
				local name, count, extraCurrencyType, icon, itemID = GetBackpackCurrencyInfo(i)
				if name and i == 1 then
					GameTooltip:AddLine(" ")
					GameTooltip:AddLine(CURRENCY)
				end
				local r, g, b = 1,1,1
				if itemID then r, g, b = GetItemQualityColor(select(3, GetItemInfo(itemID))) end
				if name and count then GameTooltip:AddDoubleLine(name, count, r, g, b, 1, 1, 1) end
			end
			GameTooltip:Show()
		end
	end)
	Stat7:SetScript("OnLeave", function() GameTooltip:Hide() end)	
end

------------------------------------------------------
-- / TIME / --
------------------------------------------------------

function module:SetClock()
	if db.Info.Clock.Enable == false then return end
	
	local Stat8 = CreateFrame("Frame")
	Stat8:EnableMouse(true)
	Stat8:SetFrameLevel(3)
	Stat8:SetFrameStrata("HIGH")
	localtime = db.Info.Clock.LocalTime
	time24 = db.Info.Clock.Time24

	Text_time  = infos_right:CreateFontString(nil, "OVERLAY")
	Text_time:SetFont(LSM:Fetch("font", db.Info.Clock.Font), db.Info.Clock.Size, db.Info.Clock.Outline)
	Text_time:SetPoint("CENTER", infos_right, "CENTER", db.Info.Clock.X, db.Info.Clock.Y)
	Text_time:SetHeight(db.Info.Clock.Size)
	Text_time:SetTextColor(db.Info.Clock.Color.r, db.Info.Clock.Color.g, db.Info.Clock.Color.b, db.Info.Clock.Color.a)

	local int = 1
	local function Update(self, t)
		local pendingCalendarInvites = CalendarGetNumPendingInvites()
		if ( pendingCalendarInvites > 0 ) then
			Text_time:SetText("(Inv. pending)")
			self:SetAllPoints(Text_time)
		else
			int = int - t
			if int < 0 then
				if localtime == true then
					Hr24 = tonumber(date("%H"))
					Hr = tonumber(date("%I"))
					Min = date("%M")
					
					if time24 == true then 
						Text_time:SetText(Hr24..":"..Min)
					else
						if Hr24>=12 then
							Text_time:SetText(Hr..":"..Min.." pm")
						else
							Text_time:SetText(Hr..":"..Min.." am")
						end
					end
				else
					local Hr, Min = GetGameTime()
					if Min<10 then Min = "0"..Min end
					
					if time24 == true then
						Text_time:SetText(Hr..":"..Min)
					else
						if Hr>=12 then
							Hr_time12 = Hr-12
						end
						
						if Hr>=12 then
							Text_time:SetText(Hr_time12..":"..Min.." pm")
						else
							Text_time:SetText(Hr..":"..Min.." am")
						end
					end
				end
				
				-- Instance Info
				-- Credits to hix for the Code.
				if db.Info.Clock.ShowInstanceDifficulty == true then
					local inInstance, instanceType = IsInInstance()
					if inInstance then
					   local _,_, instanceDifficulty,_, maxPlayers, dynamicMode, isDynamic = GetInstanceInfo()
					   local difficultytext = nil
					   if (instanceType == "raid") then
						  if (instanceDifficulty == 3 or instanceDifficulty == 4) or (isDynamic and dynamicMode == 1) then
							 difficultytext = " |cffff0000H|r)"
						  else
							 difficultytext = " |cff00ff00N|r)"
						  end
					   elseif (instanceType == "party") then
						  if (instanceDifficulty == 1) then
							 difficultytext = " |cff00ff00N|r)"
						  else
							 difficultytext = " |cffff0000H|r)"
						  end
					   end
					   
					   if difficultytext then Text_time:SetText(Text_time:GetText().." ("..maxPlayers..difficultytext) end
					end
				end

				self:SetAllPoints(Text_time)
				int = 1
			end
		end
	end
	
	Stat8:SetScript("OnEnter", function(self)
		OnLoad = function(self) RequestRaidInfo() end,
		GameTooltip:SetOwner(self, "ANCHOR_NONE ",40,-150)
		GameTooltip:ClearLines()
		local pvp = GetNumWorldPVPAreas()
		for i=1, pvp do
			local timeleft = select(5, GetWorldPVPAreaInfo(i))
			local name = select(2, GetWorldPVPAreaInfo(i))
			local inprogress = select(3, GetWorldPVPAreaInfo(i))
			local inInstance, instanceType = IsInInstance()
			if not ( instanceType == "none" ) then
				timeleft = QUEUE_TIME_UNAVAILABLE
			elseif inprogress then
				timeleft = WINTERGRASP_IN_PROGRESS
			else
				local hour = tonumber(format("%01.f", floor(timeleft/3600)))
				local min = format(hour>0 and "%02.f" or "%01.f", floor(timeleft/60 - (hour*60)))
				local sec = format("%02.f", floor(timeleft - hour*3600 - min *60)) 
				timeleft = (hour>0 and hour..":" or "")..min..":"..sec
			end
			GameTooltip:AddDoubleLine("Time to "..name,timeleft)
		end
		GameTooltip:AddLine(" ")
		
		if localtime == true then
			local Hr, Min = GetGameTime()
			if Min<10 then Min = "0"..Min end
			if time24 == true then         
				GameTooltip:AddDoubleLine("Server Time: ",Hr .. ":" .. Min);
			else             
				if Hr>=12 then
				Hr = Hr-12
				if Hr == 0 then Hr = 12 end
					GameTooltip:AddDoubleLine("Server Time: ",Hr .. ":" .. Min.." PM");
				else
					if Hr == 0 then Hr = 12 end
					GameTooltip:AddDoubleLine("Server Time: ",Hr .. ":" .. Min.." AM");
				end
			end
		else
			Hr24 = tonumber(date("%H"))
			Hr = tonumber(date("%I"))
			Min = date("%M")
			if time24 == true then
				GameTooltip:AddDoubleLine("Local Time: ",Hr24 .. ":" .. Min);
			else
				if Hr24>=12 then
					GameTooltip:AddDoubleLine("Local Time: ",Hr .. ":" .. Min.." PM");
				else
					GameTooltip:AddDoubleLine("Local Time: ",Hr .. ":" .. Min.." AM");
				end
			end
		end  
		
		local oneraid
		for i = 1, GetNumSavedInstances() do
		local name,_,reset,difficulty,locked,extended,_,isRaid,maxPlayers = GetSavedInstanceInfo(i)
		if isRaid and (locked or extended) then
			local tr,tg,tb,diff
			if not oneraid then
				GameTooltip:AddLine(" ")
				GameTooltip:AddLine("Saved Raid(s)")
				oneraid = true
			end

			local function fmttime(sec,table)
			local table = table or {}
			local d,h,m,s = ChatFrame_TimeBreakDown(floor(sec))
			local string = gsub(gsub(format(" %dd %dh %dm "..((d==0 and h==0) and "%ds" or ""),d,h,m,s)," 0[dhms]"," "),"%s+"," ")
			local string = strtrim(gsub(string, "([dhms])", {d=table.days or "d",h=table.hours or "h",m=table.minutes or "m",s=table.seconds or "s"})," ")
			return strmatch(string,"^%s*$") and "0"..(table.seconds or L"s") or string
		end
		if extended then tr,tg,tb = 0.3,1,0.3 else tr,tg,tb = 1,1,1 end
			if difficulty == 3 or difficulty == 4 then diff = "H" else diff = "N" end
				GameTooltip:AddDoubleLine(format("%s |cffaaaaaa(%s%s)",name,maxPlayers,diff),fmttime(reset),1,1,1,tr,tg,tb)
			end
		end
		GameTooltip:Show()
	end)
	
	Stat8:SetScript("OnLeave", function() GameTooltip:Hide() end)
	Stat8:RegisterEvent("CALENDAR_UPDATE_PENDING_INVITES")
	Stat8:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat8:SetScript("OnUpdate", Update)
	Stat8:SetScript("OnMouseDown", function() GameTimeFrame:Click() end)
	Update(Stat8, 10)
end

function module:ResetGold()
	LUIGold = {}
	StaticPopup_Show("RELOAD_UI")
end


--------------------------------------------------------------------
-- GUILD ROSTER
--------------------------------------------------------------------

function module:SetGuild()
	if db.Info.Guild.Enable == false then return end
	
	local Stat9 = CreateFrame("Frame")
	Stat9:EnableMouse(true)

	local tthead = {r=0.4,g=0.78,b=1}
	local ttsubh = {r=0.75,g=0.9,b=1}

	Text_guild  = infos_left:CreateFontString(nil, "OVERLAY")
	Text_guild:SetFont(LSM:Fetch("font", db.Info.Guild.Font), db.Info.Guild.Size, db.Info.Guild.Outline)
	Text_guild:SetPoint("RIGHT", infos_right, "LEFT", db.Info.Guild.X, db.Info.Guild.Y)
	Text_guild:SetHeight(db.Info.Guild.Size)
	Text_guild:SetTextColor(db.Info.Guild.Color.r, db.Info.Guild.Color.g, db.Info.Guild.Color.b, db.Info.Guild.Color.a)
	
	local function Update(self, event, ...)	
		if IsInGuild() then
			GuildRoster()
			local numOnline = (GetNumGuildMembers())            
			local total = (GetNumGuildMembers())
			local numOnline = 0
			for i = 1, total do
				local _, _, _, _, _, _, _, _, online, _, _ = GetGuildRosterInfo(i)
				if online then
					numOnline = numOnline + 1
				end
			end 			
			self:SetAllPoints(Text_guild)
			Text_guild:SetText("Guild: " .. numOnline)
		else
			Text_guild:SetText("No Guild")
		end
	end
	
	Stat9:RegisterEvent("GUILD_ROSTER_UPDATE")
	Stat9:RegisterEvent("PLAYER_GUILD_UPDATE")
	Stat9:RegisterEvent("GUILD_PERK_UPDATE")
	Stat9:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat9:RegisterEvent("CHAT_MSG_SYSTEM")
	Stat9:SetScript("OnEnter", function(self)
		if not InCombatLockdown() then
			if IsInGuild() then
				self.hovered = true
				GuildRoster()
				local name, rank, level, zone, note, officernote, connected, status, class, zone_r, zone_g, zone_b, classc, levelc
				local online, total, gmotd = 0, GetNumGuildMembers(true), GetGuildRosterMOTD()
				for i = 0, total do if select(9, GetGuildRosterInfo(i)) then online = online + 1 end end
				
				GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, LUI:Scale(6));
				GameTooltip:ClearAllPoints()
				GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, LUI.mult)
				GameTooltip:ClearLines()
				GameTooltip:AddDoubleLine(GetGuildInfo'player',format("%s: %d/%d","Guild",online,total),tthead.r,tthead.g,tthead.b,tthead.r,tthead.g,tthead.b)
				GameTooltip:AddLine' '
				if gmotd ~= "" then GameTooltip:AddLine(format("  %s |cffaaaaaa- |cffffffff%s",GUILD_MOTD,gmotd),ttsubh.r,ttsubh.g,ttsubh.b,1) end
				if online > 1 then
					GameTooltip:AddLine(" ")
					for i = 1, total do
						if online <= 1 then
							if online > 1 then GameTooltip:AddLine(format("+ %d More...", online - modules.Guild.maxguild),ttsubh.r,ttsubh.g,ttsubh.b) end
							break
						end
						-- name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName
						name, rank, _, level, _, zone, note, officernote, connected, status, class = GetGuildRosterInfo(i)
						if connected and name ~= UnitName'player' then
							if GetRealZoneText() == zone then zone_r, zone_g, zone_b = 0.3, 1.0, 0.3 else zone_r, zone_g, zone_b = 0.65, 0.65, 0.65 end
							classc, levelc = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[class], GetQuestDifficultyColor(level)
							if IsShiftKeyDown() then
								GameTooltip:AddDoubleLine(name.." |cff999999- |cffffffff"..rank,zone,classc.r,classc.g,classc.b,zone_r,zone_g,zone_b)
								if note ~= "" then GameTooltip:AddLine('  "'..note..'"',ttsubh.r,ttsubh.g,ttsubh.b,1) end
								if officernote ~= "" then GameTooltip:AddLine("  o: "..officernote,0.3,1,0.3,1) end
							else
								GameTooltip:AddDoubleLine(format("|cff%02x%02x%02x%d|r %s%s",levelc.r*255,levelc.g*255,levelc.b*255,level,name,' '..status),zone,classc.r,classc.g,classc.b,zone_r,zone_g,zone_b)
							end
						end
					end
					GameTooltip:AddLine(" ")
					GameTooltip:AddLine("Shift + Hover for more Informations")
				end
				GameTooltip:Show()
			end
		end
	end)
	Stat9:SetScript("OnLeave", function() GameTooltip:Hide() end)
	Stat9:SetScript("OnMouseDown", function() if not GuildFrame and IsInGuild() then LoadAddOn("Blizzard_GuildUI") end GuildFrame_Toggle() end)
	Stat9:SetScript("OnEvent", Update)
end

------------------------------------------------------
-- / FRIENDS / --
------------------------------------------------------

function module:SetFriends()
	if db.Info.Friends.Enable == false then return end
	
	local Stat10 = CreateFrame("Frame", "LUI_Friends", UIParent)
	Stat10:SetFrameStrata("BACKGROUND")
	Stat10:SetFrameLevel(3)

	local tthead = {r=0.4,g=0.78,b=1}
	local ttsubh = {r=0.75,g=0.9,b=1}

	Text_friends = infos_left:CreateFontString(nil, "OVERLAY")
	Text_friends:SetFont(LSM:Fetch("font", db.Info.Friends.Font), db.Info.Friends.Size, db.Info.Friends.Outline)
	Text_friends:SetPoint("RIGHT", infos_right, "LEFT", db.Info.Friends.X,db.Info.Friends.Y)
	Text_friends:SetHeight(db.Info.Friends.Size)
	Text_friends:SetTextColor(db.Info.Friends.Color.r, db.Info.Friends.Color.g, db.Info.Friends.Color.b, db.Info.Friends.Color.a)


	local function Update(self, event)
		local online, total = 0, GetNumFriends()
		local BNonline, BNtotal = 0, BNGetNumFriends()
		for i = 0, total do if select(5, GetFriendInfo(i)) then online = online + 1 end end
		if BNtotal > 0 then
			for i = 1, BNtotal do if select(7, BNGetFriendInfo(i)) then BNonline = BNonline + 1 end end
		end
		local totalonline = online + BNonline
		Text_friends:SetText("Friends: "..totalonline)
		self:SetAllPoints(Text_friends)
	end

	Stat10:RegisterEvent("FRIENDLIST_SHOW")
	Stat10:RegisterEvent("FRIENDLIST_UPDATE")
	Stat10:RegisterEvent("MUTELIST_UPDATE")
	Stat10:RegisterEvent("WHO_LIST_UPDATE")
	Stat10:RegisterEvent("PLAYER_FLAGS_CHANGED")
	Stat10:RegisterEvent("BN_FRIEND_LIST_SIZE_CHANGED")
	Stat10:RegisterEvent("BN_FRIEND_INFO_CHANGED")
	Stat10:RegisterEvent("BN_FRIEND_INVITE_LIST_INITIALIZED")
	Stat10:RegisterEvent("BN_FRIEND_INVITE_ADDED")
	Stat10:RegisterEvent("BN_FRIEND_INVITE_REMOVED")
	Stat10:RegisterEvent("BN_SELF_ONLINE")
	Stat10:RegisterEvent("BN_BLOCK_LIST_UPDATED")
	Stat10:RegisterEvent("PLAYER_ENTERING_WORLD")
	Stat10:RegisterEvent("BN_CONNECTED")
	Stat10:RegisterEvent("BN_DISCONNECTED")
	Stat10:RegisterEvent("CHAT_MSG_SYSTEM")
	--Stat10:SetScript("OnMouseDown", function() ToggleFriendsFrame(1) end)
	Stat10:SetScript("OnEnter", function(self)
		if not InCombatLockdown() then
			ShowFriends()
			self.hovered = true
			local online, total = 0, GetNumFriends()
			local name, level, class, zone, connected, status, note, classc, levelc, zone_r, zone_g, zone_b, grouped
			for i = 0, total do if select(5, GetFriendInfo(i)) then online = online + 1 end end
			local BNonline, BNtotal = 0, BNGetNumFriends()
			local presenceID, givenName, surname, toonName, toonID, client, isOnline
			if BNtotal > 0 then
				for i = 1, BNtotal do if select(7, BNGetFriendInfo(i)) then BNonline = BNonline + 1 end end
			end
			local totalonline = online + BNonline
			local totalfriends = total + BNtotal
			if online > 0 or BNonline > 0 then
				GameTooltip:SetOwner(self, "ANCHOR_TOP", 0, LUI:Scale(6));
				GameTooltip:ClearAllPoints()
				GameTooltip:SetPoint("BOTTOM", self, "TOP", 0, LUI.mult)
				GameTooltip:ClearLines()
				GameTooltip:AddDoubleLine("Friends list:", format("Online: " .. "%s/%s",totalonline,totalfriends),tthead.r,tthead.g,tthead.b,tthead.r,tthead.g,tthead.b)
				if online > 0 then
					GameTooltip:AddLine(" ")
					GameTooltip:AddLine("World of Warcraft")
					-- name, level, class, area, connected, status, note
					for i = 1, total do
						name, level, class, zone, connected, status, note = GetFriendInfo(i)
						if not connected then break end
						if GetRealZoneText() == zone then zone_r, zone_g, zone_b = 0.3, 1.0, 0.3 else zone_r, zone_g, zone_b = 0.65, 0.65, 0.65 end
						for k,v in pairs(LOCALIZED_CLASS_NAMES_MALE) do if class == v then class = k end end
						if GetLocale() ~= "enUS" then -- feminine class localization (unsure if it's really needed)
							for k,v in pairs(LOCALIZED_CLASS_NAMES_FEMALE) do if class == v then class = k end end
						end
						classc, levelc = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[class], GetQuestDifficultyColor(level)
						if UnitInParty(name) or UnitInRaid(name) then grouped = "|cffaaaaaa*|r" else grouped = "" end
						GameTooltip:AddDoubleLine(format("|cff%02x%02x%02x%d|r %s%s%s",levelc.r*255,levelc.g*255,levelc.b*255,level,name,grouped," "..status),zone,classc.r,classc.g,classc.b,zone_r,zone_g,zone_b)
						if self.altdown and note then GameTooltip:AddLine("  "..note,ttsubh.r,ttsubh.g,ttsubh.b,1) end
					end
				end
				if BNonline > 0 then
					GameTooltip:AddLine(" ")
					GameTooltip:AddLine("Battle.net")
					for i = 1, BNtotal do
						presenceID, givenName, surname, toonName, toonID, client, isOnline = BNGetFriendInfo(i)
						if not isOnline then break end
						if client == "WoW" then
							local hasFocus, toonName, client, realmName, faction, race, class, guild, zoneName, level= BNGetToonInfo(toonID)
							GameTooltip:AddDoubleLine("|cffeeeeee"..client.." ("..level.." "..toonName..")|r", "|cffeeeeee"..givenName.." "..surname.."|r")
						else
							GameTooltip:AddDoubleLine("|cffeeeeee"..client.." ("..toonName..")|r", "|cffeeeeee"..givenName.." "..surname.."|r")
						end
					end
				end
				GameTooltip:Show()
			else 
				GameTooltip:Hide() 
			end
		end
	end)

	Stat10:SetScript("OnLeave", function() GameTooltip:Hide() end)
	Stat10:SetScript("OnEvent", Update)
end

------------------------------------------------------
-- / DPS / --
------------------------------------------------------

function module:SetDPS()
	if db.Info.Dps.Enable == false then return end
	
	Text_dps = infos_left:CreateFontString(nil, "OVERLAY")
	Text_dps:SetFont(LSM:Fetch("font", db.Info.Dps.Font), db.Info.Dps.Size, db.Info.Dps.Outline)
	Text_dps:SetPoint("LEFT", infos_right, "LEFT", db.Info.Dps.X,db.Info.Dps.Y)
	Text_dps:SetHeight(db.Info.Dps.Size)
	Text_dps:SetTextColor(db.Info.Dps.Color.r, db.Info.Dps.Color.g, db.Info.Dps.Color.b, db.Info.Dps.Color.a)
	Text_dps:SetText("DPS: ")
	
	local DPS = _G.CreateFrame("Frame", "StatBlock_DPS")
	_G.LibStub("AceTimer-3.0"):Embed(DPS)
	local fmt = string.format

	DPS:RegisterEvent("UNIT_PET")
	DPS:RegisterEvent("PLAYER_LOGIN")
	DPS:RegisterEvent("PLAYER_REGEN_DISABLED")
	DPS:RegisterEvent("PLAYER_REGEN_ENABLED")
	DPS:SetScript("OnEvent", function(_, event, ...)
		DPS[event](DPS, ...)
	end)

	local pId
	local petId
	local GetTime = _G.GetTime

	local myDamage = 0
	local combatStartTime = 0
	local timer = nil

	pId = UnitGUID("player")
	if not petId then
		petId = UnitGUID("pet") or "0x0"
	end

	function DPS:UNIT_PET(unit)
		if unit == "player" then
			petId = UnitGUID("pet") or "0x0"
		end
	end

	local txt = "%.1f"
	function DPS:UpdateBlock()
		local dmg = fmt(txt, myDamage / (GetTime() - combatStartTime))
		Text_dps:SetText("DPS: "..dmg)
	end

	local events = {
		SWING_DAMAGE = true,
		RANGE_DAMAGE = true,
		SPELL_DAMAGE = true,
		SPELL_PERIODIC_DAMAGE = true,
		DAMAGE_SHIELD = true,
		DAMAGE_SPLIT = true,
	}
	
	function DPS:COMBAT_LOG_EVENT_UNFILTERED(_, eventType, Id, _, _, _, _, _, spellID, _, _, damage)
		if not events[eventType] then return end

		if Id == pId or Id == petId then
			if eventType == "SWING_DAMAGE" then
				damage = spellID
			end
			myDamage = myDamage + damage
		end
	end

	function DPS:PLAYER_REGEN_DISABLED()
		DPS:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		combatStartTime = GetTime()
		myDamage = 0
		timer = self:ScheduleRepeatingTimer("UpdateBlock", 0.2)
	end

	function DPS:PLAYER_REGEN_ENABLED()
		DPS:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

		self:UpdateBlock()
		self:CancelTimer(timer, true)
	end
end

local defaults = {
	Info = {
		Enable = true,
		Gold = {
			Enable = true,
			X = "-200",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Bags = {
			Enable = true,
			X = "-50",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Armor = {
			Enable = true,
			X = "100",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Fps = {
			Enable = true,
			X = "260",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Dps = {
			Enable = true,
			X = "-535",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Memory = {
			Enable = true,
			X = "340",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Clock = {
			Enable = true,
			LocalTime = true,
			Time24 = true,
			ShowInstanceDifficulty = true,
			X = "-5",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Friends = {
			Enable = false,
			X = "-280",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
		Guild = {
			Enable = false,
			X = "-380",
			Y = "0",
			Font = "vibroceb",
			Size = 12,
			Outline = "NONE",
			Color = {
				r = "1",
				g = "1",
				b = "1",
				a = "1",
			},
		},
	},
}

function module:LoadOptions()
	local options = {
		InfoText = {
			name = "Info Text",
			type = "group",
			order = 65,
			disabled = function() return not db.Info.Enable end,
			childGroups = "select",
			args = {
				Gold = {
					name = "Gold",
					type = "group",
					order = 9,
					args = {
						header92 = {
							name = "Gold",
							type = "header",
							order = 1,
						},
						GoldEnable = {
							name = "Enable",
							desc = "Whether you want to show your Gold Amount or not.\n",
							type = "toggle",
							get = function() return db.Info.Gold.Enable end,
							set = function(self, GoldEnable)
										db.Info.Gold.Enable = not db.Info.Gold.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						GoldReset = {
							order = 3,
							type = "execute",
							name = "Reset",
							func = function()
								self:ResetGold()
							end,
						},
						GoldX = {
							name = "X Value",
							desc = "X Value for your Gold Amount.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Gold.X,
							type = "input",
							disabled = function() return not db.Info.Gold.Enable end,
							get = function() return db.Info.Gold.X end,
							set = function(self,GoldX)
										if GoldX == nil or GoldX == "" then
											GoldX = "0"
										end
										db.Info.Gold.X = GoldX
										Text_gold:SetPoint("CENTER", infos_left, "CENTER", GoldX, db.Info.Gold.Y)
									end,
							order = 4,
						},
						GoldY = {
							name = "Y Value",
							desc = "Y Value for your Gold Amount.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Gold.Y,
							type = "input",
							disabled = function() return not db.Info.Gold.Enable end,
							get = function() return db.Info.Gold.Y end,
							set = function(self,GoldY)
										if GoldY == nil or GoldY == "" then
											GoldY = "0"
										end
										db.Info.Gold.Y = GoldY
										Text_gold:SetPoint("CENTER", infos_left, "CENTER", db.Info.Gold.X, GoldY)
									end,
							order = 5,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Gold.Enable end,
							order = 6,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Gold Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Gold.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Gold.Size end,
									set = function(_, FontSize)
											db.Info.Gold.Size = FontSize
											Text_gold:SetFont(LSM:Fetch("font", db.Info.Gold.Font), FontSize, db.Info.Gold.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Gold Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Gold.Color.r.."\n g="..LUI.defaults.profile.Info.Gold.Color.g.."\n b="..LUI.defaults.profile.Info.Gold.Color.b.."\n a="..LUI.defaults.profile.Info.Gold.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Gold.Color.r, db.Info.Gold.Color.g, db.Info.Gold.Color.b, db.Info.Gold.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Gold.Color.r = r
											db.Info.Gold.Color.g = g
											db.Info.Gold.Color.b = b
											db.Info.Gold.Color.a = a
											
											Text_gold:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Gold Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Gold.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Gold.Font end,
									set = function(self, Font)
											db.Info.Gold.Font = Font
											Text_gold:SetFont(LSM:Fetch("font", Font), db.Info.Gold.Size, db.Info.Gold.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Gold Info Text.\nDefault: "..LUI.defaults.profile.Info.Gold.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Gold.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Gold.Outline = fontflags[FontFlag]
											Text_gold:SetFont(LSM:Fetch("font", db.Info.Gold.Font), db.Info.Gold.Size, db.Info.Gold.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				Clock = {
					name = "Clock",
					type = "group",
					order = 10,
					args = {
						header93 = {
							name = "Clock",
							type = "header",
							order = 13,
						},
						ClockEnable = {
							name = "Enable",
							desc = "Whether you want to show your Clock or not.\n",
							type = "toggle",
							get = function() return db.Info.Clock.Enable end,
							set = function(self, ClockEnable)
										db.Info.Clock.Enable = not db.Info.Clock.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 14,
						},
						ShowInstanceDifficulty = {
							name = "Show Instance Difficulty",
							desc = "Whether you want to show the Instance Difficulty or not.\n",
							type = "toggle",
							disabled = function() return not db.Info.Clock.Enable end,
							get = function() return db.Info.Clock.ShowInstanceDifficulty end,
							set = function(self, ShowInstanceDifficulty)
										db.Info.Clock.ShowInstanceDifficulty = not db.Info.Clock.ShowInstanceDifficulty
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 15,
						},
						EnableLocalTime = {
							name = "Local Time",
							desc = "Whether you want to show your Local Time or Server Time.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "toggle",
							width = "50%",
							disabled = function() return not db.Info.Clock.Enable end,
							get = function() return db.Info.Clock.LocalTime end,
							set = function(self, EnableLocalTime)
										db.Info.Clock.LocalTime = not db.Info.Clock.LocalTime
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 16,
						},
						EnableTime24 = {
							name = "24h Clock",
							desc = "Whether you want to show 24 or 12 hour Clock.\n\nNote:\nYou have to reload the UI.\nType /rl",
							type = "toggle",
							width = "50%",
							disabled = function() return not db.Info.Clock.Enable end,
							get = function() return db.Info.Clock.Time24 end,
							set = function(self, EnableTime24)
										db.Info.Clock.Time24 = not db.Info.Clock.Time24
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 17,
						},
						ClockX = {
							name = "X Value",
							desc = "X Value for your Clock.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Clock.X,
							type = "input",
							disabled = function() return not db.Info.Clock.Enable end,
							get = function() return db.Info.Clock.X end,
							set = function(self,ClockX)
										if ClockX == nil or ClockX == "" then
											ClockX = "0"
										end
										db.Info.Clock.X = ClockX
										Text_time:SetPoint("CENTER", infos_right, "CENTER", ClockX, db.Info.Clock.Y)
									end,
							order = 18,
						},
						ClockY = {
							name = "Y Value",
							disabled = function() return not db.Info.Clock.Enable end,
							desc = "Y Value for your Clock.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Clock.Y,
							type = "input",
							get = function() return db.Info.Clock.Y end,
							set = function(self,ClockY)
										if ClockY == nil or ClockY == "" then
											ClockY = "0"
										end
										db.Info.Clock.Y = ClockY
										Text_time:SetPoint("CENTER", infos_right, "CENTER", db.Info.Clock.X, ClockY)
									end,
							order = 19,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Clock.Enable end,
							order = 20,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Clock Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Clock.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Clock.Size end,
									set = function(_, FontSize)
											db.Info.Clock.Size = FontSize
											Text_time:SetFont(LSM:Fetch("font", db.Info.Clock.Font), FontSize, db.Info.Clock.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Clock Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Clock.Color.r.."\n g="..LUI.defaults.profile.Info.Clock.Color.g.."\n b="..LUI.defaults.profile.Info.Clock.Color.b.."\n a="..LUI.defaults.profile.Info.Clock.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Clock.Color.r, db.Info.Clock.Color.g, db.Info.Clock.Color.b, db.Info.Clock.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Clock.Color.r = r
											db.Info.Clock.Color.g = g
											db.Info.Clock.Color.b = b
											db.Info.Clock.Color.a = a
											
											Text_time:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Clock Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Clock.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Clock.Font end,
									set = function(self, Font)
											db.Info.Clock.Font = Font
											Text_time:SetFont(LSM:Fetch("font", Font), db.Info.Clock.Size, db.Info.Clock.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Clock Info Text.\nDefault: "..LUI.defaults.profile.Info.Clock.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Clock.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Clock.Outline = fontflags[FontFlag]
											Text_time:SetFont(LSM:Fetch("font", db.Info.Clock.Font), db.Info.Clock.Size, db.Info.Clock.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				Bags = {
					name = "Bags",
					type = "group",
					order = 11,
					args = {
						header94 = {
							name = "Bags",
							type = "header",
							order = 1,
						},
						BagsEnable = {
							name = "Enable",
							desc = "Whether you want to show your Bag Status or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Bags.Enable end,
							set = function(self, BagsEnable)
										db.Info.Bags.Enable = not db.Info.Bags.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						BagsX = {
							name = "X Value",
							desc = "X Value for your Bags Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Bags.X,
							type = "input",
							disabled = function() return not db.Info.Bags.Enable end,
							get = function() return db.Info.Bags.X end,
							set = function(self,BagsX)
										if BagsX == nil or BagsX == "" then
											BagsX = "0"
										end
										db.Info.Bags.X = BagsX
										Text_bags:SetPoint("CENTER", infos_left, "CENTER", BagsX, db.Info.Bags.Y)
									end,
							order = 3,
						},
						BagsY = {
							name = "Y Value",
							desc = "Y Value for your Bags Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Bags.Y,
							type = "input",
							disabled = function() return not db.Info.Bags.Enable end,
							get = function() return db.Info.Bags.Y end,
							set = function(self,BagsY)
										if BagsY == nil or BagsY == "" then
											BagsY = "0"
										end
										db.Info.Bags.Y = BagsY
										Text_bags:SetPoint("CENTER", infos_left, "CENTER", db.Info.Bags.X, BagsY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Bags.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Bag Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Bags.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Bags.Size end,
									set = function(_, FontSize)
											db.Info.Bags.Size = FontSize
											Text_bags:SetFont(LSM:Fetch("font", db.Info.Bags.Font), FontSize, db.Info.Bags.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Bags Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Bags.Color.r.."\n g="..LUI.defaults.profile.Info.Bags.Color.g.."\n b="..LUI.defaults.profile.Info.Bags.Color.b.."\n a="..LUI.defaults.profile.Info.Bags.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Bags.Color.r, db.Info.Bags.Color.g, db.Info.Bags.Color.b, db.Info.Bags.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Bags.Color.r = r
											db.Info.Bags.Color.g = g
											db.Info.Bags.Color.b = b
											db.Info.Bags.Color.a = a
											
											Text_bags:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Bags Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Bags.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Bags.Font end,
									set = function(self, Font)
											db.Info.Bags.Font = Font
											Text_bags:SetFont(LSM:Fetch("font", Font), db.Info.Bags.Size, db.Info.Bags.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Bags Info Text.\nDefault: "..LUI.defaults.profile.Info.Bags.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Bags.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Bags.Outline = fontflags[FontFlag]
											Text_bags:SetFont(LSM:Fetch("font", db.Info.Bags.Font), db.Info.Bags.Size, db.Info.Bags.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				Durability = {
					name = "Durability",
					type = "group",
					order = 12,
					args = {
						header95 = {
							name = "Durability",
							type = "header",
							order = 1,
						},
						ArmorEnable = {
							name = "Enable",
							desc = "Whether you want to show your Durability or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Armor.Enable end,
							set = function(self, ArmorEnable)
										db.Info.Armor.Enable = not db.Info.Armor.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						ArmorX = {
							name = "X Value",
							desc = "X Value for your Durability.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Armor.X,
							type = "input",
							disabled = function() return not db.Info.Armor.Enable end,
							get = function() return db.Info.Armor.X end,
							set = function(self,ArmorX)
										if ArmorX == nil or ArmorX == "" then
											ArmorX = "0"
										end
										db.Info.Armor.X = ArmorX
										Text_dura:SetPoint("CENTER", infos_left, "CENTER", ArmorX, db.Info.Armor.Y)
									end,
							order = 3,
						},
						ArmorY = {
							name = "Y Value",
							desc = "Y Value for your Durability.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Armor.Y,
							type = "input",
							disabled = function() return not db.Info.Armor.Enable end,
							get = function() return db.Info.Armor.Y end,
							set = function(self,ArmorY)
										if ArmorY == nil or ArmorY == "" then
											ArmorY = "0"
										end
										db.Info.Armor.Y = ArmorY
										Text_dura:SetPoint("CENTER", infos_left, "CENTER", db.Info.Armor.X, ArmorY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Armor.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Armor Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Armor.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Armor.Size end,
									set = function(_, FontSize)
											db.Info.Armor.Size = FontSize
											Text_dura:SetFont(LSM:Fetch("font", db.Info.Armor.Font), FontSize, db.Info.Armor.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Armor Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Armor.Color.r.."\n g="..LUI.defaults.profile.Info.Armor.Color.g.."\n b="..LUI.defaults.profile.Info.Armor.Color.b.."\n a="..LUI.defaults.profile.Info.Armor.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Armor.Color.r, db.Info.Armor.Color.g, db.Info.Armor.Color.b, db.Info.Armor.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Armor.Color.r = r
											db.Info.Armor.Color.g = g
											db.Info.Armor.Color.b = b
											db.Info.Armor.Color.a = a
											
											Text_dura:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Armor Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Armor.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Armor.Font end,
									set = function(self, Font)
											db.Info.Armor.Font = Font
											Text_dura:SetFont(LSM:Fetch("font", Font), db.Info.Armor.Size, db.Info.Armor.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Armor Info Text.\nDefault: "..LUI.defaults.profile.Info.Armor.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Armor.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Armor.Outline = fontflags[FontFlag]
											Text_dura:SetFont(LSM:Fetch("font", db.Info.Armor.Font), db.Info.Armor.Size, db.Info.Armor.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				FPS = {
					name = "FPS/MS",
					type = "group",
					order = 13,
					args = {
						header96 = {
							name = "FPS/MS",
							type = "header",
							order = 1,
						},
						FpsEnable = {
							name = "Enable",
							desc = "Whether you want to show your Fps/Ms or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Fps.Enable end,
							set = function(self, FpsEnable)
										db.Info.Fps.Enable = not db.Info.Fps.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						FpsX = {
							name = "X Value",
							desc = "X Value for your FPS/MS Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Fps.X,
							type = "input",
							disabled = function() return not db.Info.Fps.Enable end,
							get = function() return db.Info.Fps.X end,
							set = function(self,FpsX)
										if FpsX == nil or FpsX == "" then
											FpsX = "0"
										end
										db.Info.Fps.X = FpsX
										Text_fps:SetPoint("CENTER", infos_left, "CENTER", FpsX, db.Info.Fps.Y)
									end,
							order = 3,
						},
						FpsY = {
							name = "Y Value",
							desc = "Y Value for your FPS/MS Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Fps.Y,
							type = "input",
							disabled = function() return not db.Info.Fps.Enable end,
							get = function() return db.Info.Fps.Y end,
							set = function(self,FpsY)
										if FpsY == nil or FpsY == "" then
											FpsY = "0"
										end
										db.Info.Fps.Y = FpsY
										Text_fps:SetPoint("CENTER", infos_left, "CENTER", db.Info.Fps.X, FpsY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Fps.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Fps Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Fps.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Fps.Size end,
									set = function(_, FontSize)
											db.Info.Fps.Size = FontSize
											Text_fps:SetFont(LSM:Fetch("font", db.Info.Fps.Font), FontSize, db.Info.Fps.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Fps Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Fps.Color.r.."\n g="..LUI.defaults.profile.Info.Fps.Color.g.."\n b="..LUI.defaults.profile.Info.Fps.Color.b.."\n a="..LUI.defaults.profile.Info.Fps.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Fps.Color.r, db.Info.Fps.Color.g, db.Info.Fps.Color.b, db.Info.Fps.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Fps.Color.r = r
											db.Info.Fps.Color.g = g
											db.Info.Fps.Color.b = b
											db.Info.Fps.Color.a = a
											
											Text_fps:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Fps Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Fps.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Fps.Font end,
									set = function(self, Font)
											db.Info.Fps.Font = Font
											Text_fps:SetFont(LSM:Fetch("font", Font), db.Info.Fps.Size, db.Info.Fps.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Fps Info Text.\nDefault: "..LUI.defaults.profile.Info.Fps.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Fps.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Fps.Outline = fontflags[FontFlag]
											Text_fps:SetFont(LSM:Fetch("font", db.Info.Fps.Font), db.Info.Fps.Size, db.Info.Fps.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				MemoryUsage = {
					name = "Memory Usage",
					type = "group",
					order = 14,
					args = {
						header97 = {
							name = "Memory Usage",
							type = "header",
							order = 1,
						},
						MemoryEnable = {
							name = "Enable",
							desc = "Whether you want to show your Memory Usage or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Memory.Enable end,
							set = function(self, MemoryEnable)
										db.Info.Memory.Enable = not db.Info.Memory.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						MemoryX = {
							name = "X Value",
							desc = "X Value for your Addon Memory Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Memory.X,
							type = "input",
							disabled = function() return not db.Info.Memory.Enable end,
							get = function() return db.Info.Memory.X end,
							set = function(self,MemoryX)
										if MemoryX == nil or MemoryX == "" then
											MemoryX = "0"
										end
										db.Info.Memory.X = MemoryX
										Text_mb:SetPoint("CENTER", infos_left, "CENTER", MemoryX, db.Info.Memory.Y)
									end,
							order = 3,
						},
						MemoryY = {
							name = "Y Value",
							desc = "Y Value for your Addon Memory Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Memory.Y,
							type = "input",
							disabled = function() return not db.Info.Memory.Enable end,
							get = function() return db.Info.Memory.Y end,
							set = function(self,MemoryY)
										if MemoryY == nil or MemoryY == "" then
											MemoryY = "0"
										end
										db.Info.Memory.Y = MemoryY
										Text_mb:SetPoint("CENTER", infos_left, "CENTER", db.Info.Memory.X, MemoryY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Memory.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Memory Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Memory.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Memory.Size end,
									set = function(_, FontSize)
											db.Info.Memory.Size = FontSize
											Text_mb:SetFont(LSM:Fetch("font", db.Info.Memory.Font), FontSize, db.Info.Memory.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Memory Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Memory.Color.r.."\n g="..LUI.defaults.profile.Info.Memory.Color.g.."\n b="..LUI.defaults.profile.Info.Memory.Color.b.."\n a="..LUI.defaults.profile.Info.Memory.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Memory.Color.r, db.Info.Memory.Color.g, db.Info.Memory.Color.b, db.Info.Memory.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Memory.Color.r = r
											db.Info.Memory.Color.g = g
											db.Info.Memory.Color.b = b
											db.Info.Memory.Color.a = a
											
											Text_mb:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Memory Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Memory.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Memory.Font end,
									set = function(self, Font)
											db.Info.Memory.Font = Font
											Text_mb:SetFont(LSM:Fetch("font", Font), db.Info.Memory.Size, db.Info.Memory.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Memory Info Text.\nDefault: "..LUI.defaults.profile.Info.Memory.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Memory.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Memory.Outline = fontflags[FontFlag]
											Text_mb:SetFont(LSM:Fetch("font", db.Info.Memory.Font), db.Info.Memory.Size, db.Info.Memory.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				Guild = {
					name = "Guild",
					type = "group",
					order = 15,
					args = {
						header92g = {
							name = "Guild",
							type = "header",
							order = 1,
						},
						GuildEnable = {
							name = "Enable",
							desc = "Whether you want to show your Guild Status or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Guild.Enable end,
							set = function(self, GuildEnable)
										db.Info.Guild.Enable = not db.Info.Guild.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						GuildX = {
							name = "X Value",
							desc = "X Value for your Guild Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Guild.X,
							type = "input",
							disabled = function() return not db.Info.Guild.Enable end,
							get = function() return db.Info.Guild.X end,
							set = function(self,GuildX)
										if GuildX == nil or GuildX == "" then
											GuildX = "0"
										end
										db.Info.Guild.X = GuildX
										Text_guild:SetPoint("RIGHT", infos_right, "LEFT", GuildX, db.Info.Guild.Y)
									end,
							order = 3,
						},
						GuildY = {
							name = "Y Value",
							desc = "Y Value for your Guild Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Guild.Y,
							type = "input",
							disabled = function() return not db.Info.Guild.Enable end,
							get = function() return db.Info.Guild.Y end,
							set = function(self,GuildY)
										if GuildY == nil or GuildY == "" then
											GuildY = "0"
										end
										db.Info.Guild.Y = GuildY
										Text_guild:SetPoint("RIGHT", infos_right, "LEFT", db.Info.Guild.X, GuildY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Guild.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Guild Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Guild.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Guild.Size end,
									set = function(_, FontSize)
											db.Info.Guild.Size = FontSize
											Text_guild:SetFont(LSM:Fetch("font", db.Info.Guild.Font), FontSize, db.Info.Guild.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Guild Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Guild.Color.r.."\n g="..LUI.defaults.profile.Info.Guild.Color.g.."\n b="..LUI.defaults.profile.Info.Guild.Color.b.."\n a="..LUI.defaults.profile.Info.Guild.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Guild.Color.r, db.Info.Guild.Color.g, db.Info.Guild.Color.b, db.Info.Guild.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Guild.Color.r = r
											db.Info.Guild.Color.g = g
											db.Info.Guild.Color.b = b
											db.Info.Guild.Color.a = a
											
											Text_guild:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Guild Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Guild.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Guild.Font end,
									set = function(self, Font)
											db.Info.Guild.Font = Font
											Text_guild:SetFont(LSM:Fetch("font", Font), db.Info.Guild.Size, db.Info.Guild.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Guild Info Text.\nDefault: "..LUI.defaults.profile.Info.Guild.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Guild.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Guild.Outline = fontflags[FontFlag]
											Text_guild:SetFont(LSM:Fetch("font", db.Info.Guild.Font), db.Info.Guild.Size, db.Info.Guild.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				Friends = {
					name = "Friends",
					type = "group",
					order = 16,
					args = {
						header92f = {
							name = "Friends",
							type = "header",
							order = 1,
						},
						FriendsEnable = {
							name = "Enable",
							desc = "Whether you want to show your Friends Status or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Friends.Enable end,
							set = function(self, FriendsEnable)
										db.Info.Friends.Enable = not db.Info.Friends.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						FriendsX = {
							name = "X Value",
							desc = "X Value for your Friends Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Friends.X,
							type = "input",
							disabled = function() return not db.Info.Friends.Enable end,
							get = function() return db.Info.Friends.X end,
							set = function(self,FriendsX)
										if FriendsX == nil or FriendsX == "" then
											FriendsX = "0"
										end
										db.Info.Friends.X = FriendsX
										Text_friends:SetPoint("RIGHT", infos_right, "LEFT", FriendsX, db.Info.Friends.Y)
									end,
							order = 3,
						},
						FriendsY = {
							name = "Y Value",
							desc = "Y Value for your Friends Status.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Friends.Y,
							type = "input",
							disabled = function() return not db.Info.Friends.Enable end,
							get = function() return db.Info.Friends.Y end,
							set = function(self,FriendsY)
										if FriendsY == nil or FriendsY == "" then
											FriendsY = "0"
										end
										db.Info.Friends.Y = FriendsY
										Text_friends:SetPoint("RIGHT", infos_right, "LEFT", db.Info.Friends.X, FriendsY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Friends.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Friends Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Friends.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Friends.Size end,
									set = function(_, FontSize)
											db.Info.Friends.Size = FontSize
											Text_friends:SetFont(LSM:Fetch("font", db.Info.Friends.Font), FontSize, db.Info.Friends.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Friends Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Friends.Color.r.."\n g="..LUI.defaults.profile.Info.Friends.Color.g.."\n b="..LUI.defaults.profile.Info.Friends.Color.b.."\n a="..LUI.defaults.profile.Info.Friends.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Friends.Color.r, db.Info.Friends.Color.g, db.Info.Friends.Color.b, db.Info.Friends.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Friends.Color.r = r
											db.Info.Friends.Color.g = g
											db.Info.Friends.Color.b = b
											db.Info.Friends.Color.a = a
											
											Text_friends:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Friends Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Friends.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Friends.Font end,
									set = function(self, Font)
											db.Info.Friends.Font = Font
											Text_friends:SetFont(LSM:Fetch("font", Font), db.Info.Friends.Size, db.Info.Friends.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Friends Info Text.\nDefault: "..LUI.defaults.profile.Info.Friends.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Friends.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Friends.Outline = fontflags[FontFlag]
											Text_friends:SetFont(LSM:Fetch("font", db.Info.Friends.Font), db.Info.Friends.Size, db.Info.Friends.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
				DPS = {
					name = "DPS",
					type = "group",
					order = 17,
					args = {
						header96 = {
							name = "DPS",
							type = "header",
							order = 1,
						},
						DpsEnable = {
							name = "Enable",
							desc = "Whether you want to show your DPS or not.\n",
							type = "toggle",
							width = "full",
							get = function() return db.Info.Dps.Enable end,
							set = function(self, DpsEnable)
										db.Info.Dps.Enable = not db.Info.Dps.Enable
										StaticPopup_Show("RELOAD_UI")
									end,
							order = 2,
						},
						DpsX = {
							name = "X Value",
							desc = "X Value for your DPS Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Dps.X,
							type = "input",
							disabled = function() return not db.Info.Dps.Enable end,
							get = function() return db.Info.Dps.X end,
							set = function(self,DpsX)
										if DpsX == nil or DpsX == "" then
											DpsX = "0"
										end
										db.Info.Dps.X = DpsX
										Text_dps:SetPoint("LEFT", infos_right, "LEFT", DpsX, db.Info.Dps.Y)
									end,
							order = 3,
						},
						DpsY = {
							name = "Y Value",
							desc = "Y Value for your DPS Notice.\n\nNote:\nPositive values = right\nNegativ values = left\nDefault: "..LUI.defaults.profile.Info.Dps.Y,
							type = "input",
							disabled = function() return not db.Info.Dps.Enable end,
							get = function() return db.Info.Dps.Y end,
							set = function(self,DpsY)
										if DpsY == nil or DpsY == "" then
											DpsY = "0"
										end
										db.Info.Dps.Y = DpsY
										Text_dps:SetPoint("LEFT", infos_left, "LEFT", db.Info.Dps.X, DpsY)
									end,
							order = 4,
						},
						TextSettings = {
							name = "Font Settings",
							type = "group",
							disabled = function() return not db.Info.Dps.Enable end,
							order = 5,
							guiInline = true,
							args = {
								FontSize = {
									name = "Size",
									desc = "Choose your Dps Info Text Fontsize!\n Default: "..LUI.defaults.profile.Info.Dps.Size,
									type = "range",
									min = 1,
									max = 40,
									step = 1,
									get = function() return db.Info.Dps.Size end,
									set = function(_, FontSize)
											db.Info.Dps.Size = FontSize
											Text_dps:SetFont(LSM:Fetch("font", db.Info.Dps.Font), FontSize, db.Info.Dps.Outline)
										end,
									order = 1,
								},
								Color = {
									name = "Color",
									desc = "Choose an individual Dps Info Text Color.\n Defaults:\n r="..LUI.defaults.profile.Info.Dps.Color.r.."\n g="..LUI.defaults.profile.Info.Dps.Color.g.."\n b="..LUI.defaults.profile.Info.Dps.Color.b.."\n a="..LUI.defaults.profile.Info.Dps.Color.a,
									type = "color",
									hasAlpha = true,
									get = function() return db.Info.Dps.Color.r, db.Info.Dps.Color.g, db.Info.Dps.Color.b, db.Info.Dps.Color.a end,
									set = function(_,r,g,b,a)
											db.Info.Dps.Color.r = r
											db.Info.Dps.Color.g = g
											db.Info.Dps.Color.b = b
											db.Info.Dps.Color.a = a
											
											Text_dps:SetTextColor(r, g, b, a)
										end,
									order = 2,
								},
								Font = {
									name = "Font",
									desc = "Choose the Font for your Dps Info Text!\n\nDefault: "..LUI.defaults.profile.Info.Dps.Font,
									type = "select",
									dialogControl = "LSM30_Font",
									values = widgetLists.font,
									get = function() return db.Info.Dps.Font end,
									set = function(self, Font)
											db.Info.Dps.Font = Font
											Text_dps:SetFont(LSM:Fetch("font", Font), db.Info.Dps.Size, db.Info.Dps.Outline)
										end,
									order = 3,
								},
								FontFlag = {
									name = "Font Flag",
									desc = "Choose the Font Flag for your Dps Info Text.\nDefault: "..LUI.defaults.profile.Info.Dps.Outline,
									type = "select",
									values = fontflags,
									get = function()
											for k, v in pairs(fontflags) do
												if db.Info.Dps.Outline == v then
													return k
												end
											end
										end,
									set = function(self, FontFlag)
											db.Info.Dps.Outline = fontflags[FontFlag]
											Text_dps:SetFont(LSM:Fetch("font", db.Info.Dps.Font), db.Info.Dps.Size, db.Info.Dps.Outline)
										end,
									order = 4,
								},
							},
						},
					},
				},
			},
		},
	}

	return options
end

function module:LoadModule()
	local module = {
		InfoText = {
			order = LUI:GetModuleCount(),
			type = "execute",
			name = function()
				if db.Info.Enable then
					return "|cff00ff00InfoText Enabled|r"
				else
					return "|cffFF0000InfoText Disabled|r"
				end
			end,
			func = function(self, InfoText)
				db.Info.Enable = not db.Info.Enable
				StaticPopup_Show("RELOAD_UI")
			end,
		},
	}
	
	return module
end

function module:OnInitialize()

	LUI:MergeDefaults(LUI.db.defaults.profile, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterOptions(self:LoadOptions())
	LUI:RegisterModule(self:LoadModule())
	
	if db.Info.Enable == true then
		self:SetDataTextFrames()
		self:SetFPS()
		self:SetMemoryUsage()
		self:SetBags()
		self:SetDurability()
		self:SetGuild()
		self:SetFriends()
		self:SetGold()
		self:SetClock()
		self:SetDPS()
	end
end