--[[
	Project....: LUI NextGenWoWUserInterface
	File.......: bags.lua
	Description: Bags Module
	Version....: 1.0
	Rev Date...: 11/10/2010
	
	A featureless, 'pure' version of Stuffing. 
	This version should work on absolutely everything, 
	but I've removed pretty much all of the options.
]] 

local LUI = LibStub("AceAddon-3.0"):GetAddon("LUI")
local LSM = LibStub("LibSharedMedia-3.0")
local widgetLists = AceGUIWidgetLSMlists
local LUIHook = LUI:GetModule("LUIHook")
local module = LUI:NewModule("Bags", "AceHook-3.0")

local bags_BACKPACK = {0, 1, 2, 3, 4}
local bags_BANK = {-1, 5, 6, 7, 8, 9, 10, 11}
local ST_NORMAL = 1
local ST_SPECIAL = 3
local bag_bars = 0

-- hide bags options in default interface
InterfaceOptionsDisplayPanelShowFreeBagSpace:Hide()

Stuffing = CreateFrame ("Frame", nil, UIParent)
Stuffing:RegisterEvent("ADDON_LOADED")
Stuffing:RegisterEvent("PLAYER_ENTERING_WORLD")
Stuffing:SetScript("OnEvent", function(this, event, ...)
	Stuffing[event](this, ...)
end)

-- stub for localization.
local L = setmetatable({}, {
	__index = function (t, v)
		t[v] = v
		return v
	end
})

local function Print (x)
	DEFAULT_CHAT_FRAME:AddMessage("|cffC495DDLUI:|r " .. x)
end

local function Stuffing_Sort(args)
	if not args then
		args = ""
	end

	Stuffing.itmax = 0
	Stuffing:SetBagsForSorting(args)
	Stuffing:SortBags()
end

local function Stuffing_OnShow()
	Stuffing:PLAYERBANKSLOTS_CHANGED(29)	-- XXX: hack to force bag frame update

	Stuffing:Layout()
	Stuffing:SearchReset()
end

local function StuffingBank_OnHide()
	CloseBankFrame()
end

local function Stuffing_OnHide()
	if Stuffing.bankFrame and Stuffing.bankFrame:IsShown() then
		Stuffing.bankFrame:Hide()
	end
end

local function Stuffing_Open()
	Stuffing.frame:Show()
end

local function Stuffing_Close()
	Stuffing.frame:Hide()
end

local function Stuffing_Toggle()
	if Stuffing.frame:IsShown() then
		Stuffing.frame:Hide()
	else
		Stuffing.frame:Show()
	end
end

local function Stuffing_ToggleBag(id)
	if id == -2 then
		ToggleKeyRing()
		return
	end
	Stuffing_Toggle()
end

local function Stuffing_StartMoving(self)
	self:StartMoving()
	local n = self:GetName()
end

local function Stuffing_StopMoving(self)
	self:StopMovingOrSizing()
	self:SetUserPlaced(false)

	local n = self:GetName()
	local x, y = self:GetCenter()
	
	if n == "StuffingFrameBank" then
		db.Bags.Coordinates.Bank.X = x
		db.Bags.Coordinates.Bank.Y = y
	else
		db.Bags.Coordinates.Bags.X = x
		db.Bags.Coordinates.Bags.Y = y
	end
end

--
-- bag slot stuff
--
local trashParent = CreateFrame("Frame", nil, UIParent)
local trashButton = {}
local trashBag = {}

-- for the tooltip frame used to scan item tooltips
local StuffingTT = nil

function Stuffing:SlotUpdate(b)
	if not StuffingFrameBags:IsShown() then return end -- don't do any slot update if bags are not show
	local texture, count, locked = GetContainerItemInfo (b.bag, b.slot)
	local clink = GetContainerItemLink(b.bag, b.slot)
	
	if not b.frame.lock then
		b.frame:SetBackdropBorderColor(db.Bags.Border.Color.r,db.Bags.Border.Color.g,db.Bags.Border.Color.b,db.Bags.Border.Color.a)
	end
	
	
	if b.Cooldown then
		local cd_start, cd_finish, cd_enable = GetContainerItemCooldown(b.bag, b.slot)
		CooldownFrame_SetTimer(b.Cooldown, cd_start, cd_finish, cd_enable)
	end

	if(clink) then
		local iType
		b.name, _, b.rarity, _, _, iType = GetItemInfo(clink)
		
		-- color slot according to item quality
		--if not b.frame.lock and b.rarity and b.rarity > 1 then
			--b.frame:SetBackdropBorderColor(GetItemQualityColor(b.rarity))
		--else
			b.frame:SetBackdropBorderColor(db.Bags.Border.Color.r,db.Bags.Border.Color.g,db.Bags.Border.Color.b,db.Bags.Border.Color.a)
		--end

		if not StuffingTT then
			StuffingTT = CreateFrame("GameTooltip", "StuffingTT", nil, "GameTooltipTemplate")
			StuffingTT:Hide()
		end
	else
		b.name, b.rarity = nil, nil
	end
	
	SetItemButtonTexture(b.frame, texture)
	SetItemButtonCount(b.frame, count)
	SetItemButtonDesaturated(b.frame, locked, 0.5, 0.5, 0.5)
		
	b.frame:Show()
end

function Stuffing:BagSlotUpdate(bag)
	if not self.buttons then
		return
	end

	for _, v in ipairs (self.buttons) do
		if v.bag == bag then
			self:SlotUpdate(v)
		end
	end
end

function Stuffing:BagFrameSlotNew (slot, p)
	for _, v in ipairs(self.bagframe_buttons) do
		if v.slot == slot then
			--print ("found " .. slot)
			return v, false
		end
	end

	--print ("new " .. slot)
	local ret = {}
	local tpl

	if slot > 3 then
		ret.slot = slot
		slot = slot - 4
		tpl = "BankItemButtonBagTemplate"
		ret.frame = CreateFrame("CheckButton", "StuffingBBag" .. slot, p, tpl)
		ret.frame:SetID(slot + 4)
		table.insert(self.bagframe_buttons, ret)

		BankFrameItemButton_Update(ret.frame)
		BankFrameItemButton_UpdateLocked(ret.frame)

		if not ret.frame.tooltipText then
			ret.frame.tooltipText = ""
		end
	else
		tpl = "BagSlotButtonTemplate"
		ret.frame = CreateFrame("CheckButton", "StuffingFBag" .. slot .. "Slot", p, tpl)
		ret.slot = slot
		table.insert(self.bagframe_buttons, ret)
	end

	return ret
end

function Stuffing:SlotNew (bag, slot)
	for _, v in ipairs(self.buttons) do
		if v.bag == bag and v.slot == slot then
			return v, false
		end
	end

	local tpl = "ContainerFrameItemButtonTemplate"

	if bag == -1 then
		tpl = "BankItemButtonGenericTemplate"
	end

	local ret = {}

	if #trashButton > 0 then
		local f = -1
		for i, v in ipairs(trashButton) do
			local b, s = v:GetName():match("(%d+)_(%d+)")

			b = tonumber(b)
			s = tonumber(s)

			--print (b .. " " .. s)
			if b == bag and s == slot then
				f = i
				break
			end
		end

		if f ~= -1 then
			--print("found it")
			ret.frame = trashButton[f]
			table.remove(trashButton, f)
		end
	end

	if not ret.frame then
		ret.frame = CreateFrame("Button", "StuffingBag" .. bag .. "_" .. slot, self.bags[bag], tpl)
	end

	ret.bag = bag
	ret.slot = slot
	ret.frame:SetID(slot)

	ret.Cooldown = _G[ret.frame:GetName() .. "Cooldown"]
	ret.Cooldown:Show()

	self:SlotUpdate (ret)

	return ret, true
end

-- from OneBag
 
local BAGTYPE_PROFESSION = 0x0008 + 0x0010 + 0x0020 + 0x0040 + 0x0080 + 0x0200 + 0x0400

function Stuffing:BagType(bag)
	local bagType = select(2, GetContainerNumFreeSlots(bag))

	if bit.band(bagType, BAGTYPE_PROFESSION) > 0 then
		return ST_SPECIAL
	end

	return ST_NORMAL
end

function Stuffing:BagNew (bag, f)
	for i, v in pairs(self.bags) do
		if v:GetID() == bag then
			v.bagType = self:BagType(bag)
			return v
		end
	end

	local ret

	if #trashBag > 0 then
		local f = -1
		for i, v in pairs(trashBag) do
			if v:GetID() == bag then
				f = i
				break
			end
		end

		if f ~= -1 then
			--print("found bag " .. bag)
			ret = trashBag[f]
			table.remove(trashBag, f)
			ret:Show()
			ret.bagType = self:BagType(bag)
			return ret
		end
	end

	--print("new bag " .. bag)
	ret = CreateFrame("Frame", "StuffingBag" .. bag, f)
	ret.bagType = self:BagType(bag)

	ret:SetID(bag)
	return ret
end

function Stuffing:SearchUpdate(str)
	str = string.lower(str)

	for _, b in ipairs(self.buttons) do
		if b.frame and not b.name then
			b.frame:SetAlpha(.2)
		end
		if b.name then
			if not string.find (string.lower(b.name), str) then
				SetItemButtonDesaturated(b.frame, 1, 1, 1, 1)
				b.frame:SetAlpha(.2)
			else
				SetItemButtonDesaturated(b.frame, 0, 1, 1, 1)
				b.frame:SetAlpha(1)
			end
		end
	end
end

function Stuffing:SearchReset()
	for _, b in ipairs(self.buttons) do
		b.frame:SetAlpha(1)
		SetItemButtonDesaturated(b.frame, 0, 1, 1, 1)
	end
end

-- drop down menu stuff from Postal
local Stuffing_DDMenu = CreateFrame("Frame", "Stuffing_DropDownMenu")
Stuffing_DDMenu.displayMode = "MENU"
Stuffing_DDMenu.info = {}
Stuffing_DDMenu.HideMenu = function()
	if UIDROPDOWNMENU_OPEN_MENU == Stuffing_DDMenu then
		CloseDropDownMenus()
	end
end

function Stuffing:CreateBagFrame(w)
	local n = "StuffingFrame"  .. w
	local f = CreateFrame ("Frame", n, UIParent)
	f:EnableMouse(1)
	f:SetMovable(1)
	f:SetToplevel(1)
	f:SetFrameStrata("HIGH")
	f:SetFrameLevel(20)

	if w == "Bank" then
		f:SetScript("OnMouseDown", Stuffing_StartMoving)
		f:SetScript("OnMouseUp", Stuffing_StopMoving)
	else
		if db.Bags.Locked == 0 then
			f:SetScript("OnMouseDown", Stuffing_StartMoving)
			f:SetScript("OnMouseUp", Stuffing_StopMoving)
		end
	end
	
	if w == "Bank" then
		local x = db.Bags.Coordinates.Bank.X or 0
		local y = db.Bags.Coordinates.Bank.Y or 0
		f:SetPoint ("CENTER", UIParent, "BOTTOMLEFT", x, y)
	else
		local x = db.Bags.Coordinates.Bags.X or 0
		local y = db.Bags.Coordinates.Bags.Y or 0
		f:SetPoint ("CENTER", UIParent, "BOTTOMLEFT", x, y)
	end
	
	-- close button
	f.b_close = CreateFrame("Button", "Stuffing_CloseButton" .. w, f, "UIPanelCloseButton")
	f.b_close:SetWidth(LUI:Scale(32))
	f.b_close:SetHeight(LUI:Scale(32))
	f.b_close:SetPoint("TOPRIGHT", LUI:Scale(-3), LUI:Scale(-3))
	f.b_close:SetScript("OnClick", function(self, btn)
		if self:GetParent():GetName() == "StuffingFrameBags" and btn == "RightButton" then
			if Stuffing_DDMenu.initialize ~= Stuffing.Menu then
				CloseDropDownMenus()
				Stuffing_DDMenu.initialize = Stuffing.Menu
			end
			ToggleDropDownMenu(1, nil, Stuffing_DDMenu, self:GetName(), 0, 0)
			return
		end
		self:GetParent():Hide()
	end)
	f.b_close:RegisterForClicks("AnyUp")
	f.b_close:GetNormalTexture():SetDesaturated(1)

	-- create the bags frame
	local fb = CreateFrame ("Frame", n .. "BagsFrame", f)
	fb:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, LUI:Scale(2))
	fb:SetFrameStrata("HIGH")
	f.bags_frame = fb

	return f
end

function Stuffing:InitBank()
	if self.bankFrame then
		return
	end

	local f = self:CreateBagFrame("Bank")
	f:SetScript("OnHide", StuffingBank_OnHide)
	self.bankFrame = f
end

local parent_startmoving = function(self)
	Stuffing_StartMoving(self:GetParent())
end

local parent_stopmovingorsizing = function (self)
	Stuffing_StopMoving(self:GetParent())
end

function Stuffing:InitBags()
	if self.frame then
		return
	end

	self.buttons = {}
	self.bags = {}
	self.bagframe_buttons = {}

	local f = self:CreateBagFrame("Bags")
	f:SetScript("OnShow", Stuffing_OnShow)
	f:SetScript("OnHide", Stuffing_OnHide)

	-- search editbox (tekKonfigAboutPanel.lua)
	local editbox = CreateFrame("EditBox", nil, f)
	editbox:Hide()
	editbox:SetAutoFocus(true)
	editbox:SetHeight(LUI:Scale(32))
	editbox:SetBackdrop( { 
		bgFile = LUI_Media.blank, 
		edgeFile = LUI_Media.blank, 
		tile = false, edgeSize = 0, 
		insets = { left = 0, right = 0, top = 0, bottom = 0 }
	})
	editbox:SetBackdropColor(0,0,0,0)
	editbox:SetBackdropBorderColor(0,0,0,0)

	local resetAndClear = function (self)
		self:GetParent().detail:Show()
		self:GetParent().gold:Show()
		self:ClearFocus()
		Stuffing:SearchReset()
	end

	local updateSearch = function(self, t)
		if t == true then
			Stuffing:SearchUpdate(self:GetText())
		end
	end

	editbox:SetScript("OnEscapePressed", resetAndClear)
	editbox:SetScript("OnEnterPressed", resetAndClear)
	editbox:SetScript("OnEditFocusLost", editbox.Hide)
	editbox:SetScript("OnEditFocusGained", editbox.HighlightText)
	editbox:SetScript("OnTextChanged", updateSearch)
	editbox:SetText("Search")

	local detail = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
	detail:SetPoint("TOPLEFT", f, LUI:Scale(db.Bags.Padding), LUI:Scale(-10))
	detail:SetPoint("RIGHT", LUI:Scale(-(16 + 24)), 0)
	detail:SetJustifyH("LEFT")
	detail:SetText("|cff9999ff" .. "Search")
	editbox:SetAllPoints(detail)

	local gold = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
	gold:SetJustifyH("RIGHT")
	gold:SetPoint("RIGHT", f.b_close, "LEFT", LUI:Scale(-3), 0)

	f:SetScript("OnEvent", function (self, e)
		self.gold:SetText(GetMoneyString(GetMoney(), 12))
	end)

	f:RegisterEvent("PLAYER_MONEY")
	f:RegisterEvent("PLAYER_LOGIN")
	f:RegisterEvent("PLAYER_TRADE_MONEY")
	f:RegisterEvent("TRADE_MONEY_CHANGED")

	local OpenEditbox = function(self)
		self:GetParent().detail:Hide()
		self:GetParent().gold:Hide()
		self:GetParent().editbox:Show()
		self:GetParent().editbox:HighlightText()
	end

	local button = CreateFrame("Button", nil, f)
	button:EnableMouse(1)
	button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	button:SetAllPoints(detail)
	button:SetScript("OnClick", function(self, btn)
		if btn == "RightButton" then
			OpenEditbox(self)
		else
			if self:GetParent().editbox:IsShown() then
				self:GetParent().editbox:Hide()
				self:GetParent().editbox:ClearFocus()
				self:GetParent().detail:Show()
				self:GetParent().gold:Show()
				Stuffing:SearchReset()
			end
		end
	end)

	local tooltip_hide = function()
		GameTooltip:Hide()
	end

	local tooltip_show = function (self)
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
		GameTooltip:ClearLines()
		GameTooltip:SetText("Right-click to search.")
	end

	button:SetScript("OnEnter", tooltip_show)
	button:SetScript("OnLeave", tooltip_hide)
	
	button:SetScript("OnMouseDown", parent_startmoving)
	button:SetScript("OnMouseUp", parent_stopmovingorsizing)
	
	f.editbox = editbox
	f.detail = detail
	f.button = button
	f.gold = gold
	self.frame = f
	f:Hide()
end

local isCreated = false
local isBankCreated = false

function Stuffing:Layout(lb)
	local f
	local cols
	local bs
	
	local slots = 0
	local rows = 0
	local off = 26
	local padding = db.Bags.Padding
	local spacing = db.Bags.Spacing
	local borderTex = LSM:Fetch("border", db.Bags.Border.Texture)
	local border_size = db.Bags.Border.Size
	local border_inset = db.Bags.Border.Inset
	local border_color = { db.Bags.Border.Color.r,db.Bags.Border.Color.g,db.Bags.Border.Color.b,db.Bags.Border.Color.a }
	local background_color = { db.Bags.Background.Color.r,db.Bags.Background.Color.g,db.Bags.Background.Color.b,db.Bags.Background.Color.a }
	
	if lb then
		bs = bags_BANK
		cols = db.Bags.Cols_Bank
		f = self.bankFrame
		if isBankCreated == false then
			isCreated = false
			isBankCreated = true
		end
	else
		bs = bags_BACKPACK
		cols = db.Bags.Cols_Bags
		
		f = self.frame

		f.gold:SetText(GetMoneyString(GetMoney(), 12))
		f.editbox:SetFont(LSM:Fetch("font", db.Bags.Font), 12)
		f.detail:SetFont(LSM:Fetch("font", db.Bags.Font), 12)
		f.gold:SetFont(LSM:Fetch("font", db.Bags.Font), 12)

		f.detail:ClearAllPoints()
		f.detail:SetPoint("TOPLEFT", f, LUI:Scale(db.Bags.Padding), LUI:Scale(-10))
		f.detail:SetPoint("RIGHT", LUI:Scale(-(16 + 24)), 0)
	end
	
	if isCreated == false then
		f:SetClampedToScreen(1)
		f:SetBackdrop( { 
			bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
			edgeFile = borderTex, 
			tile = false, edgeSize = 5, 
			insets = { left = 3, right = 3, top = 3, bottom = 3 }
		})
		f:SetBackdropColor(0.1,0.1,0.1,1)
		f:SetBackdropBorderColor(0.3,0.3,0.3,1)

		-- bag frame stuff
		local fb = f.bags_frame
		if bag_bars == 1 then
		
			fb:SetClampedToScreen(1)
			fb:SetBackdrop( { 
				bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
				edgeFile = borderTex, 
				tile = false, edgeSize = LUI.mult, 
				insets = { left = -LUI.mult, right = -LUI.mult, top = -LUI.mult, bottom = -LUI.mult }
			})
			fb:SetBackdropColor(unpack(background_color))
			fb:SetBackdropBorderColor(unpack(border_color))

			local bsize = 30
			if lb then bsize = 37 end
			
			local w = 2 * padding
			w = w + ((#bs - 1) * bsize)
			w = w + (spacing * (#bs - 2))

			fb:SetHeight(LUI:Scale(2 * padding + bsize))
			fb:SetWidth(LUI:Scale(w))
			fb:Show()
		else
			fb:Hide()
		end

		local idx = 0
		for _, v in ipairs(bs) do
			if (not lb and v <= 3 ) or (lb and v ~= -1) then
				local bsize = 30
				if lb then bsize = 37 end

				local b = self:BagFrameSlotNew(v, fb)

				local xoff = padding

				xoff = xoff + (idx * bsize)
				xoff = xoff + (idx * spacing)

				b.frame:ClearAllPoints()
				b.frame:SetPoint("LEFT", fb, "LEFT", LUI:Scale(xoff), 0)
				b.frame:Show()

				idx = idx + 1
			end
		end

		for _, i in ipairs(bs) do
			local x = GetContainerNumSlots(i)
			if x > 0 then
				if not self.bags[i] then
					self.bags[i] = self:BagNew(i, f)
				end

				slots = slots + GetContainerNumSlots(i)
			end
		end

		rows = floor (slots / cols)
		if (slots % cols) ~= 0 then
			rows = rows + 1
		end
		
		f:SetWidth(LUI:Scale(cols * 31 + (cols - 1) * spacing + padding * 2))
		f:SetHeight(LUI:Scale(rows * 31 + (rows - 1) * spacing + off + padding * 2))
	end
	
	local idx = 0
	for _, i in ipairs(bs) do
		local bag_cnt = GetContainerNumSlots(i)

		if bag_cnt > 0 then
			self.bags[i] = self:BagNew(i, f)
			local bagType = self.bags[i].bagType

			self.bags[i]:Show()
			for j = 1, bag_cnt do
				local b, isnew = self:SlotNew (i, j)
					
				if isnew then
					table.insert(self.buttons, idx + 1, b)
				end
					
				if isCreated == false then
					local xoff
					local yoff
					local x = (idx % cols)
					local y = floor(idx / cols)

					xoff = padding + (x * 31) + (x * spacing)
					yoff = off + padding + (y * 31) + ((y - 1) * spacing)
					yoff = yoff * -1
					
					b.frame:ClearAllPoints()
					b.frame:SetPoint("TOPLEFT", f, "TOPLEFT", LUI:Scale(xoff), LUI:Scale(yoff))
					b.frame:SetHeight(LUI:Scale(32))
					b.frame:SetWidth(LUI:Scale(32))
					b.frame:SetPushedTexture("")
					b.frame:SetNormalTexture("")
					b.frame:Show()
				
					b.frame:SetBackdrop( { 
						bgFile = "Interface/Tooltips/UI-Tooltip-Background",
						edgeFile = borderTex, 
						tile = false, tileSize = 0, edgeSize = 15, 
						insets = { left = 5, right = 5, top = 5, bottom = 5 }
					})
					b.frame:SetBackdropColor(unpack(background_color))
					b.frame:SetBackdropBorderColor(unpack(border_color))
				end
					
				LUI:StyleButton(b.frame)
				self:SlotUpdate(b)
				
				local iconTex = _G[b.frame:GetName() .. "IconTexture"]
				iconTex:SetTexCoord(.08, .92, .08, .92)
				iconTex:SetPoint("TOPLEFT", b.frame, LUI:Scale(3), LUI:Scale(-3))
				iconTex:SetPoint("BOTTOMRIGHT", b.frame, LUI:Scale(-3), LUI:Scale(3))

				iconTex:Show()
				b.iconTex = iconTex
				
				idx = idx + 1
			end
		end
	end
	
	isCreated = true
end

function Stuffing:SetBagsForSorting(c)
	Stuffing_Open()

	self.sortBags = {}

	local cmd = ((c == nil or c == "") and {"d"} or {strsplit("/", c)})

	for _, s in ipairs(cmd) do
		if s == "c" then
			self.sortBags = {}
		elseif s == "d" then
			if not self.bankFrame or not self.bankFrame:IsShown() then
				for _, i in ipairs(bags_BACKPACK) do
					if self.bags[i] and self.bags[i].bagType == ST_NORMAL then
						table.insert(self.sortBags, i)
					end
				end
			else
				for _, i in ipairs(bags_BANK) do
					if self.bags[i] and self.bags[i].bagType == ST_NORMAL then
						table.insert(self.sortBags, i)
					end
				end
			end
		elseif s == "p" then
			if not self.bankFrame or not self.bankFrame:IsShown() then
				for _, i in ipairs(bags_BACKPACK) do
					if self.bags[i] and self.bags[i].bagType == ST_SPECIAL then
						table.insert(self.sortBags, i)
					end
				end
			else
				for _, i in ipairs(bags_BANK) do
					if self.bags[i] and self.bags[i].bagType == ST_SPECIAL then
						table.insert(self.sortBags, i)
					end
				end
			end
		else
			if tonumber(s) == nil then
				Print(string.format(L["Error: don't know what \"%s\" means."], s))
			end

			table.insert(self.sortBags, tonumber(s))
		end
	end

	local bids = "Using bags: "
	for _, i in ipairs(self.sortBags) do
		bids = bids .. i .. " "
	end

	Print(bids)
end

-- slash command handler
local function StuffingSlashCmd(Cmd)
	local cmd, args = strsplit(" ", Cmd:lower(), 2)

	if cmd == "config" then
		Stuffing_OpenConfig()
	elseif cmd == "sort" then
		Stuffing_Sort(args)
	elseif cmd == "psort" then
		Stuffing_Sort("c/p")
	elseif cmd == "stack" then
		Stuffing:SetBagsForSorting(args)
		Stuffing:Restack()
	elseif cmd == "test" then
		Stuffing:SetBagsForSorting(args)
	elseif cmd == "purchase" then
		-- XXX
		if Stuffing.bankFrame and Stuffing.bankFrame:IsShown() then
			local cnt, full = GetNumBankSlots()
			if full then
				Print("can't buy anymore slots!")
				return
			end

			if args == "yes" then
				PurchaseSlot()
				return
			end

			Print(string.format("Cost: %.2f gold", GetBankSlotCost() / 10000))
			Print("Buy new slot with /bags purchase yes")
		else
			Print("You need to open your bank first.")
		end
	else
		Print("sort - sort your bags or your bank, if open.")
		Print("stack - fill up partial stacks in your bags or bank, if open.")
		Print("purchase - buy bank slot. (need to have bank open)")
	end
end


function Stuffing:ADDON_LOADED(addon)
	if addon ~= "LUI" then
		return nil
	end
	
	if db.Bags.Enable ~= true then return end
	
	self:RegisterEvent("BAG_UPDATE")
	self:RegisterEvent("ITEM_LOCK_CHANGED")

	self:RegisterEvent("BANKFRAME_OPENED")
	self:RegisterEvent("BANKFRAME_CLOSED")
	self:RegisterEvent("PLAYERBANKSLOTS_CHANGED")

	self:RegisterEvent("BAG_CLOSED")

	SlashCmdList["STUFFING"] = StuffingSlashCmd
	SLASH_STUFFING1 = "/bags"

	self:InitBags()
	
	tinsert(UISpecialFrames,"StuffingFrameBags")

	ToggleBackpack = Stuffing_Toggle
	OpenAllBags = Stuffing_Toggle
	OpenBackpack = Stuffing_Toggle
	CloseBackpack = Stuffing_Close
	CloseAllBags = Stuffing_Close

	BankFrame:UnregisterAllEvents()
end

function Stuffing:PLAYER_ENTERING_WORLD()
	if db.Bags.Enable ~= true then return end
	-- please don't do anything after 1 player_entering_world event.
	Stuffing:UnregisterEvent("PLAYER_ENTERING_WORLD")
	
	-- hooking and setting key ring bag
	-- this is just a reskin of Blizzard key bag to fit LUI
	-- hooking OnShow because sometime key max slot changes.
	ContainerFrame1:HookScript("OnShow", function(self)
		local keybackdrop = CreateFrame("Frame", nil, self)
		keybackdrop:SetPoint("TOPLEFT", LUI:Scale(9), LUI:Scale(-40))
		keybackdrop:SetPoint("BOTTOMLEFT", 0, 0)
		keybackdrop:SetSize(LUI:Scale(179),LUI:Scale(215))
		keybackdrop:SetBackdrop( { 
			bgFile = LSM:Fetch("background", LUI_Media.empty), 
			edgeFile = LSM:Fetch("border", LUI_Media.empty), 
			tile = false, edgeSize = 0, 
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})
		keybackdrop:SetBackdropColor(0,0,0,0)
		keybackdrop:SetBackdropBorderColor(0,0,0,0)
		
		ContainerFrame1CloseButton:Hide()
		ContainerFrame1Portrait:Hide()
		ContainerFrame1Name:Hide()
		ContainerFrame1BackgroundTop:SetAlpha(0)
		ContainerFrame1BackgroundMiddle1:SetAlpha(0)
		ContainerFrame1BackgroundMiddle2:SetAlpha(0)
		ContainerFrame1BackgroundBottom:SetAlpha(0)
		for i=1, GetKeyRingSize() do
			local slot = _G["ContainerFrame1Item"..i]
			local t = _G["ContainerFrame1Item"..i.."IconTexture"]
			slot:SetPushedTexture("")
			slot:SetNormalTexture("")
			t:SetTexCoord(.08, .92, .08, .92)
			t:SetPoint("TOPLEFT", slot, LUI:Scale(2), LUI:Scale(-2))
			t:SetPoint("BOTTOMRIGHT", slot, LUI:Scale(-2), LUI:Scale(2))
			slot:SetBackdrop( { 
				bgFile = LSM:Fetch("background", db.Bags.Background.Texture), 
				edgeFile = LSM:Fetch("border", db.Bags.Border.Texture), 
				tile = false, edgeSize = 20, 
				insets = { left = 5, right = -3, top = -3, bottom = 5 }
			})
			slot:SetBackdropColor(db.Bags.Background.Color.r,db.Bags.Background.Color.g,db.Bags.Background.Color.b,db.Bags.Background.Color.a)
			slot:SetBackdropBorderColor(db.Bags.Border.Color.r,db.Bags.Border.Color.g,db.Bags.Border.Color.b,db.Bags.Border.Color.a)
			LUI:StyleButton(slot, false)
		end
		self:ClearAllPoints()
		self:SetPoint("CENTER", UIParent, "CENTER", LUI:Scale(4), LUI:Scale(5))
	end)
end

function Stuffing:PLAYERBANKSLOTS_CHANGED(id)
	if id > 28 then
		for _, v in ipairs(self.bagframe_buttons) do
			if v.frame and v.frame.GetInventorySlot then

				BankFrameItemButton_Update(v.frame)
				BankFrameItemButton_UpdateLocked(v.frame)

				if not v.frame.tooltipText then
					v.frame.tooltipText = ""
				end
			end
		end
	end

	if self.bankFrame and self.bankFrame:IsShown() then
		self:BagSlotUpdate(-1)
	end
end

function Stuffing:BAG_UPDATE(id)
	self:BagSlotUpdate(id)
end

function Stuffing:ITEM_LOCK_CHANGED(bag, slot)
	if slot == nil then
		return
	end

	for _, v in ipairs(self.buttons) do
		if v.bag == bag and v.slot == slot then
			self:SlotUpdate(v)
			break
		end
	end
end

function Stuffing:BANKFRAME_OPENED()
	if not self.bankFrame then
		self:InitBank()
	end

	self:Layout(true)
	for _, x in ipairs(bags_BANK) do
		self:BagSlotUpdate(x)
	end
	self.bankFrame:Show()
	Stuffing_Open()
end

function Stuffing:BANKFRAME_CLOSED()
	if not self.bankFrame then
		return
	end

	self.bankFrame:Hide()
end

function Stuffing:BAG_CLOSED(id)
	local b = self.bags[id]
	if b then
		table.remove(self.bags, id)
		b:Hide()
		table.insert (trashBag, #trashBag + 1, b)
	end

	while true do
		local changed = false

		for i, v in ipairs(self.buttons) do
			if v.bag == id then
				v.frame:Hide()
				v.iconTex:Hide()

				table.insert (trashButton, #trashButton + 1, v.frame)
				table.remove(self.buttons, i)

				v = nil
				changed = true
			end
		end

		if not changed then
			break
		end
	end
end

function Stuffing:SortOnUpdate(e)
	if not self.elapsed then
		self.elapsed = 0
	end

	if not self.itmax then
		self.itmax = 0
	end

	self.elapsed = self.elapsed + e

	if self.elapsed < 0.1 then
		return
	end

	self.elapsed = 0
	self.itmax = self.itmax + 1

	local changed, blocked  = false, false

	if self.sortList == nil or next(self.sortList, nil) == nil then
		-- wait for all item locks to be released.
		local locks = false

		for i, v in pairs(self.buttons) do
			local _, _, l = GetContainerItemInfo(v.bag, v.slot)
			if l then
				locks = true
			else
				v.block = false
			end
		end

		if locks then
			-- something still locked. wait some more.
			return
		else
			-- all unlocked. get a new table.
			self:SetScript("OnUpdate", nil)
			self:SortBags()

			if self.sortList == nil then
				return
			end
		end
	end

	-- go through the list and move stuff if we can.
	for i, v in ipairs (self.sortList) do
		repeat
			if v.ignore then
				blocked = true
				break
			end

			if v.srcSlot.block then
				changed = true
				break
			end

			if v.dstSlot.block then
				changed = true
				break
			end

			local _, _, l1 = GetContainerItemInfo(v.dstSlot.bag, v.dstSlot.slot)
			local _, _, l2 = GetContainerItemInfo(v.srcSlot.bag, v.srcSlot.slot)

			if l1 then
				v.dstSlot.block = true
			end

			if l2 then
				v.srcSlot.block = true
			end

			if l1 or l2 then
				break
			end

			if v.sbag ~= v.dbag or v.sslot ~= v.dslot then
				if v.srcSlot.name ~= v.dstSlot.name then
					v.srcSlot.block = true
					v.dstSlot.block = true
					PickupContainerItem (v.sbag, v.sslot)
					PickupContainerItem (v.dbag, v.dslot)
					changed = true
					break
				end
			end
		until true
	end

	self.sortList = nil

	if (not changed and not blocked) or self.itmax > 250 then
		self:SetScript("OnUpdate", nil)
		self.sortList = nil
		Print ("Sorting finished.")
	end
end


local function InBags(x)
	if not Stuffing.bags[x] then
		return false
	end

	for _, v in ipairs(Stuffing.sortBags) do
		if x == v then
			return true
		end
	end
	return false
end


function Stuffing:SortBags()
	local bs = self.sortBags
	if #bs < 1 then
		Print ("Nothing to sort.")
		return
	end

	local st = {}
	local bank = false

	Stuffing_Open()

	for i, v in pairs(self.buttons) do
		if InBags(v.bag) then
			self:SlotUpdate(v)

			if v.name then
				local tex, cnt, _, _, _, _, clink = GetContainerItemInfo(v.bag, v.slot)
				local n, _, q, iL, rL, c1, c2, _, Sl = GetItemInfo(clink)
				table.insert(st, {
					srcSlot = v,
					sslot = v.slot,
					sbag = v.bag,
					--sort = q .. iL .. c1 .. c2 .. rL .. Sl .. n .. i,
					--sort = q .. iL .. c1 .. c2 .. rL .. Sl .. n .. (#self.buttons - i),
					sort = q .. c1 .. c2 .. rL .. n .. iL .. Sl .. (#self.buttons - i),
					--sort = q .. (#self.buttons - i) .. n,
				})
			end
		end
	end

	-- sort them
	table.sort (st, function(a, b)
		return a.sort > b.sort
	end)

	-- for each button we want to sort, get a destination button
	local st_idx = #bs
	local dbag = bs[st_idx]
	local dslot = GetContainerNumSlots(dbag)
 
	for i, v in ipairs (st) do
		v.dbag = dbag
		v.dslot = dslot
		v.dstSlot = self:SlotNew(dbag, dslot)
 
		dslot = dslot - 1
 
		if dslot == 0 then
			while true do
				st_idx = st_idx - 1
 
				if st_idx < 0 then
					break
				end
 
				dbag = bs[st_idx]
 
				if Stuffing:BagType(dbag) == ST_NORMAL or dbag < 1 then
					break
				end
			end
 
			dslot = GetContainerNumSlots(dbag)
		end
	end

	-- throw various stuff out of the search list
	local changed = true
	while changed do
		changed = false
		-- XXX why doesn't this remove all x->x moves in one pass?

		for i, v in ipairs (st) do

			-- source is same as destination
			if (v.sslot == v.dslot) and (v.sbag == v.dbag) then
				table.remove (st, i)
				changed = true
			end
		end
	end

	-- kick off moving of stuff, if needed.
	if st == nil or next(st, nil) == nil then
		Print("Sorting finished.")
		self:SetScript("OnUpdate", nil)
	else
		self.sortList = st
		self:SetScript("OnUpdate", Stuffing.SortOnUpdate)
	end
end

function Stuffing:RestackOnUpdate(e)
	if not self.elapsed then
		self.elapsed = 0
	end

	self.elapsed = self.elapsed + e

	if self.elapsed < 0.1 then
		return
	end

	self.elapsed = 0
	self:Restack()
end

function Stuffing:Restack()
	local st = {}

	Stuffing_Open()

	for i, v in pairs(self.buttons) do
		if InBags(v.bag) then
			local tex, cnt, _, _, _, _, clink = GetContainerItemInfo(v.bag, v.slot)
			if clink then
				local n, _, _, _, _, _, _, s = GetItemInfo(clink)

				if cnt ~= s then
					if not st[n] then
						st[n] = {{
							item = v,
							size = cnt,
							max = s
						}}
					else
						table.insert(st[n], {
							item = v,
							size = cnt,
							max = s
						})
					end
				end
			end
		end
	end

	local did_restack = false

	for i, v in pairs(st) do
		if #v > 1 then
			for j = 2, #v, 2 do
				local a, b = v[j - 1], v[j]
				local _, _, l1 = GetContainerItemInfo(a.item.bag, a.item.slot)
				local _, _, l2 = GetContainerItemInfo(b.item.bag, b.item.slot)

				if l1 or l2 then
					did_restack = true
				else
					PickupContainerItem (a.item.bag, a.item.slot)
					PickupContainerItem (b.item.bag, b.item.slot)
					did_restack = true
				end
			end
		end
	end

	if did_restack then
		self:SetScript("OnUpdate", Stuffing.RestackOnUpdate)
	else
		self:SetScript("OnUpdate", nil)
		Print ("Restacking finished.")
	end
end

function Stuffing.Menu(self, level)
	if not level then
		return
	end

	local info = self.info

	wipe(info)

	if level ~= 1 then
		return
	end

	wipe(info)
	info.text = "Sort"
	info.notCheckable = 1
	info.func = function()
		Stuffing_Sort("d")
	end
	UIDropDownMenu_AddButton(info, level)
	
	wipe(info)
	info.text = "Sort Special"
	info.notCheckable = 1
	info.func = function()
		Stuffing_Sort("c/p")
	end
	UIDropDownMenu_AddButton(info, level)

	wipe(info)
	info.text = "Stack"
	info.notCheckable = 1
	info.func = function()
		Stuffing:SetBagsForSorting("d")
		Stuffing:Restack()
	end
	UIDropDownMenu_AddButton(info, level)
	
	wipe(info)
	info.text = "Stack Special"
	info.notCheckable = 1
	info.func = function()
		Stuffing:SetBagsForSorting("c/p")
		Stuffing:Restack()
	end
	UIDropDownMenu_AddButton(info, level)

	wipe(info)
	info.text = "Show Bags"
	info.checked = function()
		return bag_bars == 1
	end

	info.func = function()
		if bag_bars == 1 then
			bag_bars = 0
		else
			bag_bars = 1
		end
		Stuffing:Layout()
		if Stuffing.bankFrame and Stuffing.bankFrame:IsShown() then
			Stuffing:Layout(true)
		end

	end
	UIDropDownMenu_AddButton(info, level)

	wipe(info)
	info.disabled = nil
	info.notCheckable = 1
	info.text = CLOSE
	info.func = self.HideMenu
	info.tooltipTitle = CLOSE
	UIDropDownMenu_AddButton(info, level)
end


local defaults = {
	Bags = {
		Enable = true,
		Font = "AvantGarde_LT_Medium",
		Cols_Bank = 14,
		Cols_Bags = 11,
		Padding = 8,
		Spacing = 3,
		Locked = 0,
		Coordinates = {
			Bank = {
				X = 0,
				Y = 0,
			},
			Bags = {
				X = 0,
				Y = 0,
			},
		},
		Background = {
			Texture = "Blizzard Tooltip",
			Color = {
				r = 0.18,
				g = 0.18,
				b = 0.18,
				a = 0.8,
			},
		},
		Border = {
			Texture = "Stripped_medium",
			Size = 5,
			Inset = -1,
			Color = {
				r = 0.2,
				g = 0.2,
				b = 0.2,
				a = 1,
			},
		},
	},
}

function module:LoadOptions()
	local options = {
		Bags = {
			name = "Bags",
			type = "group",
			order = 35,
			disabled = function() return not db.Bags.Enable end,
			childGroups = "select",
			args = {
				empty = {
					name = " \n ",
					width = "full",
					type = "description",
					order = 1,
				},
				desc = {
					name = "|cff3399ffNotice:|r\nBag Options will be included within the next LUI Updates.",
					width = "full",
					type = "description",
					order = 2,
				},
			},
		},
	}

	return options
end

function module:LoadModule()
	local module = {
		Bags = {
			order = LUI:GetModuleCount(),
			type = "execute",
			name = function()
				if db.Bags.Enable then
					return "|cff00ff00Bags Enabled|r"
				else
					return "|cffFF0000Bags Disabled|r"
				end
			end,
			func = function(self, Bags)
				db.Bags.Enable = not db.Bags.Enable
				StaticPopup_Show("RELOAD_UI")
			end,
		},
	}
	
	return module
end

function module:OnInitialize()
	LUI:MergeDefaults(LUI.db.defaults.profile, defaults)
	LUI:RefreshDefaults()
	LUI:Refresh()
	
	self.db = LUI.db.profile
	db = self.db
end

function module:OnEnable()
	LUI:RegisterOptions(self:LoadOptions())
	LUI:RegisterModule(self:LoadModule())
end

