# Change-log version 1.1.1

This is a small version with only important bug fixes. More stuff is coming in version 1.2.

## Bug fixes

- **We fixed the issue preventing from accepting the second quest on some NPCs.** That was a hard one. We want to thank everyone who reported this issue and provided quest examples. We really appreciate your help.
- **Fixed the graphical issue where characters would rise from the ground** when Storyline was opened while you, or your target, are on a mount or sitting.
- The window can no longer be resized to be bigger than the actual screen-size to prevent unfortunate situations.
- Fixed a small Lua error.