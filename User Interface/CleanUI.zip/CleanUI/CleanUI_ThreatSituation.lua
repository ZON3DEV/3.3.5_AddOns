function CleanUI_ThreatSituationUpdate()   
    if (CUI_PlayerAggroBar == nil) then
        CleanUI_InitUnitFrameUI();
    end
    
    CleanUI_Aggro();
    
    CleanUI_TargetInfo();  
    CleanUI_FocusInfo();  
    
    CleanUI_UnitIsDeadOrGhost();
    CleanUI_UnitIsOnline();
    
 	CleanUI_RaidIconUpdate();
end

function CleanUI_Aggro()   
    
    -- player
    local isTanking, status, percentage = UnitDetailedThreatSituation("player", "target");
    
    if (percentage == nil) then
        percentage = 0;
    end
    
    if (percentage > 0) then
        CUI_PlayerAggroBarInfo:SetText(format("%d", percentage).." %");
    else
        CUI_PlayerAggroBarInfo:SetText("");
    end
    
    if (percentage > 100) then
        percentage = 100;
    end
    
    CUI_PlayerAggroBar:SetValue(percentage);   
    
    -- pet
    if (UnitExists("pet")) then
        if (UnitExists("pettarget")) then
            -- set bordercolor, if pet is tanking another target
            local isTanking, status, percentage = UnitDetailedThreatSituation("pet", "pettarget");
            local r, g, b = GetThreatStatusColor(status); 
            
            PetFrame:SetBackdropBorderColor(r, g, b, 1.0); 
        else
            PetFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
        end
        
        if (UnitExists("playertarget")) then
            -- set aggro bar value for player target
            local isTanking, status, percentage = UnitDetailedThreatSituation("pet", "playertarget");
            
            if (percentage == nil) then
                percentage = 0;
            end
            
            if (percentage > 100) then
                percentage = 100;
            end
            
            _G["CUI_PetAggroBar"]:SetValue(percentage);     
        else
            _G["CUI_PetAggroBar"]:SetValue(0);     
        end
    end
    
    -- party
    for i = 1, 4 do
        local id = "party"..i;
        if (UnitExists(id)) then
            if (UnitExists(id.."target")) then
                -- set bordercolor, if party# is tanking another target
                local isTanking, status, percentage = UnitDetailedThreatSituation(id, id.."target");
                local r, g, b = GetThreatStatusColor(status); 
                
                _G["PartyMemberFrame"..i]:SetBackdropBorderColor(r, g, b, 1.0); 
            else
                _G["PartyMemberFrame"..i]:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
            end
            
            if (UnitExists("playertarget")) then
                -- set aggro bar value for player target
                local isTanking, status, percentage = UnitDetailedThreatSituation(id, "playertarget");
                
                if (percentage == nil) then
                    percentage = 0;
                end
                
                if (percentage > 100) then
                    percentage = 100;
                end
                
                _G["CUI_Party"..i.."AggroBar"]:SetValue(percentage);     
            else
                _G["CUI_Party"..i.."AggroBar"]:SetValue(0);     
            end
        end
    
        local pet = "partypet"..i;

        if (UnitExists(pet)) then
            local petmanabar = _G["CUI_Party"..i.."PetManaBar"];
            
            if (petmanabar) then
                local power = 100 * UnitPower(pet) / UnitPowerMax(pet);
            
                if (UnitPowerMax(pet) == 0) then
                    power = 0;
                end
            
                petmanabar:SetValue(power);
            end
            
            if (UnitExists(pet.."target")) then
                -- set aggro bar value for party pet target
                local isTanking, status, percentage = UnitDetailedThreatSituation(pet.."target", "playertarget");
                
                if (percentage == nil) then
                    percentage = 0;
                end
                
                if (percentage > 100) then
                    percentage = 100;
                end
                
                _G["CUI_Party"..i.."PetAggroBar"]:SetValue(percentage);   
            else
                _G["CUI_Party"..i.."PetAggroBar"]:SetValue(0);  
            end
        end
    end
end

function CleanUI_TargetInfo()   
    if (UnitExists("target")) then
        local r, g, b = GameTooltip_UnitColor("target");     
        
        if (not UnitPlayerControlled("target") and UnitIsTapped("target") and not UnitIsTappedByPlayer("target")) then
            r, g, b = 0.5, 0.5, 0.5;
            CUI_TargetTabbedInfo:SetText("tapped");
        else
            CUI_TargetTabbedInfo:SetText("");
        end
        
        TargetFrameTextureFrameName:SetTextColor(r, g, b);
        
        r, g, b = GetThreatStatusColor(status);
        PlayerFrame:SetBackdropBorderColor(r, g, b, 1.0);
    
        local t_health = 100 * UnitHealth("target") / UnitHealthMax("target");
 		local t_power = 100 * UnitPower("target") / UnitPowerMax("target");
 		
 		if (UnitPowerMax("target") == 0) then
 		    t_power = 0;
 		end
 		
        CUI_TargetHealthBarPercent:SetText(format("%d", t_health).." %");
        CUI_TargetManaBarPercent:SetText(format("%d", t_power).." %");
    else
        PlayerFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
        
        CUI_TargetHealthBarPercent:SetText("");
        CUI_TargetManaBarPercent:SetText("");
    end
    
    local targetClassificationInfo = "";
    
    if (CUI_TargetBorderFrame) then
        local targetClassification = UnitClassification("target");
        
        if (targetClassification == "rareelite") then 
            targetClassificationInfo = ELITE..", "..ITEM_QUALITY2_DESC;
        elseif (targetClassification == "elite") then
            targetClassificationInfo = ELITE;
        elseif (targetClassification == "rare") then
            targetClassificationInfo = ITEM_QUALITY2_DESC;
        else
            targetClassificationInfo = nil;
        end
        
        if (targetClassification == "rareelite" or targetClassification == "elite") then
            CUI_TargetBorderFrame:SetBackdropBorderColor(1.0, 0.9, 0.0, 1.0);
            TargetFrameTextureFrameHealthBarText:SetTextColor(1.0, 0.9, 0.0, 1.0);
            TargetFrameTextureFrameManaBarText:SetTextColor(1.0, 0.9, 0.0, 1.0);
            CUI_TargetHealthBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0);
            CUI_TargetManaBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0);
        elseif (targetClassification == "rare") then
            CUI_TargetBorderFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
            TargetFrameTextureFrameHealthBarText:SetTextColor(1.0, 0.9, 0.0, 1.0);
            TargetFrameTextureFrameManaBarText:SetTextColor(1.0, 0.9, 0.0, 1.0);
            CUI_TargetHealthBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0);
            CUI_TargetManaBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0);
        else
            CUI_TargetBorderFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
            TargetFrameTextureFrameHealthBarText:SetTextColor(1.0, 1.0, 1.0, 1.0); 
            TargetFrameTextureFrameManaBarText:SetTextColor(1.0, 1.0, 1.0, 1.0); 
            CUI_TargetHealthBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
            CUI_TargetManaBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
        end
    end
    
    if (CUI_TargetInfo) then
        local creatureType = UnitCreatureType("target");
        local creatureFamily = UnitCreatureFamily("target");
        local localizedClass, englishClass = UnitClass("target");
        
        if (localizedClass == UnitName("target")) then
            localizedClass = nil;
        end
        
        local targetinfo = "";
         
        if (creatureType) then
            targetinfo = creatureType;
        end
        
        if (creatureFamily) then
            targetinfo = targetinfo..", "..creatureFamily;
        end
        
        if (localizedClass) then
            targetinfo = targetinfo..", "..localizedClass;
        end
        
        if (targetClassificationInfo) then
            targetinfo = targetinfo..", "..targetClassificationInfo;
        end
        
        CUI_TargetInfo:SetText("("..targetinfo..")");
    end
end

function CleanUI_FocusInfo()   
    if (UnitExists("focus")) then
        local r, g, b = GameTooltip_UnitColor("focus");
        
        if (not UnitPlayerControlled("focus") and UnitIsTapped("focus") and not UnitIsTappedByPlayer("focus")) then
            r, g, b = 0.5, 0.5, 0.5;
            CUI_FocusTabbedInfo:SetText("tapped");
        else
            CUI_FocusTabbedInfo:SetText("");
        end

        FocusFrameTextureFrameName:SetTextColor(r, g, b);
        
        local f_health = 100 * UnitHealth("focus") / UnitHealthMax("focus");
 		local f_power = 100 * UnitPower("focus") / UnitPowerMax("focus");
 		
 		if (UnitPowerMax("focus") == 0) then
 		    f_power = 0;
 		end
 		
        CUI_FocusHealthBarPercent:SetText(format("%d", f_health).." %");
        CUI_FocusManaBarPercent:SetText(format("%d", f_power).." %");
    else
        CUI_FocusHealthBarPercent:SetText("");
        CUI_FocusManaBarPercent:SetText("");
    end
    
    local focusClassificationInfo = "";
    
    if (CUI_FocusBorderFrame) then
        local focusClassification = UnitClassification("focus");
        
        if (focusClassification == "rareelite") then
            focusClassificationInfo = ELITE..", "..ITEM_QUALITY2_DESC;
        elseif (focusClassification == "elite") then
            focusClassificationInfo = ELITE;
        elseif (focusClassification == "rare") then
            focusClassificationInfo = ITEM_QUALITY2_DESC;
        else
            focusClassificationInfo = nil;
        end
        
        if (focusClassification == "rareelite" or focusClassification == "elite") then
            CUI_FocusBorderFrame:SetBackdropBorderColor(1.0, 0.9, 0.0, 1.0);
            FocusFrameTextureFrameHealthBarText:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            FocusFrameTextureFrameManaBarText:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            CUI_FocusHealthBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            CUI_FocusManaBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0); 
        elseif (focusClassification == "rare") then
            CUI_FocusBorderFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
            FocusFrameTextureFrameHealthBarText:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            FocusFrameTextureFrameManaBarText:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            CUI_FocusHealthBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0); 
            CUI_FocusManaBarPercent:SetTextColor(1.0, 0.9, 0.0, 1.0); 
        else
            CUI_FocusBorderFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
            FocusFrameTextureFrameHealthBarText:SetTextColor(1.0, 1.0, 1.0, 1.0); 
            FocusFrameTextureFrameManaBarText:SetTextColor(1.0, 1.0, 1.0, 1.0);
            CUI_FocusHealthBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
            CUI_FocusManaBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
        end
    end
    
    if (CUI_FocusInfo) then
        local creatureType = UnitCreatureType("focus");
        local creatureFamily = UnitCreatureFamily("focus");
        local localizedClass, englishClass = UnitClass("focus");
        
        if (localizedClass == UnitName("focus")) then
            localizedClass = nil;
        end
         
        local focusinfo = "";
         
        if (creatureType) then
            focusinfo = creatureType;
        end
        
        if (creatureFamily) then
            focusinfo = focusinfo..", "..creatureFamily;
        end
        
        if (localizedClass) then
            focusinfo = focusinfo..", "..localizedClass;
        end
        
        if (focusClassificationInfo) then
            focusinfo = focusinfo..", "..focusClassificationInfo;
        end
                
        CUI_FocusInfo:SetText("("..focusinfo..")");
    end
end

function CleanUI_UnitIsDeadOrGhost()   
    if (UnitIsDeadOrGhost("player")) then
        PlayerFrameHealthBar:SetValue(0);
        PlayerFrameManaBar:SetValue(0);
        CUI_PlayerFrameDeadText:Show();
    else
        CUI_PlayerFrameDeadText:Hide();
    end
    
    if (UnitIsDeadOrGhost("pet")) then
        PetFrameHealthBar:SetValue(0);
        PetFrameManaBar:SetValue(0);
    else
    end
    
    if (UnitIsDeadOrGhost("target")) then
        TargetFrameHealthBar:SetValue(0);
        TargetFrameManaBar:SetValue(0);
    else
    end
    
    if (UnitIsDeadOrGhost("focus")) then
        FocusFrameHealthBar:SetValue(0);
        FocusFrameManaBar:SetValue(0);
    else
    end
    
    if (UnitIsDeadOrGhost("targettarget")) then
        TargetFrameToTHealthBar:SetValue(0);
        TargetFrameToTManaBar:SetValue(0);
    else
    end
    
    if (UnitIsDeadOrGhost("targetfocus")) then
        TargetofFocusHealthBar:SetValue(0);
        TargetofFocusManaBar:SetValue(0);
    else
    end
end

function CleanUI_UnitIsOnline()   
    if (UnitIsAFK("player") or UnitIsConnected("player") == nil) then
		PlayerFrameHealthBar:SetStatusBarColor(0.5, 0.5, 0.5);
    else
		PlayerFrameHealthBar:SetStatusBarColor(0.0, 1.0, 0.0);
    end
    
    if (UnitIsAFK("target") or UnitIsConnected("target") == nil) then
		TargetFrameHealthBar:SetStatusBarColor(0.5, 0.5, 0.5);
    else
		TargetFrameHealthBar:SetStatusBarColor(0.0, 1.0, 0.0);
    end
    
    if (UnitIsAFK("targettarget") or UnitIsConnected("targettarget") == nil) then
		TargetFrameToTHealthBar:SetStatusBarColor(0.5, 0.5, 0.5);
    else
		TargetFrameToTHealthBar:SetStatusBarColor(0.0, 1.0, 0.0);
    end
    
    if (CUI_TargetInfo) then
        if (UnitIsAFK("target")) then
            CUI_TargetInfo:SetText(AFK);
        elseif (UnitIsConnected("target") == nil) then
            CUI_TargetInfo:SetText(PLAYER_OFFLINE);
        end
    end
    
    if (UnitIsAFK("focus") or UnitIsConnected("focus") == nil) then
		FocusFrameHealthBar:SetStatusBarColor(0.5, 0.5, 0.5);
    else
		FocusFrameHealthBar:SetStatusBarColor(0.0, 1.0, 0.0);
    end
    if (UnitIsAFK("focustarget") or UnitIsConnected("focustarget") == nil) then
		FocusFrameToTHealthBar:SetStatusBarColor(0.5, 0.5, 0.5);
    else
		FocusFrameToTHealthBar:SetStatusBarColor(0.0, 1.0, 0.0);
    end
    
    if (CUI_FocusInfo) then
        if (UnitIsAFK("focus")) then
            CUI_FocusInfo:SetText(AFK);
        elseif (UnitIsConnected("focus") == nil) then
            CUI_FocusInfo:SetText(PLAYER_OFFLINE);
        end
    end
end