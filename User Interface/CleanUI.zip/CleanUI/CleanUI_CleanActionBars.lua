function CleanUI_InitActionBars(newLevel)
 	
	if (not newLevel) then
		newLevel = UnitLevel("player");
	end
	
	local name, reaction, min, max, value = GetWatchedFactionInfo();
	local visibilityChanged = nil;
	
	local y = -105;

	if (name) then
	    -- Ruf wird beobachtet
        if (newLevel < MAX_PLAYER_LEVEL and not IsXPUserDisabled()) then
            y = -91;
        else
            y = -100; 
        end
    else
        -- Kein Ruf
        if (newLevel < MAX_PLAYER_LEVEL and not IsXPUserDisabled()) then
            y = -100;
        else
            y = -105; 
        end
    end
    
    -- Offset, wenn die Aktionsleisten nicht sichtbar sind
    if (not SHOW_MULTI_ACTIONBAR_1 and not SHOW_MULTI_ACTIONBAR_2) then
        y = y - 40;
    end
    
    CleanUIPlayerArtFrame:SetPoint("BOTTOM", MainMenuBar, "BOTTOM", 0, y);
	
    CleanUI_Clean();	
end

function CleanUI_Clean()
    CleanUI_RemoveActionNames();
    CleanUI_PlayerMenuBar();
	CleanUI_CleanMinimap();
    CleanUI_InitMinimapFrameStrata();    
    CleanUI_CleanXpFrame();
end

function CleanUI_ToggleXpFrame()
    if (CleanUIData.XpFrameVisible == 1) then
        CleanUIData.XpFrameVisible = 0;
    else
        CleanUIData.XpFrameVisible = 1;
    end
    
    CleanUI_CleanXpFrame();
end

function CleanUI_RemoveActionNames()
    for i = 1, 12 do
        _G["ActionButton"..i.."Name"]:Hide();
        _G["BonusActionButton"..i.."Name"]:Hide();
        _G["MultiBarBottomLeftButton"..i.."Name"]:Hide();
        _G["MultiBarBottomRightButton"..i.."Name"]:Hide();
        _G["MultiBarRightButton"..i.."Name"]:Hide();
        _G["MultiBarLeftButton"..i.."Name"]:Hide();
    end
    
    for i = 1, 10 do
        _G["ShapeshiftButton"..i.."Name"]:Hide();
    end	
    
end

function CleanUI_PlayerMenuBar()
    CleanUI_RemoveArtwork();
    CleanUI_RescaleExpBar();
    CleanUI_RescaleReputationWatchBar();
    CleanUI_RescaleKeyringButton();
	CleanUI_RemoveActionBarUpDownButtons();	
end

function CleanUI_RemoveArtwork()
	MainMenuBarLeftEndCap:Hide();
	MainMenuBarRightEndCap:Hide();
	
	MainMenuMaxLevelBar0:Hide();
	MainMenuMaxLevelBar1:Hide();
	MainMenuMaxLevelBar2:Hide();
	MainMenuMaxLevelBar3:Hide();
	
	BonusActionBarTexture0:Hide();
	BonusActionBarTexture1:Hide();
	
	MainMenuBarTexture0:Hide();
	MainMenuBarTexture1:Hide();
	MainMenuBarTexture2:Hide();
	MainMenuBarTexture3:Hide();
	
	MainMenuXPBarTexture0:Hide();
	MainMenuXPBarTexture1:Hide();
	MainMenuXPBarTexture2:Hide();
	MainMenuXPBarTexture3:Hide();
	
	ReputationWatchBarTexture0:Hide();
	ReputationWatchBarTexture1:Hide();
	ReputationWatchBarTexture2:Hide();
	ReputationWatchBarTexture3:Hide();
	
	ReputationXPBarTexture0:Hide();
	ReputationXPBarTexture1:Hide();
	ReputationXPBarTexture2:Hide();
	ReputationXPBarTexture3:Hide();
	
	MainMenuBarPageNumber:Hide();
end

function CleanUI_RescaleExpBar()
	MainMenuExpBar:SetWidth(1012);
	MainMenuExpBar:SetHeight(10);
	ExhaustionLevelFillBar:SetHeight(10);
	
	ExhaustionTick:SetNormalTexture("Interface\\AddOns\\CleanUI\\skins\\ExhaustionTick");
	ExhaustionTick:SetHighlightTexture("Interface\\AddOns\\CleanUI\\skins\\ExhaustionTickHighlight");
end

function CleanUI_RescaleReputationWatchBar()
	ReputationWatchStatusBar:SetWidth(1012);
	ReputationWatchStatusBar:SetHeight(10);
	
	ExhaustionTick:SetNormalTexture("Interface\\AddOns\\CleanUI\\skins\\ExhaustionTick");
	ExhaustionTick:SetHighlightTexture("Interface\\AddOns\\CleanUI\\skins\\ExhaustionTickHighlight");
end

function CleanUI_RescaleKeyringButton()
	KeyRingButton:SetWidth(15);
	KeyRingButton:SetHeight(30);
end

function CleanUI_RemoveActionBarUpDownButtons()
	ActionBarUpButton:Hide();
	ActionBarDownButton:Hide();
end

function CleanUI_CleanXpFrame()

    if (GetNumPartyMembers() == 0) then
        CleanUIXpFrame:Hide();
        return;
    end
    
    if (CleanUIData.XpFrameVisible == nil) then
        CleanUIData.XpFrameVisible = 0;
    end

    if (CleanUIData.XpFrameVisible == 1) then
        CleanUIXpFrame:Show();
    else
        CleanUIXpFrame:Hide();
        return;
    end
    
    cui_party_xp[UnitName("player")] = {level=UnitLevel("player"), xp=UnitXP("player"), xpmax=UnitXPMax("player"), xpexhaustion=GetXPExhaustion()};

    local PARTY_UNITS = {"player", "party1", "party2", "party3", "party4"};
    local count = 0;

	for index, id in pairs(PARTY_UNITS) do
	
	 	local name = UnitName(id);
	 	
	 	local xpbar = _G["CleanUIXpFrame_group"..index.."xpbar"];
	 	local xpbarinfo = _G["CleanUIXpFrame_group"..index.."xpbarInfo"];
                    
        xpbar:SetAttribute("xp", nil);
        xpbar:SetAttribute("xpmax", nil);
        xpbar:SetAttribute("pxp", nil);
        xpbar:SetAttribute("xpexhaustion", nil);
	 	
	 	if (not name) then
	 	    xpbar:SetAlpha(0);
	 	    xpbarinfo:SetText("");
	 	else
	        count = count + 1;
	    
	 	    local _, classFileName = UnitClass(id);
	 	    local classTextColor = RAID_CLASS_COLORS[classFileName];
		    
		    if (cui_party_xp[name] == nil) then
	 	        xpbar:SetAlpha(0);
		    else
                local level = tonumber(cui_party_xp[name].level);
                
                if (level < MAX_PLAYER_LEVEL) then
                    local xp = tonumber(cui_party_xp[name].xp);
                    local xpmax = tonumber(cui_party_xp[name].xpmax);
                    local pxp = 100 * xp / xpmax;
                    
                    local xpexhaustion = tonumber(cui_party_xp[name].xpexhaustion);
                    
                    xpbar:SetAttribute("xp", xp);
                    xpbar:SetAttribute("xpmax", xpmax);
                    xpbar:SetAttribute("pxp", pxp);
                    xpbar:SetAttribute("xpexhaustion", xpexhaustion);
                        
                    xpbar:SetAlpha(1);                    
                    xpbarinfo:SetText(name.."  "..format(XP_TEXT, xp, xpmax, pxp));                    
                    xpbar:SetValue(pxp);
                    
                    if (xpexhaustion) then
                        xpbar:SetStatusBarColor(0.0, 0.39, 0.88);
                    else
                        xpbar:SetStatusBarColor(0.58, 0.0, 0.55);
                    end
                    
                else
	 	            xpbar:SetAlpha(0);
                end
		    end
	 	end
	end
	
	CleanUIXpFrame:SetHeight(11 + count * 12);
end

function CleanUI_SetXpTooltip(self)
    local xp =  self:GetAttribute("xp");
    local xpmax = self:GetAttribute("xpmax");
    local pxp = self:GetAttribute("pxp");
    local xpexhaustion = self:GetAttribute("xpexhaustion");
    
    if (not xp) then
        return;
    end
 	
 	local erfahrung = 100;
 	
 	if (xpexhaustion) then
 	    erfahrung = 200;
 	end
                    
    GameTooltip_SetDefaultAnchor(GameTooltip, this);
    
    local XPText = format(XP_TEXT, xp, xpmax, pxp);
    local tooltipText = XPText..format(EXHAUST_TOOLTIP1, "", erfahrung);
    
    GameTooltip:SetText(tooltipText);
        
    GameTooltip:Show();
end