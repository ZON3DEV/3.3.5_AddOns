function CleanUI_InitMinimapButtons()
    GameTimeFrame:SetParent(CleanUIMinimapButtons);
    GameTimeFrame:ClearAllPoints();
    GameTimeFrame:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 0, -6);
    GameTimeFrame:SetScale(0.6);
    GameTimeFrame:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    GameTimeFrame:HookScript("OnLeave", CleanUI_HideMinimapButtons);

    MiniMapTracking:SetParent(CleanUIMinimapButtons);
    MiniMapTracking:ClearAllPoints();
    MiniMapTracking:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 0, -36);
    MiniMapTracking:SetScale(0.75);
    MiniMapTrackingButton:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    MiniMapTrackingButton:HookScript("OnLeave", CleanUI_HideMinimapButtons);
    
    MiniMapWorldMapButton:SetParent(CleanUIMinimapButtons);
    MiniMapWorldMapButton:ClearAllPoints();
    MiniMapWorldMapButton:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 1, -66);
    MiniMapWorldMapButton:SetScale(0.75);
    MiniMapWorldMapButton:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    MiniMapWorldMapButton:HookScript("OnLeave", CleanUI_HideMinimapButtons);
    
    MiniMapMailFrame:SetParent(CleanUIMinimapButtons);
    MiniMapMailFrame:ClearAllPoints();
    MiniMapMailFrame:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 1, -96);
    MiniMapMailFrame:SetScale(0.75);
    MiniMapMailFrame:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    MiniMapMailFrame:HookScript("OnLeave", CleanUI_HideMinimapButtons);
    
    MiniMapLFGFrame:SetParent(CleanUIMinimapButtons);
    MiniMapLFGFrame:ClearAllPoints();
    MiniMapLFGFrame:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 1, -126);
    MiniMapLFGFrame:SetScale(0.75);
    MiniMapLFGFrame:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    MiniMapLFGFrame:HookScript("OnLeave", CleanUI_HideMinimapButtons);
    
    MiniMapBattlefieldFrame:SetParent(CleanUIMinimapButtons);
    MiniMapBattlefieldFrame:ClearAllPoints();
    MiniMapBattlefieldFrame:SetPoint("TOP", CleanUIMinimapButtons, "TOP", 1, -156);
    MiniMapBattlefieldFrame:SetScale(0.75);
    MiniMapBattlefieldFrame:HookScript("OnEnter", CleanUI_ShowMinimapButtons);
    MiniMapBattlefieldFrame:HookScript("OnLeave", CleanUI_HideMinimapButtons);
end

function CleanUI_ShowMinimapButtons()
    CleanUIMinimapButtons:SetAlpha(1);
end

function CleanUI_HideMinimapButtons()
    CleanUIMinimapButtons:SetAlpha(0);
end

function CleanUI_InitMinimapFrameStrata()
 	CleanUIMinimapBorderTop:SetFrameStrata("LOW");
 	CleanUIMinimapBorder:SetFrameStrata("LOW");
 	
 	Minimap:SetFrameStrata("BACKGROUND");
 	MinimapZoneTextButton:SetFrameStrata("HIGH");
 	MiniMapInstanceDifficulty:SetFrameStrata("HIGH");
 	
	for i, child in ipairs({Minimap:GetChildren()}) do
	    child:SetFrameStrata("HIGH");
	end
	
	for i, child in ipairs({MinimapBackdrop:GetChildren()}) do
	    child:SetFrameStrata("HIGH");
	end
end

function CleanUI_CleanMinimap()
    Minimap:SetMaskTexture("Interface/Buttons/WHITE8x8");
	MinimapBorder:Hide();
	MinimapBorderTop:Hide();
	
	MinimapCluster:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", 14, 0); 
	
	if (TimeManagerClockButton) then
	    TimeManagerClockButton:GetRegions():Hide();	
	    TimeManagerClockButton:SetPoint("CENTER", Minimap, "CENTER", 52, -63); 
    end
    
	if (MinimapZoneTextButton) then
	    MinimapZoneTextButton:SetPoint("CENTER", MinimapCluster, "CENTER", 7, 84); 
    end
    
	if (MiniMapInstanceDifficulty) then
	    MiniMapInstanceDifficulty:SetPoint("BOTTOMRIGHT", MinimapCluster, "BOTTOMRIGHT", 100, -152); 
    end
    
    if (MiniMapVoiceChatFrame) then
        MiniMapVoiceChatFrame:ClearAllPoints();
        MiniMapVoiceChatFrame:SetPoint("BOTTOMLEFT", Minimap, "BOTTOMLEFT", -5, -10);
        MiniMapVoiceChatFrameBackground:Hide();
        MiniMapVoiceChatFrameBorder:Hide();
    end
    
    if (MiniMapRecordingButton) then
        MiniMapRecordingButton:ClearAllPoints();
        MiniMapRecordingButton:SetPoint("BOTTOMLEFT", Minimap, "BOTTOMLEFT", 15, -5);
        MiniMapRecordingBorder:Hide();
    end
end