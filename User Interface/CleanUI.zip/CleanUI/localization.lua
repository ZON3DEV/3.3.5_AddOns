﻿-- English, the default

BINDING_HEADER_CUIHEADER = "CleanUI";
BINDING_NAME_CUITOGGLEXPFRAME = "toggle xp frame";

-- German
if (GetLocale() == "deDE") then

    -- Fix für die deutsche Lokalisierung von Blizzards Bufftimern
    MINUTE_ONELETTER_ABBR = "%d m"
    DAY_ONELETTER_ABBR = "%d |4d:d;"

    BINDING_HEADER_CUIHEADER = "CleanUI";
    BINDING_NAME_CUITOGGLEXPFRAME = "XP-Frame an- und ausschalten";
end

-- Ä = \195\132
-- ä = \195\164

-- Ö = \195\150
-- ö = \195\182

-- Ü = \195\156
-- ü = \195\188

-- ß = \195\159