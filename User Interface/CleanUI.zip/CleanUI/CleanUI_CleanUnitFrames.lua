function CleanUI_InitUnitFrames()
    CleanUI_InitUnitTextures();
    
	CleanUI_ColorizeRuneFrame();
    CleanUI_MoveComboFrameIcons();
    
    CleanUI_MovePlayerIcons();
    CleanUI_MovePartyIcons();
    CleanUI_MovePetIcons();
    CleanUI_MoveTargetIcons();
    CleanUI_MoveFocusIcons();
    CleanUI_CheckClassColors();
    
    PartyMemberBuffTooltip:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    PartyMemberBuffTooltip:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
end

function CleanUI_Init3DModels()
    local playerModelFrame = _G["CUI_PlayerModelFrame"];
    if (not playerModelFrame) then
        playerModelFrame = CreateFrame("PlayerModel", "CUI_PlayerModelFrame", PlayerFrame);
	end
    playerModelFrame:SetWidth(62);
    playerModelFrame:SetHeight(62);
    playerModelFrame:ClearAllPoints();
    playerModelFrame:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 4, -4);
    playerModelFrame:SetFrameStrata("BACKGROUND");
    playerModelFrame:SetScript("OnShow", function(self) self:SetCamera(0) end);
	
	local targetModelFrame = _G["CUI_TargetModelFrame"];
    if (not targetModelFrame) then
        targetModelFrame = CreateFrame("PlayerModel", "CUI_TargetModelFrame", TargetFrame);
	end
    targetModelFrame:SetWidth(62);
    targetModelFrame:SetHeight(62);
    targetModelFrame:ClearAllPoints();
    targetModelFrame:SetPoint("TOPRIGHT", TargetFrame, "TOPRIGHT", -4, -4);
    targetModelFrame:SetFrameStrata("BACKGROUND");
    targetModelFrame:SetScript("OnShow", function(self) self:SetCamera(0) end);
	
	local focusModelFrame = _G["CUI_FocusModelFrame"];
    if (not focusModelFrame) then
        focusModelFrame = CreateFrame("PlayerModel", "CUI_FocusModelFrame", FocusFrame);
	end
    focusModelFrame:SetWidth(62);
    focusModelFrame:SetHeight(62);
    focusModelFrame:ClearAllPoints();
    focusModelFrame:SetPoint("TOPRIGHT", FocusFrame, "TOPRIGHT", -4, -4);
    focusModelFrame:SetFrameStrata("BACKGROUND");
    focusModelFrame:SetScript("OnShow", function(self) self:SetCamera(0) end);
	
    for i=1, 4, 1 do
    
        local partyFrame = _G["PartyMemberFrame"..i];
            
        local partyModelFrame = _G["CUI_Party"..i.."ModelFrame"];
        if (not partyModelFrame) then
            partyModelFrame = CreateFrame("PlayerModel", "CUI_Party"..i.."ModelFrame", partyFrame);
        end
        partyModelFrame:SetWidth(40);
        partyModelFrame:SetHeight(40);
        partyModelFrame:ClearAllPoints();
        partyModelFrame:SetPoint("TOPLEFT", partyFrame, "TOPLEFT", 4, -4);
        partyModelFrame:SetFrameStrata("LOW");
        partyModelFrame:SetScript("OnShow", function(self) self:SetCamera(0) end);
        
        local help = _G["CUI_Party"..i.."BGFrame"];
        if (not help) then
            help = CreateFrame("Frame", "CUI_Party"..i.."BGFrame", partyFrame);
    
            help:SetBackdrop( { 
                bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
                tile = true, tileSize = 16, edgeSize = 16, 
                insets = { left = 0, right = 0, top = 0, bottom = 0 }
            });
            
            help:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
        end
        help:SetWidth(40);
        help:SetHeight(40);
        help:ClearAllPoints();
        help:SetPoint("TOPLEFT", partyFrame, "TOPLEFT", 4, -4);
    end
end

function CleanUI_SetPortrait3D(modelFrame, id)
    if (modelFrame) then
	    modelFrame:ClearModel();
	    modelFrame:SetUnit(id);
        modelFrame:SetCamera(0);
    end
end

function CleanUI_SetPortraitTexture(portraitframe, unit)
    if (portraitframe) then
 	    if (portraitframe:GetName() == "PlayerPortrait") then
	        CleanUI_SetPortrait3D(_G["CUI_PlayerModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "TargetFramePortrait") then
	        CleanUI_SetPortrait3D(_G["CUI_TargetModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "FocusFramePortrait") then
	        CleanUI_SetPortrait3D(_G["CUI_FocusModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "PartyMemberFrame1Portrait") then
	        CleanUI_SetPortrait3D(_G["CUI_Party1ModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "PartyMemberFrame2Portrait") then
	        CleanUI_SetPortrait3D(_G["CUI_Party2ModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "PartyMemberFrame3Portrait") then
	        CleanUI_SetPortrait3D(_G["CUI_Party3ModelFrame"], unit);
 	    elseif (portraitframe:GetName() == "PartyMemberFrame4Portrait") then
	        CleanUI_SetPortrait3D(_G["CUI_Party4ModelFrame"], unit);
 	    end
 	end
end

function CleanUI_CheckClassColors()

    CleanUI_SetClassColors("player", PlayerName);
    
    for i=1, 4, 1 do
        CleanUI_SetClassColors("party"..i, _G["PartyMemberFrame"..i.."Name"]);
    end
end

function CleanUI_SetClassColors(unit, text)
    local _, class = UnitClass(unit);
    
    local classTextColor;
	if (class) then
		classTextColor = RAID_CLASS_COLORS[class];
	else
		classTextColor = NORMAL_FONT_COLOR;
	end
    text:SetTextColor(classTextColor.r, classTextColor.g, classTextColor.b);
end

function CleanUI_InitUnitFrameUI()
    local playerAggroBar = CreateFrame("StatusBar", "CUI_PlayerAggroBar", PlayerFrame, "CleanUIPlayerAggroBarTemplate");
	playerAggroBar:ClearAllPoints();
    playerAggroBar:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 66, -5);
    
    local petAggroBar = CreateFrame("StatusBar", "CUI_PetAggroBar", PetFrame, "CleanUIPetAggroBarTemplate");
 
    petAggroBar:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    });
    
    petAggroBar:SetBackdropColor(0.0, 0.0, 0.0, 1.0);

    petAggroBar:SetFrameStrata("BACKGROUND");
    petAggroBar:ClearAllPoints();
    petAggroBar:SetPoint("CENTER", PetFrame, "CENTER", 0, 14);
    
    -- Fokus setzen
	local setFocusButton = CreateFrame("Button", "CUI_SetFocusButton", TargetFrame, "CleanUIFocusButtonTemplate");
	setFocusButton:SetScale(1);
    setFocusButton:ClearAllPoints();
    setFocusButton:SetPoint("TOPLEFT", TargetFrame, "TOPRIGHT", 1, 0);
	setFocusButton:SetAttribute("type", "macro");
	setFocusButton:SetAttribute("macrotext", "/focus");
 
    setFocusButton:SetBackdrop( {
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16
    });    
   
	local setFocusButtonIcon = _G["CUI_SetFocusButtonIcon"];
	setFocusButton:SetNormalTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	setFocusButton:SetHighlightTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	setFocusButton:SetPushedTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	setFocusButtonIcon:SetTexture("Interface\\AddOns\\CleanUI\\skins\\setfocus");
	_G["CUI_SetFocusButtonBorder"]:Hide();
	_G["CUI_SetFocusButtonNormalTexture"]:Hide();
	
	-- Fokus entfernen
	local removeFocusButton = CreateFrame("Button", "CUI_RemoveFocusButton", FocusFrame, "CleanUIFocusButtonTemplate");
	removeFocusButton:SetScale(1);
    removeFocusButton:ClearAllPoints();
    removeFocusButton:SetPoint("TOPLEFT", FocusFrame, "TOPRIGHT", 1, 0);
	removeFocusButton:SetAttribute("type", "macro");
	removeFocusButton:SetAttribute("macrotext", "/clearfocus");
 
    removeFocusButton:SetBackdrop( {
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16
    }); 
   
	local removeFocusButtonIcon = _G["CUI_RemoveFocusButtonIcon"];
	removeFocusButton:SetNormalTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	removeFocusButton:SetHighlightTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	removeFocusButton:SetPushedTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	removeFocusButtonIcon:SetTexture("Interface\\AddOns\\CleanUI\\skins\\clearfocus");
	_G["CUI_RemoveFocusButtonBorder"]:Hide();
	_G["CUI_RemoveFocusButtonNormalTexture"]:Hide();
		
	-- Party
    for i=1, 4, 1 do
        -- party aggrobar
        local partyFrame = _G["PartyMemberFrame"..i];
        local partyAggroBar = CreateFrame("StatusBar", "CUI_Party"..i.."AggroBar", partyFrame, "CleanUIPartyAggroBarTemplate");
 
        partyAggroBar:SetBackdrop( { 
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
            tile = true, tileSize = 16, edgeSize = 16, 
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        });
        
        partyAggroBar:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
        partyAggroBar:SetFrameStrata("BACKGROUND");
        partyAggroBar:ClearAllPoints();
        partyAggroBar:SetPoint("LEFT", partyFrame, "LEFT", 44, 14);
        
        -- party pet manabar
        local partyPetManaBar = CreateFrame("StatusBar", "CUI_Party"..i.."PetManaBar", _G["PartyMemberFrame"..i.."PetFrame"], "CleanUIPartyPetManaBarTemplate");
        partyPetManaBar:ClearAllPoints();
        partyPetManaBar:SetPoint("CENTER", _G["PartyMemberFrame"..i.."PetFrame"], "CENTER", 0, -15);
        partyPetManaBar:SetFrameStrata("BACKGROUND");
    
        -- party pet aggrobar
        local partyPetFrame = _G["PartyMemberFrame"..i.."PetFrame"];
        local partyPetAggroBar = CreateFrame("StatusBar", "CUI_Party"..i.."PetAggroBar", _G["PartyMemberFrame"..i.."PetFrame"], "CleanUIPartyPetAggroBarTemplate");
 
        partyPetAggroBar:SetBackdrop( { 
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
            tile = true, tileSize = 16, edgeSize = 16, 
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        });
        
        partyPetAggroBar:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
        partyPetAggroBar:SetFrameStrata("BACKGROUND");
        partyPetAggroBar:ClearAllPoints();
        partyPetAggroBar:SetPoint("CENTER", partyPetFrame, "CENTER", 0, 14);
        
        --party pet name
        local partyPetName = partyPetFrame:CreateFontString("CUI_Party"..i.."PetName", "ARTWORK");
        partyPetName:SetFontObject("GameFontNormalSmall");
        partyPetName:SetWidth(66);
        partyPetName:SetHeight(10);
        partyPetName:ClearAllPoints(); 
        partyPetName:SetPoint("CENTER", _G["PartyMemberFrame"..i.."PetFrame"], "CENTER", 0, 15);
        partyPetName:SetJustifyH("CENTER");
        partyPetName:SetText("");
    end
    
    local targetHealthBarPercent = TargetFrame:CreateFontString("CUI_TargetHealthBarPercent", "ARTWORK");
	targetHealthBarPercent:SetFontObject("GameFontNormalSmall");
    targetHealthBarPercent:SetWidth(50);
    targetHealthBarPercent:SetHeight(10);
    targetHealthBarPercent:ClearAllPoints(); 
    targetHealthBarPercent:SetPoint("RIGHT", TargetFrameHealthBar, "RIGHT", 35, 0);
    targetHealthBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
    targetHealthBarPercent:SetJustifyH("RIGHT");
    targetHealthBarPercent:SetText("");
    
    local targetManaBarPercent = TargetFrame:CreateFontString("CUI_TargetManaBarPercent", "ARTWORK");
	targetManaBarPercent:SetFontObject("GameFontNormalSmall");
    targetManaBarPercent:SetWidth(50);
    targetManaBarPercent:SetHeight(10);
    targetManaBarPercent:ClearAllPoints(); 
    targetManaBarPercent:SetPoint("RIGHT", TargetFrameManaBar, "RIGHT", 35, 0);
    targetManaBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
    targetManaBarPercent:SetJustifyH("RIGHT");
    targetManaBarPercent:SetText("");
    
    local targetInfo = TargetFrame:CreateFontString("CUI_TargetInfo", "ARTWORK");
	targetInfo:SetFontObject("GameFontNormalSmall");
    targetInfo:SetWidth(200);
    targetInfo:SetHeight(10);
    targetInfo:ClearAllPoints(); 
    targetInfo:SetPoint("CENTER", TargetFrame, "CENTER", 0, 30);
    targetInfo:SetTextColor(1.0, 1.0, 1.0, 1.0);
    targetInfo:SetTextHeight(8);
    targetInfo:SetText("");
    
    local focusHealthBarPercent = FocusFrame:CreateFontString("CUI_FocusHealthBarPercent", "ARTWORK");
	focusHealthBarPercent:SetFontObject("GameFontNormalSmall");
    focusHealthBarPercent:SetWidth(50);
    focusHealthBarPercent:SetHeight(10);
    focusHealthBarPercent:ClearAllPoints(); 
    focusHealthBarPercent:SetPoint("RIGHT", FocusFrameHealthBar, "RIGHT", 35, 0);
    focusHealthBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
    focusHealthBarPercent:SetJustifyH("RIGHT");
    focusHealthBarPercent:SetText("");
    
    local focusManaBarPercent = FocusFrame:CreateFontString("CUI_FocusManaBarPercent", "ARTWORK");
	focusManaBarPercent:SetFontObject("GameFontNormalSmall");
    focusManaBarPercent:SetWidth(50);
    focusManaBarPercent:SetHeight(10);
    focusManaBarPercent:ClearAllPoints(); 
    focusManaBarPercent:SetPoint("RIGHT", FocusFrameManaBar, "RIGHT", 35, 0);
    focusManaBarPercent:SetTextColor(1.0, 1.0, 1.0, 1.0);
    focusManaBarPercent:SetJustifyH("RIGHT");
    focusManaBarPercent:SetText("");
    
    local focusInfo = FocusFrame:CreateFontString("CUI_FocusInfo", "ARTWORK");
	focusInfo:SetFontObject("GameFontNormalSmall");
    focusInfo:SetWidth(200);
    focusInfo:SetHeight(10);
    focusInfo:ClearAllPoints(); 
    focusInfo:SetPoint("CENTER", FocusFrame, "CENTER", 0, 30);
    focusInfo:SetTextColor(1.0, 1.0, 1.0, 1.0);
    focusInfo:SetTextHeight(8);
    focusInfo:SetText("");
    
    local playerFrameDeadText = PlayerFrame:CreateFontString("CUI_PlayerFrameDeadText", "ARTWORK");
	playerFrameDeadText:SetFontObject("GameFontNormalSmall");
    playerFrameDeadText:SetWidth(100);
    playerFrameDeadText:SetHeight(10);
    playerFrameDeadText:ClearAllPoints(); 
    playerFrameDeadText:SetPoint("CENTER", PlayerFrameHealthBar, "CENTER", 0, 0);
    playerFrameDeadText:SetText(DEAD);
    
    local targetTabbedInfo = TargetFrame:CreateFontString("CUI_TargetTabbedInfo", "OVERLAY");
	targetTabbedInfo:SetFontObject("NumberFontNormalHuge");
	targetTabbedInfo:SetTextHeight(36);
    targetTabbedInfo:SetWidth(200);
    targetTabbedInfo:SetHeight(100);
    targetTabbedInfo:SetTextColor(1.0, 0.2, 0.2);
    targetTabbedInfo:ClearAllPoints(); 
    targetTabbedInfo:SetPoint("CENTER", TargetFrame, "CENTER", 0, 10);
    targetTabbedInfo:SetText("");
    
    local focusTabbedInfo = FocusFrame:CreateFontString("CUI_FocusTabbedInfo", "OVERLAY");
	focusTabbedInfo:SetFontObject("NumberFontNormalHuge");
	focusTabbedInfo:SetTextHeight(36);
    focusTabbedInfo:SetWidth(200);
    focusTabbedInfo:SetHeight(100);
    focusTabbedInfo:SetTextColor(1.0, 0.2, 0.2);
    focusTabbedInfo:ClearAllPoints(); 
    focusTabbedInfo:SetPoint("CENTER", FocusFrame, "CENTER", 0, 10);
    focusTabbedInfo:SetText("");
end

function CleanUI_UnitFrame_UpdateTooltip(self)

    local name, id = GameTooltip:GetUnit();
    
    if (name == UnitName("player")) then
        cui_party_xp[name] = {level=UnitLevel("player"), xp=UnitXP("player"), xpmax=UnitXPMax("player"), xpexhaustion=GetXPExhaustion()};
    end
    
    if (cui_party_xp[name] == nil or cui_party_xp[name].xp == nil or cui_party_xp[name].xpmax == nil) then
        return;
    end
    
    local level =  tonumber(cui_party_xp[name].level);
    
    if (level < MAX_PLAYER_LEVEL) then
        local xp =  tonumber(cui_party_xp[name].xp);
        local xpmax =  tonumber(cui_party_xp[name].xpmax);
        local pxp = 100 * xp / xpmax;
            
        GameTooltip:AddLine(" ");
        GameTooltip:AddLine("|c333399ffXP:|r |cffffffff"..xp.."/"..xpmax.."  (|r"..format("%d", pxp).." %|cffffffff)|r");
            
        GameTooltip:AppendText("");
    end
end

function CleanUI_ColorizeRuneFrame()
    RuneFrame:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
    
    local _, class = UnitClass("player");
	
	if ( class == "DEATHKNIGHT" ) then    
        for index = 1,25 do
            local _, _, _, _, _, _, _, _, _, _, spellId = UnitAura("player", index);
            if (spellId == 48263) then        -- Frost: 48263
                RuneFrame:SetBackdropBorderColor(0.0, 1.0, 1.0, 1.0);
            elseif (spellId == 48266) then    -- Blut: 48266
                RuneFrame:SetBackdropBorderColor(1.0, 0.0, 0.0, 1.0);
            elseif (spellId == 48265) then    -- Unheilig: 48265
                RuneFrame:SetBackdropBorderColor(0.0, 0.5, 0.0, 1.0);
            end
        end
    end
end

function CleanUI_InitUnitTextures()
    PlayerStatusTexture:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-Player-Status");
    PlayerStatusTexture:SetTexCoord(0, 1, 0, 1);
    
    PlayerFrameFlash:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash");
    PlayerFrameFlash:SetTexCoord(0, 1, 0, 1);
    
    PetFrameFlash:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash");
    PetFrameFlash:SetTexCoord(0, 1, 0, 1);
    
    PetAttackModeTexture:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Red");
    PetAttackModeTexture:SetTexCoord(0, 1, 0, 1);
    
    TargetFrameFlash:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Target");
    TargetFrameFlash:SetTexCoord(0, 1, 0, 1);
    
    FocusFrameFlash:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Target");
    FocusFrameFlash:SetTexCoord(0, 1, 0, 1);
    
	for i=1, 4, 1 do
        _G["PartyMemberFrame"..i.."Flash"]:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Red");
        _G["PartyMemberFrame"..i.."Flash"]:SetTexCoord(0, 1, 0, 1);
        _G["PartyMemberFrame"..i.."Status"]:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Red");
        _G["PartyMemberFrame"..i.."Status"]:SetTexCoord(0, 1, 0, 1);

        _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetTexture("Interface\\AddOns\\CleanUI\\skins\\CleanUI-TargetingFrame-Flash-Red");
        _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetTexCoord(0, 1, 0, 1);
	end
	
	CleanUI_InitUnitDrawLayer();
end

function CleanUI_InitUnitDrawLayer()
    PlayerStatusTexture:SetDrawLayer("OVERLAY");
    PlayerFrameFlash:SetDrawLayer("OVERLAY");
    PetFrameFlash:SetDrawLayer("OVERLAY");
    PetAttackModeTexture:SetDrawLayer("OVERLAY");
    TargetFrameFlash:SetDrawLayer("OVERLAY");
    FocusFrameFlash:SetDrawLayer("OVERLAY");
    
	for i=1, 4, 1 do
        _G["PartyMemberFrame"..i.."Flash"]:SetDrawLayer("OVERLAY");
        _G["PartyMemberFrame"..i.."Status"]:SetDrawLayer("OVERLAY");
        _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetDrawLayer("OVERLAY");
	end
end

function CleanUI_MovePlayerIcons()
    CleanUI_PlayerFrame_UpdateArt(PlayerFrame);
end

function CleanUI_MovePartyIcons()
    for i = 1, 4 do
        PartyMemberFrame_UpdateArt(_G["PartyMemberFrame"..i]);
    end
end

function CleanUI_PlayerFrame_UpdateArt(self)
    CleanUI_MovePlayerDefaultIcons();
end

function CleanUI_PartyMemberFrame_UpdateArt(self)
 	local i = self:GetID();
 	local unit = "party"..i;
	
	if (UnitExists(unit)) then
	    CleanUI_MovePartyDefaultIcons(i);
    end
end

function CleanUI_MovePlayerDefaultIcons()    
    PlayerFrame:ClearAllPoints();
    PlayerFrame:SetPoint("TOPLEFT", 0, 0);
    
    PlayerFrame:SetWidth(232);
    PlayerFrame:SetHeight(70);
    PlayerFrame:SetHitRectInsets(0, 0, 0, 0);
    
    PlayerStatusTexture:SetWidth(226);
    PlayerStatusTexture:SetHeight(64);
    
    PlayerStatusTexture:ClearAllPoints();
    PlayerStatusTexture:SetPoint("TOPLEFT", 3, -3);
    
    PlayerFrameFlash:SetWidth(226);
    PlayerFrameFlash:SetHeight(64);
    
    PlayerFrameFlash:ClearAllPoints();
    PlayerFrameFlash:SetPoint("TOPLEFT", 3, -3);
    
    PlayerFrame:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    PlayerFrame:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
    PlayerFrameTexture:Hide();
    PlayerFrameVehicleTexture:Hide();
    PlayerFrameBackground:Hide();
    PlayerPortrait:Hide();
    
    PlayerName:ClearAllPoints();
	PlayerName:SetPoint("LEFT", 20, 24);
    PlayerName:SetWidth(200);
    PlayerName:SetJustifyH("LEFT");
	
    PlayerFrameReadyCheck:ClearAllPoints();
	PlayerFrameReadyCheck:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 10, -15);
	
    PlayerLeaderIcon:ClearAllPoints();
	PlayerLeaderIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 3, -3);
	
    PlayerMasterIcon:ClearAllPoints();
	PlayerMasterIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 3, -15);
	
    PlayerGuideIcon:ClearAllPoints();
	PlayerGuideIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 0, -63);
	
    PlayerFrameRoleIcon:ClearAllPoints();
	PlayerFrameRoleIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 0, -63);
	
    PlayerLevelText:ClearAllPoints();
	PlayerLevelText:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 8, -54);
	
    PlayerRestIcon:ClearAllPoints();
	PlayerRestIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 21, -46);
	
    PlayerRestGlow:ClearAllPoints();
	PlayerRestGlow:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 21, -49);
    
    PlayerAttackIcon:ClearAllPoints();
	PlayerAttackIcon:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 20, -52);
	PlayerAttackIcon:SetTexCoord(0.5, 1.0, 0, 0.49);
    
    PlayerAttackGlow:ClearAllPoints();
	PlayerAttackGlow:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 20, -52);
    
    PlayerAttackBackground:ClearAllPoints();
	PlayerAttackBackground:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 2, 100); -- out of screen
    
    PlayerPVPIcon:ClearAllPoints();
	PlayerPVPIcon:SetPoint("CENTER", PlayerFrame, "RIGHT", 8, -15);
    
    PlayerPVPTimerText:ClearAllPoints();
	PlayerPVPTimerText:SetPoint("CENTER", PlayerFrame, "RIGHT", 24, -5);
	
	PlayerHitIndicator:ClearAllPoints();
	PlayerHitIndicator:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 15, -20);

	local _, class = UnitClass("player");
	if ( class == "DEATHKNIGHT") then
	    RuneFrame:SetWidth(166);
	    RuneFrame:SetHeight(32);
	    RuneFrame:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 66, -68);
	    
	    RuneFrame:SetBackdrop( { 
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
            edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
            insets = { left = 4, right = 4, top = 4, bottom = 4 }
        });
        RuneFrame:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
        
        RuneButtonIndividual1:SetPoint("LEFT", RuneFrame, "LEFT", 8, 0);
        RuneButtonIndividual3:SetPoint("LEFT", RuneButtonIndividual2, "RIGHT", 17, 0);
        RuneButtonIndividual5:SetPoint("LEFT", RuneButtonIndividual4, "RIGHT", 17, 0);
	elseif ( class == "SHAMAN" ) then
	    TotemFrame:SetWidth(165);
	    TotemFrame:SetHeight(54);
	    TotemFrame:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 67, -69);
	    
	    TotemFrame:SetBackdrop( { 
            bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
            edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
            insets = { left = 4, right = 4, top = 4, bottom = 4 }
        });
        TotemFrame:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
        
        TotemFrameTotem1:SetPoint("TOPLEFT", TotemFrame, "TOPLEFT", 4, -5);
        TotemFrameTotem2:SetPoint("LEFT", TotemFrameTotem1, "RIGHT", 3, 0);
        TotemFrameTotem3:SetPoint("LEFT", TotemFrameTotem2, "RIGHT", 3, 0);
        TotemFrameTotem4:SetPoint("LEFT", TotemFrameTotem3, "RIGHT", 3, 0);
	end
	
	PlayerFrameGroupIndicatorLeft:Hide();
	PlayerFrameGroupIndicatorRight:Hide();
	PlayerFrameGroupIndicatorMiddle:Hide();
    
    PlayerFrameGroupIndicator:SetFrameStrata("HIGH");
    PlayerFrameGroupIndicator:ClearAllPoints();
	PlayerFrameGroupIndicator:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 30, -49);
    
    PlayerFrameAlternateManaBarBackground:Hide();
    PlayerFrameAlternateManaBarBorder:Hide();
    
    CleanUI_UpdateShapeshiftForm();
end

function CleanUI_UpdateShapeshiftForm()
        
    PlayerFrameAlternateManaBar:SetWidth(161);    
    PlayerFrameAlternateManaBar:SetHeight(9);
	PlayerFrameAlternateManaBar:ClearAllPoints();
    PlayerFrameAlternateManaBar:SetPoint("TOPLEFT", 66, -56);
    
	if ( PlayerFrameAlternateManaBar:IsVisible() ) then
        PlayerFrameHealthBar:SetWidth(161);
        PlayerFrameHealthBar:SetHeight(20);  
        PlayerFrameHealthBar:SetPoint("TOPLEFT", 66, -27);
        PlayerFrameHealthBarText:SetPoint("CENTER", 35, -2);
    
        PlayerFrameManaBar:SetWidth(161);    
        PlayerFrameManaBar:SetHeight(9);
        PlayerFrameManaBar:SetPoint("TOPLEFT", 66, -47);
        PlayerFrameManaBarText:SetPoint("CENTER", 35, -16);
    else
        PlayerFrameHealthBar:SetWidth(161);
        PlayerFrameHealthBar:SetHeight(26);  
        PlayerFrameHealthBar:SetPoint("TOPLEFT", 66, -27);
        PlayerFrameHealthBarText:SetPoint("CENTER", 35, -5);
    
        PlayerFrameManaBar:SetWidth(161);    
        PlayerFrameManaBar:SetHeight(12);
        PlayerFrameManaBar:SetPoint("TOPLEFT", 66, -53);
        PlayerFrameManaBarText:SetPoint("CENTER", 35, -24);
    end
end

function CleanUI_MovePetIcons()
    
    PetFrame:SetWidth(128);
    PetFrame:SetHeight(48);
    PetFrame:SetHitRectInsets(0, 0, 0, 0);
    
    PetFrame:ClearAllPoints();
    PetFrame:SetPoint("TOPLEFT", 152, -68);
    
    PetFrame:SetBackdrop( { 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    PetFrame:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
    PetPortrait:Hide();
    PetFrameTexture:Hide();
    
    PetName:ClearAllPoints();
	PetName:SetPoint("CENTER", 0, 14);
    
    PetFrameFlash:SetWidth(122);
    PetFrameFlash:SetHeight(42);
    
    PetFrameFlash:ClearAllPoints();
    PetFrameFlash:SetPoint("TOPLEFT", 3, -3);
    
    PetAttackModeTexture:SetWidth(122);
    PetAttackModeTexture:SetHeight(42);
    
    PetAttackModeTexture:ClearAllPoints();
    PetAttackModeTexture:SetPoint("TOPLEFT", 3, -3);
    
    PetFrameHappiness:ClearAllPoints();
    PetFrameHappiness:SetPoint("LEFT", PetFrame, "RIGHT", 0, 0);
    
    PetFrameHealthBar:SetWidth(119);
    PetFrameHealthBar:SetHeight(18);  
    PetFrameHealthBar:ClearAllPoints();
    PetFrameHealthBar:SetPoint("CENTER", 0, -1);
    PetFrameHealthBarText:SetPoint("CENTER", 0, 0);
    
    PetFrameHealthBar:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    });
    
    PetFrameHealthBar:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
    
    PetFrameManaBar:SetWidth(119);    
    PetFrameManaBar:SetHeight(10);
    PetFrameManaBar:ClearAllPoints();
    PetFrameManaBar:SetPoint("CENTER", 0, -15);
    PetFrameManaBarText:SetPoint("CENTER", 0, -15);
    
    PetFrameManaBar:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    });
    
    PetFrameManaBar:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
end

function CleanUI_MovePartyDefaultIcons(i)

    PartyMemberFrame1:ClearAllPoints();
	PartyMemberFrame1:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, -160);
	
    PartyMemberFrame2:ClearAllPoints();
	PartyMemberFrame2:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, -240);
	
    PartyMemberFrame3:ClearAllPoints();
	PartyMemberFrame3:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, -320);
	
    PartyMemberFrame4:ClearAllPoints();
	PartyMemberFrame4:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, -400);
	
    _G["PartyMemberFrame"..i]:SetWidth(158);	
    _G["PartyMemberFrame"..i]:SetHeight(48);
    
    _G["PartyMemberFrame"..i.."Portrait"]:Hide();
    _G["PartyMemberFrame"..i.."Texture"]:Hide();
    _G["PartyMemberFrame"..i.."VehicleTexture"]:Hide();
    _G["PartyMemberFrame"..i.."Background"]:Hide();
    
    _G["PartyMemberFrame"..i]:SetBackdrop( { 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    
    _G["PartyMemberFrame"..i.."Name"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."Name"]:SetPoint("CENTER", 0, 15);
    
    _G["PartyMemberFrame"..i.."RoleIcon"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."RoleIcon"]:SetPoint("TOPLEFT", 0, -42);
    
    _G["PartyMemberFrame"..i.."GuideIcon"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."GuideIcon"]:SetPoint("TOPLEFT", 0, -42);
    
    _G["PartyMemberFrame"..i.."MasterIcon"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."MasterIcon"]:SetPoint("TOPLEFT", 20, 5);
    
    _G["PartyMemberFrame"..i.."LeaderIcon"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."LeaderIcon"]:SetPoint("TOPLEFT", 0, 5);
    
    _G["PartyMemberFrame"..i.."PVPIcon"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."PVPIcon"]:SetPoint("CENTER", _G["PartyMemberFrame"..i], "RIGHT", -1, -3);
    
    _G["PartyMemberFrame"..i.."HealthBar"]:SetWidth(109);
    _G["PartyMemberFrame"..i.."HealthBar"]:SetHeight(18);  
    _G["PartyMemberFrame"..i.."HealthBar"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."HealthBar"]:SetPoint("LEFT", 44, -1);
    _G["PartyMemberFrame"..i.."HealthBar"]:SetFrameStrata("LOW");
    _G["PartyMemberFrame"..i.."HealthBarText"]:SetPoint("CENTER", _G["PartyMemberFrame"..i.."HealthBar"], "CENTER", 0,0);
    
    _G["PartyMemberFrame"..i.."HealthBar"]:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    });
    
    _G["PartyMemberFrame"..i.."HealthBar"]:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
    
    _G["PartyMemberFrame"..i.."ManaBar"]:SetWidth(109);    
    _G["PartyMemberFrame"..i.."ManaBar"]:SetHeight(10);
    _G["PartyMemberFrame"..i.."ManaBar"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."ManaBar"]:SetPoint("LEFT", 44, -15);
    _G["PartyMemberFrame"..i.."ManaBar"]:SetFrameStrata("LOW");
    _G["PartyMemberFrame"..i.."ManaBarText"]:SetPoint("CENTER", _G["PartyMemberFrame"..i.."ManaBar"], "CENTER", 0, 0);
    
    _G["PartyMemberFrame"..i.."ManaBar"]:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    });
    
    _G["PartyMemberFrame"..i.."ManaBar"]:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
    
    _G["PartyMemberFrame"..i.."Flash"]:SetWidth(152);
    _G["PartyMemberFrame"..i.."Flash"]:SetHeight(42);
    _G["PartyMemberFrame"..i.."Flash"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."Flash"]:SetPoint("TOPLEFT", 3, -3);
    _G["PartyMemberFrame"..i.."Flash"]:SetDrawLayer("OVERLAY");
    
    _G["PartyMemberFrame"..i.."Status"]:SetWidth(152);
    _G["PartyMemberFrame"..i.."Status"]:SetHeight(42);
    _G["PartyMemberFrame"..i.."Status"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."Status"]:SetPoint("TOPLEFT", 3, -3);
    _G["PartyMemberFrame"..i.."Status"]:SetDrawLayer("OVERLAY");
    
    _G["PartyMemberFrame"..i.."Debuff1"]:SetPoint("TOPLEFT", 59, -50);
    
    CleanUI_MovePartyDefaultPetIcons(i);
end

function CleanUI_PartyMemberFrame_UpdatePet(self, id)
	if ( not id ) then
		id = self:GetID();
	end
	
    _G["PartyMemberFrame"..id.."PetFrame"]:ClearAllPoints();
	_G["PartyMemberFrame"..id.."PetFrame"]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPRIGHT", -1, 0);
    _G["PartyMemberFrame"..id.."PetFrame"]:SetWidth(75);
    _G["PartyMemberFrame"..id.."PetFrame"]:SetHeight(48);  
end

function CleanUI_MovePartyDefaultPetIcons(i)
    
    _G["PartyMemberFrame"..i.."PetFrame"]:SetBackdrop( { 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    
    _G["PartyMemberFrame"..i.."PetFrame"]:SetFrameStrata("LOW");
    
    _G["PartyMemberFrame"..i.."PetFrame"]:ClearAllPoints();
	_G["PartyMemberFrame"..i.."PetFrame"]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..i], "TOPRIGHT", -1, 0);
    _G["PartyMemberFrame"..i.."PetFrame"]:SetWidth(75);
    _G["PartyMemberFrame"..i.."PetFrame"]:SetHeight(48);  
    
    _G["PartyMemberFrame"..i.."PetFrameHealthBar"]:SetWidth(66);
    _G["PartyMemberFrame"..i.."PetFrameHealthBar"]:SetHeight(18);  
    _G["PartyMemberFrame"..i.."PetFrameHealthBar"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."PetFrameHealthBar"]:SetPoint("CENTER", 0, -1);
    _G["PartyMemberFrame"..i.."PetFrameHealthBar"]:SetFrameStrata("BACKGROUND");
    
    _G["PartyMemberFrame"..i.."PetFramePortrait"]:Hide();
    _G["PartyMemberFrame"..i.."PetFrameTexture"]:Hide();
    
    _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetWidth(68);
    _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetHeight(22);
    _G["PartyMemberFrame"..i.."PetFrameFlash"]:ClearAllPoints();
    _G["PartyMemberFrame"..i.."PetFrameFlash"]:SetPoint("TOPLEFT", 4, -3);
    
    _G["PartyMemberFrame"..i.."PetFrameDebuff1"]:SetPoint("TOPLEFT", 7, -50);
    
    local pet = "partypet"..i;
    
    if (UnitExists(pet)) then
        local petname = UnitName(pet);
        
        if (petname) then
            _G["CUI_Party"..i.."PetName"]:SetText(petname);
            _G["CUI_Party"..i.."PetName"]:Show();
        end
    else  
        _G["CUI_Party"..i.."PetName"]:SetText("");  
        _G["CUI_Party"..i.."PetName"]:Hide(); 
    end
end

function CleanUI_MoveTargetIcons()
    
    TargetFrame:SetWidth(200);
    TargetFrame:SetHeight(104);
    TargetFrame:SetHitRectInsets(0, 0, 0, 0);
    TargetFrame:SetFrameStrata("LOW");
        
    TargetFrame:ClearAllPoints();
    TargetFrame:SetPoint("TOPLEFT", 300, 0);
    
    local borderframe = CreateFrame("Frame", "CUI_TargetBorderFrame", TargetFrame);
    
    borderframe:SetWidth(200);
    borderframe:SetHeight(70);
    borderframe:ClearAllPoints();
    borderframe:SetPoint("TOP", 0, 0);
    borderframe:SetFrameStrata("BACKGROUND");
    
    borderframe:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    borderframe:SetBackdropColor(0.0, 0.0, 0.0, 0.5);
    
    TargetFrameFlash:SetWidth(194);
    TargetFrameFlash:SetHeight(64);
    TargetFrameFlash:ClearAllPoints();
    TargetFrameFlash:SetPoint("TOPLEFT", 3, -3);

    TargetFrame:Hide();
    TargetFrameBackground:Hide();
    TargetFrameNameBackground:Hide();
    TargetFrameTextureFrameTexture:Hide();
    TargetFramePortrait:Hide();
    
    TargetFrameTextureFrameName:SetWidth(200);
    TargetFrameTextureFrameName:SetHeight(10);
    TargetFrameTextureFrameName:ClearAllPoints();
	TargetFrameTextureFrameName:SetPoint("TOP", 0, -7);
    
    TargetFrameHealthBar:SetWidth(130);
    TargetFrameHealthBar:SetHeight(26); 
    TargetFrameHealthBar:ClearAllPoints(); 
    TargetFrameHealthBar:SetPoint("TOPLEFT", 4, -27);
    TargetFrameTextureFrameHealthBarText:ClearAllPoints(); 
    TargetFrameTextureFrameHealthBarText:SetPoint("CENTER", TargetFrameHealthBar, "CENTER", 0, 0);
    
    TargetFrameManaBar:SetWidth(130);    
    TargetFrameManaBar:SetHeight(12);
    TargetFrameManaBar:ClearAllPoints(); 
    TargetFrameManaBar:SetPoint("TOPLEFT", 4, -53);
    TargetFrameTextureFrameManaBarText:ClearAllPoints(); 
    TargetFrameTextureFrameManaBarText:SetPoint("CENTER", TargetFrameManaBar, "CENTER", 0, 0);
    
    TargetFrameTextureFrameLeaderIcon:ClearAllPoints(); 
    TargetFrameTextureFrameLeaderIcon:SetPoint("TOPLEFT", TargetFrame, "TOPLEFT", 5, -5);
    
    TargetFrameTextureFrameLevelText:ClearAllPoints(); 
    TargetFrameTextureFrameLevelText:SetPoint("TOPRIGHT", TargetFrame, "TOPRIGHT", -5, -5);
    
    TargetFrameTextureFrameHighLevelTexture:ClearAllPoints(); 
    TargetFrameTextureFrameHighLevelTexture:SetPoint("TOPRIGHT", TargetFrame, "TOPRIGHT", -5, -5);
    
    TargetFrameTextureFrameRaidTargetIcon:ClearAllPoints(); 
    TargetFrameTextureFrameRaidTargetIcon:SetPoint("TOPRIGHT", TargetFrame, "TOPRIGHT", -5, -35);
    
    TargetFrameTextureFramePVPIcon:ClearAllPoints(); 
    TargetFrameTextureFramePVPIcon:SetPoint("CENTER", TargetFrame, "RIGHT", 8, 2);
    
    TargetFrameTextureFrameDeadText:ClearAllPoints(); 
    TargetFrameTextureFrameDeadText:SetPoint("CENTER", TargetFrameHealthBar, "CENTER", 0, 0);
    
    CleanUI_MoveTargetOfTargetIcons();
    CleanUI_SetSpellbarAspect(TargetFrameSpellBar);
end

function CleanUI_MoveTargetOfTargetIcons()
    TargetFrameToT:SetWidth(128);
    TargetFrameToT:SetHeight(48);
    TargetFrameToT:SetHitRectInsets(0, 0, 0, 0);
    
    TargetFrameToT:ClearAllPoints();
    TargetFrameToT:SetPoint("TOPLEFT", 120, -68);
    
    TargetFrameToT:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    TargetFrameToT:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
    TargetFrameToTPortrait:Hide();
    TargetFrameToTBackground:Hide();
    TargetFrameToTTextureFrameTexture:Hide();
    
    TargetFrameToTTextureFrameName:ClearAllPoints();
	TargetFrameToTTextureFrameName:SetPoint("CENTER", 0, 14);
	TargetFrameToTTextureFrameName:SetJustifyH("CENTER");
    
    TargetFrameToTHealthBar:SetWidth(119);
    TargetFrameToTHealthBar:SetHeight(18);  
    TargetFrameToTHealthBar:ClearAllPoints();
    TargetFrameToTHealthBar:SetPoint("CENTER", 0, -1);
    
    TargetFrameToTManaBar:SetWidth(119);    
    TargetFrameToTManaBar:SetHeight(10);
    TargetFrameToTManaBar:ClearAllPoints();
    TargetFrameToTManaBar:SetPoint("CENTER", 0, -15);
    
    TargetFrameToTTextureFrameDeadText:ClearAllPoints(); 
    TargetFrameToTTextureFrameDeadText:SetPoint("CENTER", TargetFrameToTHealthBar, "CENTER", 0, 0);
end

function CleanUI_FocusFrame_OnDragStart(self, button)
	FOCUS_FRAME_MOVING = false;
	if ( not FOCUS_FRAME_LOCKED ) then
		local cursorX, cursorY = GetCursorPosition();
		self:StartMoving();
		FOCUS_FRAME_MOVING = true;
	end
end

function CleanUI_FocusFrame_OnDragStop(self)
	if ( not FOCUS_FRAME_LOCKED and FOCUS_FRAME_MOVING ) then
		self:StopMovingOrSizing();
		if ( self:GetBottom() < 15 + MainMenuBar:GetHeight() ) then
			local anchorX = self:GetLeft();
			local anchorY = 60;
			if ( self.smallSize ) then
				anchorY = 90;	-- empirically determined
			end
			self:SetPoint("BOTTOMLEFT", anchorX, anchorY);
		end
		FOCUS_FRAME_MOVING = false;
	end
end

function CleanUI_MoveFocusIcons()
    local fullsize = GetCVarBool("fullSizeFocusFrame");
    
    FocusFrame:SetWidth(200);
    FocusFrame:SetHeight(104);
    FocusFrame:SetHitRectInsets(0, 0, 0, 0);
    
    FocusFrame:SetClampedToScreen(true);
    
    local borderframe = CreateFrame("Frame", "CUI_FocusBorderFrame", FocusFrame);
    
    borderframe:SetWidth(200);
    borderframe:SetHeight(70);
    borderframe:ClearAllPoints();
    borderframe:SetPoint("TOP", 0, 0);
    borderframe:SetFrameStrata("BACKGROUND");
    
    borderframe:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    borderframe:SetBackdropColor(0.0, 0.0, 0.0, 0.5);
    
    FocusFrameFlash:SetWidth(194);
    FocusFrameFlash:SetHeight(64);
    FocusFrameFlash:ClearAllPoints();
    FocusFrameFlash:SetPoint("TOPLEFT", 3, -3);

    FocusFrame:Hide();
    FocusFrameBackground:Hide();
    FocusFrameNameBackground:Hide();
    FocusFrameTextureFrameTexture:Hide();
    FocusFramePortrait:Hide();
    
    FocusFrameTextureFrameName:SetWidth(200);
    FocusFrameTextureFrameName:SetHeight(10);
    FocusFrameTextureFrameName:ClearAllPoints();
	FocusFrameTextureFrameName:SetPoint("TOP", 0, -7);
    
    FocusFrameHealthBar:SetWidth(130);
    FocusFrameHealthBar:SetHeight(26); 
    FocusFrameHealthBar:ClearAllPoints(); 
    FocusFrameHealthBar:SetPoint("TOPLEFT", 4, -27);
    FocusFrameTextureFrameHealthBarText:ClearAllPoints(); 
    FocusFrameTextureFrameHealthBarText:SetPoint("CENTER", FocusFrameHealthBar, "CENTER", 0, 0);
    
    FocusFrameManaBar:SetWidth(130);    
    FocusFrameManaBar:SetHeight(12);
    FocusFrameManaBar:ClearAllPoints(); 
    FocusFrameManaBar:SetPoint("TOPLEFT", 4, -53);
    FocusFrameTextureFrameManaBarText:ClearAllPoints(); 
    FocusFrameTextureFrameManaBarText:SetPoint("CENTER", FocusFrameManaBar, "CENTER", 0, 0);
    
    FocusFrameTextureFrameLeaderIcon:ClearAllPoints(); 
    FocusFrameTextureFrameLeaderIcon:SetPoint("TOPLEFT", FocusFrame, "TOPLEFT", 5, -5);
    
    FocusFrameTextureFrameLevelText:ClearAllPoints(); 
    FocusFrameTextureFrameLevelText:SetPoint("TOPRIGHT", FocusFrame, "TOPRIGHT", -5, -5);
    
    FocusFrameTextureFrameHighLevelTexture:ClearAllPoints(); 
    FocusFrameTextureFrameHighLevelTexture:SetPoint("TOPRIGHT", FocusFrame, "TOPRIGHT", -5, -5);
    
    FocusFrameTextureFrameRaidTargetIcon:ClearAllPoints(); 
    FocusFrameTextureFrameRaidTargetIcon:SetPoint("TOPRIGHT", FocusFrame, "TOPRIGHT", -5, -35);
    
    FocusFrameTextureFramePVPIcon:ClearAllPoints(); 
    FocusFrameTextureFramePVPIcon:SetPoint("CENTER", FocusFrame, "RIGHT", 8, 2);
    
    FocusFrameTextureFrameDeadText:ClearAllPoints(); 
    FocusFrameTextureFrameDeadText:SetPoint("CENTER", FocusFrameHealthBar, "CENTER", 0, 0);
    
    FocusFrame:HookScript("OnMouseDown", CleanUI_OnMouseDown);
	FocusFrame:HookScript("OnMouseUp", CleanUI_OnMouseUp);
    
    CleanUI_MoveTargetOfFocusIcons();
    CleanUI_SetSpellbarAspect(FocusFrameSpellBar);
end

function CleanUI_OnMouseDown(self)
    if (arg1 == "RightButton") then
        if (IsControlKeyDown()) then
            self:StartMoving();
        end
    end
end

function CleanUI_OnMouseUp(self)
    if (arg1 == "RightButton") then
        self:StopMovingOrSizing();
    end
end

function CleanUI_MoveTargetOfFocusIcons()	
    local fullsize = GetCVarBool("fullSizeFocusFrame");
    
    FocusFrameToT:SetWidth(128);
    FocusFrameToT:SetHeight(48);
    FocusFrameToT:SetHitRectInsets(0, 0, 0, 0);
    
    FocusFrameToT:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    FocusFrameToT:SetBackdropColor(0.0, 0.0, 0.0, 1.0);
	
    FocusFrameToTPortrait:Hide();
    FocusFrameToTBackground:Hide();
    FocusFrameToTTextureFrameTexture:Hide();
    
    FocusFrameToTTextureFrameName:ClearAllPoints();
	FocusFrameToTTextureFrameName:SetPoint("CENTER", 0, 14);
	FocusFrameToTTextureFrameName:SetJustifyH("CENTER");
    
    FocusFrameToTHealthBar:SetWidth(119);
    FocusFrameToTHealthBar:SetHeight(18);  
    FocusFrameToTHealthBar:ClearAllPoints();
    FocusFrameToTHealthBar:SetPoint("CENTER", 0, -1);
    
    FocusFrameToTManaBar:SetWidth(119);    
    FocusFrameToTManaBar:SetHeight(10);
    FocusFrameToTManaBar:ClearAllPoints();
    FocusFrameToTManaBar:SetPoint("CENTER", 0, -15);
    
    FocusFrameToTTextureFrameDeadText:ClearAllPoints(); 
    FocusFrameToTTextureFrameDeadText:SetPoint("CENTER", FocusFrameToTHealthBar, "CENTER", 0, 0);
    
    if (fullsize) then
        FocusFrameToT:SetScale(1.0);
    
        FocusFrameToT:ClearAllPoints();
        FocusFrameToT:SetPoint("TOPLEFT", 120, -68);
    else
        FocusFrameToT:SetScale(0.9);
    
        FocusFrameToT:ClearAllPoints();
        FocusFrameToT:SetPoint("TOPLEFT", 95, -76);
    end
end

function CleanUI_CastingBarFrame_OnEvent(self, event, ...)
	
	local unit = self.unit;
 	
 	if ( self.showShield and event == "UNIT_SPELLCAST_INTERRUPTIBLE" ) then
        if (unit == "target") then
            CleanUITargetSpellbarBorder:SetBackdropBorderColor(0.0, 1.0, 0.0, 1.0);
        elseif (unit == "focus") then
            CleanUIFocusSpellbarBorder:SetBackdropBorderColor(0.0, 1.0, 0.0, 1.0);
        end
    elseif ( self.showShield and event == "UNIT_SPELLCAST_NOT_INTERRUPTIBLE" ) then
        if (unit == "target") then
            CleanUITargetSpellbarBorder:SetBackdropBorderColor(1.0, 0.0, 0.0, 1.0);
        elseif (unit == "focus") then
            CleanUIFocusSpellbarBorder:SetBackdropBorderColor(1.0, 0.0, 0.0, 1.0);
        end
    else
        if (unit == "target") then
            CleanUITargetSpellbarBorder:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
        elseif (unit == "focus") then
            CleanUIFocusSpellbarBorder:SetBackdropBorderColor(1.0, 1.0, 1.0, 1.0);
        end
    end
end

function CleanUI_SetSpellbarAspect(self)

    self:SetWidth(172);
    self:SetHeight(20);

	local spellBarName = self:GetName();

	local frameText = _G[spellBarName.."Text"];
	if ( frameText ) then
		frameText:SetFontObject(SystemFont_Shadow_Small);
		frameText:ClearAllPoints();
		frameText:SetPoint("TOP", self, "TOP", 0, -1);
	end

	local frameBorder = _G[spellBarName.."Border"];
	if ( frameBorder ) then
		frameBorder:SetTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	end
	
	local frameIcon = _G[spellBarName.."Icon"];
	if ( frameIcon ) then
        frameIcon:SetWidth(22);
        frameIcon:SetHeight(22);
		frameIcon:ClearAllPoints();
		frameIcon:SetPoint("RIGHT", self, "LEFT", 0, 0);
    end

	local frameBorderShield = _G[spellBarName.."BorderShield"];
	if ( frameBorderShield ) then
		frameBorderShield:SetTexture("Interface\\AddOns\\CleanUI\\skins\\empty");
	end

	local frameFlash = _G[spellBarName.."Flash"];
	if ( frameFlash ) then
		frameFlash:SetTexture("Interface\\AddOns\\CleanUI\\skins\\spellbar_flash");
		frameFlash:SetWidth(238);
		frameFlash:SetHeight(200);
		frameFlash:ClearAllPoints();
		frameFlash:SetPoint("CENTER", self, "CENTER", -11, 0);
	end

	local frameSpark = _G[spellBarName.."Spark"];
	if ( frameSpark ) then
		frameSpark:SetWidth(40);
		frameSpark:SetHeight(40);
	end
end

function CleanUI_SetTexture(object, texture)
	object:SetNormalTexture(texture);
	object:SetPushedTexture(texture);
end

function CleanUI_SetTextureCoords(object, index)
	object:GetNormalTexture():SetTexCoord(CUI_RAIDICONS[index].left,CUI_RAIDICONS[index].right,CUI_RAIDICONS[index].top,CUI_RAIDICONS[index].bottom);
	object:GetPushedTexture():SetTexCoord(CUI_RAIDICONS[index].left,CUI_RAIDICONS[index].right,CUI_RAIDICONS[index].top,CUI_RAIDICONS[index].bottom);
end

function CleanUI_RaidIconUpdate()  
	for i=1, 4, 1 do
		local button = getglobal("CleanUIParty"..i.."RaidIcon");
	
		if (UnitExists("party"..i) == 1 and _G["PartyMemberFrame"..i]:IsVisible()) then		    
		    local index = GetRaidTargetIndex("party"..i.."target");
		    
		    if (UnitExists("party"..i.."target") == 1) then
                if (index == nil or index == 0) then
                    CleanUI_SetTexture(button, "Interface\\AddOns\\CleanUI\\skins\\assist");
                    CleanUI_SetTextureCoords(button, 9);
                else
                    CleanUI_SetTexture(button, CUI_RAIDICON_FILE);
                    CleanUI_SetTextureCoords(button, index);
                end
            else
                CleanUI_SetTexture(button, CUI_RAIDICON_FILE);
                CleanUI_SetTextureCoords(button, 0);
            end
		end
	end
end

function CleanUI_MoveComboFrameIcons()
    ComboFrame:SetBackdrop( { 
        bgFile = "Interface/DialogFrame/UI-DialogBox-Background", 
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, 
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    });
    ComboFrame:SetBackdropColor(0.0, 0.0, 0.0, 1.0);	
    
    ComboFrame:SetWidth(25);
    ComboFrame:SetHeight(70);
    
    ComboFrame:ClearAllPoints();
    ComboFrame:SetPoint("TOPLEFT", TargetFrame, "TOPRIGHT", -2, 0);
    
	for i=1, MAX_COMBO_POINTS do
		comboPoint = _G["ComboPoint" .. i];
	    comboPoint:SetWidth(13);
	    comboPoint:SetHeight(13);
	    comboPoint:ClearAllPoints();
        comboPoint:SetPoint("CENTER", ComboFrame, "TOP", 0, -12 - ((i-1) * 12));
    end
end