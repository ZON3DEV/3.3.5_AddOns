function CleanUI_InitChat()
end