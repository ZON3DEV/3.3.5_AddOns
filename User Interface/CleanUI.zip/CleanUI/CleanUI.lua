-- saved variables
CleanUIData = {}

CleanUIData.XpFrameVisible = 0;

cui_party_xp = {};

CUI_RAIDICON_FILE = "interface\\targetingframe\\ui-raidtargetingicons";
CUI_RAIDICONS = {};
CUI_RAIDICONS[0] = {left=0, right=0, top=0, bottom=0};
CUI_RAIDICONS[1] = {left=0, right=0.25, top=0, bottom=0.25};
CUI_RAIDICONS[2] = {left=0.25, right=0.5, top=0, bottom=0.25};
CUI_RAIDICONS[3] = {left=0.5, right=0.75, top=0, bottom=0.25};
CUI_RAIDICONS[4] = {left=0.75, right=1, top=0, bottom=0.25};
CUI_RAIDICONS[5] = {left=0, right=0.25, top=0.25, bottom=0.5};
CUI_RAIDICONS[6] = {left=0.25, right=0.5, top=0.25, bottom=0.5};
CUI_RAIDICONS[7] = {left=0.5, right=0.75, top=0.25, bottom=0.5};
CUI_RAIDICONS[8] = {left=0.75, right=1, top=0.25, bottom=0.5};
CUI_RAIDICONS[9] = {left=0, right=1, top=0, bottom=1};

-- ein etwas helleres Blau f�r Mana
PowerBarColor["MANA"] = { r = 0.20, g = 0.35, b = 1.00 };
PowerBarColor[0] = PowerBarColor["MANA"];

UnitPopupMenus["FOCUS"] = { "RAID_TARGET_ICON", "CANCEL" };

-- functions
function CleanUI_OnLoad()
 	DEFAULT_CHAT_FRAME:AddMessage("|c333399ffNirriti's |rCleanUI loaded.", 1.0, 1.0, 1.0, 1, 10);
 	    
    CleanUI_RegisterEvents();
    CleanUI_HookEvents();
	CleanUI_InitSlashCommandHandler();
end

function CleanUI_RegisterEvents()
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("ADDON_LOADED");
	
	this:RegisterEvent("MINIMAP_ZONE_CHANGED");
	this:RegisterEvent("WORLD_MAP_UPDATE");
	
	this:RegisterEvent("ZONE_CHANGED");
	this:RegisterEvent("ZONE_CHANGED_INDOORS");
	this:RegisterEvent("ZONE_CHANGED_NEW_AREA");
	
	this:RegisterEvent("UPDATE_PENDING_MAIL");	
	
	this:RegisterEvent("PARTY_MEMBERS_CHANGED");
	this:RegisterEvent("PARTY_MEMBER_ENABLE");
	this:RegisterEvent("PARTY_MEMBER_DISABLE");
	
	this:RegisterEvent("PLAYER_XP_UPDATE");
	this:RegisterEvent("CHAT_MSG_ADDON");
	
	this:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE");	
	this:RegisterEvent("UNIT_THREAT_LIST_UPDATE");
	this:RegisterEvent("PLAYER_TARGET_CHANGED");
	this:RegisterEvent("PLAYER_FOCUS_CHANGED");
	this:RegisterEvent("PLAYER_FLAGS_CHANGED");
	this:RegisterEvent("UNIT_TARGET");
	this:RegisterEvent("UNIT_HEALTH");
	this:RegisterEvent("UNIT_COMBAT");
	this:RegisterEvent("UNIT_AURA");
	this:RegisterEvent("RAID_TARGET_UPDATE");
	this:RegisterEvent("CVAR_UPDATE");
	this:RegisterEvent("CALENDAR_UPDATE_PENDING_INVITES");
	
	this:RegisterEvent("UPDATE_SHAPESHIFT_FORM");
	this:RegisterEvent("UPDATE_SHAPESHIFT_USABLE");
	
	this:RegisterEvent("UNIT_ENTERED_VEHICLE");
	this:RegisterEvent("UNIT_EXITED_VEHICLE");
	
	--this:RegisterAllEvents();
end

function CleanUI_HookEvents()
    hooksecurefunc("MultiActionBar_Update", CleanUI_InitActionBars);
    hooksecurefunc("ReputationWatchBar_Update", CleanUI_InitActionBars);
    hooksecurefunc("UnitFrame_UpdateTooltip", CleanUI_UnitFrame_UpdateTooltip);
    hooksecurefunc("PlayerFrame_SequenceFinished", CleanUI_PlayerFrame_UpdateArt);
    hooksecurefunc("PartyMemberFrame_ToPlayerArt", CleanUI_PartyMemberFrame_UpdateArt);
    hooksecurefunc("PartyMemberFrame_ToVehicleArt", CleanUI_PartyMemberFrame_UpdateArt);
    hooksecurefunc("PartyMemberFrame_UpdatePet", CleanUI_PartyMemberFrame_UpdatePet);
    hooksecurefunc("SetPortraitTexture", CleanUI_SetPortraitTexture);
    hooksecurefunc("CastingBarFrame_OnEvent", CleanUI_CastingBarFrame_OnEvent);
    
    FocusFrame:SetScript("OnDragStart", CleanUI_FocusFrame_OnDragStart);
    FocusFrame:SetScript("OnDragStop", CleanUI_FocusFrame_OnDragStop);
    
    MainMenuExpBar:HookScript("OnMouseUp", CleanUI_ToggleXpFrame);
end

function CleanUI_InitSlashCommandHandler()

	SLASH_CLEANUI1 = "/cui";
  	SLASH_CLEANUI2 = "/cleanui";
  	SlashCmdList["CLEANUI"] = function(msg)
		CleanUI_SlashCommandHandler(msg);
	end
end

function CleanUI_SlashCommandHandler(msg)	
	if (msg == "reload") then
	 	ReloadUI();
	elseif (msg == "togglexp") then
	 	CleanUI_ToggleXpFrame();
	elseif (string.find(msg, "fake") == 1) then
 	    CleanUI_SendXpUpdate();
 	    CleanUI_XXXXX();
	end
end
    
function CleanUI_OnUpdate(self, elapsed)
end

function CleanUI_OnEvent(self, event, ...)
	if (event == "ADDON_LOADED") then
		local addonName = ...;
		if (addonName == "CustomButtons") then
            CleanUI_InitMinimapButtons();
            CleanUI_InitActionBars(nil);
            CleanUI_InitChat();
        end
    end
    if (event == "CVAR_UPDATE") then
        CleanUI_InitUnitFrames();
    end
    if (event == "UPDATE_PENDING_MAIL") then
        if ( HasNewMail() ) then
            CleanUIMinimapButtons:SetAlpha(1);
        end
	end
    if ( event == "CALENDAR_UPDATE_PENDING_INVITES") then
        if ( CalendarGetNumPendingInvites() > 0 ) then
            CleanUIMinimapButtons:SetAlpha(1);
        end
    end
    if (event == "PARTY_MEMBERS_CHANGED") then
        CleanUI_CleanXpFrame();
        CleanUI_CheckClassColors();
        CleanUI_PartyMemberFrame_UpdateArt(self);
    end
    if (event == "PLAYER_XP_UPDATE" or event == "PARTY_MEMBERS_CHANGED") then
        CleanUI_SendXpUpdate();
    end
    if (event == "UNIT_AURA" or event == "UNIT_COMBAT") then
        CleanUI_ColorizeRuneFrame();
        CleanUI_UpdateShapeshiftForm();
    end
    if (event == "PLAYER_ENTERING_WORLD") then
        CleanUI_ColorizeRuneFrame();
        CleanUI_UpdateShapeshiftForm();
        CleanUI_InitUnitFrames();	
        CleanUI_Init3DModels();
        CleanUI_SetPortraitTexture(PlayerPortrait, "player");
    end
    if (event == "UPDATE_SHAPESHIFT_FORM" or event == "UPDATE_SHAPESHIFT_USABLE") then
        CleanUI_UpdateShapeshiftForm();
    end
    if (event == "CHAT_MSG_ADDON") then
        local prefix, message, type, sender = ...;
        CleanUI_ReceiveXpUpdate(prefix, message, type, sender);
    end
    if (event == "UNIT_SPELLCAST_INTERRUPTIBLE") then
        local unit, spellname = ...;
        CleanUI_SetSpellInterruptible(unit, spellname);
    end
    if (event == "UNIT_SPELLCAST_NOT_INTERRUPTIBLE") then
        local unit, spellname = ...;
        CleanUI_SetSpellNotInterruptible(unit, spellname);
    end

	CleanUI_InitUnitDrawLayer();
    CleanUI_InitMinimapFrameStrata();
    CleanUI_ThreatSituationUpdate();
end

function CleanUI_SendXpUpdate()   
    local name = UnitName("player");
    local level = UnitLevel("player");
    local xp = UnitXP("player");
    local xpmax = UnitXPMax("player");
    local xpexhaustion = GetXPExhaustion();
    
    if (not xpexhaustion) then
        xpexhaustion = "";
    end
    
    local message = name..";"..level..";"..xp..";"..xpmax..";"..xpexhaustion;
    SendAddonMessage("CleanUI", message, "RAID");
end

function CleanUI_ReceiveXpUpdate(prefix, message, type, sender)  

    if (prefix == nil or prefix ~= "CleanUI") then
        return;
    end
    
    local name, _level, _xp, _xpmax, _xpexhaustion = strsplit(";", message, 5);
    
    if (_xpexhaustion == "") then
        _xpexhaustion = nil;
    end
    
    if (name ~= UnitName("player")) then
        cui_party_xp[name] = {level=_level, xp=_xp, xpmax=_xpmax, xpexhaustion=_xpexhaustion};
    end
    
    CleanUI_CleanXpFrame();
end

function CleanUI_XXXXX()
    
    TargetFrameSpellBar:Show();
    TargetFrameSpellBar:SetAlpha(1);

    --[[
    
    local kids = { RaidGroup1:GetChildren() };

    for _, child in ipairs(kids) do
        local tt = child:GetObjectType();
 	    DEFAULT_CHAT_FRAME:AddMessage(" .. "..tt, 1.0, 1.0, 1.0, 1, 10);
    end
    

    RaidGroup1
    RaidGroup8
    
    CUI_FocusTabbedInfo:SetText("tapped");
    CUI_TargetTabbedInfo:SetText("tapped");
    
    for i = 1, 4 do
        CleanUI_MovePartyDefaultIcons(i);
        
        _G["PartyMemberFrame"..i]:Show();
        _G["PartyMemberFrame"..i]:SetAlpha(1);
        
        _G["PartyMemberFrame"..i.."RoleIcon"]:Show();
        _G["PartyMemberFrame"..i.."RoleIcon"]:SetAlpha(1);
        
        _G["PartyMemberFrame"..i.."Debuff1"]:Show();
        _G["PartyMemberFrame"..i.."Debuff1"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."Debuff2"]:Show();
        _G["PartyMemberFrame"..i.."Debuff2"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."Debuff3"]:Show();
        _G["PartyMemberFrame"..i.."Debuff3"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."Debuff4"]:Show();
        _G["PartyMemberFrame"..i.."Debuff4"]:SetAlpha(1);
        
        _G["PartyMemberFrame"..i.."PetFrame"]:Show();
        _G["PartyMemberFrame"..i.."PetFrame"]:SetAlpha(1);
        
        _G["PartyMemberFrame"..i.."PetFrameDebuff1"]:Show();
        _G["PartyMemberFrame"..i.."PetFrameDebuff1"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."PetFrameDebuff2"]:Show();
        _G["PartyMemberFrame"..i.."PetFrameDebuff2"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."PetFrameDebuff3"]:Show();
        _G["PartyMemberFrame"..i.."PetFrameDebuff3"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."PetFrameDebuff4"]:Show();
        _G["PartyMemberFrame"..i.."PetFrameDebuff4"]:SetAlpha(1);
        _G["PartyMemberFrame"..i.."ManaBar"]:SetValue(100);
    end
    
    PlayerFrameRoleIcon:Show();
    PlayerLeaderIcon:Show();
    PlayerFrameReadyCheck:Show();
    PlayerGuideIcon:Show();	
    PlayerMasterIcon:Show();
    
    ]]--
    
end