--[[

$Revision: 0 $

(C) Copyright 2010 Bethink (bethink at naef dot com)
See LICENSE.txt for license terms.

]]


-- Constants
GAIN_TRACKER_INTERVAL = 60.0
GAIN_TRACKER_ARCHIVE_DAYS = 30
GAIN_TRACKER_EVENT_HANDLERS = { }
SLASH_GAIN_TRACKER1 = "/gt"

local CATACLYSM = select(4, GetBuildInfo()) >= 40000


----------------------------------------------------------------------
-- Frame event handlers

-- Handles the loading of  the addon frame
function GainTracker_OnLoad (self, ...)
	-- Initialize variables
	GainTracker = { }
	GainTracker.xpGained = 0
	GainTracker.moneyGained = 0
	GainTracker.elapsed = 0.0
	GainTracker.xpGainedSession = 0
	GainTracker.moneyGainedSession = 0
	GainTracker.elapsedSession = 0.0
	GainTracker.pendingLevelGrant = false
	GainTracker.pendingInboxMoney = false
	GainTracker_Data = GainTracker_Data or { }
	
	-- Register events
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("PLAYER_XP_UPDATE")
	self:RegisterEvent("PLAYER_LEVEL_UP")
	self:RegisterEvent("PLAYER_MONEY")
	self:RegisterEvent("PLAYER_FLAGS_CHANGED")
	self:RegisterEvent("PARTY_MEMBERS_CHANGED")
	self:RegisterEvent("UNIT_INVENTORY_CHANGED")
	self:RegisterEvent("LEVEL_GRANT_PROPOSED")
	
	-- Set hooks
	hooksecurefunc("TakeInboxMoney", GainTracker_TakeInboxMoney)
end

-- Handles registered events
function GainTracker_OnEvent (self, event, ...)
	local eventHandler = GAIN_TRACKER_EVENT_HANDLERS[event]
	if eventHandler then
		eventHandler(self, event, ...)
	end
end

-- Handles periodic frame updates
function GainTracker_OnUpdate (self, elapsed)
	GainTracker.elapsed = GainTracker.elapsed + elapsed
	if GainTracker.elapsed > GAIN_TRACKER_INTERVAL then
		GainTracker_Checkpoint()
	end
end


----------------------------------------------------------------------
-- Frame event handlers and hooks

-- Initializes the core data structures when the player enters the world.
function GainTracker_PlayerEnteringWorld (self, event)
	-- Store current client version
	GainTracker_Data.clientVersion = GetBuildInfo()
	
	-- Acquire the player node
	local locale = GetCVar("locale")
	local realmName = GetRealmName()
	local charName = UnitName("player")
	GainTracker_CharNode = GainTracker_GetNode(GainTracker_Data,
			"locales", locale,
			"realmNames", realmName,
			"charNames", charName)
	local class = select(2, UnitClass("player"))
	if class ~= GainTracker_CharNode.class then
		GainTracker_CharNode.class = class
		GainTracker_CharNode.days = { }
	end
	
	-- Get a fixing on current XP and money
	GainTracker.xp = UnitXP("player")
	GainTracker.xpMax = UnitXPMax("player")
	GainTracker.money = GetMoney()
	GainTracker_UpdatePlayerState()
	
	-- Clean out expired data
	local expireBefore = date("!%Y%m%d",
			time() - GAIN_TRACKER_ARCHIVE_DAYS * 24 * 60 * 60)
	for key in pairs(GainTracker_CharNode.days) do
		if key < expireBefore then
			GainTracker_CharNode.days[key] = nil
		end
	end
end

-- Tracks changes in the player experience.
function GainTracker_PlayerXpUpdate (self, event, unitId)
	local xp = UnitXP("player")
	local xpGained = xp - GainTracker.xp
	if xpGained > 0 then
		GainTracker.xpGained = GainTracker.xpGained + xpGained
		GainTracker_Checkpoint()
	end
	GainTracker.xp = xp
	GainTracker.xpMax = UnitXPMax("player")
end

-- Tracks changes in the player level.
function GainTracker_PlayerLevelUp (self, event)
	local xpGained = GainTracker.xpMax - GainTracker.xp
	if xpGained > 0 then
		GainTracker.xpGained = GainTracker.xpGained + xpGained
		GainTracker_Checkpoint()
	end
	GainTracker.xp = 0
	GainTracker.xpMax = 0 -- UnitXPMax() would still return old value
end

-- Tracks changes in the player money.
function GainTracker_PlayerMoney(self, event)
	local money = GetMoney()
	if not GainTracker.pendingInboxMoney then
		local moneyGained = money - GainTracker.money
		if moneyGained > 0 then
			GainTracker.moneyGained = GainTracker.moneyGained + moneyGained
			GainTracker_Checkpoint()
		end
	else
		GainTracker.pendingInboxMoney = false
	end
	GainTracker.money = money
end

-- Updates the player state
function GainTracker_UpdatePlayerState (self, event)
	-- Update tracking state
	local tracking = true
	if UnitIsAFK("player") then
		tracking = false
	end
	for i = 1, GetNumPartyMembers() do
		if UnitLevel("party" .. i) - 8 > UnitLevel("player") then
			tracking = false
			break
		end
	end
	if GainTracker.pendingLevelGrant then
		tracking = false
	end
	GainTracker.tracking = tracking
	
	-- Update XP state
	local xpFactor = 1.0
	if GetInventoryItemQuality("player", 3) == 7 then
		xpFactor = xpFactor + 0.1 -- shoulder heirloom
	end
	if GetInventoryItemQuality("player", 5) == 7 then
		xpFactor = xpFactor + 0.1 -- chest heirloom
	end
	if GetInventoryItemQuality("player", 11) == 7 or
			GetInventoryItemQuality("player", 12) == 7 then
		xpFactor = xpFactor + 0.05 -- finger heirloom
	end
	GainTracker.xpFactor = xpFactor
end

-- Handles changes in the equiped items of a unit
function GainTracker_UnitInventoryChanged (self, event, unitId)
	if unitId == "player" then
		GainTracker_UpdatePlayerState(self, event)
	end
end

-- Handles a proposed level grant
function GainTracker_LevelGrantProposed (self, event)
	GainTracker.pendingLevelGrant = true
	GainTracker_UpdatePlayerState(self, event)
end

-- Event handler map
GAIN_TRACKER_EVENT_HANDLERS = {
	PLAYER_ENTERING_WORLD = GainTracker_PlayerEnteringWorld,
	PLAYER_XP_UPDATE = GainTracker_PlayerXpUpdate,
	PLAYER_LEVEL_UP = GainTracker_PlayerLevelUp,
	PLAYER_MONEY = GainTracker_PlayerMoney,
	PLAYER_FLAGS_CHANGED = GainTracker_UpdatePlayerState,
	PARTY_MEMBERS_CHANGED = GainTracker_UpdatePlayerState,
	UNIT_INVENTORY_CHANGED = GainTracker_UnitInventoryChanged,
	LEVEL_GRANT_PROPOSED = GainTracker_LevelGrantProposed
}

-- Handles the pending gain of inbox money
function GainTracker_TakeInboxMoney ()
	GainTracker.pendingInboxMoney = true
end


----------------------------------------------------------------------
-- Data management

-- Checkpoints data
function GainTracker_Checkpoint () 
	if GainTracker.tracking then
		local dataNode = GainTracker_GetCharDataNode()
		GainTracker.xpGained = math.floor(
				GainTracker.xpGained / GainTracker.xpFactor + 0.5)
		dataNode.xp = dataNode.xp + GainTracker.xpGained
		dataNode.money = dataNode.money + GainTracker.moneyGained
		dataNode.elapsed = dataNode.elapsed + GainTracker.elapsed
		GainTracker.xpGainedSession = GainTracker.xpGainedSession
				+ GainTracker.xpGained
		GainTracker.moneyGainedSession = GainTracker.moneyGainedSession
				+ GainTracker.moneyGained
		GainTracker.elapsedSession = GainTracker.elapsedSession
				+ GainTracker.elapsed
	end
	GainTracker.xpGained = 0
	GainTracker.moneyGained = 0
	GainTracker.elapsed = 0.0
end

-- Returns the current char data node.
function GainTracker_GetCharDataNode ()
	local day = date("!%Y%m%d")
	local talentTab = GainTracker_GetTalentTab()
	local level = UnitLevel("player")
	local rested = GetXPExhaustion() ~= nil
	local zoneName = GetRealZoneText()
	local dataNode = GainTracker_GetNode(GainTracker_CharNode,
		"days", day,
		"talentTabs", talentTab,
		"levels", level,
		"rested", rested,
		"zoneNames", zoneName)
	dataNode.xp = dataNode.xp or 0
	dataNode.money = dataNode.money or 0
	dataNode.elapsed = dataNode.elapsed or 0.0
	return dataNode
end

-- Returns a node by path, creating subtables as needed.
function GainTracker_GetNode (root, ...)
	local current = root
	for i = 1, select("#", ...) do
		local key = select(i, ...)
		if not current[key] then
			current[key] = { }
		end
		current = current[key]
	end
	return current
end

-- Returns the number of the talent tab the player has most points in. Returns
-- 0 if the player has no talent points spent. Returns the first tab in case of
-- a tie.
function GainTracker_GetTalentTab ()
	local maxPointsSpent = 0
	local talentTab = 0
	for i = 1, GetNumTalentTabs() do
		local pointsSpent = select(CATACLYSM and 5 or 3, GetTalentTabInfo(i))
		if pointsSpent > maxPointsSpent then
			maxPointsSpent = pointsSpent
			talentTab = i
		end
	end
	return talentTab
end


----------------------------------------------------------------------
-- Slash command

-- Handles the Gain Tracker slash command
function GainTracker_SlashCommand (msg, editbox)
	if GainTracker.tracking then
		DEFAULT_CHAT_FRAME:AddMessage("Gain Tracker IS tracking.")
	else
		DEFAULT_CHAT_FRAME:AddMessage("Gain Tracker IS NOT tracking.")
	end
	local xp = GainTracker.xpGainedSession
	local gold = GainTracker.moneyGainedSession / 10000
	local hours = GainTracker.elapsedSession / 3600
	DEFAULT_CHAT_FRAME:AddMessage(string.format("Tracked this session: "
			.. "%.1f h, %d XP (%.1f XP/h), %.1f G (%.1f G/h)", hours, xp,
			hours > 0 and xp / hours or 0.0, gold, hours > 0 and gold / hours
			or 0.0))
end

SlashCmdList["GAIN_TRACKER"] = GainTracker_SlashCommand