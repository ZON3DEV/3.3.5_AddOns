QuestHelper_File["bst_astrolabe.lua"] = "1.4.1"
QuestHelper_Loadtime["bst_astrolabe.lua"] = GetTime()
