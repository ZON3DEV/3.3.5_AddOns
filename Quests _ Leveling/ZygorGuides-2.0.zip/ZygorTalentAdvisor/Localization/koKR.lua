if GetLocale()~="koKR" then return end

ZygorTalentAdvisor_L("Main", "koKR", function() return {
	-- ["English"] = "Localized",
} end)
