if GetLocale()~="frFR" then return end

ZygorGuidesViewer_L("Main", "frFR", function() return {
	-- ["English"] = "Localized",
} end)
