if GetLocale()~="zhCN" then return end

ZygorGuidesViewer.LocaleFont = [[Fonts\ZYKai_T.ttf]]

ZygorGuidesViewer_L("Main", "zhCN", function() return {
	-- ["English"] = "Localized",
} end)
