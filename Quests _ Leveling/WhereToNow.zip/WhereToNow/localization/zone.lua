--[[
	Where To Now?
	English Localization File
	Version alpha
]]

local B = LibStub("LibBabble-Zone-3.0")
local BL = B:GetUnstrictLookupTable()

--== Zone List ==--
-- Classic & Starting Zones
WTN_ZONE_GILNEAS = BL["Gilneas"]
WTN_ZONE_KEZAN = BL["Kezan"]
WTN_ZONE_AZUREMYSTISLE = BL["Azuremyst Isle"]
WTN_ZONE_DUNMOROGH = BL["Dun Morogh"]
WTN_ZONE_DUROTAR = BL["Durotar"]
WTN_ZONE_ELWYNNFOREST = BL["Elwynn Forest"]
WTN_ZONE_EVERSONGWOODS = BL["Eversong Woods"]
WTN_ZONE_MULGORE = BL["Mulgore"]
WTN_ZONE_TELDRASSIL = BL["Teldrassil"]
WTN_ZONE_TIRISFALGLADES = BL["Tirisfal Glades"]
WTN_ZONE_GILNEAS = BL["Gilneas"]
WTN_ZONE_LOSTISLES = BL["The Lost Isles"]
WTN_ZONE_WESTFALL = BL["Westfall"]
WTN_ZONE_AZSHARA = BL["Azshara"]
WTN_ZONE_BLOODMYSTISLE = BL["Bloodmyst Isle"]
WTN_ZONE_DARKSHORE = BL["Darkshore"]
WTN_ZONE_GHOSTLANDS = BL["Ghostlands"]
WTN_ZONE_LOCHMODAN = BL["Loch Modan"]
WTN_ZONE_NORTHERNBARRENS = BL["Northern Barrens"]
WTN_ZONE_SILVERPINEFOREST = BL["Silverpine Forest"]
WTN_ZONE_RUINSOFGILNEAS = BL["Ruins of Gilneas"]
WTN_ZONE_REDRIDGEMOUNTAINS = BL["Redridge Mountains"]
WTN_ZONE_ASHENVALE = BL["Ashenvale"]
WTN_ZONE_DUSKWOOD = BL["Duskwood"]
WTN_ZONE_HILLSBRADFOOTHILLS = BL["Hillsbrad Foothills"]
WTN_ZONE_WETLANDS = BL["Wetlands"]
WTN_ZONE_ARATHIHIGHLANDS = BL["Arathi Highlands"]WTN_ZONE_NORTHERNSTRANLETHORN = BL["Northern Stranglethorn"]
WTN_ZONE_STONETALONMOUNTAINS = BL["Stonetalon Mountains"]
WTN_ZONE_CAPEOFSTRANGLETHORN = BL["The Cape of Stranglethorn"]
WTN_ZONE_DESOLACE = BL["Desolace"]
WTN_ZONE_HINTERLANDS = BL["The Hinterlands"]
WTN_ZONE_SOUTHERNBARRENS = BL["Southern Barrens"]
WTN_ZONE_DUSTWALLOWMARSH = BL["Dustwallow Marsh"]
WTN_ZONE_FERALAS = BL["Feralas"]
WTN_ZONE_WESTERNPLAGUELANDS = BL["Western Plaguelands"]
WTN_ZONE_EASTERNPLAGUELANDS = BL["Eastern Plaguelands"]
WTN_ZONE_THOUSANDNEEDLES = BL["Thousand Needles"]WTN_ZONE_BADLANDS = BL["Badlands"]
WTN_ZONE_FELWOOD = BL["Felwood"]
WTN_ZONE_TANARIS = BL["Tanaris"]
WTN_ZONE_SEARINGGORGE = BL["Searing Gorge"]
WTN_ZONE_BURNINGSTEPPES = BL["Burning Steppes"]
WTN_ZONE_UNGOROCRATER = BL["Un'Goro Crater"]
WTN_ZONE_WINTERSPRING = BL["Winterspring"]
WTN_ZONE_SWAMPOFSORROWS = BL["Swamp of Sorrows"]
WTN_ZONE_BLASTEDLANDS = BL["Blasted Lands"]
WTN_ZONE_SCARLETENCLAVE = BL["Plaguelands: The Scarlet Enclave"]
WTN_ZONE_DEADWINDPASS = BL["Deadwind Pass"]
WTN_ZONE_MOONGLADE = BL["Moonglade"]
WTN_ZONE_SILITHUS = BL["Silithus"]

-- BC Zones
WTN_ZONE_HELLFIREPENINSULA = BL["Hellfire Peninsula"]
WTN_ZONE_ZANGERMARSH = BL["Zangarmarsh"]
WTN_ZONE_TERROKARFOREST = BL["Terokkar Forest"]
WTN_ZONE_NAGRAND = BL["Nagrand"]
WTN_ZONE_BLADESEDGEMOUNTAIN = BL["Blade's Edge Mountains"]
WTN_ZONE_NETHERSTORM = BL["Netherstorm"]
WTN_ZONE_SHADOWMOONVALLEY = BL["Shadowmoon Valley"]
--WTN_ZONE_DEADWINDPASS = BL["Deadwind Pass"]

-- wotlk Zones
WTN_ZONE_HOWLINGFJORD = BL["Howling Fjord"]
WTN_ZONE_BOREANTUNDRA = BL["Borean Tundra"]
WTN_ZONE_ISLEOFQUELDANAS = BL["Isle of Quel'Danas"]
WTN_ZONE_DRAGONBLIGHT = BL["Dragonblight"]
WTN_ZONE_GRIZZLYHILLS = BL["Grizzly Hills"]
WTN_ZONE_ZULDRAK = BL["Zul'Drak"]
WTN_ZONE_SHOLAZARBASIN = BL["Sholazar Basin"]
WTN_ZONE_CRYSTALSONGFOREST = BL["Crystalsong Forest"]
WTN_ZONE_HROTHGARSLANDING = BL["Hrothgar's Landing"]
WTN_ZONE_ICECROWN = BL["Icecrown"]
WTN_ZONE_STORMPEAKS = BL["The Storm Peaks"]

-- cata Zones
WTN_ZONE_WINTERGRASP = BL["Wintergrasp"]
WTN_ZONE_MOUNTHYJAL = BL["Mount Hyjal"]
WTN_ZONE_VASHJIR = BL["Vashj'ir"]
WTN_ZONE_DEEPHOLM = BL["Deepholm"]
WTN_ZONE_ULDUM = BL["Uldum"]
WTN_ZONE_TWILIGHTHIGHLANDS = BL["Twilight Highlands"]
WTN_ZONE_TOLBARAD = BL["Tol Barad"]

--== Dungeon List ==--
-- Classic Dungeons
WTN_DUNGEON_RAGEFIRECHASM = BL["Ragefire Chasm"];
WTN_DUNGEON_THEDEADMINES = BL["The Deadmines"];
WTN_DUNGEON_WAILINGCAVERNS = BL["Wailing Caverns"];	
WTN_DUNGEON_SHADOWFANGKEEP = BL["Shadowfang Keep"];
WTN_DUNGEON_BLACKFATHOMDEEPS = BL["Blackfathom Deeps"];
WTN_DUNGEON_STORMWINDSTOCKADE = BL["The Stockade"];
WTN_DUNGEON_GNOMEREGAN = BL["Gnomeregan"];
WTN_DUNGEON_THESCARLETMONASTRYGRAVEYARD = BL["Scarlet Monastery"]..": "..BL["Graveyard"];
WTN_DUNGEON_THESCARLETMONASTERYLIBRARY = BL["Scarlet Monastery"]..": "..BL["Library"];
WTN_DUNGEON_RAZORFENKRAUL = BL["Razorfen Kraul"];
WTN_DUNGEON_MARAUDON = BL["Maraudon"];
WTN_DUNGEON_THESCARLETMONASTERYARMORY = BL["Scarlet Monastery"]..": "..BL["Armory"];
WTN_DUNGEON_THESCARLETMONASTERYCATHEDRAL = BL["Scarlet Monastery"]..": "..BL["Cathedral"];
WTN_DUNGEON_ULDAMAN = BL["Uldaman"];
WTN_DUNGEON_DIREMAULWARPWOODQUATER = BL["Dire Maul (West)"];
WTN_DUNGEON_SCHOLOMANCE = BL["Scholomance"];
WTN_DUNGEON_DIREMAULCAPITALGARDENS = BL["Dire Maul (East)"];
WTN_DUNGEON_RAZORFENDOWNS = BL["Razorfen Downs"];
WTN_DUNGEON_DIREMAULGORDOCKCOMMONS = BL["Dire Maul (North)"];
WTN_DUNGEON_STRATHOLMEMAINGATE = BL["Stratholme"];
WTN_DUNGEON_ZULFARRAK = BL["Zul'Farrak"];
WTN_DUNGEON_STRATHOLMESERVICEENTRANCE = BL["Stratholme"];	
WTN_DUNGEON_BLACKROCKDEPTHSDETENTIONBLOCK = BL["Blackrock Depths"];
WTN_DUNGEON_TEMPLEOFATALHAKKAR = BL["The Temple of Atal'Hakkar"];
WTN_DUNGEON_BLACKROCKDEPTHSUPPERCITY = BL["Blackrock Depths"];
WTN_DUNGEON_LOWERBLACKROCKSPIRE = BL["Lower Blackrock Spire"];
WTN_DUNGEON_UPPERBLACKROCKSPIRE = BL["Upper Blackrock Spire"];
-- BC Dungeons
WTN_DUNGEON_HELLFIRECITADELHELLFIRERAMPARTS = BL["Hellfire Citadel"]..": "..BL["Hellfire Ramparts"];
WTN_DUNGEON_HELLFIRECITADELTHEBLOODFURNANCE = BL["Hellfire Citadel"]..": "..BL["The Blood Furnace"];
WTN_DUNGEON_COILFANGRESERVOIRSLAVEPENS = BL["Coilfang Reservoir"]..": "..BL["The Slave Pens"];
WTN_DUNGEON_COILFANGRESERVOIRTHEUNDERBOG = BL["Coilfang Reservoir"]..": "..BL["The Underbog"];
WTN_DUNGEON_AUCHINDOUNMANATOMBS = BL["Auchindoun"]..": "..BL["Mana-Tombs"];
WTN_DUNGEON_AUCHINDOUNAUCHENAICRYPTS = BL["Auchindoun"]..": "..BL["Auchenai Crypts"];
WTN_DUNGEON_CAVERNSOFTIMEESCAPEFROMDURNHOLDEKEEP =  BL["Caverns of Time"]..": "..BL["Old Hillsbrad Foothills"];
WTN_DUNGEON_AUCHINDOUNSETHEKKHALLS = BL["Auchindoun"]..": "..BL["Sethekk Halls"];
WTN_DUNGEON_COILFANGRESERVOIRTHESTEAMVAULT = BL["Coilfang Reservoir"]..": "..BL["The Steamvault"];
WTN_DUNGEON_AUCHINDOUNSHADOWLABYRINTH = BL["Auchindoun"]..": "..BL["Shadow Labyrinth"];
WTN_DUNGEON_HELLFIRECITADELSHATTEREDHALLS = BL["Hellfire Citadel"]..": "..BL["The Shattered Halls"];
WTN_DUNGEON_TEMPESTKEEPTHEMECHANAR = BL["Tempest Keep"]..": "..BL["The Mechanar"];
WTN_DUNGEON_TEMPESTKEEPTHEBOTANICA =  BL["Tempest Keep"]..": "..BL["The Botanica"];
WTN_DUNGEON_CAVERNSOFTIMEPENINGTHEDARKPORTAL =  BL["Caverns of Time"]..": "..BL["The Dark Portal"];
WTN_DUNGEON_TEMPESTKEEPTHEARCATRAZ =  BL["Tempest Keep"]..": "..BL["The Arcatraz"];
WTN_DUNGEON_MAGISTERSTERRACE = BL["Magisters' Terrace"];
-- WotLK Dungeons
WTN_DUNGEON_UTGARDEKEEP = BL["Utgarde Keep"];
WTN_DUNGEON_THENEXUS = BL["The Nexus"];
WTN_DUNGEON_AHNKAHETTHEOLDKINGDOM = BL["Ahn'kahet: The Old Kingdom"];
WTN_DUNGEON_AZJOLNERUB = BL["Azjol-Nerub"];
WTN_DUNGEON_DRAKTHARONKEEP = BL["Drak'Tharon Keep"];
WTN_DUNGEON_THEVIOLETHOLD = BL["The Violet Hold"];
WTN_DUNGEON_GUNDRAK = BL["Gundrak"];
WTN_DUNGEON_HALLSOFSTONE = BL["Halls of Stone"];
WTN_DUNGEON_HALLSOFLIGHTNING = BL["Halls of Lightning"];
WTN_DUNGEON_THEOCULUS = BL["The Oculus"];
WTN_DUNGEON_UTGARDEPINNACLE =  BL["Utgarde Pinnacle"];
WTN_DUNGEON_CAVERNSOFTIMECULLINGOFSTRATHOLME = BL["Caverns of Time"]..": "..BL["Old Stratholme"]; 
WTN_DUNGEON_TRIALOFTHECHAMPION = BL["Trial of the Champion"];

WTN_DUNGEON_THRONEOFTIDES = BL["Throne of the Tides"];
WTN_DUNGEON_BLACKROCKCAVERNS = BL["Blackrock Caverns"];
WTN_DUNGEON_THESTONECORE = BL["The Stonecore"];
WTN_DUNGEON_VORTEXPINNACLE = BL["Vortex Pinnacle"];
WTN_DUNGEON_LOSTCITYOFTHETOLVIR = BL["Lost City of the Tol'vir"];
WTN_DUNGEON_GRIMBARTOL = BL["Grim Batol"];
WTN_DUNGEON_HALLSOFORIGINATION = BL["Halls of Origination"];


--== Raid List ==--
WTN_RAID_UPPERBLACKROCKSPIRE = BL["Upper Blackrock Spire"]
WTN_RAID_ZULGURUB = BL["Zul'Gurub"]
WTN_RAID_KARAZHAN = BL["Karazhan"]
WTN_RAID_EYEOFETERNITY = BL["The Eye of Eternity"]