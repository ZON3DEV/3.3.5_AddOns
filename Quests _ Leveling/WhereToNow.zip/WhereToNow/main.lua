--[[
	Where To Now?
	Version 1.6
]]

WhereToNow_Version = "2.0.0 beta";

local L = LibStub("AceLocale-3.0"):GetLocale("WTN")

WhereToNow_Defaults = {
	["Options"] = {
		["Version"] = WhereToNow_Version,
		["Sort"] = "ExpansionMin",
		["ShowMinInstanceLevel"] = 0, -- Other value: 1
		["TooltipColor"] = 1,
	},
}

-- Message zones
function WhereToNow_Msg(msg, channel, debug)
	if (msg == nil) then
		return;
	end
	if debug == nil then
		debug = 10;
	end
	if (channel == "Error") then
		DEFAULT_CHAT_FRAME:AddMessage(RED_FONT_COLOR_CODE..L["WTN_TITLE"].." "..L["WTN_ERROR"]..": |r"..msg);
	elseif (channel == "Debug") then
		DEFAULT_CHAT_FRAME:AddMessage(LIGHTYELLOW_FONT_COLOR_CODE..L["WTN_TITLE"].." "..L["WTN_DEBUG"]..": |r"..msg);
	else
		DEFAULT_CHAT_FRAME:AddMessage(GREEN_FONT_COLOR_CODE..L["WTN_TITLE"]..": |r"..msg);
	end
end

-- Loading Function
function WhereToNow_Load(self)
	self:RegisterEvent("VARIABLES_LOADED");

	-- Slash Commands
	SlashCmdList["WhereToNow"] = WhereToNow_CommandLine;
	SLASH_WhereToNow1 = L["WTN_CMD_SLASH1"];
	SLASH_WhereToNow2 = L["WTN_CMD_SLASH2"];
	SLASH_WhereToNow3 = L["WTN_CMD_SLASH3"];
	SLASH_WhereToNow4 = L["WTN_CMD_SLASH4"];
end

function WhereToNow_OnEvent(self,event,...)
	if event == "VARIABLES_LOADED" then
		WhereToNow_Loaded();
	end
end

function WhereToNow_Loaded()
	WhereToNow_MakeDatabase();

	WhereToNow_Msg(L["WTN_VERSION"].." "..WhereToNow_Version.." "..L["WTN_NOWLOADED"]);
end

function WhereToNow_MakeDatabase()
	if (not WhereToNow_Options) then
		WhereToNow_Options = WhereToNow_Defaults["Options"];
	end

	if (not WhereToNow_Options["Version"]) or (WhereToNow_Options["Version"] < WhereToNow_Version) then
		local WhereToNow_Options_temp = WhereToNow_Defaults["Options"];
		for k,v in pairs(WhereToNow_Options) do
			if (WhereToNow_Defaults["Options"][k]) then
				WhereToNow_Options_temp[k] = v;
			end
		end
		WhereToNow_Options_temp["Version"] = WhereToNow_Options_Version;
		WhereToNow_Options = WhereToNow_Options_temp;
	end
end

function WhereToNow_CommandLine(cmd)
	-- Force lowercase so we don't have to double-up our options! Also makes it more user-proof.
	cmd = strlower(cmd);

	if (cmd == "minimap off") then
		WhereToNowMinimapButton:Hide();
		WhereToNow_Msg("Hiding minimap button.");
	elseif (cmd == "minimap on") then
		WhereToNowMinimapButton:Show();
		WhereToNow_Msg("Showing minimap button.");
	elseif (cmd == "minimap") then
		if (WhereToNowMinimapButton:IsVisible()) then
			WhereToNowMinimapButton:Hide();
			WhereToNow_Msg("Hiding minimap button.");
		else
			WhereToNowMinimapButton:Show();
			WhereToNow_Msg("Showing minimap button.");
		end
	elseif (cmd == "tooltip color on") then
		WhereToNow_Options["TooltipColor"] = 1;
	elseif (cmd == "tooltip color off") then
		WhereToNow_Options["TooltipColor"] = 0;
	elseif (cmd == "min level on") or (cmd == "min lvl on") then
		WhereToNow_Options["ShowMinInstanceLevel"] = 1;
		WhereToNow_Msg("Now showing the minimum level needed to enter an instance.");
	elseif (cmd == "min level off") or (cmd == "min lvl off") then
		WhereToNow_Options["ShowMinInstanceLevel"] = 0;
		WhereToNow_Msg("Now hiding the minimum level needed to enter an instance.");
	elseif (cmd == "sort name") then
		WhereToNow_Options["Sort"] = "Name";
		WhereToNow_Msg("Now sorting alphabetically by name.");
	elseif (cmd == "sort min") then
		WhereToNow_Options["Sort"] = "Min";
		WhereToNow_Msg("Now sorting by minimum level.");
	elseif (cmd == "sort max") then
		WhereToNow_Options["Sort"] = "Max";
		WhereToNow_Msg("Now sorting by maximum level.");
	elseif (cmd == "sort min level") or (cmd == "sort minlevel") or (cmd == "sort min lvl") or (cmd == "sort minlvl") then
		WhereToNow_Options["Sort"] = "MinLvl";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance.");
	elseif (cmd == "sort min level min") or (cmd == "sort minlevel min") or (cmd == "sort min lvl min") or (cmd == "sort minlvl min") then
		WhereToNow_Options["Sort"] = "MinLvlMin";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance, then by the minimum level.");
	elseif (cmd == "sort min level max") or (cmd == "sort minlevel max") or (cmd == "sort min lvl max") or (cmd == "sort minlvl max") then
		WhereToNow_Options["Sort"] = "MinLvlMax";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance, then by the maximum level.");
	elseif (cmd == "sort min level expansion") or (cmd == "sort min level expan") or (cmd == "sort min level xpan") or 
		(cmd == "sort minlevel expansion") or (cmd == "sort minlevel expan") or (cmd == "sort minlevel xpan") or 
		(cmd == "sort min lvl expansion") or (cmd == "sort min lvl expan") or (cmd == "sort min lvl xpan") or 
		(cmd == "sort minlvl expansion") or (cmd == "sort minlvl expan") or (cmd == "sort minlvl xpan") then
		WhereToNow_Options["Sort"] = "MinLvlExpan";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance, then by expansion");
	elseif (cmd == "sort min level expansion min") or (cmd == "sort min level expan min") or (cmd == "sort min level xpan min") or 
		(cmd == "sort minlevel expansion min") or (cmd == "sort minlevel expan min") or (cmd == "sort minlevel xpan min") or 
		(cmd == "sort min lvl expansion min") or (cmd == "sort min lvl expan min") or (cmd == "sort min lvl xpan min") or 
		(cmd == "sort minlvl expansion min") or (cmd == "sort minlvl expan min") or (cmd == "sort minlvl xpan min") then
		WhereToNow_Options["Sort"] = "MinLvlExpanMin";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance, then by expansion, then by minimum level.");
	elseif (cmd == "sort min level expansion max") or (cmd == "sort min level expan max") or (cmd == "sort min level xpan max") or 
		(cmd == "sort minlevel expansion max") or (cmd == "sort minlevel expan max") or (cmd == "sort minlevel xpan max") or 
		(cmd == "sort min lvl expansion max") or (cmd == "sort min lvl expan max") or (cmd == "sort min lvl xpan max") or 
		(cmd == "sort minlvl expansion max") or (cmd == "sort minlvl expan max") or (cmd == "sort minlvl xpan max") then
		WhereToNow_Options["Sort"] = "MinLvlExpanMax";
		WhereToNow_Msg("Now sorting by the minium level to enter the instance, then by expansion, then by maximum level.");
	elseif (cmd == "sort expansion") or (cmd == "sort expan") or (cmd == "sort xpan") then
		WhereToNow_Options["Sort"] = "Expansion";
		WhereToNow_Msg("Now sorting by expansion.");
	elseif (cmd == "sort expansion min") or (cmd == "sort expan min") or (cmd == "sort xpan min") then
		WhereToNow_Options["Sort"] = "ExpansionMin";
		WhereToNow_Msg("Now sorting by Expansion, then by minimum level.");
	elseif (cmd == "sort expansion max") or (cmd == "sort expan max") or (cmd == "sort xpan max") then
		WhereToNow_Options["Sort"] = "ExpansionMax";
		WhereToNow_Msg("Now sorting by Expansion, then by maximum level.");
	elseif (cmd == "sort expansion min level") or (cmd == "sort expan min level") or (cmd == "sort xpan min level") or 
		(cmd == "sort expansion minlevel") or (cmd == "sort expan minlevel") or (cmd == "sort xpan minlevel") or 
		(cmd == "sort expansion min lvl") or (cmd == "sort expan min lvl") or (cmd == "sort xpan min lvl") or 
		(cmd == "sort expansion minlvl") or (cmd == "sort expan minlvl") or (cmd == "sort xpan minlvl") then
		WhereToNow_Options["Sort"] = "ExpansionMinLvl";
		WhereToNow_Msg("Now sorting by Expansion, then by the minium level to enter the instance.");
	elseif (cmd == "sort expansion min level min") or (cmd == "sort expan min level min") or (cmd == "sort xpan min level min") or 
		(cmd == "sort expansion minlevel min") or (cmd == "sort expan minlevel min") or (cmd == "sort xpan minlevel min") or 
		(cmd == "sort expansion min lvl min") or (cmd == "sort expan min lvl min") or (cmd == "sort xpan min lvl min") or 
		(cmd == "sort expansion minlvl min") or (cmd == "sort expan minlvl min") or (cmd == "sort xpan minlvl min") then
		WhereToNow_Options["Sort"] = "ExpansionMinLvlMin";
		WhereToNow_Msg("Now sorting by Expansion, then by the minium level to enter the instance, then by minimum level.");
	elseif (cmd == "sort expansion min level max") or (cmd == "sort expan min level max") or (cmd == "sort xpan min level max") or 
		(cmd == "sort expansion minlevel max") or (cmd == "sort expan minlevel max") or (cmd == "sort xpan minlevel max") or 
		(cmd == "sort expansion min lvl max") or (cmd == "sort expan min lvl max") or (cmd == "sort xpan min lvl max") or 
		(cmd == "sort expansion minlvl max") or (cmd == "sort expan minlvl max") or (cmd == "sort xpan minlvl max") then
		WhereToNow_Options["Sort"] = "ExpansionMinLvlMax";
		WhereToNow_Msg("Now sorting by Expansion, then by the minium level to enter the instance, then by maximum level.");
	else
		WhereToNow_Parse(cmd);
	end
end

local OutputModes = {
	"whisper",
	"guild",
	"raid",
	"party",
	"say",
	"yell",
}

local diffcolor = {
	["-6"] = "|cffff2020",	-- Red
	["-5"] = "|cffff9900",	-- Orange
	["-4"] = "|cffff9900",
	["-3"] = "|cffff9900",
	["-2"] = "|cffffff00",	-- Yellow
	["-1"] = "|cffffff00",
	["0"] = "|cffffff00",
	["1"] = "|cffffff00",
	["2"] = "|cff20ff20",	-- Green
	["3"] = "|cff20ff20",
	["4"] = "|cff20ff20",
	["5"] = "|cff808080",	-- Gray
}

function WhereToNow_Parse(cmd)
	local channel, player, level;

	local commands = {};
	for v in string.gmatch(cmd,"[^ ]+") do
		tinsert(commands,v);
	end

	for k,v in pairs(commands) do
		for o=1,#OutputModes do
			if OutputModes[o] == v then
				channel = v;
			end
		end
		if tonumber(v) ~= nil then
			level = v;
		end
		if channel ~= nil and v ~= channel then
			player = v;
		end
	end

--	WhereToNow_Msg("Parse Test: Level="..tostring(level)..", Channel="..tostring(channel)..", Player="..tostring(player))

	if ((channel == "whisper") and (player == nil)) then
		WhereToNow_Msg(L["WTN_ERROR_WRONGCMDORDERWHISPER"],"Error");
		return;
	end

	WhereToNow_Main(tonumber(level), player, channel);
end

-- Torn out into it's own function to make things easier. Also, we don't have to double up our code.
-- Returns 2 arrays of the zones and instances found for the specified level, and 2 variables indicating how many zones & instances were found.
function WhereToNow_GetLists(Level)
	local zonearray, instancearray = {}, {};
	local zonefound, instancefound = 0, 0;

	sort(WhereToNowDatabase);
	for ZName, v in pairs(WhereToNowDatabase) do
		if ((WhereToNowDatabase[ZName]["min"] <= Level) and (WhereToNowDatabase[ZName]["max"] >= Level)) then
			local SortName;
			local thissort = WhereToNow_Options["Sort"];

			if thissort == "MinLvl" then
				thissort = "Name";
			elseif thissort == "MinLvlMin" then
				thissort = "Min";
			elseif thissort == "MinLvlMax" then
				thissort = "Max";
			elseif thissort == "MinLvlExpan" then
				thissort = "Expansion";
			elseif thissort == "ExpansionMinLvl" then
				thissort = "Expansion";
			elseif thissort == "ExpansionMinLvlMin" then
				thissort = "ExpansionMin";
			elseif thissort == "ExpansionMinLvlMax" then
				thissort = "ExpansionMax";
			elseif thissort == "MinLvlExpanMin" then
				thissort = "ExpansionMin";
			elseif thissort == "MinLvlExpanMax" then
				thissort = "ExpansionMax";
			end

			local thismin, thismax, thisexpan = WhereToNowDatabase[ZName]["min"], WhereToNowDatabase[ZName]["max"], WhereToNowDatabase[ZName]["Expan"];

			if thissort == "Min" then
				SortName = thismin..ZName;
			elseif thissort == "Max" then
				SortName = thismax..ZName;
			elseif thissort == "Expansion" then
				SortName = thisexpan..ZName;
			elseif thissort == "ExpansionMin" then
				SortName = thisexpan..thismin..ZName;
			elseif thissort == "ExpansionMax" then
				SortName = thisexpan..thismax..ZName;
			-- Sort by Name by Default!
			else
				SortName = ZName;
			end

			if (not zonearray[SortName]) then
				zonearray[SortName] = {
					["name"] = ZName,
					["min"] = thismin,
					["max"] = thismax,
				}
				zonefound = zonefound + 1;
			end

		end
		for Instance,v in pairs(WhereToNowDatabaseDungeon) do
			if (Zname == WhereToNowDatabaseDungeon[Instance]["Zone"]) then
				local SortName;
				local thissort = WhereToNow_Options["Sort"];
				local imin, imax, iexpan, ilimit = WhereToNowDatabaseDungeon[Instance]["min"], WhereToNowDatabaseDungeon[Instance]["max"], WhereToNowDatabaseDungeon[Instance]["Expan"], WhereToNowDatabaseDungeon[Instance]["limit"];
				local thismin = imin;

				if (WhereToNow_Options["ShowMinInstanceLevel"] == 1) then
					thismin = WhereToNowDatabaseDungeon[Instance]["limit"];
				end

				if ((thismin <= Level) and (WhereToNowDatabaseDungeon[Instance]["max"] >= Level)) then
					-- Sorting
					if thissort == "Min" then
						SortName = imin..Instance;
					elseif thissort == "Max" then
						SortName = imax..Instance;
					elseif thissort == "Expansion" then
						SortName = iexpan..Instance;
					elseif thissort == "ExpansionMin" then
						SortName = iexpan..imin..Instance;
					elseif thissort == "ExpansionMax" then
						SortName = iexpan..imax..Instance;
					elseif thissort == "MinLvl" then
						SortName = ilimit..Instance;
					elseif thissort == "MinLvlMin" then
						SortName = ilimit..imin..Instance;
					elseif thissort == "MinLvlMax" then
						SortName = ilimit..imax..Instance;
					elseif thissort == "MinLvlExpan" then
						SortName = ilimit..iexpan..Instance;
					elseif thissort == "MinLvlExpanMin" then
						SortName = ilimit..iexpan..imin..Instance;
					elseif thissort == "MinLvlExpanMax" then
						SortName = ilimit..iexpan..imax..Instance;
					elseif thissort == "ExpansionMinLvl" then
						SortName = iexpan..ilimit..Instance;
					elseif thissort == "ExpansionMinLvlMin" then
						SortName = iexpan..ilimit..imin..Instance;
					elseif thissort == "ExpansionMinLvlMax" then
						SortName = iexpan..ilimit..imax..Instance;
					else
						SortName = Instance;
					end

					-- Generate Data, based on SortName.
					if (not instancearray[SortName]) then
						instancearray[SortName] = {
							["name"] = Instance,
							["limit"] = ilimit,
							["min"] = imin,
							["max"] = imax,
						}
						instancefound = instancefound + 1;
					end
				end
			end
		end
	end

	return zonearray, instancearray, zonefound, instancefound;
end

function WhereToNow_StringSplit(Zones,Instances)
	local msg1, msg2, msg3, msg4, msg5, msg6 = "","","","","","";
	if strlen(Zones) > 255 then
		local zarray = {strsplit(",",Zones)};
		for x=1,#zarray do
			if (strlen(msg2)+strlen(strtrim(zarray[x]))+2) > 255 then
				if msg2 ~= "" then msg2 = msg2..", " end
				msg2 = msg2..tostring(strtrim(zarray[x]));
			else
				if msg1 ~= "" then msg1 = msg1..", " end
				msg1 = msg1..tostring(strtrim(zarray[x]));
			end
		end
	else
		msg1 = Zones;
	end
	if strlen(Instances) > 255 then
		local iarray = {strsplit(",",Instances)};
		local out1, out2, out3, out4 = "","","","";
		local lock1, lock2, lock3;

		for x=1,#iarray do
			local addlen = strlen(strtrim(iarray[x]))+2;

			if lock1 == nil and strlen(out1)+addlen < 255 then
				if out1 ~= "" then out1 = out1..", " end
				out1 = out1..tostring(strtrim(iarray[x]));
			else
				lock1 = 1;
				if lock2 == nil and strlen(out2)+addlen < 255 then
					if out2 ~= "" then out2 = out2..", " end
					out2 = out2..tostring(strtrim(iarray[x]));
				else
					lock2 = 1;
					if lock3 == nil and strlen(out3)+addlen < 255 then
						if out3 ~= "" then out3 = out3..", " end
						out3 = out3..tostring(strtrim(iarray[x]));
					else
						lock3 = 1;
						if out4 ~= "" then out4 = out4..", " end
						out4 = out4..tostring(strtrim(iarray[x]));
					end
				end
			end
		end
		if msg2 ~= "" then
			msg3, msg4, msg5, msg6 = out1, out2, out3, out4;
		else
			msg2, msg3, msg4, msg5 = out1, out2, out3, out4;
		end
	else

		msg2 = Instances;
	end

	return msg1, msg2, msg3, msg4, msg5, msg6;
end

function WhereToNow_Main(Level, Character, Channel)
	local output = "None";

	if (Level == nil) then
		Level = UnitLevel("player");
	end
	if (Channel ~= nil) and (Character ~= nil) then
		output = Channel;
	end

	local zonearray, instancearray, zonefound, instancefound = WhereToNow_GetLists(Level);

	local msg0 = L["WTN_MSG_WTNREPORT_START"]..Level..L["WTN_MSG_WTNREPORT_END "];

	local msg1, msg2, msg3, msg4, msg5, msg6, ZoneString, InstanceString;
	local ColorCode1, ColorCode2 = NORMAL_FONT_COLOR_CODE, "|r";
	if Channel ~= nil then
		ColorCode1 = "";
		ColorCode2 = "";
	end

	sort(zonearray);
	sort(instancearray);

	if zonefound > 0 then
		local zonetxt = "";
		for title,v in WhereToNow_pairsByKeys(zonearray) do
			if zonetxt ~= "" then zonetxt = zonetxt..", " end
			zonetxt = zonetxt..zonearray[title]["name"].." ("..zonearray[title]["min"].."-"..zonearray[title]["max"]..")";
		end
		ZoneString = ColorCode1..L["WTN_REC_ZONES"]..ColorCode2..zonetxt..".";
	end
	if instancefound > 0 then
		local instancetxt = "";
		for title,v in WhereToNow_pairsByKeys(instancearray) do
			if (instancetxt ~= "") then instancetxt = instancetxt..", "; end
			instancetxt = instancetxt..instancearray[title]["name"].." ("..instancearray[title]["limit"].."/"..instancearray[title]["min"].."-"..instancearray[title]["max"]..")";
		end
		InstanceString = ColorCode1..L["WTN_REC_INSTANCES"]..ColorCode2..instancetxt..".";
	end
	if zonefound <= 0 and instancefound <=0 then
		msg1 = ColorCode1..L["WTN_REC_NONE"]..ColorCode2;
	else
		msg1, msg2, msg3, msg4, msg5, msg6 = WhereToNow_StringSplit(ZoneString, InstanceString);
	end

--	WhereToNow_Msg("Output Test: Level="..tostring(Level)..", Channel="..tostring(Channel)..", Player="..tostring(Character))

	if (Channel == "party") then
		SendChatMessage(msg0,"PARTY");
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"PARTY");
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"PARTY");
		end
		if msg3 ~= "" or nil then
			SendChatMessage(msg3,"PARTY");
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"PARTY");
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"PARTY");
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"PARTY");
		end
	elseif (Channel == "guild") then
		SendChatMessage(msg0,"GUILD");
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"GUILD");
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"GUILD");
		end
		if msg3 ~="" or nil then
			SendChatMessage(msg3,"GUILD");
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"GUILD");
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"GUILD");
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"GUILD");
		end
	elseif (Channel == "say") then
		SendChatMessage(msg0,"SAY");
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"SAY");
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"SAY");
		end
		if msg3 ~= "" or nil then
			SendChatMessage(msg3,"SAY");
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"SAY");
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"SAY");
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"SAY");
		end
	elseif (Channel == "yell") then
		SendChatMessage(msg0,"YELL");
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"YELL");
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"YELL");
		end
		if msg3 ~= "" or nil then
			SendChatMessage(msg3,"YELL");
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"YELL");
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"YELL");
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"YELL");
		end
	elseif (Channel == "raid") then
		SendChatMessage(msg0,"RAID");
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"RAID");
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"RAID");
		end
		if msg3 ~= "" or nil then
			SendChatMessage(msg3,"RAID");
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"RAID");
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"RAID");
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"RAID");
		end
	elseif (Channel == "whisper") then
		SendChatMessage(msg0,"WHISPER",nil,Character);
		if msg1 ~= "" or nil then
			SendChatMessage(msg1,"WHISPER",nil,Character);
		end
		if msg2 ~= "" or nil then
			SendChatMessage(msg2,"WHISPER",nil,Character);
		end
		if msg3 ~= "" or nil then
			SendChatMessage(msg3,"WHISPER",nil,Character);
		end
		if msg4 ~= "" or nil then
			SendChatMessage(msg4,"WHISPER",nil,Character);
		end
		if msg5 ~= "" or nil then
			SendChatMessage(msg5,"WHISPER",nil,Character);
		end
		if msg6 ~= "" or nil then
			SendChatMessage(msg6,"WHISPER",nil,Character);
		end
	else
		if msg1 ~= "" or nil then
			WhereToNow_Msg(msg1);
		end
		if msg2 ~= "" or nil then
			WhereToNow_Msg(msg2);
		end
		if msg3 ~= "" or nil then
			WhereToNow_Msg(msg3);
		end
		if msg4 ~= "" or nil then
			WhereToNow_Msg(msg4);
		end
		if msg5 ~= "" or nil then
			WhereToNow_Msg(msg5);
		end
		if msg6 ~= "" or nil then
			WhereToNow_Msg(msg5);
		end
	end
end

function WhereToNow_Tooltip()
	local Level=UnitLevel("player");
	local output = "";
	local zonefound, instancefound = 0, 0;
	local instancelist = {};

	local zonearray, instancearray, zonefound, instancefound = WhereToNow_GetLists(Level);

	if (instances == "") then
		instances = L["WTN_NONE"];
	end
	if (zones == "") then
		zones = L["WTN_NONE"];
	end

	sort(zonearray);
	sort(instancearray);

	if zonefound > 0 then
		local zonetxt = "";
		for title,v in WhereToNow_pairsByKeys(zonearray) do
			if zonetxt ~= "" then zonetxt = zonetxt.."\n" end
			local zonecolor = WhereToNow_GetDiffColor(zonearray[title]["min"],zonearray[title]["max"],Level)
			local minmax = zonearray[title]["min"];

			if (zonearray[title]["min"] ~= zonearray[title]["max"]) then
				minmax = minmax.."-"..zonearray[title]["max"];
			end
			zonetxt = zonetxt..zonecolor..zonearray[title]["name"].." ("..minmax..")|r";
		end
		output = output.."\n"..NORMAL_FONT_COLOR_CODE..L["WTN_REC_ZONES_FOR_LEVEL"]..Level..":\n|r"..zonetxt;
	end
	if instancefound > 0 then
		local instancetxt = "";
		for title,v in WhereToNow_pairsByKeys(instancearray) do
			if (instancetxt ~= "") then instancetxt = instancetxt.."\n"; end
			local minmax = instancearray[title]["min"];

			local minlvltxt = "";
			if (WhereToNow_Options["ShowMinInstanceLevel"] == 1) then
				minlvltxt = ", Min: "..instancearray[title]["limit"];
			end
			if (instancearray[title]["min"] ~= instancearray[title]["max"]) then
				minmax = minmax.."-"..instancearray[title]["max"];
			end
			local instancecolor = WhereToNow_GetDiffColor(instancearray[title]["min"],instancearray[title]["max"],Level)
			instancetxt = instancetxt..instancecolor..instancearray[title]["name"].." ("..minmax..minlvltxt..")|r";
		end
		output = output.."\n\n"..NORMAL_FONT_COLOR_CODE..L["WTN_REC_INSTANCES_FOR_LEVEL"]..Level..":\n|r"..instancetxt;
	end

	if zonefound <= 0 and instancefound <= 0 then
		output = L["WTN_REC_NONE"];
	end

	return output;
end

-- Toolset
-- Functions that we can use as tools.

function WhereToNow_GetDiffColor(min,max,level)
	if min == nil then WhereToNow_Msg("No Min, Killing."); return ""; end
	if max == nil then WhereToNow_Msg("No Max, Killing."); return ""; end
	if level == nil then WhereToNow_Msg("No Level, Killing."); return ""; end

	local avglvl = (min + max) / 2;
	local odiff = level-avglvl;
	local diff = odiff;
	if odiff < 0 then
		diff = ceil(diff);
	else
		diff = floor(diff);
	end

	local notdiff = diff;

	if not diffcolor[tostring(diff)] then
		if tostring(diff) < "0" then
			while not diffcolor[tostring(notdiff)] do
				notdiff = notdiff + 1;
			end
		else
			while not diffcolor[tostring(notdiff)] do
				notdiff = notdiff - 1;
			end
		end

	end
	local colorout = diffcolor[tostring(notdiff)];

	-- Manual settings
	if odiff > 1 or odiff < -1 then
		if level == min then
			colorout = diffcolor["-4"];
		elseif level == max then
			colorout = diffcolor["4"];
		end
	end

	if WhereToNow_Options["TooltipColor"] == 0 then
		colorout = "";
	end

	return colorout;
end

function WhereToNow_MapList()
	local zonelist = {}
	local continentNames = { GetMapContinents() };
	for ckey, cval in pairs(continentNames) do
		local ZoneNames = { GetMapZones(ckey) };
		for zkey, zval in pairs(ZoneNames) do
			zonelist[zval] = 1;
		end
	end

	return zonelist;
end

-- Let's us sort tables!
-- Copy/Pasted from LUA Website
function WhereToNow_pairsByKeys (t, f)
	local a = {}
		for n in pairs(t) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0      -- iterator variable
		local iter = function ()   -- iterator function
			i = i + 1
			if a[i] == nil then return nil
			else return a[i], t[a[i]]
			end
		end
	return iter
end