DugisGuideViewer:RegisterGuide("Stratholme (55-58 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Stratholme_A' />
 </body></html>
]]
end)