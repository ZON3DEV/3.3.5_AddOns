DugisGuideViewer:RegisterGuide("Sunken Temple (48-52 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Sunken_Temple_A' />
 </body></html>
]]
end)