DugisGuideViewer:RegisterGuide("Sethekk Halls (67-68 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Sethekk_Halls_A' />
 </body></html>
]]
end)