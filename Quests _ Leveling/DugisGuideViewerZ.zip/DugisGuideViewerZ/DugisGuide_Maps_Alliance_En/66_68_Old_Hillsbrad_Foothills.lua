DugisGuideViewer:RegisterGuide("Old Hillsbrad Foothills (66-68 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Old_Hillsbrad_Foothills_A' />
 </body></html>
]]
end)