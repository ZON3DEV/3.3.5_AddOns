DugisGuideViewer:RegisterGuide("Scarlet Monestary (27-39 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Scarlet_Monastery_A' />
 </body></html>
]]
end)