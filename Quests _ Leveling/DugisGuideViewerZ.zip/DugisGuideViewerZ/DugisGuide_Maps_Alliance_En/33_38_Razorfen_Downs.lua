
DugisGuideViewer:RegisterGuide("Razorfen Downs (33-38 Map)", "Scarlet Monestary Armory / Cathedral (34-40) ", "Alliance", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Razorfen_Downs_A' />
 </body></html>
]]
end)