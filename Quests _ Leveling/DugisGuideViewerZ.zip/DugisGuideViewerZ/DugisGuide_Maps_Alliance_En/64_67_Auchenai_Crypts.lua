DugisGuideViewer:RegisterGuide("Auchenai Crypts (64-67 Map)", nil, "Alliance", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Alliance_En\Artwork\Auchenai_Crypts_A' />
 </body></html>
]]
end)