DugisGuideViewer:RegisterGuide("Sethekk Halls (67-68 Map)", nil, "Horde", "M", function()
    return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Sethekk_Halls_H' />
 </body></html>
]]
end)