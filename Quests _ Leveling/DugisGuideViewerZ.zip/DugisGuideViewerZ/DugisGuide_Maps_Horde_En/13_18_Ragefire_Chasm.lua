DugisGuideViewer:RegisterGuide("Ragefire Chasm (13-18 Map)", nil, "Horde", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Ragefire_Chasm_H' />
 </body></html>
]]
end)
