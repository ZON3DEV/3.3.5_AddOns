DugisGuideViewer:RegisterGuide("Shadowfang Keep (18-22 Map)", nil, "Horde", "M", function()
return [[
 <html><body>
<img align="center" src='Interface\Addons\DugisGuideViewerZ\DugisGuide_Maps_Horde_En\Artwork\Shadowfang_Keep_H' />
 </body></html>
]]
end)