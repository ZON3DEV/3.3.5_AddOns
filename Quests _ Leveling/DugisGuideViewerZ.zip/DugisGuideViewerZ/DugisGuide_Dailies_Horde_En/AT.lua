DugisGuideViewer:RegisterGuide("|cfff0c502___________ Argent Tournament ______________|r ", nil, "Horde", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)
