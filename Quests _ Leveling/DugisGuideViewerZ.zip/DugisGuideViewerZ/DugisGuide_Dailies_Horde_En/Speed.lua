DugisGuideViewer:RegisterGuide("|cfff0c502____________ Speed Gold Runs _______________|r", "Speed Gold Run (80 Dailies)", "Horde", "D", function()
return [[

N Tick to continue to Speed Gold Run (80 Dailies) |N|Tick to continue to Speed Gold Run (80 Dailies)|
N Guide Complete

]]
end)
