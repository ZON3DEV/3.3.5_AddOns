DugisGuideViewer:RegisterGuide("|cfff0c502_______________ Profession _________________|r", "Jewelcrafting (65+ Dailies)", "Horde", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)
