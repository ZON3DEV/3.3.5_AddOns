DugisGuideViewer:RegisterGuide("Grizzly Hills (74+ Pre-Quests)", nil, "Horde", "D", function()
return [[

F Grizzly Hills |N|Fly to Grizzly Hills (16.2, 47.7)| |QID|11984|

A Filling the Cages |N|Samir (16.2, 47.7)| |QID|11984|
C Filling the Cages |QID|11984| |U|35736| |N|Talk to Budd (16.4, 48.1), then head to the Ruins of Drak'Zin (13.7, 58.6) and use your pet bar to send him after a troll, then use the [Bounty Hunter's Cage] once dazed|
T Filling the Cages |N|Samir (16.2, 47.7)| |QID|11984| 
A Truce? |N|Drakuru (16.5, 47.8)| |QID|11989|
C Truce? |QID|11989| |N|Loot the [Dull Carving Knife] next to the cage, use it, then talk to Drakuru (16.5, 47.8) to shake his hand| |U|38083|
T Truce? |N|Drakuru (16.5, 47.8)| |QID|11989|
A Vial of Visions |N|Drakuru (16.5, 47.8)| |QID|11990|
B Buy [Imbued Vial] |N|Buy [Imbued Vial] from (16.0, 47.8)| |QID|11990| |L|18256|
C Vial of Visions |QID|11990| |N|Waterweed is in the lake (15.2, 40.6). Haze leaf is found around (13.1, 41.3) and (13.0, 38.9)|
T Vial of Visions |N|Drakuru (16.5, 47.8)| |QID|11990|
A Scourgekabob |N|Prigmon (15.8, 46.8)| |QID|12484| 
C Scourgekabob |QID|12484| |N|Loot a mummy then head down to the bonfire (16.7, 48.2) and burn it| |U|38149|
T Scourgekabob |N|Mack Fearsen (16.7, 48.3)| |QID|12484|
A Seared Scourge |N|Mack Fearsen (16.7, 48.3)| |QID|12029|
C Seared Scourge |QID|12029| |U|35908| |N|Go to Drak'tharon Keep (17.8, 27.3). Go up the stairs and jump onto the edges of the staircase. Lob [Mack's Dark Grog] at the trolls below|
T Seared Scourge |N|Mack Fearsen (16.7, 48.3)| |QID|12029|

N Guide Complete |N|Tick to continue to the next guide| 
]]
end)
