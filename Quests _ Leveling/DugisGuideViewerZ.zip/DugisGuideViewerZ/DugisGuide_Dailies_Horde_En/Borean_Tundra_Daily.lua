DugisGuideViewer:RegisterGuide("Borean Tundra (72-80 Dailies)", nil, "Horde", "D", function()
return [[

F Borean Tundra |N|Fly to Borean Tundra (64, 45.8)|
A Preparing for the Worst |N|Utaik (64, 45.8)| |QID|11945| |D|
C Preparing for the Worst |N|Collect 8x [Kaskala Supplies] around (73.4, 51.9)| |QID|11945|  |D|
T Preparing for the Worst |N|Utaik (64, 45.8)| |QID|11945|  |D|

F Transitus Shield |N|Fly to Transitus Shield in Borean Tundra|
A Drake Hunt |N|Raelorasz (33.3, 34.5)| |QID|11940| |D|
C Drake Hunt |N|Go to the valley at (27, 30) and look for a Nexus Drake up above then use [Raelorasz's Spear]| |U|35506| |QID|11940| |D|
T Drake Hunt |N|Raelorasz (33.3, 34.5)| |QID|11940| |D|

A Aces High! |N|Corastrasza (29.5, 24.8)| |QID|13414| |D|
C Aces High! |N|Kill the Felsworn Elite using the Drake by using this ability combo 1, 1, 1, 1, 1, 5, 3  NOTE: When you press 3 you need to self-cast or target yourself| |QID|13414| |D|
T Aces High! |N|Corastrasza (29.5, 24.8)| |QID|13414| |D|

N Guide Complete |N|Tick to continue to the next guide| 
]]
end)
