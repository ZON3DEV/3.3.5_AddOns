DugisGuideViewer:RegisterGuide("|cfff0c502___________ Pre-requisite Quests ____________|r", "The Storm Peaks (76-80 Required For Dailies)", "Horde", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)