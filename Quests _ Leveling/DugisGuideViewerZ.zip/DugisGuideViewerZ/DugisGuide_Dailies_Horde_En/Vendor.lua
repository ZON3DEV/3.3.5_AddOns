DugisGuideViewer:RegisterGuide("|cfff0c502___________ Vendor Supply Run _____________|r", nil, "Horde", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)