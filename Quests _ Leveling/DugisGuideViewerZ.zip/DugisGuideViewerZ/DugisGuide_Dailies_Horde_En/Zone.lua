DugisGuideViewer:RegisterGuide("|cfff0c502_________________ Zone _____________________|r", "Borean Tundra (72-80 Dailies)", "Horde", "D", function()
return [[

N Do not tick |N|Do not tick, this is not a guide|
N Do not tick |N|Do not tick, this is not a guide|

]]
end)
