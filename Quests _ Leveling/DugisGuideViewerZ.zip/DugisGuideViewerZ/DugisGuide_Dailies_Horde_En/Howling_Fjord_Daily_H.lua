DugisGuideViewer:RegisterGuide("Howling Fjord (71+ Dailies)", nil, "Horde", "D", function()
return [[

F Kamagua |N|Fly to Kamagua in Howling Fjord|

A The Way to His Heart... |N|Anuniaq (24.6, 58.8)| |QID|11472|  |D|
N Collect a Fish |N|Use the [Anuniaq's Net] on a school of fish around (33, 71.8)| |U|40946| |L|34127|
C The Way to His Heart... |N|Damage a Bull (31.9, 74.1) slightly (be unarmed if you melee attack hits too hard) and make them chase you to the Cow , once you reach the cow use [Tasty Reef Fish] on the Bull| |U|34127| |QID|11472|  |D|
T The Way to His Heart... |N|Anuniaq (24.6, 58.8)| |QID|11472|  |D|

N Guide Complete |N|Tick to continue to the next guide| 
]]
end)
