DugisGuideViewer:RegisterGuide("Dragonblight (72-74+ Dailies)", nil, "Horde", "D", function()
return [[

F Moa'Ki Harbor |N|Fly to Moa'Ki Harbor in Dragonblight|
A Planning for the Future |N|Trapper Mau'i (48.3, 74.3)| |QID|11960|  |D|
C Planning for the Future |N|Go to the camp site around (45.7, 61.6) and collect 12x [Snowfall Glade Pup]| |QID|11960|  |D|
T Planning for the Future |N|Trapper Mau'i (48.3, 74.3)| |QID|11960|  |D|

A Defending Wyrmrest Temple |N|Lord Afrasastrasz (59.2, 54.3)| |QID|12372| |D|
C Defending Wyrmrest Temple |N|Kill 3 Azure Dragons, 5 Azure Drakes and Destabilize the Azure Dragonshrine (55.5, 66), the little dragons only need 1 Fireball and 1 Immolate to kill, while the big dragons will need 4 - 5 Fireball and an Immolate to die| |QID|12372| |D|
T Defending Wyrmrest Temple |N|Lord Afrasastrasz (59.2, 54.3)| |QID|12372| |D|

N Guide Complete  |N|Tick to continue to the next guide| 
]]
end)
