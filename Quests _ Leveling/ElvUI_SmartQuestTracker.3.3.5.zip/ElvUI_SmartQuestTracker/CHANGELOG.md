v2.0.12:

-   Improved handling of world quests
-   (Internal) More code share between standalone version
-   (Internal) Adds debug output
-   (Internal) Bump version to standalone version

v2.0.10:

-   Interface version bump to 7.3
-   (Internal) Change build process of addon.

v2.0.10:

-   Interface version bump to 7.3
-   (Internal) Change build process of addon.

v2.0.9:

-   Fixes a bug in detection of quest completion status
-   Improved tracking of completed dungeon quests

v2.0.8:

-   Improved tracking of dungeon quests

v2.0.7:

-   Fixes yet another strange issue. Can someone please retrieve me from those broken add-on events? ｡ﾟ( ﾟஇ‸இﾟ)ﾟ｡

v2.0.6:

-   Fixes a race-condition, which could lead to unexpected nil values. This should also fix many problems related to unexpectedly auto-tracked quests.
-   No April fools, I promise!

v2.0.5:

-   Interface version bump to 7.2
-   Adds workaround for resetting the world map during travelling

v2.0.4:

-   Interface version bump to 7.1

v2.0.3:

-   Fixes broken archive

v2.0.2:

-   Sorting of quests should now be done more frequently
-   Fixes a bug, which prevented the untracking of quests in certain circumstances

v2.0.1:

-   Fixes reported bug "table index is nil"

v2.0:

-   updated interface version to legion
-   Actually runs with beta ElvUI
