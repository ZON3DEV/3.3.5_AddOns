Decursive for World of Warcraft
===============================

Download and documentation:

http://www.2072productions.com/to/decursive.php

http://www.wowace.com/addons/decursive/

Documentation is also available under the doc/ directory:

    ./doc/Description.txt

    ./doc/user-actions.txt

    ./doc/commands.txt

    ./doc/macro.txt

    ./doc/MUFs.txt

    ./doc/faq.txt

