EventWatchInvasion = LibStub("AceAddon-3.0"):NewAddon("EventWatchInvasion", "AceConsole-3.0", "AceEvent-3.0", "AceComm-3.0", "AceTimer-3.0", "AceSerializer-3.0", "AceHook-3.0")
