--[[-------------------------------------------------------------------------
  LightHeaded -  Copyright 2007 by Jim Whitehead

  This is a very simple addon which compiles quest information and comments
  from http://www.wowhead.com and displays them in-game.  This addon was 
  inspired by Wowhead_Quests by sid367, and I thank him for the idea

  IMPORTANT: Addon authors that wish to use this API and data should
  include the wowhead logo in the frame that displays this information.
  They are kind enough to let me continue parsing their database, and we
  owe them at least that much.  Thank you.
---------------------------------------------------------------------------]]

This is an addon for World of Warcraft.  Please place the following directories into your 'Addons' directory in order to install this addon:

LightHeaded
LightHeaded_Data_A
LightHeaded_Data_B
LightHeaded_Data_C
LightHeaded_Data_D
LightHeaded_Data_E
LightHeaded_Data_NPC
LightHeaded_Data_QIDNames

For detailed installation information please visit http://www.wowinterface.com/forums/faq.php?faq=new_faq_item#faq_install.

The author supports and distributes this addon on http://www.wowinterface.com and requests that you refrain from posting this software in public locations.  This prevents confusion and difficulty when trying to provide support.
