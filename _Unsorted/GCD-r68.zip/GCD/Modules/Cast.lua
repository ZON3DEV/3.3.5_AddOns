local addon = LibStub("AceAddon-3.0"):GetAddon("GCD")
local module = addon:NewModule("cast")
local media = LibStub("LibSharedMedia-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("GCD")
local dbVersion = 1

local GetTime = GetTime
local castStartTime, castEndTime, castDuration, castInterrupted, castLatency, castSent, isCasting
local castFrame
local options
local ringMod

local defaults = {
	profile = {
		barColor = {r=1, g=1, b=1, a=0.8},
		backgroundColor = {r=0.4, g=0.4, b=0.4, a=0.8},
		sparkColor = {r=1, g=1, b=1, a=1},
		latencyColor = {r=1, g=0, b=0, a=1},
		radius = 22,
		sparkOnly = false,
		spellText = {
			enabled = false,
			font = "Calibri",
			fontSize = 12
		},
		hideCastBar = false
	}
}

local tileLookup = {}
for r=1,16 do
	for c=1,16 do
		local row = {
			l = ((c - 1) * 128) / 2048,
			b = (2048 - (r - 1) * 128) / 2048,
			r = (c * 128) / 2048,
			t = (2048 - r * 128) / 2048
		}
		tinsert(tileLookup, row)
	end
end

function module:FixDatabase()
	if self.db.profile.version then
		-- nothing to do yet
	end
	self.db.profile.version = dbVersion
end

function module:OnInitialize()
	self.db = addon.db:RegisterNamespace("Cast", defaults)
	self:FixDatabase()
	ringMod = addon:GetModule("ring", true)
end

function module:GetOptions()
	options = {
		name = L["Casttime"],
		type = "group",
		args = {
			sparkOnly = {
				name = L["Show spark only"],
				type = "toggle",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.sparkOnly end,
				set = function(info, val)
							self.db.profile.sparkOnly = val
							self:ApplyOptions()
						end,
				order = 1
			},
			radius = {
				name = L["Radius"],
				type = "range",
				min = 10,
				max = 64,
				step = 1,
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.radius end,
				set = function(info, val)
							self.db.profile.radius = val
							self:ApplyOptions()
						end,
				order = 2
			},
			colors = {
				name = L["Colors"],
				type = "header",
				order = 20
			},
			barColor = {
				name = L["Bar"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.barColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 21
			},
			bgColor = {
				name = L["Background"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.backgroundColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 22
			},
			sparkColor = {
				name = L["Spark"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.sparkColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 23
			},
			latencyColor = {
				name = L["Latency color"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.latencyColor.r, self.db.profile.latencyColor.g, self.db.profile.latencyColor.b, self.db.profile.latencyColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.latencyColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 24
			},
			spellText = {
				name = L["Spell Text"],
				type = "header",
				order = 30
			},
			spellTextEnabled = {
				name = L["Enabled"],
				type = "toggle",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.spellText.enabled end,
				set = function(info,val)
						self.db.profile.spellText.enabled = val
						self:ApplyOptions()
					end,
				order = 31
			},
			font = {
				name = L["Font"],
				type = "select",
				disabled = function() return (not addon.db.profile.modules.cast or not self.db.profile.spellText.enabled) end,
				dialogControl = 'LSM30_Font',
				get = function() return self.db.profile.spellText.font end,
				set = function(_, value)
							self.db.profile.spellText.font = value
							self:ApplyOptions()
						end,
				values = media:HashTable("font"),
				order = 32
			},
			fontSize = {
				name = L["Font Size"],
				type = "range",
				disabled = function() return (not addon.db.profile.modules.cast or not self.db.profile.spellText.enabled) end,
				min = 1,
				max = 30,
				step = 1,
				get = function() return self.db.profile.spellText.fontSize end,
				set = function(_, value)
							self.db.profile.spellText.fontSize = value
							self:ApplyOptions()
						end,
				order = 33
			},
			misc = {
				name = L["Miscellaneous"],
				type = "header",
				order = 40
			},
			defaults = {
				name = L["Restore defaults"],
				type = "execute",
				disabled = function() return not addon.db.profile.modules.cast end,
				func = function()
							self.db:ResetProfile()
							self:ApplyOptions()
						end,
				order = 41
			},
			hideCastBar = {
				name = L["Hide default castbar"],
				type = "toggle",
				disabled = function() return not addon.db.profile.modules.cast end,
				get = function(info) return self.db.profile.hideCastBar end,
				set = function(info,val)
						self.db.profile.hideCastBar = val
						if val then
							CastingBarFrame:UnregisterAllEvents()
							CastingBarFrame:Hide()
						else
							CastingBarFrame:UnregisterAllEvents()
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_START")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_STOP")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_FAILED")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_DELAYED")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
							CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
						end
					end,
				order = 42
			}
		}
	}
	return options
end

function module:OnEnable()
	self:RegisterEvent("UNIT_SPELLCAST_SENT")
	self:RegisterEvent("UNIT_SPELLCAST_START")
	self:RegisterEvent("UNIT_SPELLCAST_STOP")
	self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
	self:RegisterEvent("UNIT_SPELLCAST_FAILED")
	self:RegisterEvent("UNIT_SPELLCAST_DELAYED")
	self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
	self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
	self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
	self:ApplyOptions()
end

function module:OnDisable()
	self:UnregisterAllEvents()
	self:Hide()
end

local function round(val)
	if val < 0.5 then
		return floor(val)
	else
		return ceil(val)
	end
end

function module:Show()
	addon:Show("cast")
	if ringMod and ringMod:IsEnabled() then ringMod:Show("cast") end
	if self.db.profile.spellText.enabled then
		castFrame.spellText:Show()
	else
		castFrame.spellText:Hide()
	end
	
	castFrame:Show()
	
	local angle = castLatency * 360
	local tileNum, tile
	if not module.db.profile.sparkOnly then
		tileNum = round(angle / 1.40625)
		
		if tileNum == 0 then
			tileNum = 1
		elseif tileNum > 256 then
			tileNum = 256
		end
		
		tile = tileLookup[tileNum]
		castFrame.latencyTexture:SetTexCoord(tile.r, tile.t, tile.r, tile.b, tile.l, tile.t, tile.l, tile.b)
	end
end

function module:Hide()
	castFrame:Hide()
	if ringMod and ringMod:IsEnabled() then ringMod:Hide("cast") end
	addon:Hide("cast")
end

local function OnUpdate(self, elapsed)
	local castPerc = (1000 * GetTime() - castStartTime) / castDuration
	if castPerc < 1 then
		local angle = castPerc * 360
		local tileNum, tile
		if not module.db.profile.sparkOnly then
			tileNum = round(angle / 1.40625)
			if tileNum <= 0 then
				tileNum = 1
			elseif tileNum > 256 then
				tileNum = 256
			end
			
			tile = tileLookup[tileNum]
			castFrame.barTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)
		end
		angle = 360 -(-90 + angle)
		
		local x = cos(angle) * module.db.profile.radius * 0.95
		local y = sin(angle) * module.db.profile.radius * 0.95
		local spark = castFrame.sparkTexture
		spark:SetRotation(rad(angle+90))
		spark:ClearAllPoints()
		spark:SetPoint("CENTER", castFrame.barTexture, "CENTER", x, y)
		
		if module.db.profile.sparkOnly and castPerc > 1-castLatency then
			spark:SetVertexColor(module.db.profile.latencyColor.r, module.db.profile.latencyColor.g, module.db.profile.latencyColor.b, module.db.profile.latencyColor.a)
		else
			spark:SetVertexColor(module.db.profile.sparkColor.r, module.db.profile.sparkColor.g, module.db.profile.sparkColor.b, module.db.profile.sparkColor.a)
		end
	else
		module:Hide()
	end
end

function module:UNIT_SPELLCAST_SENT(_, unit)
	if unit ~= 'player' then return end
	castSent = GetTime() * 1000
end

function module:UNIT_SPELLCAST_START(_, unit, spell)
	if unit ~= 'player' then return end
	_, _, _, icon, castStartTime, castEndTime = UnitCastingInfo(unit)
	local sendLag = (castSent and castSent > 0) and GetTime() * 1000 - castSent or 0
	castDuration = castEndTime - castStartTime
	sendLag = sendLag > castDuration and castDuration or sendLag
	castLatency = sendLag / castDuration
	if castFrame.spellText then
		castFrame.spellText:SetText(spell)
	end
	self:Show()
end

function module:UNIT_SPELLCAST_STOP(_, unit)
	if unit ~= 'player' then return end
	self:Hide()
end

function module:UNIT_SPELLCAST_FAILED(event, unit)
	if unit ~= 'player' then return end
	self:Hide()
end

function module:UNIT_SPELLCAST_INTERRUPTED(event, unit)
	if unit ~= 'player' then return end
	self:Hide()
end

function module:UNIT_SPELLCAST_DELAYED(event, unit)
	if unit ~= 'player' then return end
	_, _, _, _, castStartTime, castEndTime = UnitCastingInfo(unit)
	castDuration = castEndTime - castStartTime
end

function module:UNIT_SPELLCAST_CHANNEL_START(event,unit)
	if unit ~= 'player' then return end
	_, _, _, _, castStartTime, castEndTime = UnitChannelInfo(unit)
	local sendLag = (castSent and castSent > 0) and GetTime() * 1000 - castSent or 0
	castDuration = castEndTime - castStartTime
	sendLag = sendLag > castDuration and castDuration or sendLag
	castLatency = sendLag / castDuration
	castFrame.spellText:SetText(spell)
	self:Show()
end

function module:UNIT_SPELLCAST_CHANNEL_STOP(event,unit)
	if unit ~= 'player' then return end
	self:Hide()
end

function module:UNIT_SPELLCAST_CHANNEL_UPDATE(event,unit)
	if unit ~= 'player' then return end
	_, _, _, _, castStartTime, castEndTime = UnitChannelInfo(unit)
	castDuration = castEndTime - castStartTime
end

function module:ApplyOptions()
	local anchor = addon.anchor
	if self:IsEnabled() then
		if not castFrame then
			castFrame = CreateFrame("Frame")
			castFrame:SetParent(anchor)
			castFrame:SetAllPoints()
			
			castFrame.backgroundTexture = castFrame:CreateTexture(nil, 'BACKGROUND')
			castFrame.backgroundTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			castFrame.backgroundTexture:SetPoint("CENTER",castFrame,"CENTER")
			local tile = tileLookup[256]
			castFrame.backgroundTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)

			castFrame.barTexture = castFrame:CreateTexture(nil, 'ARTWORK')
			castFrame.barTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			castFrame.barTexture:SetPoint("CENTER",castFrame,"CENTER")
			
			castFrame.latencyTexture = castFrame:CreateTexture(nil, 'ARTWORK')
			castFrame.latencyTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			castFrame.latencyTexture:SetPoint("CENTER",castFrame,"CENTER")
			
			castFrame.sparkTexture = castFrame:CreateTexture(nil, 'OVERLAY')
			castFrame.sparkTexture:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
			castFrame.sparkTexture:SetBlendMode("ADD")
		end
		
		self:Hide()
		castFrame:SetScript('OnUpdate', OnUpdate)

		if not self.db.profile.sparkOnly then
			castFrame.backgroundTexture:SetVertexColor(self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a)
			castFrame.backgroundTexture:SetWidth(2*self.db.profile.radius)
			castFrame.backgroundTexture:SetHeight(2*self.db.profile.radius)
			castFrame.backgroundTexture:Show()

			castFrame.barTexture:SetVertexColor(self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a)
			castFrame.barTexture:SetWidth(2*self.db.profile.radius)
			castFrame.barTexture:SetHeight(2*self.db.profile.radius)
			castFrame.barTexture:Show()
			
			castFrame.latencyTexture:SetVertexColor(self.db.profile.latencyColor.r, self.db.profile.latencyColor.g, self.db.profile.latencyColor.b, self.db.profile.latencyColor.a)
			castFrame.latencyTexture:SetWidth(2*self.db.profile.radius)
			castFrame.latencyTexture:SetHeight(2*self.db.profile.radius)
			castFrame.latencyTexture:Show()
		else
			castFrame.backgroundTexture:Hide()
			castFrame.barTexture:Hide()
			castFrame.latencyTexture:Hide()
		end
		
		castFrame.sparkTexture:SetVertexColor(self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a)
		castFrame.sparkTexture:SetWidth(self.db.profile.radius)
		castFrame.sparkTexture:SetHeight(self.db.profile.radius)
		castFrame.sparkTexture:Show()
		
		if self.db.profile.spellText then
			local spellText = castFrame.spellText or castFrame:CreateFontString(nil, "OVERLAY")
			spellText:ClearAllPoints()
			spellText:SetPoint("BOTTOM", castFrame, "CENTER", 0, self.db.profile.radius + 5)
			spellText:SetFont(media:Fetch("font", self.db.profile.spellText.font), self.db.profile.spellText.fontSize)
			spellText:Show()
			castFrame.spellText = spellText
		elseif castFrame.spellText then
			castFrame.spellText:ClearAllPoints()
			castFrame.spellText:Hide()
		end
		
		if self.db.profile.hideCastBar then
			CastingBarFrame:UnregisterAllEvents()
			CastingBarFrame:Hide()
		else
			CastingBarFrame:UnregisterAllEvents()
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_START")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_STOP")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_FAILED")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_DELAYED")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
			CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
		end
	end
end