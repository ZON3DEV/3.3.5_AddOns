local addon = LibStub("AceAddon-3.0"):GetAddon("GCD")
local module = addon:NewModule("gcd")
local L = LibStub("AceLocale-3.0"):GetLocale("GCD")
local dbVersion = 1

local GetTime = GetTime
local spellNum
local gcdFrame
local options
local ringMod

local tileLookup = {}
for r=1,16 do
	for c=1,16 do
		local row = {
			l = ((c - 1) * 128) / 2048,
			b = (2048 - (r - 1) * 128) / 2048,
			r = (c * 128) / 2048,
			t = (2048 - r * 128) / 2048
		}
		tinsert(tileLookup, row)
	end
end

local spells = {
	["DRUID"] = 5176,
	["PALADIN"] = 20154,
	["PRIEST"] = 585,
	["SHAMAN"] = 403,
	["WARRIOR"] = 34428,
	["DEATHKNIGHT"] = 47541,
	["HUNTER"] = 56641,
	["MAGE"] = 133,
	["WARLOCK"] = 686,
	["ROGUE"] = 1752
}

local defaults = {
	profile = {
		barColor = {r=1, g=1, b=1, a=0.8},
		backgroundColor = {r=0.4, g=0.4, b=0.4, a=0.8},
		sparkColor = {r=1, g=1, b=1, a=1},
		radius = 18,
		sparkOnly = false
	}
}

function module:OnEnable()
	self:SPELLS_CHANGED()
	self:RegisterEvent("SPELLS_CHANGED")
	self:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
end

function module:OnDisable()
	self:UnregisterAllEvents()
	self:Hide()
end

function module:FixDatabase()
	if self.db.profile.version then
		-- nothing to do yet
	end
	self.db.profile.version = dbVersion
end

function module:OnInitialize()
	self.db = addon.db:RegisterNamespace("GCD", defaults)
	self:FixDatabase()
	ringMod = addon:GetModule("ring", true)
end

function module:GetOptions()
	options = {
		name = "GCD",
		type = "group",
		args = {
			sparkOnly = {
				name = L["Show spark only"],
				type = "toggle",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.sparkOnly end,
				set = function(info, val)
							self.db.profile.sparkOnly = val
							self:ApplyOptions()
						end,
				order = 1
			},
			radius = {
				name = L["Radius"],
				type = "range",
				min = 10,
				max = 64,
				step = 1,
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.radius end,
				set = function(info, val)
							self.db.profile.radius = val
							self:ApplyOptions()
						end,
				order = 2
			},
			colors = {
				name = L["Colors"],
				type = "header",
				order = 10
			},
			barColor = {
				name = L["Bar"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.barColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 11
			},
			bgColor = {
				name = L["Background"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.backgroundColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 12
			},
			sparkColor = {
				name = L["Spark"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.sparkColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 13
			},
			misc = {
				name = L["Miscellaneous"],
				type = "header",
				order = 20
			},
			defaults = {
				name = L["Restore defaults"],
				type = "execute",
				disabled = function() return not addon.db.profile.modules.gcd end,
				func = function()
							self.db:ResetProfile()
							self:ApplyOptions()
						end,
				order = 21
			}
		}
	}
	return options
end

function module:Show()
	addon:Show("gcd")
	if ringMod and ringMod:IsEnabled() then ringMod:Show("gcd") end
	gcdFrame:Show()
end

function module:Hide()
	gcdFrame:Hide()
	if ringMod and ringMod:IsEnabled() then ringMod:Hide("gcd") end
	addon:Hide("gcd")
end

local function round(val)
	if val < 0.5 then
		return floor(val)
	else
		return ceil(val)
	end
end

local function OnUpdate(self, elapsed)
	local gcdPerc = (GetTime() - self.startTime) / self.duration
	if gcdPerc < 1 then
		local angle = gcdPerc * 360
		local tileNum, tile
		if not module.db.profile.sparkOnly then
			tileNum = round(angle / 1.40625)
			if tileNum <= 0 then
				tileNum = 1
			elseif tileNum > 256 then
				tileNum = 256
			end
			
			tile = tileLookup[tileNum]
			gcdFrame.barTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)
		end
		angle = 360 -(-90 + angle)

		local x = cos(angle) * module.db.profile.radius * 0.95
		local y = sin(angle) * module.db.profile.radius * 0.95
		local spark = gcdFrame.sparkTexture
		spark:SetRotation(rad(angle+90))
		spark:ClearAllPoints()
		spark:SetPoint("CENTER", gcdFrame.barTexture, "CENTER", x, y)
	else
		module:Hide()
	end
end

function module:ApplyOptions()
	local anchor = addon.anchor
	if self:IsEnabled() then
		if not gcdFrame then
			gcdFrame = CreateFrame("Frame")
			gcdFrame:SetParent(anchor)
			gcdFrame:SetAllPoints()
			
			gcdFrame.backgroundTexture = gcdFrame:CreateTexture(nil, 'BACKGROUND')
			gcdFrame.backgroundTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			gcdFrame.backgroundTexture:SetPoint("CENTER",gcdFrame,"CENTER")
			local tile = tileLookup[256]
			gcdFrame.backgroundTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)

			gcdFrame.barTexture = gcdFrame:CreateTexture(nil, 'ARTWORK')
			gcdFrame.barTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			gcdFrame.barTexture:SetPoint("CENTER",gcdFrame,"CENTER")
			
			gcdFrame.sparkTexture = gcdFrame:CreateTexture(nil, 'OVERLAY')
			gcdFrame.sparkTexture:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
			gcdFrame.sparkTexture:SetBlendMode("ADD")
		end
		self:Hide()
		gcdFrame:SetScript('OnUpdate', OnUpdate)

		if not self.db.profile.sparkOnly then
			gcdFrame.backgroundTexture:SetVertexColor(self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a)
			gcdFrame.backgroundTexture:SetWidth(2*self.db.profile.radius)
			gcdFrame.backgroundTexture:SetHeight(2*self.db.profile.radius)
			gcdFrame.backgroundTexture:Show()

			gcdFrame.barTexture:SetVertexColor(self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a)
			gcdFrame.barTexture:SetWidth(2*self.db.profile.radius)
			gcdFrame.barTexture:SetHeight(2*self.db.profile.radius)
			gcdFrame.barTexture:Show()
		else
			gcdFrame.backgroundTexture:Hide()
			gcdFrame.barTexture:Hide()
		end
		
		gcdFrame.sparkTexture:SetVertexColor(self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a)
		gcdFrame.sparkTexture:SetWidth(self.db.profile.radius)
		gcdFrame.sparkTexture:SetHeight(self.db.profile.radius)
		gcdFrame.sparkTexture:Show()
	end
end

function module:ACTIONBAR_UPDATE_COOLDOWN()
	if spellNum then
		local start, dur = GetSpellCooldown(spellNum, BOOKTYPE_SPELL)

		if dur > 0 and dur <= 1.5 then
			gcdFrame.startTime = start
			gcdFrame.duration = dur
			self:Show()
		end
	end
end

function module:SPELLS_CHANGED()
	local _, class = UnitClass("player")
	spellNum = addon:GetSpellPosInSpellbook(GetSpellInfo(spells[class]))
	self:ApplyOptions()
end