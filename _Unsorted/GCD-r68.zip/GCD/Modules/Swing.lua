--[[
	Most of the functionality was taken from the Quartz - Swing Module. Credits go to Nymbia and Nevcairiel
]]

local addon = LibStub("AceAddon-3.0"):GetAddon("GCD")
local module = addon:NewModule("swing")
local L = LibStub("AceLocale-3.0"):GetLocale("GCD")
local dbVersion = 1

local GetTime = GetTime
local swingFrame
local options
local ringMod

local swingMode
local playerClass

local autoshot = GetSpellInfo(75)
local shoot = GetSpellInfo(5019)
local slam = GetSpellInfo(1464)
local slamStart
local startTime, duration

local tileLookup = {}
for r=1,16 do
	for c=1,16 do
		local row = {
			l = ((c - 1) * 128) / 2048,
			b = (2048 - (r - 1) * 128) / 2048,
			r = (c * 128) / 2048,
			t = (2048 - r * 128) / 2048
		}
		tinsert(tileLookup, row)
	end
end

local defaults = {
	profile = {
		barColor = {r=1, g=1, b=1, a=0.8},
		backgroundColor = {r=0.4, g=0.4, b=0.4, a=0.8},
		sparkColor = {r=1, g=1, b=1, a=1},
		radius = 15,
		sparkOnly = false
	}
}

function module:OnEnable()
	self:ApplyOptions()
	self:RegisterEvent("PLAYER_ENTER_COMBAT")
	self:RegisterEvent("PLAYER_LEAVE_COMBAT")
	
	self:RegisterEvent("START_AUTOREPEAT_SPELL")
	self:RegisterEvent("STOP_AUTOREPEAT_SPELL")
	
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	
	if playerClass == "WARRIOR" then
		self:RegisterEvent("UNIT_SPELLCAST_START")
		self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
	end
	
	self:RegisterEvent("UNIT_ATTACK")
end

function module:OnDisable()
	self:UnregisterAllEvents()
	self:Hide()
end

function module:FixDatabase()
	if self.db.profile.version then
		-- nothing to do yet
	end
	self.db.profile.version = dbVersion
end

function module:OnInitialize()
	self.db = addon.db:RegisterNamespace("Swing", defaults)
	self:FixDatabase()
	ringMod = addon:GetModule("ring", true)
	playerClass = UnitClass("player")
end

function module:GetOptions()
	options = {
		name = "Swing",
		type = "group",
		args = {
			sparkOnly = {
				name = L["Show spark only"],
				type = "toggle",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.sparkOnly end,
				set = function(info, val)
							self.db.profile.sparkOnly = val
							self:ApplyOptions()
						end,
				order = 1
			},
			radius = {
				name = L["Radius"],
				type = "range",
				min = 10,
				max = 64,
				step = 1,
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.radius end,
				set = function(info, val)
							self.db.profile.radius = val
							self:ApplyOptions()
						end,
				order = 2
			},
			colors = {
				name = L["Colors"],
				type = "header",
				order = 10
			},
			barColor = {
				name = L["Bar"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.barColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 11
			},
			bgColor = {
				name = L["Background"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.backgroundColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 12
			},
			sparkColor = {
				name = L["Spark"],
				type = "color",
				disabled = function() return not addon.db.profile.modules.gcd end,
				get = function(info) return self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a end,
				set = function(info, r, g, b, a)
							self.db.profile.sparkColor = {r=r, g=g, b=b, a=a}
							self:ApplyOptions()
						end,
				hasAlpha = true,
				order = 13
			},
			misc = {
				name = L["Miscellaneous"],
				type = "header",
				order = 20
			},
			defaults = {
				name = L["Restore defaults"],
				type = "execute",
				disabled = function() return not addon.db.profile.modules.gcd end,
				func = function()
							self.db:ResetProfile()
							self:ApplyOptions()
						end,
				order = 21
			}
		}
	}
	return options
end

function module:Show()
	addon:Show("swing")
	if ringMod and ringMod:IsEnabled() then ringMod:Show("swing") end
	startTime = GetTime()
	if swingMode == 1 then
		duration = UnitAttackSpeed("player")
	elseif swingMode == 2 then
		duration = UnitRangedDamage("player")
	end
	swingFrame:Show()
end

function module:Hide()
	swingFrame:Hide()
	if ringMod and ringMod:IsEnabled() then ringMod:Hide("swing") end
	startTime, duration = nil, nil
	addon:Hide("swing")
end

local function round(val)
	if val < 0.5 then
		return floor(val)
	else
		return ceil(val)
	end
end

local function OnUpdate(self, elapsed)
	local perc = (GetTime() - startTime) / duration
	if perc < 1 then
		local angle = perc * 360
		local tileNum, tile
		if not module.db.profile.sparkOnly then
			tileNum = round(angle / 1.40625)
			if tileNum <= 0 then
				tileNum = 1
			elseif tileNum > 256 then
				tileNum = 256
			end
			
			tile = tileLookup[tileNum]
			swingFrame.barTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)
		end
		angle = 360 -(-90 + angle)

		local x = cos(angle) * module.db.profile.radius * 0.95
		local y = sin(angle) * module.db.profile.radius * 0.95
		local spark = swingFrame.sparkTexture
		spark:SetRotation(rad(angle+90))
		spark:ClearAllPoints()
		spark:SetPoint("CENTER", swingFrame.barTexture, "CENTER", x, y)
	else
		module:Hide()
	end
end

function module:PLAYER_ENTER_COMBAT()
	local _,_,offhandlow, offhandhigh = UnitDamage("player")
	if (offhandhigh - offhandlow) <= 0.1 or playerClass == "DRUID" then
		swingMode = 1
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	end
end

function module:PLAYER_LEAVE_COMBAT()
	if swingMode == 1 then
		swingMode = nil
		self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	end
end

function module:START_AUTOREPEAT_SPELL()
	swingMode = 2
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
end

function module:STOP_AUTOREPEAT_SPELL()
	if swingMode == 2 then
		swingMode = nil
		self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	end
end

function module:UNIT_SPELLCAST_SUCCEEDED(event, unit, spell)
	if unit ~= "player" or not swingMode then return end
	if swingMode == 1 then
		if spell == slam and slamstart then
			startTime = startTime + GetTime() - slamStart
			slamStart = nil
		end
	elseif swingMode == 2 then
		if spell == autoshot or spell == shoot then
			self:Show()
		end
	end
end

function module:UNIT_SPELLCAST_INTERRUPTED(event, unit, spell)
	if unit == "player" and spell == slam and slamstart then 
		slamstart = nil
	end 
end

function module:UNIT_SPELLCAST_START(event, unit, spell)
	if unit == "player" and spell == slam then
		slamStart = GetTime()
	end
end

function module:COMBAT_LOG_EVENT_UNFILTERED(event, timestamp, combatevent, srcGUID, srcName, srcFlags, dstName, dstGUID, dstFlags, spellID, spellName)
	if srcGUID == UnitGUID("player") then
		if combatevent == "SWING_DAMAGE" or combatevent == "SWING_MISSED" then
			self:Show()
		end
	elseif dstGUID == UnitGUID("player") and combatevent == "SWING_MISSED" and spellID == "PARRY" and duration then
		duration = duration * 0.6
	end
end

function module:UNIT_ATTACK(event, unit)
	if unit == "player" and swingMode then
		if swingMode == 1 then
			duration = UnitAttackSpeed("player")
		elseif swingMode == 2 then
			duration = UnitRangedDamage("player")
		end
	end
end

function module:ApplyOptions()
	local anchor = addon.anchor
	if self:IsEnabled() then
		if not swingFrame then
			swingFrame = CreateFrame("Frame")
			swingFrame:SetParent(anchor)
			swingFrame:SetAllPoints()
			
			swingFrame.backgroundTexture = swingFrame:CreateTexture(nil, 'BACKGROUND')
			swingFrame.backgroundTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			swingFrame.backgroundTexture:SetPoint("CENTER",swingFrame,"CENTER")
			local tile = tileLookup[256]
			swingFrame.backgroundTexture:SetTexCoord(tile.l, tile.r, tile.t, tile.b)

			swingFrame.barTexture = swingFrame:CreateTexture(nil, 'ARTWORK')
			swingFrame.barTexture:SetTexture("Interface\\Addons\\GCD\\Textures\\slices")
			swingFrame.barTexture:SetPoint("CENTER",swingFrame,"CENTER")
			
			swingFrame.sparkTexture = swingFrame:CreateTexture(nil, 'OVERLAY')
			swingFrame.sparkTexture:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
			swingFrame.sparkTexture:SetBlendMode("ADD")
		end
		self:Hide()
		swingFrame:SetScript('OnUpdate', OnUpdate)

		if not self.db.profile.sparkOnly then
			swingFrame.backgroundTexture:SetVertexColor(self.db.profile.backgroundColor.r, self.db.profile.backgroundColor.g, self.db.profile.backgroundColor.b, self.db.profile.backgroundColor.a)
			swingFrame.backgroundTexture:SetWidth(2*self.db.profile.radius)
			swingFrame.backgroundTexture:SetHeight(2*self.db.profile.radius)
			swingFrame.backgroundTexture:Show()

			swingFrame.barTexture:SetVertexColor(self.db.profile.barColor.r, self.db.profile.barColor.g, self.db.profile.barColor.b, self.db.profile.barColor.a)
			swingFrame.barTexture:SetWidth(2*self.db.profile.radius)
			swingFrame.barTexture:SetHeight(2*self.db.profile.radius)
			swingFrame.barTexture:Show()
		else
			swingFrame.backgroundTexture:Hide()
			swingFrame.barTexture:Hide()
		end
		
		swingFrame.sparkTexture:SetVertexColor(self.db.profile.sparkColor.r, self.db.profile.sparkColor.g, self.db.profile.sparkColor.b, self.db.profile.sparkColor.a)
		swingFrame.sparkTexture:SetWidth(self.db.profile.radius)
		swingFrame.sparkTexture:SetHeight(self.db.profile.radius)
		swingFrame.sparkTexture:Show()
	end
end
