--[[ You noisy little rebel, aren't you? ]] -- 

local buffs = {
	["Warcry"] = true,
	["Battle Shout"] = true,
}

local WarcryMonitor = CreateFrame("Frame","WarcryMonitor")

WarcryMonitor:SetBackdrop({
      bgFile="Interface\\Addons\\WarcryMonitor\\Icons\\Warcry", 
})
WarcryMonitor:SetWidth(25)
WarcryMonitor:SetHeight(25)
WarcryMonitor:SetPoint("CENTER", UIParent, "CENTER", -242, -205)
WarcryMonitor:EnableMouse(true)
WarcryMonitor:SetMovable(false)
WarcryMonitor:RegisterForDrag("LeftButton")
WarcryMonitor:SetScript("OnDragStart", function(self) self:StartMoving() end)
WarcryMonitor:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
WarcryMonitor:SetFrameStrata("BACKGROUND")
WarcryMonitor:SetAlpha(1)


WarcryMonitor:RegisterEvent("PLAYER_LOGIN")
	DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r is now Loaded!")

SLASH_WARCRYMONITOR1 = "/wcm";
SLASH_WARCRYMONITOR2 = "/wcmhelp";
SlashCmdList.WARCRYMONITOR = function()
	DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r To Show/Hide icons type /wcmShow and /wcmHide")
	DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r To Lock/Unlock icons type /wcmLock and /wcmUnlock.")
end	

SLASH_WARCRYMONITORLOCK1 = "/wcmlock";
SlashCmdList.WARCRYMONITORLOCK = function()
		DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r is now Locked!")
	WarcryMonitor:SetMovable(false)
	BattleShout:SetMovable(false)
end

SLASH_WARCRYMONITORUNLOCK1 = "/wcmunlock";
SlashCmdList.WARCRYMONITORUNLOCK = function()
		DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r is now Unlocked!")
	WarcryMonitor:SetMovable(true)
	BattleShout:SetMovable(true)
end 

SLASH_WARCRYMONITORSHOW1 = "/wcmshow";
SlashCmdList.WARCRYMONITORSHOW = function()
		DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r is now Shown!")
	WarcryMonitor:Show()
	BattleShout:Show()
end 

SLASH_WARCRYMONITORHIDE1 = "/wcmhide";
SlashCmdList.WARCRYMONITORHIDE = function()
		DEFAULT_CHAT_FRAME:AddMessage("|cFFff9900[Warcry Monitor]|r is now Hidden!")
	WarcryMonitor:Hide()
	BattleShout:Hide()
end 

WarcryMonitor:RegisterEvent("UNIT_AURA")
WarcryMonitor:SetScript("OnEvent", function(self, event, ...)

    local unit = ...
    if unit ~= "player" then
        return
    end
	
    for buff in pairs(buffs) do
        if UnitBuff("player", "Warcry") then
			WarcryMonitor:SetAlpha(0.4)
			local  WarcryMonitorTimer = CreateFrame("Frame","WarcryMonitorTimer");
			function WarcryMonitorTimer:onUpdate(sinceLastUpdate)
				self.sinceLastUpdate = (self.sinceLastUpdate or 0) + sinceLastUpdate;			
				if ( self.sinceLastUpdate >= 120 ) then
					WarcryMonitor:SetAlpha(1)
					PlaySound(6278)
				self.sinceLastUpdate = 0;
				end
			end
			WarcryMonitorTimer:SetScript("OnUpdate",WarcryMonitorTimer.onUpdate)
        end
    end
	
	for buff in pairs(buffs) do
		if UnitBuff("player", "Battle Shout") then
			BattleShout:SetAlpha(1)
		else
			BattleShout:SetAlpha(0.4)
        end
    end	
	
end)

local BattleShout = CreateFrame("Frame","BattleShout")

BattleShout:SetBackdrop({
      bgFile="Interface\\Addons\\WarcryMonitor\\Icons\\BattleShout", 
})
BattleShout:SetWidth(25)
BattleShout:SetHeight(25)
BattleShout:SetPoint("CENTER", WarcryMonitor, "RIGHT", 17, 0)
BattleShout:EnableMouse(true)
BattleShout:SetMovable(true)
BattleShout:SetFrameStrata("BACKGROUND")
BattleShout:SetAlpha(0.4)
