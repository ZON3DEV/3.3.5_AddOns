WoWPro_Leveling:RegisterGuide("JamSwa4444", "Swamp of Sorrows", "Jame", "44", "44", "JamBad4444", "Horde", function()
return [[
H Orgrimmar |QID|1393|

b Grom'gol Base Camp  |QID|1393|N|Take the Zeppelin to Grom'gol Base Camp |
F Stonard  |QID|1393|N|Fly to Stonard|
A Little Morsels |QID|9440|
R Fallow Sanctuary  |QID|1393|N| |M|61,23|
C Little Morsels |QID|9440|U|23659|N|Look for 3 caged animals: Captured Crocolisk , Tarantua (62.78,23.69) and Jaguar(65.4,22.6).  Target each one and feed them the Fel-Tainted morsels. |M|60.49,22.35|
A Galen's Escape |QID|1393|N|Escort quest: Before taking this quest, clear as much of the camp to the southwest of the cage.  He's slow and an idiot once free. |M|65.40,18.40|
T Galen's Escape |QID|1393|N|Once he's safe, he'll direct you to his encampment.  Look for a strongbox there and open it to finish the quest. |M|48,40|

C Lack of Surplus |QID|699|N|Kill Sawtooth Snappers  - in the bog all along the eastern coast  - until you get 6 claws.|M|80,24|
T Lack of Surplus |QID|699|M|81.3,81.0|
A Threat From the Sea (Part 1)|QID|1422|M|81.3,81.0|
T Threat From the Sea (Part 1)|QID|1422|N|Turn in to Katar. |M|83.8,80.4|
A Threat From the Sea (Part 2)|QID|1426|M|83.8,80.4|
C Threat From the Sea (Part 2)|QID|1426|N|Head down to the shore and start killing murlocs.  The Murlock Flesheaters are mainly north of the camp. |
T Threat From the Sea (Part 2)|QID|1426|M|83.8,80.4|
A Threat From the Sea (Part 3)|QID|1427|M|83.8,80.4|
T Threat From the Sea (Part 3)|QID|1427|N|Turn it in to Tok'Kar |M|81.3,81.0|
T Little Morsels |QID|9440|N|Back at Stonard.|
]]
end)