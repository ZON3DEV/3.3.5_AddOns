-- Colours
COLOR_RED = "|cffff0000";
COLOR_GREEN = "|cff00ff00";
COLOR_BLUE = "|cff0000ff";
COLOR_PURPLE = "|cff700090";
COLOR_YELLOW = "|cffffff00";
COLOR_ORANGE = "|cffff6d00";
COLOR_GREY = "|cff808080";
COLOR_GOLD = "|cffcfb52b";
COLOR_WHITE = "|cffffffff";
COLOR_NEON_BLUE = "|cff4d4dff";
COLOR_END = "|r";

	-- general
	MarkBar_MARK = "Mark";
	MarkBar_SETTINGS = "Settings";
	MarkBar_ANNOUNCE = "Announce marks";
	MarkBar_REMOVEMARK = "Remove";
	MarkBar_MARKSANNOUNCETITLE = "Marks explanation:";
	MarkBar_ASSIGNED = "%s assigned to %s";

	-- help
	MarkBar_HELP1 = "toggles show/hide toolbar.";
	MarkBar_HELP2 = "(n=0,1) 1=enables autoshow on join/leave party, 0=disables.";
	MarkBar_HELP3 = "resets to default settings.";
	MarkBar_HELP4 = "(n=0-1) sets toolbar transparency.";
	MarkBar_HELP5 = "(n=0-1) sets toolbar scale.";
	MarkBar_HELP6 = "(n=0-8) sets mark to current target (useful for use within macros).";
	MarkBar_HELP7 = "(n=0,1) 1=allow other party members to mark, 0=disallow.";
	MarkBar_HELP8 = "(n=0,1) 1=shows tooltip on mouse over mark, 0=doesn't.";
	MarkBar_HELP9 = "(n=0,1) 1=skip marks without assignment in announcement, 0=doesn't skip.";
	MarkBar_HELP10 = " toggles lock/unlock toolbark.";

	-- Stuff
	MarkBar_LOCK = "locked";
	MarkBar_UNLOCK = "unlocked";

	-- marks
	MarkBar_MARKNAME1 = "{rt1}";
	MarkBar_MARKNAME2 = "{rt2}";
	MarkBar_MARKNAME3 = "{rt3}";
	MarkBar_MARKNAME4 = "{rt4}";
	MarkBar_MARKNAME5 = "{rt5}";
	MarkBar_MARKNAME6 = "{rt6}";
	MarkBar_MARKNAME7 = "{rt7}";
	MarkBar_MARKNAME8 = "{rt8}";

	-- UI labels
	MarkBar_LB_CLEARASSIGN = "Clear >>";
	MarkBar_LB_ASSIGNWARN = "Assignments are not stored with profile.";
	MarkBar_LB_CLOSE = "Close";
	MarkBar_LB_AUTOTOGGLE = "Toggles automatically when join/leave a group";
	MarkBar_LB_SHOWTOOLTIP = "Show icon tooltip";
	MarkBar_LB_SKIPNA = "Skip marks without assignment in announcement";
	MarkBar_LB_ALPHA = "Toolbar Alpha";
	MarkBar_LB_SCALE = "Toolbar Scale";
	MarkBar_LB_MARKS = "Marks";
	MarkBar_LB_SETTINGS = "Settings";
	MarkBar_LB_LOCK_FRAME = "Lock";

	-- errors
	MarkBar_ERRUNKNOWNCMD = "Error: Unknown command.";
	MarkBar_NOTASSIGNED = "Not assigned";
	MarkBar_NOTGROUPED = "Error: You're not in a party or raid";
	MarkBar_ERRICONNUMBER = "Invalid icon number";