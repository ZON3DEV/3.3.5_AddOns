-- GlobalVars ->
MarkBar = {}
MarkBar.title       = "MarkBar";
MarkBar.version     = "1.4.1 Final";
MarkBar.author      = "BrainInBlack";
MarkBar.CMD_PREFIX = "MARKBAR";
MarkBar.CMD_MARK   = "MARK";
MarkBar.CMD_TOKEN  = "#";

-- OnLoad ->
function MarkBar.OnLoad()
	--SlashCommands ->
	SLASH_MARKBAR1 = "/markbar";
	SLASH_MARKBAR2 = "/mb";
	SlashCmdList["MARKBAR"] = function(msg)
		MarkBar.Command(msg);
end

	-- RegisterEvents ->
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("PARTY_MEMBERS_CHANGED");
	this:RegisterEvent("PARTY_LEADER_CHANGED");
	this:RegisterEvent("CHAT_MSG_ADDON");

	-- EscapeExit ->
	tinsert(UISpecialFrames,"MarkBar_SettingsFrame");

	-- LoadInfo
	MarkBar.Print("Version "..MarkBar.version.." by "..MarkBar.author.." loaded. Type \"/mb help\" for help.");
end

function MarkBar.OnUpdate()
	-- FakeHandler ->
end

-- OnVarsLoaded ->
function MarkBar.OnVariablesLoaded()
	-- SavedVars ->
	if (not MarkBarOptions) then
		MarkBarOptions = {
			XPos = 0,
			YPos = -200,
			Scale = 1,
			Alpha = 1,
			ShowTooltip = 1,
			AutoToogle = 1,
			AllowPartyMark = 0,
			SkipNotAssigned = 0,
			ActiveSet = "Default",
			LockFrame = "unlocked", -- NewVar!
			Debug = 0,
			MarksSets = {
				["Default"] = {
					Name = "Default",
					Mark0 = MarkBar_REMOVEMARK,
					Mark1 = MarkBar_MARK.." 1",
					Mark2 = MarkBar_MARK.." 2",
					Mark3 = MarkBar_MARK.." 3",
					Mark4 = MarkBar_MARK.." 4",
					Mark5 = MarkBar_MARK.." 5",
					Mark6 = MarkBar_MARK.." 6",
					Mark7 = MarkBar_MARK.." 7",
					Mark8 = MarkBar_MARK.." 8"
				}
			}
		}

		if ( not MarkBarOptions.LockFrame ) then
			MarkBarOptions.LockFrame = "unlocked";
		end
		if ( not MarkBarOptions.AllowPartyMark ) then
			MarkBarOptions.AllowPartyMark = 0;
		end
		if ( not MarkBarOptions.SkipNotAssigned ) then
			MarkBarOptions.SkipNotAssigned = 1;
		end
		if ( not MarkBarOptions.Debug ) then
			MarkBarOptions.Debug = 0;
		end
	end
	-- DeafaultPosition
	MarkBar_MainFrame:SetPoint("CENTER", "UIParent", "CENTER", 0 , -200);
	MarkBar_MainFrame:SetScale(MarkBarOptions.Scale);
	MarkBar_MainFrame:SetAlpha(MarkBarOptions.Alpha);

	-- TempVars
	MarkBarVars = {
		closedByUser = nil,
		inGroup = nil,
		TimeSinceLastUpdate = 0,
		MarksAssignments = {
			Mark1 = "",
			Mark2 = "",
			Mark3 = "",
			Mark4 = "",
			Mark5 = "",
			Mark6 = "",
			Mark7 = "",
			Mark8 = ""
		},
		MarksNames = {
			Mark1 = MarkBar_MARKNAME1,
			Mark2 = MarkBar_MARKNAME2,
			Mark3 = MarkBar_MARKNAME3,
			Mark4 = MarkBar_MARKNAME4,
			Mark5 = MarkBar_MARKNAME5,
			Mark6 = MarkBar_MARKNAME6,
			Mark7 = MarkBar_MARKNAME7,
			Mark8 = MarkBar_MARKNAME8
		}
	}
end

-- SlashFunctionHandle ->
function MarkBar.Command(msg)
	local cmd, param = MarkBar.ParamParser(msg);

	if ( cmd == "" ) then
		MarkBar.ToggleBar();
	elseif(cmd=="lock") then
		if( MarkBarOptions.LockFrame == "unlocked" ) then
			MarkBarOptions.LockFrame = "locked";
			MarkBar.Print(MarkBar_LOCK);
		else
			MarkBarOptions.LockFrame = "unlocked";
			MarkBar.Print(MarkBar_UNLOCK);
		end
	elseif(cmd=="help") then
		MarkBar.ShowHelp();
	elseif(cmd=="reset") then
		MarkBar.Reset();
	elseif(cmd=="auto") then
		MarkBarOptions.AutoToogle = param;
	elseif(cmd=="alpha") then
		MarkBarOptions.Alpha = param;
		MarkBar_MainFrame:SetAlpha(MarkBarOptions.Alpha);
	elseif(cmd=="showtooltip") then
		MarkBarOptions.ShowTooltip = param;
	elseif(cmd=="scale") then
		MarkBarOptions.Scale = param; 
		MarkBar_MainFrame:SetScale(MarkBarOptions.Scale);
	elseif(cmd=="allow") then
		MarkBarOptions.AllowPartyMark = param;
	elseif(cmd=="skip") then
		MarkBarOptions.SkipNotAssigned = param;
	elseif(cmd=="debug") then
		MarkBarOptions.Debug = param;
	elseif(cmd=="mark") then
		if ( tonumber(param) >=0 and tonumber(param)<=8 ) then
			SetRaidTargetIcon("target", tonumber(param));
			return;
		end
		MarkBar.Print(MarkBar_ERRICONNUMBER);
	else
		MarkBar.Print(MarkBar_ERRUNKNOWNCMD);
		MarkBar.ShowHelp();
	end
end

-- EventTrigger
function MarkBar.OnEvent()
	if ( event == "VARIABLES_LOADED" ) then
		MarkBar.OnVariablesLoaded();
	elseif ( event == "PARTY_MEMBERS_CHANGED" or event == "PARTY_LEADER_CHANGED" ) then
		local inParty, inRaid = MarkBar.GroupMode();
		MarkBarVars.inGroup = (inParty or inRaid);
		if ( MarkBarOptions.AutoToogle==1 and not MarkBarVars.closedByUser ) then
			if ( (inRaid and (IsRaidLeader() or IsRaidOfficer())) ) then
				MarkBar_MainFrame:Show();
			elseif ( UnitInParty("player") ) then
				MarkBar_MainFrame:Show();
			else
				MarkBar_MainFrame:Hide();
			end
		end
		if (not MarkBarVars.inGroup) then
			MarkBarVars.closedByUser = nil;
		end
	elseif ( event=="CHAT_MSG_ADDON" and arg1 == MarkBar.CMD_PREFIX and (arg3=="PARTY" or arg3=="RAID") ) then
		MarkBar.CommHandler(arg2, arg4);
	end
end

-- ResetAssignment ->
function MarkBar.Reset()
	MarkBarVars.closedByUser = nil;
	for i=1,8 do
		MarkBarVars.MarksAssignments["Mark"..i] = "";
	end
end

-- HelpPrint ->
function MarkBar.ShowHelp()
	MarkBar.Print(MarkBar.title.." "..MarkBar.version )
	MarkBar.Print(COLOR_GOLD.."/mb "..COLOR_END..COLOR_WHITE..MarkBar_HELP1..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb lock"..COLOR_END..COLOR_WHITE..MarkBar_HELP10..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb auto n "..COLOR_END..COLOR_WHITE..MarkBar_HELP2..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb reset "..COLOR_END..COLOR_WHITE..MarkBar_HELP3..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb alpha n "..COLOR_END..COLOR_WHITE..MarkBar_HELP4..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb scale n "..COLOR_END..COLOR_WHITE..MarkBar_HELP5..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb mark n "..COLOR_END..COLOR_WHITE..MarkBar_HELP6..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb allow n "..COLOR_END..COLOR_WHITE..MarkBar_HELP7..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb showtooltip n "..COLOR_END..COLOR_WHITE..MarkBar_HELP8..COLOR_END);
	MarkBar.Print(COLOR_GOLD.."/mb skip n "..COLOR_END..COLOR_WHITE..MarkBar_HELP9..COLOR_END);
end

-- [[ MainFrame ]] ->

-- Show/HideToggle ->
function MarkBar.ToggleBar(arg)
	local show;

	if (arg) then
		show = arg;
	else
		if( MarkBar_MainFrame:IsVisible() ) then
			show = 0;
		else
			show = 1;
		end
	end
	
	if( show==1 ) then
		MarkBar_MainFrame:Show();
	else
		MarkBar_MainFrame:Hide();
		if (MarkBarVars.inGroup) then
			MarkBarVars.closedByUser = 1; 
		end
	end
end

function MarkBar.SetRaidTargetIcon(icon, id)
	local info = UnitPopupButtons["RAID_TARGET_"..id];
	icon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons");
	icon:SetTexCoord(info.tCoordLeft, info.tCoordRight, info.tCoordTop, info.tCoordBottom);
end

-- [[ MarkButtonHandlers ]] ->

function MarkBar.Mark_OnClick(arg1)
	local icon = this:GetID();
	this:SetChecked(0);
	if (arg1 == "LeftButton") then
		if ( UnitExists("target") ) then
			SetRaidTargetIcon("target", icon);
		end
	else
		if( UnitIsFriend("player","target") ) then
			local mark =  "Mark"..icon;
			local textbox, assignlabel, icon = getglobal("MarkBar_Set"..icon.."Description"), getglobal("MarkBar_Set"..icon.."Assignment"), getglobal("MarkBar_Set"..icon.."Icon");
			assignlabel:SetText(UnitName("target"));
			icon:SetAlpha(1.0);
			MarkBarVars.MarksAssignments[mark] = UnitName("target");
			local msg = format(MarkBar_ASSIGNED, MarkBarVars.MarksNames[mark], UnitName("target"));
			if(MarkBarOptions.Debug==0) then
				SendChatMessage(msg, "RAID_WARNING");
			else
				MarkBar.Print(msg);
			end
		else
			SetRaidTargetIcon("target", icon);
		end
	end
end

function MarkBar.Mark_OnEnter(arg1)
	if ( MarkBarOptions.ShowTooltip == 1 ) then
		local set, mark, assignedTo, color = MarkBarOptions.ActiveSet, "Mark"..this:GetID();
		assignedTo = MarkBarVars.MarksAssignments[mark];
		if (not assignedTo or assignedTo=="" ) then
			color = { r=0.7, g=0.7, b=0.7}; -- gray
			assignedTo = MarkBar_NOTASSIGNED;
		else
			color = { r=1.0, g=1.0, b=1.0};
		end
		GameTooltip:SetOwner(this, "ANCHOR_BOTTOMLEFT");
		GameTooltip:SetText(MarkBarOptions.MarksSets[set][mark]); -- mark description
		GameTooltip:AddLine(assignedTo, color.r, color.g, color.b); -- assignment
		GameTooltip:Show();
	end
end

function MarkBar.MoveHandler_OnMouseDown(arg1)
	if (arg1 == "LeftButton" and MarkBarOptions.LockFrame == "unlocked") then
		MarkBar_MainFrame:StartMoving();
	else
		-- MouseScale ->
	end
end
function MarkBar.MoveHandler_OnMouseUp(arg1)
	if (arg1 == "LeftButton" and MarkBarOptions.LockFrame == "unlocked") then
		MarkBar_MainFrame:StopMovingOrSizing();
	else
		MarkBarVars.Scaling = nil;
	end
end

-- [[ Settings Frame ]]

-- LoadProfile ->
function MarkBar.LoadSettings()
	for i=1,8 do
		local set = MarkBarOptions.ActiveSet;
		local mark = "Mark"..i;
		local textbox, assignlabel, icon = getglobal("MarkBar_Set"..i.."Description"), getglobal("MarkBar_Set"..i.."Assignment"), getglobal("MarkBar_Set"..i.."Icon");
		local desc, assignment = MarkBarOptions.MarksSets[set][mark], MarkBarVars.MarksAssignments[mark];
		textbox:SetText(desc);
		assignlabel:SetText(assignment);
		if ( assignment==nil or assignment=="" ) then
			icon:SetAlpha(0.3);
		else
			icon:SetAlpha(1);
		end
	end
	if(MarkBarOptions.LockFrame == "locked") then
		MarkBar_ChkLockFrame:SetChecked(1);
	else
		MarkBar_ChkLockFrame:SetChecked(0);
	end
	MarkBar_ChkAutoToggle:SetChecked(MarkBarOptions.AutoToogle);
	MarkBar_ChkShowTooltip:SetChecked(MarkBarOptions.ShowTooltip);
	MarkBar_ChkSkipNA:SetChecked(MarkBarOptions.SkipNotAssigned);
	MarkBar_ScaleSlider:SetValue(MarkBarOptions.Scale);
	MarkBar_AlphaSlider:SetValue(MarkBarOptions.Alpha);
end

-- SaveProfile ->
function MarkBar.SaveSettings()
	for i=1,8 do
		local set, desc = MarkBarOptions.ActiveSet, getglobal("MarkBar_Set"..i.."Description"):GetText();
		MarkBarOptions.MarksSets[set]["Mark"..i] = desc;
	end
	if ( MarkBar_ChkAutoToggle:GetChecked() ) then
		MarkBarOptions.AutoToogle = 1;
	else
		MarkBarOptions.AutoToogle = 0;
	end
	if ( MarkBar_ChkShowTooltip:GetChecked() ) then
		MarkBarOptions.ShowTooltip = 1;
	else
		MarkBarOptions.ShowTooltip = 0;
	end
	if ( MarkBar_ChkSkipNA:GetChecked() ) then
		MarkBarOptions.SkipNotAssigned = 1;
	else
		MarkBarOptions.SkipNotAssigned = 0;
	end
	if ( MarkBar_ChkLockFrame:GetChecked() ) then
		MarkBarOptions.LockFrame = "locked";
	else
		MarkBarOptions.LockFrame = "unlocked";
	end
end

function MarkBar.ToggleSettings()
	if ( MarkBar_SettingsFrame:IsVisible() ) then
		MarkBar.SaveSettings();
		MarkBar_SettingsFrame:Hide();
	else
		MarkBarTab_OnClick(1);
		MarkBar.LoadSettings();
		MarkBar_SettingsFrame:Show();
	end
end

function MarkBar.ClearAssign_OnClick()
	local p = this:GetParent();
	local i = p:GetID();
	local mark = "Mark"..i;
	MarkBarVars.MarksAssignments[mark] = "";
	local set = MarkBarOptions.ActiveSet;
	local textbox, assignlabel, icon = getglobal("MarkBar_Set"..i.."Description"), getglobal("MarkBar_Set"..i.."Assignment"), getglobal("MarkBar_Set"..i.."Icon");
	assignlabel:SetText("");
	icon:SetAlpha(0.3);
end

function MarkBarScaleSlider_OnValueChanged(value)
	MarkBarOptions.Scale = value;
	MarkBar_MainFrame:SetScale(MarkBarOptions.Scale);
end

function MarkBarAlphaSlider_OnValueChanged(value)
	MarkBarOptions.Alpha = value;
	MarkBar_MainFrame:SetAlpha(MarkBarOptions.Alpha);
end

function MarkBarTab_OnClick(index)
	if ( not index ) then
		index = this:GetID();
	end

	if ( MarkBar_SettingsFrame.numTabs == nil) then
		PanelTemplates_SetNumTabs(MarkBar_SettingsFrame, 2);
	end

	PanelTemplates_SetTab(MarkBar_SettingsFrame, index);
	MarkBar_SettingsFrameMarks:Hide();
	MarkBar_SettingsFrameSettings:Hide();
	if ( index == 1 ) then
		-- Marks Tab
		MarkBar_SettingsFrameSettings:Hide();
		MarkBar_SettingsFrameMarks:Show();
	elseif ( index == 2 ) then
		-- General Settings Tab
		MarkBar_SettingsFrameMarks:Hide();
		MarkBar_SettingsFrameSettings:Show();
	end
end

-- [[ Announce ]] ->
function MarkBar.Announce()
	local inParty, inRaid = MarkBar.GroupMode();
	if (not inParty and not inRaid and MarkBarOptions.Debug==0) then
		MarkBar.Print(MarkBar_NOTGROUPED);
		return;
	else
		local channel;
		if (inRaid) then
			channel = "RAID";
		else
			channel = "PARTY";
		end
		if (MarkBarOptions.Debug==0) then
			SendChatMessage(MarkBar_MARKSANNOUNCETITLE, "RAID_WARNING");
		end
		local set, msg = MarkBarOptions.ActiveSet;
		for i=1,8 do
			local mark, name, assignedTo, description;
			mark = "Mark"..i;
			name = MarkBarVars.MarksNames[mark];
			assignedTo = MarkBarVars.MarksAssignments[mark];
			description = MarkBarOptions.MarksSets[set][mark];
			local skip = 0;
			if ( description==nil or description == "" ) then
				description = " ";
			end
			if ( assignedTo==nil or assignedTo == "" ) then
				if ( MarkBarOptions.SkipNotAssigned==1 ) then
					skip = skip+1;
				end
				assignedTo = " ";
			end

			if (skip<1) then
				msg=format("%s: %s >> %s", name, description, assignedTo);
				if (MarkBarOptions.Debug==0) then
					SendChatMessage(msg, channel);
				else
					MarkBar.Print("Debug> "..msg);
				end
			end
		end
	end
end

-- [[ Addon Comms / Message Format:	"COMMAND..TOKEN..PARAM" ]] ->
function MarkBar.CommHandler( msg, sender )
	if ( sender==UnitName("player") and MarkBarOptions.Debug==0 ) then return; end;
	
	local target = MarkBar.GetUnitIdByName(sender);
	local a, b = string.find(msg, "(.+)"..MarkBar.CMD_TOKEN.."(.+)" );
	local cmd = strsub(msg, a);
	local param = strsub(msg, b	);

	if (MarkBarOptions.Debug==1) then
		MarkBar.Print("Debug>msg="..msg);
		MarkBar.Print("Debug>sender="..sender);
		MarkBar.Print("Debug>cmd="..cmd);
		MarkBar.Print("Debug>param="..param);	
		MarkBar.Print("Debug>target="..target);
	end
	if ( cmd==MarkBar.CMD_MARK ) then
		if ( target and MarkBarOptions.AllowPartyMark==1 ) then
			target = target.."target";
			if ( UnitExists(target) ) then
				SetRaidTargetIcon(target, param);
			end
		end
	end
end

-- GetUnitID ->
function MarkBar.GetUnitIdByName(name)
	local inParty, inRaid = MarkBar.GroupMode();
	local z, gtype, target;
	if ( inRaid ) then
		z = GetNumRaidMembers();
		gtype = "raid";
	elseif ( inParty ) then
		z = GetNumPartyMembers();
		gtype = "party";
	else
		return ""; 
	end
	for i = 1,z do
		if ( UnitName(gtype..i)==name ) then
			return gtype..i;
		end
	end
	return "";
end

-- Parse data after /slash command
function MarkBar.ParamParser(msg)
 	if msg then
 		local a,b,c=strfind(msg, "(%S+)");
 		if a then
 			return c, strsub(msg, b+2);
 		else	
 			return "";
 		end
 	end
end;

-- PrintFunction ->
function MarkBar.Print (msg)
	DEFAULT_CHAT_FRAME:AddMessage(COLOR_ORANGE..MarkBar.title..": "..COLOR_END..msg);
end

-- GroupMode ->
function MarkBar.GroupMode()
	local inRaid = (GetNumRaidMembers() > 0);
	local inParty = (GetNumPartyMembers() > 0);
	return inParty, inRaid; 
end