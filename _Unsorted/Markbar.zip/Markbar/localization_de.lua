if ( GetLocale() == "deDE" ) then
-- Colours
COLOR_RED = "|cffff0000";
COLOR_GREEN = "|cff00ff00";
COLOR_BLUE = "|cff0000ff";
COLOR_PURPLE = "|cff700090";
COLOR_YELLOW = "|cffffff00";
COLOR_ORANGE = "|cffff6d00";
COLOR_GREY = "|cff808080";
COLOR_GOLD = "|cffcfb52b";
COLOR_WHITE = "|cffffffff";
COLOR_NEON_BLUE = "|cff4d4dff";
COLOR_END = "|r";

	-- general
	MarkBar_MARK = "Zeichen";
	MarkBar_SETTINGS = "Einstellungen";
	MarkBar_ANNOUNCE = "Zuteilung ansagen";
	MarkBar_REMOVEMARK = "Entfernen";
	MarkBar_MARKSANNOUNCETITLE = "Zeichenbeschreibung:";
	MarkBar_ASSIGNED = "%s auf %s zugeordnet!";

	-- help
	MarkBar_HELP1 = "zeigt/versteckt die Toolbar.";
	MarkBar_HELP2 = "(n=0,1) 1=aktiviert die Toolbar beim betreten einer Gruppe/Raid, 0=deaktiviert.";
	MarkBar_HELP3 = "standard Einstellungen laden.";
	MarkBar_HELP4 = "(n=0-1) stellt die Tranzparenz ein.";
	MarkBar_HELP5 = "(n=0-1) stellt die Gr\195\182\195\159e ein.";
	MarkBar_HELP6 = "(n=0-8) setzt das Zeichen auf das aktuelle Ziel.";
	MarkBar_HELP7 = "(n=0,1) 1=erlaubt Gruppenmitglieder Zeichen zu setzen, 0=verboten.";
	MarkBar_HELP8 = "(n=0,1) 1=zeigt den Tooltip, 0=versteckt.";
	MarkBar_HELP9 = "(n=0,1) 1=nicht gesetzte Spielerzuteilungen werden nicht angesagt, 0=alle Zeichen werden Beschrieben.";
	MarkBar_HELP10 = " sperrt/entsperrt die Toolbar.";

	-- Stuff
	MarkBar_LOCK = "gesperrt";
	MarkBar_UNLOCK = "entsperrt";

	-- marks
	MarkBar_MARKNAME1 = "{rt1}";
	MarkBar_MARKNAME2 = "{rt2}";
	MarkBar_MARKNAME3 = "{rt3}";
	MarkBar_MARKNAME4 = "{rt4}";
	MarkBar_MARKNAME5 = "{rt5}";
	MarkBar_MARKNAME6 = "{rt6}";
	MarkBar_MARKNAME7 = "{rt7}";
	MarkBar_MARKNAME8 = "{rt8}";

	-- UI labels
	MarkBar_LB_CLEARASSIGN = "L\195\182schen >";
	MarkBar_LB_ASSIGNWARN = "Zuordnung nicht in diesem Profil gespeichert.";
	MarkBar_LB_CLOSE = "Schlie\195\159en";
	MarkBar_LB_AUTOTOGGLE = "Automatisch zeigen wenn Gruppe/Raid beigetreten.";
	MarkBar_LB_SHOWTOOLTIP = "Zeige Tooltip";
	MarkBar_LB_SKIPNA = "Nicht gesetzte Spielerzuteilungen nicht verbreiten.";
	MarkBar_LB_ALPHA = "Transparenz einstellen";
	MarkBar_LB_SCALE = "Skalierung einstellen";
	MarkBar_LB_MARKS = "Zeichen";
	MarkBar_LB_SETTINGS = "Einstellung";
	MarkBar_LB_LOCK_FRAME = "Sperren";

	-- errors
	MarkBar_ERRUNKNOWNCMD = "Fehler: Unbekannter Befehl.";
	MarkBar_NOTASSIGNED = "Nicht zugeteilt";
	MarkBar_NOTGROUPED = "Fehler: Du bist in keiner Gruppe/Schlachtzug.";
	MarkBar_ERRICONNUMBER = "Unbekannte Iconnummer.";
end