if ( GetLocale() == "esES" ) then
	-- � � \195\129 \195\161
	-- � � \195\137 \195\169
	-- � � \195\141 \195\173
	-- � � \195\147 \195\179
	-- � � \195\154 \195\186
	-- � � \195\145 \195\177
	
	-- general
	MarkBar_MARK = "Marca";
	MarkBar_SETTINGS = "Ajustes";
	MarkBar_ANNOUNCE = "Anunciar marcas";
	MarkBar_REMOVEMARK = "Quitar";
	MarkBar_MARKSANNOUNCETITLE = "Explicaci\195\179n de Marcas:";
	MarkBar_ASSIGNED = "%s asignada a %s";

	-- help
	MarkBar_HELP1 = "muestra/oculta barra.";
	MarkBar_HELP2 = "(n=0,1) 1=habilita mostrar auto al unirse/dejar grupo, 0=deshabilita.";
	MarkBar_HELP3 = "resetea a valores por defecto.";
	MarkBar_HELP4 = "(n=0-1) establece la transparencia de la barra.";
	MarkBar_HELP5 = "(n=0-1) establece la escala de la barra.";
	MarkBar_HELP6 = "(n=0,8) establece la marca del objetivo (\195\186til para usarse en macros).";
	MarkBar_HELP7 = "(n=0,1) 1=permite marcar a otros miembros del grupo, 0=no permite.";
	MarkBar_HELP8 = "(n=0,1) 1=muestra tooltip al pasar el rat�n, 0=no muestra.";
	MarkBar_HELP9 = "(n=0,1) 1=omite en el anuncio las marcas sin asignaci\195\179n, 0=no omite.";
	MarkBar_HELP10 = " toggles toolbarklock.";

	-- Stuff
	MarkBar_LOCK = "locked";
	MarkBar_UNLOCK = "unlocked";

	-- marks
	MarkBar_MARKNAME1 = "{rt1}";
	MarkBar_MARKNAME2 = "{rt2}";
	MarkBar_MARKNAME3 = "{rt3}";
	MarkBar_MARKNAME4 = "{rt4}";
	MarkBar_MARKNAME5 = "{rt5}";
	MarkBar_MARKNAME6 = "{rt6}";
	MarkBar_MARKNAME7 = "{rt7}";
	MarkBar_MARKNAME8 = "{rt8}";
	
	-- UI labels
	MarkBar_LB_CLEARASSIGN = "Quitar >>";
	MarkBar_LB_ASSIGNWARN = "Las asignaciones no se guardan con el perfil";
	MarkBar_LB_CLOSE = "Cerrar";
	MarkBar_LB_AUTOTOGGLE = "Se muestra/oculta autom\195\161ticamente al unirse/dejar un grupo";
	MarkBar_LB_SHOWTOOLTIP = "Mostrar tooltip en iconos";
	MarkBar_LB_SKIPNA = "Omite en el anuncio las marcas sin asignaci\195\179n";
	MarkBar_LB_ALPHA = "Transparencia barra";
	MarkBar_LB_SCALE = "Escala barra";
	MarkBar_LB_MARKS = "Marcas";
	MarkBar_LB_SETTINGS = "Configuraci\195\179n";

	-- errors
	MarkBar_ERRUNKNOWNCMD = "Error: Comando desconocido.";
	MarkBar_NOTASSIGNED = "Sin asignar";
	MarkBar_NOTGROUPED = "Error: No est\195\161s en un grupo o banda";
	MarkBar_ERRICONNUMBER = "N\195\186mero de icono no v\195\161lido";
end