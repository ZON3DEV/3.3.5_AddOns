﻿local L =  LibStub:GetLibrary("AceLocale-3.0"):NewLocale("Grid2Options", "koKR")
if not L then return end

L["raid-debuffs"] = "레이드 디버프"
