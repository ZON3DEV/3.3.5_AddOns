﻿local L =  LibStub:GetLibrary("AceLocale-3.0"):NewLocale("Grid2Options", "zhCN")
if not L then return end

L["raid-debuffs"] = "raid-debuffs"
