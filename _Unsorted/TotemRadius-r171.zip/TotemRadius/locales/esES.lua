local folder, core = ...
local L = LibStub("AceLocale-3.0"):NewLocale(folder, "esES")
if not L then return end
L["Add other shaman's totems to your minimap."] = "Añadir otros tótems de chamanes a tu minimapa."
L["Air Colour"] = "Color Aire"
L["Colour of the circle around the totem"] = "Color del círculo alrededor del tótem"
L["Core"] = "Núcleo"
L["Earth Colour"] = "Color Tierra"
L["Enable"] = "Habilitar"
L["Enables / Disables the addon"] = "Habilita / Deshabilita el addon"
L["Fire Colour"] = "Color Fuego"
L["Hide the icon if we're beyond * yards away."] = "Ocultar el icono si estamos más lejos de * metros."
L["Icon Size"] = "Tamaño del Icono"
L["Minimap Show Range"] = "Mostrar Rango en Minimapa"
L["Size of the totem icon on the minimap. (Not the circle)"] = "Tamaño del icono del minimapa. (El círculo no)"
L["Track other's totems"] = "Rastrear tótems de otros"
L["Water Colour"] = "Color Agua"
