local lineAdded = false
members = {}
memberInspect = {}

local function HandlePartyMember(tooltip, member)
	if CanInspect(member) then
		unitname = UnitName(member)
		memberInspect[unitname] = {}
		NotifyInspect(member)
		for i=1, 18 do
    			iLink = GetInventoryItemLink(member, i);
    			if(iLink ~= nil)then
       				--iLvl = GetItemLevel(iLink);
				memberInspect[unitname][i] = iLink
				name, link, quality, iLevel, reqLevel, class, subclass, maxStack, equipSlot, texture, vendorPrice = GetItemInfo(iLink)

				tt_name, tt_link = tooltip:GetItem()
				tt_name, tt_link, tt_quality, tt_iLevel, tt_reqLevel, tt_class, tt_subclass, tt_maxStack, tt_equipSlot, tt_texture, tt_vendorPrice = GetItemInfo(tt_link)
				
				if (tt_class == "Weapon") then
					if(class == "Weapon") then
						tooltip:AddLine(format("%s [%d] %s", unitname, iLevel, name), GetItemQualityColor(quality))
					end
				else
					if (tt_equipSlot == equipSlot) then
						tooltip:AddLine(format("%s [%d] %s", unitname, iLevel, name), GetItemQualityColor(quality))
					elseif (tt_equipSlot == "INVTYPE_CHEST" and equipSlot == "INVTYPE_ROBE") then
						tooltip:AddLine(format("%s [%d] %s", unitname, iLevel, name), GetItemQualityColor(quality))
					end
				end
    			end
 		end
	end
end

local function OnTooltipSetItem(tooltip, ...)
	if not lineAdded then
		HandlePartyMember(tooltip, "party1")
		HandlePartyMember(tooltip, "party2")
		HandlePartyMember(tooltip, "party3")
		HandlePartyMember(tooltip, "party4")
		HandlePartyMember(tooltip, "party5")
		lineAdded = true
	end
end


local function OnTooltipCleared(tooltip, ...)
  lineAdded = false
end

GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
GameTooltip:HookScript("OnTooltipCleared", OnTooltipCleared)