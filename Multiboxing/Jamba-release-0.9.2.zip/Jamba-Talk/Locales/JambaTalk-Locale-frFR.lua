--[[
Jamba - Jafula's Awesome Multi-Boxer Assistant
Copyright 2008 - 2011 Michael "Jafula" Miller
All Rights Reserved
http://wow.jafula.com/addons/jamba/
jamba at jafula dot com
]]--

local L = LibStub("AceLocale-3.0"):NewLocale( "Jamba-Talk", "frFR" )
if L then
L["Slash Commands"] = "Commandes"
L["Chat"] = "Bavarder"
L["Talk"] = "Discussion"
L["Push Settings"] = "Transférer"
L["Push the talk settings to all characters in the team."] = "Transférer les réglages de discussion à tous les personnages de l'équipe"
L["Settings received from A."] = function( characterName )
	return string.format( "Réglages reçus de %s.", characterName )
end
L["Talk Options"] = "Options de discussion"
L["Forward Whispers To Master And Relay Back"] = "Transférer les chuchotements"
L["Forward Using Normal Whispers"] = "Transférer en utilisant des chuchotements normaux"
L["Chat Snippets"] = "Extraits de conversation"
L["Remove"] = "Supprimer"
L["Snippet Text"] = "Extrait de texte"
L["Add"] = "Ajouter"
L["Enter the shortcut text for this chat snippet:"] = "Saisir le raccourci pour cet extrait de conversation : "
L["Are you sure you wish to remove the selected chat snippet?"] = "Etes-vous sûr(e) de vouloir supprimer l'extrait de conversation sélectionné ?"
L["<GM>"] = "<MJ>"
L["GM"] = "MJ"
L[" whispers: "] = "chuchote : "
L["Forward Via Fake Whispers For Clickable Links And Players"] = "Simuler chuchotements aux joueurs"
L["Enable Chat Snippets"] = "Permettre extraits de conversation"
L["(RealID)"] = "(Nom réel)"
L["Add Forwarder To Reply Queue On Master"] = "Ajouter le transféreur à la liste de réponse sur le maître"
L["Only Show Messages With Links"] = "Ne montrer que les messages avec des liens"
L["Add Originator To Reply Queue On Master"] = "Ajouter l'expéditeur à la liste de réponse sur le maître"
L["Send Fake Whispers To"] = "Envoyer les faux chuchotements à "
L[" "] = " "
L[" (via "] = " (via "
L[")"] = ")"
L["Update"] = "actualiser"
L["whispered you."] = "vous a chuchoté."
end
