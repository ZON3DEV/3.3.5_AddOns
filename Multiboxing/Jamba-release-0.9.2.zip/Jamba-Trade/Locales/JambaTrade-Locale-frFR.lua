--[[
Jamba - Jafula's Awesome Multi-Boxer Assistant
Copyright 2008 - 2011 Michael "Jafula" Miller
All Rights Reserved
http://wow.jafula.com/addons/jamba/
jamba at jafula dot com
]]--

local L = LibStub("AceLocale-3.0"):NewLocale( "Jamba-Trade", "frFR" )
if L then
L["Slash Commands"] = "Commandes"
L["Interaction"] = "interaction"
L["Trade"] = "Echange"
L["Trade Options"] = "Optiosn d'échange"
L["Push Settings"] = "Appliquer les réglages"
L["Push the trade settings to all characters in the team."] = true
L["Settings received from A."] = function( characterName )
	return "Réglages reçus de "..characterName.."."
end
L["Message Area"] = "Zone de message"
L["Load Item By Name"] = "Ajouter objet par nom"
L["Load a certain amount of an item by name into the trade window."] = "Ajouter une quantité d'un objet par nom dans la fenêtre d'échange"
L["Load Items By Type"] = "Ajouter objets par type"
L["Load items by type into the trade window."] = "Ajouter objets par type dans la fenêtre d'échange"
L["Load Mine"] = "Ajouter les miens"
L["Load Theirs"] = "Ajouter les leurs"
L["Jamba-Trade: Please provide a class and a subclass seperated by a comma for the loadtype command."] = "Jamba-Echange : merci d'indiquer une classe et une sous-classe séparés par une virgule pour la commande loadtype"
L["Jamba-Trade: Please provide a name and an amount seperated by a comma for the loadname command."] = "Jamba-Echange : merci d'indiquer un nom et une quantité séparés par une virgule pour la commande loadname"
L["!Single Item"] = "!Objet unique"
L["Show Jamba Trade Window On Trade"] = "Afficher la fenêtre Jamba lors d'un échange"
L["Adjust Toon Money While Visiting The Guild Bank"] = "Ajuster l'or du perso lors des visites à la banque de guilde"
L["Amount of Gold"] = "Quantité d'or"
L["!Quality"] = "!Qualité"
L["0. Poor (gray)"] = "0. Mauvais (gris)"
L["1. Common (white)"] = "1. Commun (blanc)"
L["2. Uncommon (green)"] = "2. Inhabituel (vert)"
L["3. Rare / Superior (blue)"] = "3. Rare (bleu)"
L["4. Epic (purple)"] = "4. Epique (violet)"
L["5. Legendary (orange)"] = "5. Légendaire (orange)"
L["6. Artifact (golden yellow)"] = "6. Artefact (or)"
L["7. Heirloom (light yellow)"] = "7. Héritage (jaune clair)"
L["Unknown"] = "Iconnu"
L["Ignore Soulbound"] = "Ignorer objets liés"
L["Trade Excess Gold To Master From Slave"] = true
L["Amount Of Gold To Keep"] = true
end
