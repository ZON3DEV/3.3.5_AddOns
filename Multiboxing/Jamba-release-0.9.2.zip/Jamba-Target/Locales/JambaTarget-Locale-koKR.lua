--[[
Jamba - Jafula's Awesome Multi-Boxer Assistant
Copyright 2008 - 2011 Michael "Jafula" Miller
All Rights Reserved
http://wow.jafula.com/addons/jamba/
jamba at jafula dot com
]]--

local L = LibStub("AceLocale-3.0"):NewLocale( "Jamba-Target", "koKR", true )
L["Slash Commands"] = true
L["Combat"] = true
L["Target"] = true
L["Push Settings"] = true
L["Push the target settings to all characters in the team."] = true
L["Settings received from A."] = function( characterName )
	return string.format( "Settings received from %s.", characterName )
end
L["Target Options"] = true
