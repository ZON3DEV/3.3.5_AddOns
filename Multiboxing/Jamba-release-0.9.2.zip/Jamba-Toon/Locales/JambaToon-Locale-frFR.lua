--[[
Jamba - Jafula's Awesome Multi-Boxer Assistant
Copyright 2008 - 2011 Michael "Jafula" Miller
All Rights Reserved
http://wow.jafula.com/addons/jamba/
jamba at jafula dot com
]]--

local L = LibStub( "AceLocale-3.0" ):NewLocale( "Jamba-Toon", "frFR" )
if L then
L["Slash Commands"] = "Commandes"
L["Toon: Warnings"] = "Personnage : Alertes"
L["Push Settings"] = "Transférer"
L["Push the toon settings to all characters in the team."] = "Transférer les réglages de personnages à tous les personnages de l'équipe."
L["Settings received from A."] = function( characterName )
	return string.format( "Réglages reçus de %s.", characterName )
end
L["Toon"] = "Personnage"
L[": "] = " : "
L["I'm Attacked!"] = "Je suis attaqué !"
L["Not Targeting!"] = "Pas de cible !"
L["Not Focus!"] = "Pas de focus !"
L["Low Health!"] = "Vie faible !"
L["Low Mana!"] = "Mana faible !"
L["Merchant"] = "Marchand"
L["Auto Repair"] = "Réparation automatique"
L["Auto Repair With Guild Funds"] = "Réparer automatiquement avec les fonds de la guilde"
L["Send Request Message Area"] = "Zone d'envoi de message de requête"
L["Requests"] = "Requêtes"
L["Auto Deny Duels"] = "Automatiquement refuser les duels"
L["Auto Deny Guild Invites"] = "Automatiquement refuser les invitations dans une guilde"
L["Auto Accept Resurrect Request"] = "Automatiquement accepter les résurections"
L["Send Request Message Area"] = "Zone d'envoi de message de requête"
L["Combat"] = "Combat"
L["Health / Mana"] = "Vie / Mana"
L["Bag Space"] = "Emplacement de sac"
L["Bags Full!"] = "Sacs pleins !"
L["Warn If All Regular Bags Are Full"] = "Avertir si tous les sacs ordinaires sont pleins"
L["Bags Full Message"] = "Message de sacs pleins"
L["Warn If Hit First Time In Combat (Slave)"] = "Avertir la 1ère fois si touché en combat"
L["Hit First Time Message"] = "Message d'avertissement"
L["Warn If Target Not Master On Combat (Slave)"] = "Avertir si la cible d'un esclave n'est pas le maître"
L["Warn Target Not Master Message"] = "Message d'avertissement"
L["Warn If Focus Not Master On Combat (Slave)"] = "Avertir si le focus d'un esclave n'est pas le maître"
L["Warn Focus Not Master Message"] = "Message d'avertissement"
L["Warn If My Health Drops Below"] = "Avertir si ma vie tombe sous"
L["Health Amount - Percentage Allowed Before Warning"] = "Pourcentage minimum de vie avant avertissement"
L["Warn Health Drop Message"] = "Message d'avertissement de vie basse"
L["Warn If My Mana Drops Below"] = "Avertir si ma mana tombe sous"
L["Mana Amount - Percentage Allowed Before Warning"] = "Pourcentage minimum de mana avant avertissement"
L["Warn Mana Drop Message"] = "Message d'avertissement de mana basse"
L["Send Warning Area"]  = "Zone d'envoi d'avertissement"
L["I refused a guild invite to: X from: Y"] = function( guild, inviter )
	return string.format( "J'ai refusé une invitation dans la guilde %s par %s", guild, inviter )
end
L["I refused a duel from: X"] = function( challenger )
	return string.format( "J'ai refusé un duel de %s", challenger )
end
L["I do not have enough money to repair all my items."] = "Je n'ai pas assez d'argent pour réparer tout mon équipement."
L["Repairing cost me: X"] = function( costString )
    return string.format( "Repairing cost me: %s", costString )
end
L["I am inactive!"] = "Je suis inactif !"
L["Warn If Toon Goes Inactive (PVP)"] = "Avertir si un perosnnage devient inactif (pvp) !"
L["Inactive Message"] = "Message d'inactivité"
-- Brgin special.
-- This is the inactive buff - you need to make sure it is localized correctly.
-- http://www.wowhead.com/spell=43681
L["Inactive"] = "Inactif" -- checked wowhead - Daeri
-- End special.
L["Currency"] = "Monnaie"
L["Justice Points"] = "Points de justice"
L["JP"] = "PJ"
L["Valor Points"] = "Points de vaillance"
L["VP"] = "PV"
L["Honor Points"] = "Points d'honneur"
L["HP"] = "PH"
L["Conquest Points"] = "Points de conquête"
L["CP"] = "PC"
L["Tol Barad Commendation"] = "Recommandation de Tol Barad"
L["TBC"] = "RTB"
L["Champion's Seal"] = "Sceaux de champion"
L["CS"] = "SC"
L["Illustrious Jewelcrafter's Token"] = "Marque de l'illustre joaillier"
L["IJT"] = "MIJ"
L["Dalaran Jewelcrafting Token"] = "Marque de joaillerie de Dalaran"
L["DJT"] = "MJD"
L["Chef's Award"] = "Récompense de chef"
L["CA"] = "RC"
L["Dalaran Cooking Award"] = "Prix de cuisine de Dalaran"
L["DCA"] = "PCD"
L["Show Currency"] = "Afficher monnaie"
L["Show the current toon the currency values for all members in the team."] = "Afficher sur ce personnage les monnaies de tous les membres de l'équipe"
L["Blizzard Tooltip"] = true
L["Blizzard Dialog Background"] = true
L["Curr"] = "Mon"
L["Jamba Currency"] = "Monnaie Jamba"
L["Update"] = "Actualiser"
L["Gold"] = "Or"
L["Include Gold In Guild Bank"] = "Inclure l'or de la banque de guilde"
L["Total"] = "Total"
L["Guild"] = "Guilde"
L[" ("] = " ("
L[")"] = ")"
L["Currency Selection"] = "Choix de monnaie"
L["Scale"] = "Echelle"
L["Transparency"] = "Transparence"
L["Border Style"] = "Style de bordure"
L["Border Colour"] = "Couleur de bordure"
L["Background"] = "Fond"
L["Background Colour"] = "Couleur de fond"
L["Appearance & Layout"] = "Apparence & Disposition"
L["Space For Name"] = "Espace pour le nom"
L["Space For Gold"] = "Espace pour l'or"
L["Space For Points"] = "Espace pour les points"
L["Space Between Values"] = "Espace entre les valeurs"
L["Lock Currency List (enables mouse click-through)"] = "Verrouiller la liste de monnaie (permet de cliquer au travers)"
L["Open Currency List On Start Up (Master Only)"] = true
end
