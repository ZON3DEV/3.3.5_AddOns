-- --------------------
-- TellMeWhen (Fan Update)
-- by Oozebull of Twisting Nether
-- --------------------


-- -------------
-- ADDON GLOBALS
-- -------------

TellMeWhen = {};

TELLMEWHEN_VERSION = "1.2.0";
TELLMEWHEN_MAXGROUPS = 8;
TELLMEWHEN_MAXROWS = 7;
TELLMEWHEN_ICONSPACING = 2;
TELLMEWHEN_UPDATE_INTERVAL = 0.2;

TellMeWhen_Icon_Defaults = {
	BuffOrDebuff		= "HELPFUL",
	BuffShowWhen		= "present",
	CooldownShowWhen	= "usable",
	CooldownType		= "spell",
	Enabled				= false,
	Name				= "",
	OnlyMine			= false,
	ShowTimer			= false,
	Type				= "",
	Unit				= "player",
	WpnEnchantType		= "mainhand",
};



TellMeWhen_Group_Defaults = {
	Enabled			= false,
	Scale			= 2.0,
	Rows			= 1,
	Columns			= 4,
	Icons			= {},
	OnlyInCombat	= false,
	PrimarySpec		= true,
	SecondarySpec	= true,
};

for iconID = 1, TELLMEWHEN_MAXROWS*TELLMEWHEN_MAXROWS do
	TellMeWhen_Group_Defaults["Icons"][iconID] = TellMeWhen_Icon_Defaults;
end;

TellMeWhen_Defaults = {
	Version 		= 	TELLMEWHEN_VERSION,
	Locked 			= 	false,
	Groups 			= 	{}, 
};

for groupID = 1, TELLMEWHEN_MAXGROUPS do
	TellMeWhen_Defaults["Groups"][groupID] = TellMeWhen_Group_Defaults;
	if (groupID == 1) then
		TellMeWhen_Defaults["Groups"][groupID].Enabled = true;
	end
end

--	TellMeWhen_Settings_Metatable = {};
--	TellMeWhen_Settings_Metatable.__index = TellMeWhen_Defaults;

function TellMeWhen_Test(stuff)
	if ( stuff ) then
		DEFAULT_CHAT_FRAME:AddMessage("TellMeWhen test: "..stuff);
	else
		DEFAULT_CHAT_FRAME:AddMessage("TellMeWhen test: "..this:GetName());
	end



end

-- ---------------
-- EXECUTIVE FRAME
-- ---------------

function TellMeWhen_OnEvent(self, event)
	if ( event == 'VARIABLES_LOADED' ) then
		SlashCmdList["TELLMEWHEN"] = TellMeWhen_SlashCommand;
		SLASH_TELLMEWHEN1 = "/tellmewhen";
		SLASH_TELLMEWHEN2 = "/tmw";
		if ( not TellMeWhen_Settings ) then
			TellMeWhen_Settings = CopyTable(TellMeWhen_Defaults);
			TellMeWhen_Settings["Groups"][1]["Enabled"] = true;
		elseif ( TellMeWhen_Settings["Version"] < TELLMEWHEN_VERSION ) then
			TellMeWhen_SafeUpgrade();
		end
	elseif ( event == "PLAYER_LOGIN" ) or ( event == "PLAYER_ENTERING_WORLD" ) then
		-- initialization needs to be late enough that the icons can find their textures
		self:RegisterEvent("PLAYER_TALENT_UPDATE");
		TellMeWhen_Update();
	elseif ( event == "PLAYER_TALENT_UPDATE") then
		TellmeWhen_TalentUpdate();
		TellMeWhen_Update();
	end
end

function TellMeWhen_SafeUpgrade()
	TellMeWhen_Settings = TellMeWhen_AddNewSettings(TellMeWhen_Settings, TellMeWhen_Defaults);
	TellMeWhen_Settings["Version"] = TELLMEWHEN_VERSION;
	--  Convert 1.1.6 to 1.2.0 settings
	for groupID = 1, TELLMEWHEN_MAXGROUPS do
		if (groupID < 5) then 
			oldgroupSettings = TellMeWhen_Settings["Spec"][1]["Groups"][groupID];
			TellMeWhen_Settings["Groups"][groupID]["SecondarySpec"] = false;
		else
			--  get Spec2 groups 1-4 for new groups 5-8
			local temp_groupID = groupID-4;
			TellMeWhen_Settings["Groups"][groupID]["PrimarySpec"] = false;
			oldgroupSettings = TellMeWhen_Settings["Spec"][2]["Groups"][temp_groupID];
			--  need to copy old frames 1-4 positions to 5-8  (THIS DOESN'T WORK, RUN TOO EARLY DURING LOAD?)
			-- local oldgroup = getglobal("TellMeWhen_Group"..temp_groupID);
			-- local newgroup = getglobal("TellMeWhen_Group"..groupID);
			-- local point, relativeTo, relativePoint, xOfs, yOfs = oldgroup:GetPoint();
			-- newgroup:SetPoint(point,relativeTo,relativePoint,xOfs,yOfs);
			--  end copy frame positions
		end
		if (oldgroupSettings) then
			TellMeWhen_Settings["Groups"][groupID]["Enabled"] = oldgroupSettings.Enabled;
			TellMeWhen_Settings["Groups"][groupID]["Scale"] = oldgroupSettings.Scale;
			TellMeWhen_Settings["Groups"][groupID]["Rows"] = oldgroupSettings.Rows;
			TellMeWhen_Settings["Groups"][groupID]["Columns"] = oldgroupSettings.Columns;
			TellMeWhen_Settings["Groups"][groupID]["OnlyInCombat"] = oldgroupSettings.OnlyInCombat;
		end

		for iconID = 1, TELLMEWHEN_MAXROWS*TELLMEWHEN_MAXROWS do
			if (oldgroupSettings) then 
				oldiconSettings = oldgroupSettings["Icons"][iconID];
				if (oldiconSettings) then
					iconSettings = TellMeWhen_Settings["Groups"][groupID]["Icons"][iconID];
					iconSettings.BuffOrDebuff = oldiconSettings.BuffOrDebuff;
					iconSettings.BuffShowWhen = oldiconSettings.BuffShowWhen;
					iconSettings.CooldownShowWhen = oldiconSettings.CooldownShowWhen;
					iconSettings.CooldownType = oldiconSettings.CooldownType;
					iconSettings.Enabled = oldiconSettings.Enabled;
					iconSettings.Name = oldiconSettings.Name;
					iconSettings.OnlyMine = oldiconSettings.OnlyMine;
					iconSettings.ShowTimer = oldiconSettings.ShowTimer;
					iconSettings.Type = oldiconSettings.Type;
					iconSettings.Unit = oldiconSettings.Unit;
					iconSettings.WpnEnchantType = oldiconSettings.WpnEnchantType;
				end
			end
			if (iconSettings.Name == "" and iconSettings.type ~= "wpnenchant") then
				TellMeWhen_Settings["Groups"][groupID]["Icons"][iconID]["Enabled"] = false;
			end
		end
	end
	TellMeWhen_Settings["Spec"] = nil;  -- Remove "Spec" {}
	-- End convert 1.1.6 to 1.2.0
end

function TellMeWhen_AddNewSettings(settings, defaults)
	for k, v in pairs(defaults) do
		if ( not settings[k] ) then
			if ( type(v) == "table" ) then
				settings[k] = {};
				settings[k] = TellMeWhen_AddNewSettings(settings[k], defaults[k]);
			else
				settings[k] = v;
			end

		--[[
		elseif ( type(v) == "table" ) and ( type(settings[k]) ~= "table" ) then
			local oldSetting = settings[k];
			settings[k] = {};
			settings[k][1] = oldSetting;
			--	settings[k] = {settings[k]};
		--]]

		elseif ( type(v) == "table" ) then
			settings[k] = TellMeWhen_AddNewSettings(settings[k], defaults[k]);
		end
	end
	return settings;
end

function TellMeWhen_Update()
	for groupID = 1, TELLMEWHEN_MAXGROUPS do
		TellMeWhen_Group_Update(groupID);
	end
end

do
	local executiveFrame = CreateFrame("Frame", "TellMeWhen_ExecutiveFrame");
	executiveFrame:SetScript("OnEvent", TellMeWhen_OnEvent);
	executiveFrame:RegisterEvent("VARIABLES_LOADED");
	executiveFrame:RegisterEvent("PLAYER_LOGIN");
	executiveFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
end



-- -----------
-- GROUP FRAME
-- -----------

function TellMeWhen_Group_OnEvent(self, event)
	-- called if OnlyInCombat true for this group
	if ( event == "PLAYER_REGEN_DISABLED" ) then
		self:Show();
	elseif ( event == "PLAYER_REGEN_ENABLED" ) then
		self:Hide();
	end
end

function TellMeWhen_Group_Update(groupID)
	local currentSpec = TellmeWhen_GetActiveTalentGroup();
	local groupName = "TellMeWhen_Group"..groupID;
	local group = getglobal(groupName);
	local resizeButton = getglobal(groupName.."_ResizeButton");

	local locked = TellMeWhen_Settings["Locked"];
	local enabled = TellMeWhen_Settings["Groups"][groupID]["Enabled"];
	local scale = TellMeWhen_Settings["Groups"][groupID]["Scale"];
	local rows = TellMeWhen_Settings["Groups"][groupID]["Rows"];
	local columns = TellMeWhen_Settings["Groups"][groupID]["Columns"];
	local onlyInCombat = TellMeWhen_Settings["Groups"][groupID]["OnlyInCombat"];
	local activePriSpec = TellMeWhen_Settings["Groups"][groupID]["PrimarySpec"];
	local activeSecSpec = TellMeWhen_Settings["Groups"][groupID]["SecondarySpec"];
	
	if (currentSpec==1 and not activePriSpec) or (currentSpec==2 and not activeSecSpec) then
		enabled = false;
	end
	
	if (enabled) then 
		for row = 1, rows do
			for column = 1, columns do
				local iconID = (row-1)*columns + column; 
				local iconName = groupName.."_Icon"..iconID;
				local icon = getglobal(iconName) or CreateFrame("Frame", iconName, group, "TellMeWhen_IconTemplate");
				icon:SetID(iconID);
				icon:Show();
				if ( column > 1 ) then
					icon:SetPoint("TOPLEFT", getglobal(groupName.."_Icon"..(iconID-1)), "TOPRIGHT", TELLMEWHEN_ICONSPACING, 0);
				elseif ( row > 1 ) and ( column == 1 ) then 
					icon:SetPoint("TOPLEFT", getglobal(groupName.."_Icon"..(iconID-columns)), "BOTTOMLEFT", 0, -TELLMEWHEN_ICONSPACING);
				elseif ( iconID == 1 ) then 
					icon:SetPoint("TOPLEFT", group, "TOPLEFT");
				end
				TellMeWhen_Icon_Update(icon, groupID, iconID);
				if ( not enabled ) then
					TellMeWhen_Icon_ClearScripts(icon);
				end
			end
		end
		for iconID = rows*columns+1, TELLMEWHEN_MAXROWS*TELLMEWHEN_MAXROWS do
			local icon = getglobal(groupName.."_Icon"..iconID);
			if icon then
				icon:Hide();
				TellMeWhen_Icon_ClearScripts(icon);
			end
		end

		group:SetScale(scale);
		local lastIcon = groupName.."_Icon"..(rows*columns);
		resizeButton:SetPoint("BOTTOMRIGHT", lastIcon, "BOTTOMRIGHT", 3, -3);
		if ( locked ) then
			resizeButton:Hide();
		else
			resizeButton:Show();
		end


	end -- ENABLED
		
	if ( onlyInCombat and enabled and locked ) then
		group:RegisterEvent("PLAYER_REGEN_ENABLED");
		group:RegisterEvent("PLAYER_REGEN_DISABLED");
		group:SetScript("OnEvent", TellMeWhen_Group_OnEvent);
		group:Hide();
	else
		group:UnregisterEvent("PLAYER_REGEN_ENABLED");
		group:UnregisterEvent("PLAYER_REGEN_DISABLED");
		group:SetScript("OnEvent", nil);
		if ( enabled ) then
			group:Show();
		else
			group:Hide();
		end
	end
end



-- -------------
-- ICON FUNCTION
-- -------------

function TellMeWhen_Icon_Update(icon, groupID, iconID)

	local iconSettings = TellMeWhen_Settings["Groups"][groupID]["Icons"][iconID];
	local enabled = iconSettings.Enabled;
	local iconType = iconSettings.Type;
	local cooldownType = iconSettings.CooldownType;
	local cooldownShowWhen = iconSettings.CooldownShowWhen;
	local buffShowWhen = iconSettings.BuffShowWhen;
	icon.name = iconSettings.Name;
	icon.unit = iconSettings.Unit;
	icon.showTimer = iconSettings.ShowTimer;
	icon.onlyMine = iconSettings.OnlyMine;
	icon.buffOrDebuff = iconSettings.BuffOrDebuff;
	icon.wpnEnchantType = iconSettings.WpnEnchantType;

	icon.updateTimer = TELLMEWHEN_UPDATE_INTERVAL;

	icon.texture = getglobal(icon:GetName().."Texture");
	icon.countText = getglobal(icon:GetName().."Count");
	icon.cooldown = getglobal(icon:GetName().."Cooldown");

	icon:UnregisterEvent("ACTIONBAR_UPDATE_USABLE");
	icon:UnregisterEvent("PLAYER_TARGET_CHANGED");
	icon:UnregisterEvent("PLAYER_FOCUS_CHANGED");
	icon:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	icon:UnregisterEvent("UNIT_INVENTORY_CHANGED");
	icon:UnregisterEvent("ACTIONBAR_UPDATE_COOLDOWN");
	icon:UnregisterEvent("BAG_UPDATE_COOLDOWN");
	icon:UnregisterEvent("UNIT_AURA");
	
	if ( TellMeWhen_Settings["Locked"] and not enabled) then
	    -- DO NOTHING
	else 
	
		-- used by both cooldown and reactive icons
		if ( cooldownShowWhen == "usable" ) then
			icon.usableAlpha = 1;
			icon.unusableAlpha = 0;
		elseif ( cooldownShowWhen == "unusable" ) then
			icon.usableAlpha = 0;
			icon.unusableAlpha = 1;
		else -- ( cooldownShowWhen == "always")
			icon.usableAlpha = 1;
			icon.unusableAlpha = 1;
		end
		-- used by both buff/debuff and wpnenchant icons
		if ( buffShowWhen == "present" ) then
			icon.presentAlpha = 1;
			icon.absentAlpha = 0;
		elseif ( buffShowWhen == "absent" ) then
			icon.presentAlpha = 0;
			icon.absentAlpha = 1;
		else -- ( buffShowWhen == "always")
			icon.presentAlpha = 1;
			icon.absentAlpha = 1;
		end

		if ( iconType == "cooldown" ) then
			if ( cooldownType == "spell" ) then
				if ( GetSpellCooldown(TellMeWhen_GetSpellNames(icon.name,1)) ) then
					icon.texture:SetTexture(GetSpellTexture(TellMeWhen_GetSpellNames(icon.name,1)));
					icon:SetScript("OnUpdate", TellMeWhen_Icon_SpellCooldown_OnUpdate);
					if (icon.showTimer) then
						icon:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN");
						icon:SetScript("OnEvent", TellMeWhen_Icon_SpellCooldown_OnEvent);
					else
						icon:SetScript("OnEvent", nil);
					end
				else
					TellMeWhen_Icon_ClearScripts(icon);
					icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
				end
			elseif ( cooldownType == "item" ) then
				local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(TellMeWhen_GetItemNames(icon.name,1));
				if ( itemName ) then
					icon.texture:SetTexture(itemTexture);
					icon:SetScript("OnUpdate", TellMeWhen_Icon_ItemCooldown_OnUpdate);
					if (icon.showTimer) then
						icon:RegisterEvent("BAG_UPDATE_COOLDOWN");
						icon:SetScript("OnEvent", TellMeWhen_Icon_ItemCooldown_OnEvent);
					else
						icon:SetScript("OnEvent", nil);
					end
				else
					TellMeWhen_Icon_ClearScripts(icon);
					icon.learnedTexture = false;
					icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
				end
			end
			icon.cooldown:SetReverse(false);

		elseif ( iconType == "buff" ) then

			icon:RegisterEvent("PLAYER_TARGET_CHANGED");
			icon:RegisterEvent("PLAYER_FOCUS_CHANGED");
			icon:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
			icon:RegisterEvent("UNIT_AURA");
			icon:SetScript("OnEvent", TellMeWhen_Icon_Buff_OnEvent);
			icon:SetScript("OnUpdate", nil);

			if ( icon.name == "" ) then
				icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
			elseif ( GetSpellTexture(TellMeWhen_GetSpellNames(icon.name,1)) ) then
				icon.texture:SetTexture(GetSpellTexture(TellMeWhen_GetSpellNames(icon.name,1)));
			elseif ( not icon.learnedTexture ) then
				icon.texture:SetTexture("Interface\\Icons\\INV_Misc_PocketWatch_01");
			end	
			icon.cooldown:SetReverse(true);

		elseif ( iconType == "reactive" ) then
			if ( GetSpellTexture(TellMeWhen_GetSpellNames(icon.name,1)) ) then
				icon.texture:SetTexture(GetSpellTexture(TellMeWhen_GetSpellNames(icon.name,1)));
				icon:RegisterEvent("ACTIONBAR_UPDATE_USABLE");
				icon:SetScript("OnEvent", TellMeWhen_Icon_Reactive_OnEvent);
				icon:SetScript("OnUpdate", nil);
			else
				TellMeWhen_Icon_ClearScripts(icon);
				icon.learnedTexture = false;
				icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
			end	

		elseif ( iconType == "wpnenchant" ) then
			icon:RegisterEvent("UNIT_INVENTORY_CHANGED");
			local slotID;
			if ( icon.wpnEnchantType == "mainhand" ) then
				slotID, _ = GetInventorySlotInfo("MainHandSlot");
			elseif ( icon.wpnEnchantType == "offhand" ) then
				slotID, _ = GetInventorySlotInfo("SecondaryHandSlot");
			end
			local wpnTexture = GetInventoryItemTexture("player", slotID);
			if ( wpnTexture ) then 
				icon.texture:SetTexture(wpnTexture);
				icon:SetScript("OnEvent", TellMeWhen_Icon_WpnEnchant_OnEvent);
				icon:SetScript("OnUpdate", TellMeWhen_Icon_WpnEnchant_OnUpdate);
			else
				TellMeWhen_Icon_ClearScripts(icon);
				icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
			end

		else
			TellMeWhen_Icon_ClearScripts(icon);
			if ( icon.name ~= "" ) then
				icon.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
			else
				icon.texture:SetTexture(nil);
			end
		end
	end -- ENABLED CHECK
	
	icon.countText:Hide();
	icon.cooldown:Hide();

	if ( enabled ) then
		icon:SetAlpha(1.0);
	else
		icon:SetAlpha(0.4);
		TellMeWhen_Icon_ClearScripts(icon);
	end

	icon:Show();
	if ( TellMeWhen_Settings["Locked"] ) then
		icon:EnableMouse(0);
		if ( not enabled ) then
			icon:Hide();
		elseif (icon.name == "") and ( iconType ~= "wpnenchant" ) then
			icon:Hide();
		end
		TellMeWhen_Icon_StatusCheck(icon, iconType);
	else
		icon:EnableMouse(1);
		icon.texture:SetVertexColor(1, 1, 1, 1);
		TellMeWhen_Icon_ClearScripts(icon);
	end
end

function TellMeWhen_Icon_ClearScripts(icon)
	icon:SetScript("OnEvent", nil);
	icon:SetScript("OnUpdate", nil);
end

function TellMeWhen_Icon_StatusCheck(icon, iconType)
	-- this function is so OnEvent-based icons can do a check when the addon is locked
	if ( iconType == "reactive" ) then
		TellMeWhen_Icon_ReactiveCheck(icon);
	elseif ( iconType == "buff" ) then
		TellMeWhen_Icon_BuffCheck(icon);
	elseif ( iconType == "cooldown" ) then
		TellMeWhen_Icon_SpellCooldown_OnEvent(icon);
	end
end

function TellMeWhen_Icon_SpellCooldown_OnEvent(self)
	local startTime, timeLeft, enabled = GetSpellCooldown(TellMeWhen_GetSpellNames(self.name,1));
	if ( timeLeft and timeLeft > 1.5 ) then
		CooldownFrame_SetTimer(self.cooldown, startTime, timeLeft, enabled);
	end
end

function TellMeWhen_Icon_SpellCooldown_OnUpdate(self, elapsed)
	self.updateTimer = self.updateTimer - elapsed;
	if ( self.updateTimer <= 0 ) then 
		self.updateTimer = TELLMEWHEN_UPDATE_INTERVAL;
		local _, timeLeft, _ = GetSpellCooldown(TellMeWhen_GetSpellNames(self.name,1));
		if (timeLeft ~= nil) then
			if ( timeLeft > 1.5 ) then
				self:SetAlpha(self.unusableAlpha);
			elseif ( timeLeft == 0 ) then
				self:SetAlpha(self.usableAlpha);
			end
		end
	end
end

function TellMeWhen_Icon_ItemCooldown_OnEvent(self)
	local startTime, timeLeft, enabled = GetItemCooldown(TellMeWhen_GetItemNames(self.name,1));
	if ( timeLeft > 1.5 ) then
		CooldownFrame_SetTimer(self.cooldown, startTime, timeLeft, enabled);
	end
end

function TellMeWhen_Icon_ItemCooldown_OnUpdate(self, elapsed)
	self.updateTimer = self.updateTimer - elapsed;
	if ( self.updateTimer <= 0 ) then 
		self.updateTimer = TELLMEWHEN_UPDATE_INTERVAL;
		local _, timeLeft, _ = GetItemCooldown(TellMeWhen_GetItemNames(self.name,1));
		if ( timeLeft > 1.5 ) then
			self:SetAlpha(self.unusableAlpha);
		elseif ( timeLeft == 0 ) then
			self:SetAlpha(self.usableAlpha);
		end
	end
end

function TellMeWhen_Icon_Buff_OnEvent(self, event, ...)
	if ( event == "COMBAT_LOG_EVENT_UNFILTERED" ) and ( select(2, ...) == "UNIT_DIED" ) then
		if ( select(6, ...) == UnitGUID(self.unit) ) then
			TellMeWhen_Icon_BuffCheck(self);
		end
	elseif ( event == "UNIT_AURA" ) and ( select(1, ...) == self.unit ) then
		TellMeWhen_Icon_BuffCheck(self);
	elseif ( event == "PLAYER_TARGET_CHANGED" ) or ( event == "PLAYER_FOCUS_CHANGED" ) then
		TellMeWhen_Icon_BuffCheck(self);
	end
end

function TellMeWhen_Icon_BuffCheck(icon)
	if ( UnitExists(icon.unit) ) then
		local auraNames = TellMeWhen_GetSpellNames(icon.name)
		local i, iName
		for i, iName in ipairs(auraNames) do
	--		local buffName, rank, iconTexture, count, debuffType, duration, expirationTime, unitCaster, isStealable;
			local buffName, _, iconTexture, count, _, duration, expirationTime, unitCaster = UnitAura(icon.unit, iName, nil, icon.buffOrDebuff);
			if ( buffName and ((( unitCaster == "player" ) or ( unitCaster == "pet" ) or ( unitCaster == "vehicle" )) or not icon.onlyMine) ) then
				if ( icon.texture:GetTexture() ~= iconTexture ) then
					icon.texture:SetTexture(iconTexture);
					icon.learnedTexture = true;
				end
				icon:SetAlpha(icon.presentAlpha);
				icon.texture:SetVertexColor(1, 1, 1, 1);
				if ( count > 1 ) then
					icon.countText:SetText(count);
					icon.countText:Show();
				else
					icon.countText:Hide();
				end
				if ( icon.showTimer ) then
					CooldownFrame_SetTimer(icon.cooldown, expirationTime - duration, duration, 1);
				end
				return;
			end
			  
		end
		
		icon:SetAlpha(icon.absentAlpha);
		if ( icon.presentAlpha == 1 ) and ( icon.absentAlpha == 1) then
			icon.texture:SetVertexColor(1, 0.35, 0.35, 1);
		end
		
		icon.countText:Hide();
		if ( icon.showTimer ) then
			CooldownFrame_SetTimer(icon.cooldown, 0, 0, 0);
		end
	else
		icon:SetAlpha(0);
	end
end

function TellMeWhen_Icon_Reactive_OnEvent(self, event)
	if ( event == "ACTIONBAR_UPDATE_USABLE" ) then
		TellMeWhen_Icon_ReactiveCheck(self);
	end
end

function TellMeWhen_Icon_ReactiveCheck(icon)
	local usable, nomana = IsUsableSpell(TellMeWhen_GetSpellNames(icon.name,1));
	local _, timeLeft, _ = GetSpellCooldown(icon.name);
	if ( usable ) and ( timeLeft < 1.5 ) then
		icon:SetAlpha(icon.usableAlpha);
	elseif ( not usable and not nomana ) or ( timeLeft > 1.5 ) then
		icon:SetAlpha(icon.unusableAlpha);
	end
end

function TellMeWhen_Icon_WpnEnchant_OnEvent(self, event, ...)
	if ( event == "UNIT_INVENTORY_CHANGED" ) and ( select(1, ...) == "player" ) then
		local slotID;
		if ( self.wpnEnchantType == "mainhand" ) then
			slotID, _ = GetInventorySlotInfo("MainHandSlot");
		elseif ( self.wpnEnchantType == "offhand" ) then
			slotID, _ = GetInventorySlotInfo("SecondaryHandSlot");
		end
		local wpnTexture = GetInventoryItemTexture("player", slotID);
		if ( wpnTexture ) then 
			self.texture:SetTexture(wpnTexture);
		else
			self.texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark");
		end
		self.startTime = GetTime();
	end
end

function TellMeWhen_Icon_WpnEnchant_OnUpdate(self, elapsed)
	self.updateTimer = self.updateTimer - elapsed;
	if ( self.updateTimer <= 0 ) then 
		self.updateTimer = TELLMEWHEN_UPDATE_INTERVAL;
		local hasMainHandEnchant, mainHandExpiration, mainHandCharges, hasOffHandEnchant, offHandExpiration, offHandCharges = GetWeaponEnchantInfo();
		if ( self.wpnEnchantType == "mainhand" ) and ( hasMainHandEnchant ) then
			self:SetAlpha(self.presentAlpha);
			if ( mainHandCharges > 1 ) then
				self.countText:SetText(mainHandCharges);
				self.countText:Show();
			else
				self.countText:Hide();
			end
			if (self.showTimer) then
				if ( self.startTime ~= nil ) then
					CooldownFrame_SetTimer(self.cooldown, GetTime(), mainHandExpiration/1000, 1);
				else
					self.startTime = GetTime();
				end
			end
		elseif ( self.wpnEnchantType == "offhand" ) and ( hasOffHandEnchant ) then
			self:SetAlpha(self.presentAlpha);
			if ( offHandCharges > 1 ) then
				self.countText:SetText(offHandCharges);
				self.countText:Show();
			else
				self.countText:Hide();
			end
			if (self.showTimer) then
				if ( self.startTime ~= nil ) then
					CooldownFrame_SetTimer(self.cooldown, GetTime(), offHandExpiration/1000, 1);
				else
					self.startTime = GetTime();
				end
			end
		else
			self:SetAlpha(self.absentAlpha);
			CooldownFrame_SetTimer(self.cooldown, 0, 0, 0);
		end
	end
end

function TellMeWhen_GetMatchedBuffName(checkName, buffName)
	local buffNames = TellMeWhen_SplitNames(buffName)
	if tonumber( checkName ) ~= nil then
		checkName = GetSpellInfo(checkName)
	end
	
	local i, iName
	for i, iName in ipairs(buffNames) do
		if ( checkName == iName ) then
			return iName
		end
	end
	
	return nil
end

function TellMeWhen_GetSpellNames(buffName,firstOnly) 
	local buffNames = TellMeWhen_SplitNames(buffName,"spell")
	if (firstOnly ~= nil) then
		return buffNames[1]
	end
	return buffNames
end

function TellMeWhen_GetItemNames(buffName,firstOnly) 
	local buffNames = TellMeWhen_SplitNames(buffName,"item")
	if (firstOnly ~= nil) then
		return buffNames[1]
	end
	return buffNames
end

function TellMeWhen_SplitNames(buffName,convertIDs)
	-- If buffName contains one or more semicolons, split the list into parts
	local buffNames = {}
	if (buffName:find(";") ~= nil) then
		buffNames = { strsplit(";", buffName) }
	else
		buffNames = { buffName }
	end
	
	local i, iName
	for i, iName in ipairs(buffNames) do
		if (tonumber( iName ) ~= nil) then
			if (convertIDs == "item") then
				buffNames[i] = GetItemInfo(iName)
			else
				buffNames[i] = GetSpellInfo(iName)
			end
		end
	end
	
	return buffNames
end

function TellmeWhen_TalentUpdate()
	activeSpec = GetActiveTalentGroup()
end

function TellmeWhen_GetActiveTalentGroup()
	if ( activeSpec == nil ) then
		TellmeWhen_TalentUpdate()
	end
	return activeSpec
end