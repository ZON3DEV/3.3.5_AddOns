﻿
TELLMEWHEN_CMD_RESET = "сброс";
TELLMEWHEN_CMD_OPTIONS = "настройки";

TELLMEWHEN_ICON_TOOLTIP1 = "TellMeWhen";
TELLMEWHEN_ICON_TOOLTIP2 = "Правый клик для настроек. Больше настроек в меню настроек близзарда. Введите /tellmewhen что бы заблокировать и включить аддон.";

TELLMEWHEN_RESIZE = "Изменить размер";
TELLMEWHEN_RESIZE_TOOLTIP = "Нажмите и ведите для изменения размера";

TELLMEWHEN_ICONMENU_CHOOSENAME = "Выбирите заклинание/вещь/бафф/и т.д.";
TELLMEWHEN_CHOOSENAME_DIALOG = "Введите имя или ИД Заклинания/Способности/Дебаффа который эта иконка будет наблюдать. Вы можете добавить разные Баффы/Дебаффы разделяя их ;";
TELLMEWHEN_ICONMENU_ENABLE = "Включить иконку";

TELLMEWHEN_ICONMENU_TYPE = "Тип Иконки";
TELLMEWHEN_ICONMENU_COOLDOWN = "Восстановление";
TELLMEWHEN_ICONMENU_BUFFDEBUFF = "Бафф/Дебафф";
TELLMEWHEN_ICONMENU_REACTIVE = "Реактивировать заклинание или способность";
TELLMEWHEN_ICONMENU_WPNENCHANT = "Временное наложение чар на оружие";

TELLMEWHEN_ICONMENU_OPTIONS = "Больше настроек";

TELLMEWHEN_ICONMENU_COOLDOWNTYPE = "Тип Куллдауна";
TELLMEWHEN_ICONMENU_SPELL = "Заклинание или способность";
TELLMEWHEN_ICONMENU_ITEM = "Вещь";
TELLMEWHEN_ICONMENU_SHOWWHEN = "Показать иконку когда";
TELLMEWHEN_ICONMENU_USABLE = "Используемое";
TELLMEWHEN_ICONMENU_UNUSABLE = "Неиспользуемое";

TELLMEWHEN_ICONMENU_BUFFTYPE = "Бафф или Дебафф?";
TELLMEWHEN_ICONMENU_BUFF = "Бафф";
TELLMEWHEN_ICONMENU_DEBUFF = "Дебафф";
TELLMEWHEN_ICONMENU_UNIT = "Кого наблюдать?";
TELLMEWHEN_ICONMENU_PLAYER = "Игрока";
TELLMEWHEN_ICONMENU_TARGET = "Цель";
TELLMEWHEN_ICONMENU_FOCUS = "Фокус";
TELLMEWHEN_ICONMENU_PET = "Питомец";
TELLMEWHEN_ICONMENU_TARGETTARGET = "Цельцели";
TELLMEWHEN_ICONMENU_FOCUSTARGET = "Цельфокуса";
TELLMEWHEN_ICONMENU_PETTARGET = "Цельпитомца";
TELLMEWHEN_ICONMENU_BUFFSHOWWHEN = "Показать когда бафф/дебафф";
TELLMEWHEN_ICONMENU_PRESENT = "Есть";
TELLMEWHEN_ICONMENU_ABSENT = "Нет";
TELLMEWHEN_ICONMENU_ALWAYS = "Всегда";
TELLMEWHEN_ICONMENU_ONLYMINE = "Показывать только когда колудется мной";
TELLMEWHEN_ICONMENU_SHOWTIMER = "Показать таймер";

TELLMEWHEN_ICONMENU_WPNENCHANTTYPE = "Просмотр слота оружия";
TELLMEWHEN_ICONMENU_MAINHAND = "Главной руки";
TELLMEWHEN_ICONMENU_OFFHAND = "Второй руки";
--	TELLMEWHEN_ICONMENU_WPNSHOWWHEN = "Show when enchant";

TELLMEWHEN_ICONMENU_CLEAR = "Очистить настройки";

TELLMEWHEN_UIPANEL_SUBTEXT1 = "Эти настройки позволят вам менять номер, классификацию, и поведение иконок напоминания.";
TELLMEWHEN_UIPANEL_SUBTEXT2 = "Иконки работают и заблокированы. Когда разблокированы, вы можете двигать/менять размер группы иконок и правым кликом настраивать индивидуальные иконки. Вы также можете ввести '/tellmewhen' или '/tmw' что бы  заблокировать/разблокировать.";
TELLMEWHEN_UIPANEL_ICONGROUP = "Группа иконок ";
TELLMEWHEN_UIPANEL_ROWS = "Ряды";
TELLMEWHEN_UIPANEL_COLUMNS = "Колонки";
TELLMEWHEN_UIPANEL_ONLYINCOMBAT = "Показывать только в бою";
TELLMEWHEN_UIPANEL_PRIMARYSPEC = "Главная спец.";
TELLMEWHEN_UIPANEL_SECONDARYSPEC = "Второстепенная спец.";
TELLMEWHEN_UIPANEL_LOCK = "Заблокировать аддон";
TELLMEWHEN_UIPANEL_UNLOCK = "Разблокировать аддон";
TELLMEWHEN_UIPANEL_TOOLTIP_ENABLEGROUP = "Показать и включить эту группу иконок";
TELLMEWHEN_UIPANEL_TOOLTIP_ROWS = "Установить количество рядов иконок в этой группе";
TELLMEWHEN_UIPANEL_TOOLTIP_COLUMNS = "Установить количество колонок иконок в этой группе";
TELLMEWHEN_UIPANEL_TOOLTIP_ONLYINCOMBAT = "Отметить что бы показывать только эту группу иконок пока в бою";
TELLMEWHEN_UIPANEL_TOOLTIP_PRIMARYSPEC = "Отметить что бы показывать только эту группу иконок пока в главной спец.";
TELLMEWHEN_UIPANEL_TOOLTIP_SECONDARYSPEC = "Отметить что бы показывать только эту группу иконок пока в второстепенной спец.";