-- SkillMonitor
-- Copyright (C) 2008-2009 Verissi of Argent Dawn, All rights reserved.
-- Project home: http://www.wowinterface.com/downloads/info13202-SkillMonitor.html

local SM = "SkillMonitor";
local SM_rev = "1.1.0";

local skillTable={};

-- SM_StatusBar : StatusBar frame handle
local SM_StatusBar;

-- SM_MenuHandle : Menu frame handle
local SM_MenuHandle;

-- SM_OptionsHandle : Options frame handle
local SM_OptionsHandle;

-- Options panel controls
local SM_OptionsPanel_Locked, SM_OptionsPanel_ClickThru, SM_OptionsPanel_Show, SM_OptionsPanel_Reset;

-- SM_options: Table for storing add-on options
SM_options = {};

local SM_defaults = {
	trackID = 0;
	frameLocked = "0";
	frameShown = "1";
    frameClickThru = "1";
}

-- main() {   Old habits die hard
-- Create a frame to hook the events to
local eventFrame = CreateFrame("Frame");
local events = {};

-- Populate the event table with functions that handle those events

function events:PLAYER_LOGIN()
-- events:PLAYER_LOGIN() : Event handler for player login
  SM_OnLoad(self);
end

function events:SKILL_LINES_CHANGED()
  if (SM_MenuHandle ~= nil and SM_StatusBar ~= nil) then
    SM_ReadSkills();
    SM_UpdateBar(SM_options.trackID);
  end
end

function events:PLAYER_LEVEL_UP()
-- events:PLAYER_LEVEL_UP() : Event handler for when a player gains a level
--		Necessary because weapon skill maximums increase with every level
  SM_ReadSkills();
  SM_UpdateBar(SM_options.trackID);
end

function events:CHAT_MSG_SKILL()
-- events:CHAT_MSG_SKILL() : Event handler for when a player gains a skill point
  SM_UpdateBar( SM_options.trackID );
end

-- iterate through the events table and register the respective events
-- Thanks to Halinsback of Darkspear for an example of this lovely shortcut
for key,_ in pairs(events) do
  eventFrame:RegisterEvent(key);
end

-- Set the OnEvent code for the handler functions
eventFrame:SetScript("OnEvent", function(self, event, ...)
  events[event](self, ...);
end);

-- }   main() *giggles*


function SM_OnLoad(self)
-- Called when the add-on is loaded
  if (not SM_options.trackID) then
    SM_options = SM_defaults;
  end
  
  SM_StatusBar = SM_CreateBar();
  SM_ReadSkills();
  SM_MenuHandle = SM_CreateMenu();
  SM_OptionsHandle = SM_CreateOptionsPane();
  
  SM_ToggleClickThru(SM_options.frameClickThru);
  SM_ToggleLock(SM_options.frameLocked);
  
  SLASH_SM1 = "/skillmonitor";
  SLASH_SM2 = "/sm";
  SlashCmdList["SM"] = SM_Command;
end

function SM_CreateBar()
-- Create the StatusBar frame and return the created frame handle
  local bar = CreateFrame("StatusBar", "SkillMonitor_SBar", UIParent, "AchievementProgressBarTemplate");
  bar:SetWidth(120);
  bar:SetHeight(12);
  bar:SetScale(1 / bar:GetEffectiveScale());
  bar:SetOrientation("HORIZONTAL");
  bar:SetStatusBarColor(1, 0, 0, 1);
  bar:SetBackdropColor(0, 0, 0, 0.5);
  
  bar:SetMinMaxValues(1,100);
  bar:SetValue(50);
  
  if (SM_options.x and SM_options.y) then
    bar:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", SM_options.x, SM_options.y);
  else
    bar:SetPoint("CENTER", UIParent, "CENTER", 0, 0);
  end
  bar.text:SetPoint("TOP", bar, "TOP", 0, -1);
  bar.text:SetFontObject("SystemFont_Tiny");
  bar.text:SetTextColor(1, 1, 1);
  
  bar:EnableMouse();
  bar:SetMovable();
  bar:RegisterForDrag("LeftButton");

  bar:SetScript("OnDragStart", SM_StartDrag);
  bar:SetScript("OnDragStop", SM_StopDrag);
  bar:SetScript("OnMouseUp", SM_ClickHandler);

  if (SM_options.frameShown == "1") then
	bar:Show();
  else
    bar:Hide();
  end
  
  return bar;
end

function SM_CreateOptionsPane(...)
  local optionsFrame = CreateFrame("Frame", "SM_OptionsPanel");
  
  optionsFrame.name = "SkillMonitor";
  optionsFrame.default = function (self) SM_OptionsPanel_Default(); end;
  InterfaceOptions_AddCategory(optionsFrame);
 
  SM_OptionsPanel_ClickThru = CreateFrame("CheckButton", "SM_OptionsPanel_ClickThru", optionsFrame, "OptionsCheckButtonTemplate");
  SM_OptionsPanel_ClickThru:SetPoint("TOPLEFT", 16, -16);
  SM_OptionsPanel_ClickThruText:SetText("Enable mouse interaction\n(disabling will lock the skill progress bar's position also)");
  SM_OptionsPanel_ClickThruText:SetJustifyH("LEFT");
  SM_OptionsPanel_ClickThru:SetChecked(SM_options.frameClickThru);
  SM_OptionsPanel_ClickThru.setFunc = SM_ToggleClickThru;
  
  SM_OptionsPanel_Locked = CreateFrame("CheckButton", "SM_OptionsPanel_Locked", SM_OptionsPanel_ClickThru, "OptionsSmallCheckButtonTemplate");
  SM_OptionsPanel_Locked:SetPoint("TOPLEFT", "SM_OptionsPanel_ClickThru", "BOTTOMLEFT", 10, -3);
  SM_OptionsPanel_LockedText:SetText("Locks the skill progress bar");
  SM_OptionsPanel_Locked:SetChecked(SM_options.frameLocked);
  SM_OptionsPanel_Locked.setFunc = SM_ToggleLock;
  
  SM_OptionsPanel_Show = CreateFrame("CheckButton", "SM_OptionsPanel_Show", optionsFrame, "OptionsCheckButtonTemplate");
  SM_OptionsPanel_Show:SetPoint("TOPLEFT", "SM_OptionsPanel_Locked", "BOTTOMLEFT", -10, -3);
  SM_OptionsPanel_ShowText:SetText("Show the skill progress bar (uncheck to hide)");
  SM_OptionsPanel_Show:SetChecked(SM_options.frameShown);
  SM_OptionsPanel_Show.setFunc = SM_ToggleFrameShow;

  return optionsFrame;
end

function SM_OptionsPanel_Default()
  SM_UpdateBar(SM_defaults.trackID);
  SM_ResetPos();
end

function SM_ClickHandler(self, mButton, ...)
-- Duh, it's a click handler!
  if (mButton == "RightButton") then
    SM_ShowMenu();
  end  
end

function SM_ShowMenu()
-- More convenient way of toggling the drop down menu display
  ToggleDropDownMenu(1, nil, SM_SkillMenu, SkillMonitor_SBar, 0, 0);
end

function SM_StartDrag(self)
-- Drag handling function, if frame isn't locked by the user
  if (SM_options.frameLocked ~= "1") then
    self:StartMoving();
  end
end

function SM_StopDrag(self)
-- Stop the frame drag and record the location in SM_options
  self:StopMovingOrSizing();
  SM_options.x = self:GetLeft();
  SM_options.y = self:GetTop();
end

function SM_UpdateBar(tracknum)
-- Updates the StatusBar
  if ( tracknum ~= nil and ( tracknum >= 1 and tracknum <= GetNumSkillLines() ) ) then
    local skillName, _, _, skillRank, _, _, skillMaxRank = GetSkillLineInfo(tracknum);
    SM_StatusBar:SetMinMaxValues(1, skillMaxRank);
    SM_StatusBar:SetValue(skillRank);
    SM_StatusBar.text:SetText(skillName .. ":  " .. skillRank .. "/" .. skillMaxRank);
  else
    SM_options.trackID = 0;
    SM_StatusBar.text:SetText(SM .. " " .. SM_rev);
  end
end

function SM_CreateMenu()
-- Creates the frame handle for the drop-down menu and initialises it, returning the frame handle
  local sIndex = 0;
  local menuframe = CreateFrame("Frame", "SM_SkillMenu", SM_StatusBar, "UIDropDownMenuTemplate");
  menuframe:SetPoint("LEFT", SM_StatusBar);
  UIDropDownMenu_Initialize(menuframe, SM_InitialiseMenu, "MENU");
  
  return menuframe;
end

function SM_InitialiseMenu(self, level)
-- Populates the drop-down menu with skills from skillTable
  local skilllevel = skilllevel or 1;
  
  for sIndex=1, #skillTable do
    local info = UIDropDownMenu_CreateInfo();
    info.value = sIndex;
	info.text = skillTable[sIndex][2];
    
    -- Checks to see if skill is a header.  If not, make it not selectable
	if (sIndex == skillTable[sIndex][1]) then
      info.isTitle = true;
      info.func = nil;
      info.notCheckable = true;
	else
    -- If it's not a header, assign it a click handler
      info.isTitle = false;
	  info.func = function(self) SM_Menu_OnClick() end;
	end
    
	info.checked = nil;
	info.icon = nil;
	info.owner = SM_SkillMenu;
	
	UIDropDownMenu_AddButton(info, skilllevel);
  end
end

function SM_Menu_OnClick()
-- Called when selecting a drop-down menu value.
-- Updates the status bar and options with the value selected.
  if (this.value ~= skillTable[this.value][1]) then
    SM_options.trackID = this.value;
    SM_UpdateBar(SM_options.trackID);
  end
end

function SM_ReadSkills()
-- Reads all available skills into skillTable
    local numSkills = GetNumSkillLines();
    local sIndex = 0;
    local lastHeaderIndex = 0;
    
    for sIndex=1, numSkills do
        local skillName, isHeader = GetSkillLineInfo(sIndex)
    
        -- If it's a skill header, indicate it in lastHeaderIndex
        if isHeader ~= nil then
            lastHeaderIndex = sIndex;
        end
   
        skillTable[sIndex] = { lastHeaderIndex, skillName };
    end
end

function SM_ToggleFrameShow(setting)
-- Toggles showing the status bar frame
  SM_options.frameShown = setting;
  
  if (setting == "1") then
    SM_StatusBar:Show();
  else
    SM_StatusBar:Hide();
  end
  
  SM_OptionsPanel_Show:SetChecked(SM_options.frameShown);
end

function SM_ToggleClickThru(setting)
  SM_options.frameClickThru = setting;
  SM_StatusBar:EnableMouse(SM_options.frameClickThru);
 
  SM_OptionsPanel_ClickThru:SetChecked(SM_options.frameClickThru);
  
  if (setting == "0") then
    BlizzardOptionsPanel_CheckButton_Disable(SM_OptionsPanel_Locked);
  else
    BlizzardOptionsPanel_CheckButton_Enable(SM_OptionsPanel_Locked);
  end
end


function SM_ToggleLock(setting)
  SM_options.frameLocked = setting;
  
  SM_OptionsPanel_Locked:SetChecked(SM_options.frameLocked);
end

function SM_ResetPos()
-- Resets the position of the status bar to the centre of the screen.
-- Also resets any position values stored in SM_options
  SM_StatusBar:ClearAllPoints();
  SM_StatusBar:SetPoint("CENTER", UIParent, "CENTER", 0, 0);
  SM_options.x = SM_StatusBar:GetLeft();
  SM_options.y = SM_StatusBar:GetTop();
  
  SM_ToggleClickThru(SM_defaults.frameClickThru);
  SM_ToggleLock(SM_defaults.frameLocked);
  SM_ToggleFrameShow(SM_defaults.frameShown);
end

function SM_Command(args)
-- Command-line argument parser
  if (args == "lock") then
    SM_OptionsPanel_Locked:Click();
  elseif (args == "mouse") then
    SM_OptionsPanel_ClickThru:Click();
  elseif (args == "show") then
	SM_ToggleFrameShow("1");
  elseif (args == "hide") then
	SM_ToggleFrameShow("0");
  elseif (args == "reset") then
    SM_ResetPos();
  elseif (args == "options" or args == "config") then
    InterfaceOptionsFrame_OpenToCategory(SM_OptionsHandle);
  else
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00SkillMonitor - version " .. SM_rev .. "|r");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm show |r: Show the skill progress bar");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm hide |r: Hides the skill progress bar");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm lock |r: Locks/unlocks the skill progress bar");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm mouse |r: Enables/disables mouse interaction entirely (will lock the bar position)");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm reset |r: Resets the skill progress bar's position");
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00  /sm config |r: Opens the configuration window");
  end
end