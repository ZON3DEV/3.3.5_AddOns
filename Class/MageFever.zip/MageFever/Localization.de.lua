-------------------------------------------------------------------------------
-- Title: Mage Fever, English localization
-- Author: Nuclear, Kritologist
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

FoFtext = "Eisige Finger"
BFtext = "Hirnfrost"
HStext = "Kampfeshitze"
MBtext = "Geschosssalve"
FStext = "Feuerteufel"
CCtext = "Freizaubern"
LBtext = "Lebende Bombe"
SCHtext = "Scorch"
IMPTtext = "Impact"
TTWtext = "TtW"
ABtext = "Arcane Blast"
MItext = "Mirror Image"
T102PCtext = "Bloodmage"


FPtext = "Feurige Rache"

STARTtext = "MageFever 1.8.1 geladen. Type /mfever."

ERRORtext = "Um das Optionsfenster einzublenden: /mfever options"

end