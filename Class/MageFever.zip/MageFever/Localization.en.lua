-------------------------------------------------------------------------------
-- Title: Mage Fever, English localization
-- Author: Nuclear, Kritologist
-------------------------------------------------------------------------------


FoFtext = "Fingers of Frost"
BFtext = "Brain Freeze"
HStext = "Hot Streak"
MBtext = "Missile Barrage"
FStext = "Firestarter"
CCtext = "Clearcasting"
LBtext = "Living Bomb"
SCHtext = "Scorch"
IMPTtext = "Impact"
TTWtext = "TtW"
ABtext = "Arcane Blast"
MItext = "Mirror Image"
T102PCtext = "Bloodmage"

FPtext = "Fiery Payback"

STARTtext = "MageFever 1.8.1 started. Type /mfever."

ERRORtext = "To show options window type: /mfever options"