-------------------------------------------------------------------------------
-- Title: Mage Fever, French localization
-- Author: Nuclear, Kritologist
-------------------------------------------------------------------------------

if (GetLocale() == "frFR") then

FoFtext = "Doigts de givre"
BFtext = "Gel mental"
HStext = "Chaleur continue"
MBtext = "B. de projectiles"      -- Nom de talent vraiment trop long
FStext = "Boute-Flammes"
CCtext = "Id\195\169es Claires"
LBtext = "Bombe Vivante" 
SCHtext = "Scorch"
IMPTtext = "Impact"
TTWtext = "TtW" 
ABtext = "Arcane Blast"
MItext = "Mirror Image"
T102PCtext = "Bloodmage"

FPtext = "Revanche Ardente"

STARTtext = "MageFever 1.8.1 actif. Tapez /mfever."

ERRORtext = "Pour configurer tapez: /mfever options"

end 