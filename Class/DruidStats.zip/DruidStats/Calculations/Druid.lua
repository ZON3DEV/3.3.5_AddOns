-- no druid stats for non-druids
if select(2, UnitClass("player")) ~= "DRUID" then
	return;
end

local StatLogic = LibStub:GetLibrary("LibStatLogic-1.1");

DruidStats = {};
local DruidStats = _G.DruidStats;
DruidStats.enable = true;

--[[ ========================== ]]--
--[[                            ]]--
--[[ ========================== ]]--
local armorMultiplyTypes = {
	["INVTYPE_BODY"] = true,
	["INVTYPE_CHEST"] = true,
	["INVTYPE_CLOAK"] = true,
	["INVTYPE_FEET"] = true,
	["INVTYPE_HAND"] = true,
	["INVTYPE_HEAD"] = true,
	["INVTYPE_LEGS"] = true,
	["INVTYPE_ROBE"] = true,
	["INVTYPE_SHOULDER"] = true,
	["INVTYPE_WAIST"] = true,
	["INVTYPE_WRIST"] = true,
};


--[[ ========================== ]]--
--[[ TALENT MODIFIED BASE STATS ]]--
--[[ ========================== ]]--
local getModStrength = function(bonuses)
	return (bonuses["STR"] or 0) * DruidStats.pd.f_SOTF * DruidStats.pd.f_MOTW;
end

local getModAgility = function(bonuses)
	return (bonuses["AGI"] or 0) * DruidStats.pd.f_SOTF * DruidStats.pd.f_MOTW;
end

local getModStamina = function(bonuses)
	return (bonuses["STA"] or 0) * DruidStats.pd.f_SOTF * DruidStats.pd.f_MOTW;
end

local getModIntellect = function(bonuses)
	local intellect = (bonuses["INT"] or 0) * DruidStats.pd.f_HOTW_INT;
	return (intellect) * DruidStats.pd.f_SOTF * DruidStats.pd.f_MOTW;
end

local getModSpirit = function(bonuses)
	return (bonuses["SPI"] or 0) * DruidStats.pd.f_SOTF * DruidStats.pd.f_LS * DruidStats.pd.f_MOTW;
end

-- WoW 2.4 Spirit calculations - USES GLOBAL STATS!
local getMP5FromSpi = function(spi, int)
	local intl = UnitStat("player", 4);
	local inth = intl+int;
	local spil = UnitStat("player", 5);
	local spih = spil+spi;
	
	local mp5h = StatLogic:GetNormalManaRegenFromSpi(spih, inth);
	local mp5l = StatLogic:GetNormalManaRegenFromSpi(spil, intl);
	
	return mp5h-mp5l;
end


--[[ ========================= ]]--
--[[   CASTER FORM FUNCTIONS   ]]--
--[[ ========================= ]]--
-- MOD: BEAR, DIRE BEAR, MOONKIN, TOL
local getArmor = function(bonuses)
	local fromBaseArmor = bonuses["ARMOR"] or 0;
	
	-- Thick Hide (Feral)
	if armorMultiplyTypes[bonuses["itemType"]] then
		fromBaseArmor = fromBaseArmor * DruidStats.pd.f_TH;
	end
	
	-- any armor packs or enchants?
	local fromReinforcedArmor = bonuses["ARMOR_BONUS"] or 0;

	return fromBaseArmor + fromReinforcedArmor + getModAgility(bonuses)*2;
end

-- MOD: BEAR, DIRE BEAR
local getHealth = function(bonuses)	
	return getModStamina(bonuses)*10 + (bonuses["HEALTH"] or 0);
end

local getDodgeChance = function(bonuses)
	local defense     = bonuses["DEFENSE_RATING"] or 0;
	defense = StatLogic:GetEffectFromRating(bonuses["DEFENSE_RATING"], CR_DEFENSE_SKILL, DruidStats.pd.level);
	
	return StatLogic:GetDodgeFromAgi(getModAgility(bonuses))
		+ StatLogic:GetEffectFromRating(bonuses["DODGE_RATING"], CR_DODGE, DruidStats.pd.level)
		+ defense * 0.04;
end

local getHP5 = function(bonuses)
	if bonuses["SPI"] then
		return StatLogic:GetHealthRegenFromSpi(getModSpirit(bonuses), "DRUID");
	end
end

-- MOD: BEAR, CAT, MOONKIN
local getAP = function(bonuses)
	return (bonuses["AP"] or 0) + getModStrength(bonuses)*2;
end

-- MOD: BEAR, CAT, BOOMKIN/TREE
local getCritChance = function(bonuses)	
	local fromAgi = StatLogic:GetCritFromAgi(getModAgility(bonuses), "DRUID", DruidStats.pd.level);
	local fromCritRating = StatLogic:GetEffectFromRating(bonuses["MELEE_CRIT_RATING"] or 0, CR_CRIT_MELEE, DruidStats.pd.level);
	
	return fromAgi + fromCritRating;
end

-- MOD: none
local getHitChance = function(bonuses)	
	return StatLogic:GetEffectFromRating(bonuses["MELEE_HIT_RATING"] or 0, CR_HIT_MELEE, DruidStats.pd.level);
end

-- MOD: Feral
local getHasteSpell = function(bonuses)	
	return StatLogic:GetEffectFromRating(bonuses["MELEE_HASTE_RATING"] or 0, CR_HASTE_SPELL, DruidStats.pd.level);
end
local getHasteMelee = function(bonuses)
	return StatLogic:GetEffectFromRating(bonuses["MELEE_HASTE_RATING"] or 0, CR_HASTE_MELEE, DruidStats.pd.level);
	--/print StatLogic:GetEffectFromRating(55, CR_HASTE_SPELL, 80);
	--/print StatLogic:GetEffectFromRating(77, CR_CRIT_SPELL, 80);
end

-- MOD: none
local getExpertise = function(bonuses)	
	return StatLogic:GetEffectFromRating(bonuses["EXPERTISE_RATING"] or 0, CR_EXPERTISE, DruidStats.pd.level);
end

-- MOD: none
local getPenetration = function(bonuses)	
	return StatLogic:GetEffectFromRating(bonuses["ARMOR_PENETRATION_RATING"] or 0, CR_ARMOR_PENETRATION, DruidStats.pd.level);
end

local getCritChanceFeral = function(bonuses)
	local crit = 0
	
	-- From agility
	if bonuses["AGI"] then
		crit = crit + StatLogic:GetCritFromAgi(getModAgility(bonuses), "DRUID", DruidStats.pd.level)
	end
	
	-- From crit rating
	if bonuses["MELEE_CRIT_RATING"] then
		crit = crit + StatLogic:GetEffectFromRating(bonuses["MELEE_CRIT_RATING"], CR_CRIT_MELEE, DruidStats.pd.level)
	end
	
	-- From combat rating
	if bonuses["FERAL_WEAPON_RATING"]  then
		crit = crit + bonuses["FERAL_WEAPON_RATING"] * 0.01
	end
	
	return crit;
end

local getMana = function(b)	
	return getModIntellect(b) * 15 + (b["MANA"] or 0);
end

local getMP5C = function(b)
	local pd = DruidStats.pd;
	local mp5 = b["MANA_REG"] or 0;

	if IsEquippedItem(b["link"]) then
		-- Intensity (Restoration - FROM SPIRIT)
		mp5 = mp5 + (getMP5FromSpi(-getModSpirit(b), -getModIntellect(b)) * pd.f_INT);
		-- Dreamstate (Balance - FROM INTELLECT)
		if pd.ds > 0 then
			mp5 = mp5 + getModIntellect(b) * pd.f_DS;
		end
	else
		-- Intensity (Restoration - FROM SPIRIT)
		mp5 = mp5 + (getMP5FromSpi(getModSpirit(b), getModIntellect(b)) * pd.f_INT);
		-- Dreamstate (Balance - FROM INTELLECT)
		if pd.ds > 0 then
			mp5 = mp5 + getModIntellect(b) * pd.f_DS;
		end
	end
	
	return mp5;
end

local getMP5NC = function(b)
	local pd = DruidStats.pd;
	local mp5 = b["MANA_REG"] or 0;

	if IsEquippedItem(b["link"]) then
		-- (FROM SPIRIT / INTELLECT)
		mp5 = mp5 + math.abs(getMP5FromSpi(-getModSpirit(b), -getModIntellect(b)));
		-- Dreamstate (Balance - FROM INTELLECT)
		if pd.ds > 0 then
			mp5 = mp5 + getModIntellect(b) * pd.f_DS;
		end
	else
		-- (FROM SPIRIT / INTELLECT)
		mp5 = mp5 + getMP5FromSpi(getModSpirit(b), getModIntellect(b));
		-- Dreamstate (Balance - FROM INTELLECT)
		if pd.ds > 0 then
			mp5 = mp5 + getModIntellect(b) * pd.f_DS;
		end
	end
	
	return mp5;
end

local getSpellDamage = function(bonuses)
	local pd = DruidStats.pd;
	-- Lunar Guidance (Balance - FROM INTELLECT)
	local fromInt = getModIntellect(bonuses) * pd.f_LG;
	
	-- + Earth and Moon SD-Component
	return (fromInt + (bonuses["SPELL_DMG"] or 0)) * pd.f_EAM_SD;
end

-- MOD: TOL: But only to party members
local getHealing = function(bonuses)	
	local pd = DruidStats.pd;
	-- Lunar Guidance (Balance - FROM INTELLECT)
	local fromInt = getModIntellect(bonuses) * pd.f_LG;
	
	-- Nurturing Instinct
	local fromAgi = getModAgility(bonuses) * pd.f_NI;

	return fromInt + (bonuses["HEAL"] or 0) + fromAgi;
end

-- MOD: NONE
local getSpellCrit = function(b)	
	local pd = DruidStats.pd;
	local spellCrit = 0;
	
	if b["INT"] then
		spellCrit = StatLogic:GetSpellCritFromInt(getModIntellect(b), "DRUID", pd.level);
	end
	
	if(b["SPELL_CRIT_RATING"]) then
		spellCrit = spellCrit + StatLogic:GetEffectFromRating(b["SPELL_CRIT_RATING"], CR_CRIT_SPELL, pd.level);
	end
	
	return spellCrit;
end



--[[ ========================= ]]--
--[[        TREE OF LIFE       ]]--
--[[ ========================= ]]--
-- MOD: TOL - But only to party members
local getHealingTOL = function(bonuses)
	local h = getHealing(bonuses);
	if bonuses["SPI"] then
		return h + getModSpirit(bonuses) * DruidStats.pd.f_ITOL_HP;
	end

	return getHealing(bonuses);
end

local getArmorTOL = function(bonuses)
	local armor = bonuses["ARMOR"] or 0;

	-- iTOL armor
	if armorMultiplyTypes[bonuses["itemType"]] then
		-- + Thick Hide (Feral)
		armor = armor * DruidStats.pd.f_ITOL_AR * DruidStats.pd.f_TH;
	end
	
	-- any armor packs or enchants?
	armor = armor + (bonuses["ARMOR_BONUS"] or 0);
	
	-- TOL armor
	armor = (armor + getModAgility(bonuses)*2);

	return armor;
end
--[[ ========================= ]]--
--[[        (DIRE) BEAR        ]]--
--[[ ========================= ]]--
local getArmorBear = function(bonuses)
	local armor = bonuses["ARMOR"] or 0;

	if armorMultiplyTypes[bonuses["itemType"]] then
		-- Level check for Bear form
		if(DruidStats.pd.level < 40) then
			armor = armor * 2.8
		else
			armor = armor * 4.7
		end
		armor = armor * DruidStats.pd.f_TH * DruidStats.pd.f_SOTF_AR;
	end

	-- any armor packs or enchants?
	local reinforcedArmor = bonuses["ARMOR_BONUS"] or 0;
	
	return armor + reinforcedArmor + getModAgility(bonuses)*2;
end

local getHealthBear = function(bonuses)	
	if bonuses["STA"] then
		-- Survival of the Fittest / Heart of the Wild / Bear form bonus
		local stamina = getModStamina(bonuses) * DruidStats.pd.f_HOTW_STA * 1.25;
		return stamina*10 + (bonuses["HEALTH"] or 0);
	end
	return bonuses["HEALTH"];
end

local weaponSlots = {
	["INVTYPE_2HWEAPON"] = true,
	["INVTYPE_WEAPON"] = true,
	["INVTYPE_WEAPONMAINHAND"] = true,
	["INVTYPE_WEAPONOFFHAND"] = true,
};

local getAPBear = function(b)
	local ap = b["AP"] or 0;
	-- From Strength
	ap = ap + getModStrength(b) * 2;
	
	if weaponSlots[b["itemType"]] then
		-- weapon AP bonus
		if b["DPS"] and b["DPS"] >= 54.8 then
			-- http://www.wowwiki.com/Feral_attack_power
			ap = ap + floor((b["DPS"] - 54.8) * 14);
		end

		-- Predatory Strikes AP bonus
		ap = ap * DruidStats.pd.f_PS;
	end
	
	ap = ap * DruidStats.pd.f_POTP_AP;
	
	-- From the +x Weapon damage (ring-) enchant
	if b["MELEE_DMG"] then
		ap = ap + b["MELEE_DMG"] * 5.6 -- 14 / 2.5
	end

	return ap;
end

local getTankPoints = function(b)
	
end

local getMitigation = function(bonuses)
	local dodge = getDodgeChance(bonuses)/100; -- dps reduction by this value
	local armor = StatLogic:GetReductionFromArmor(getArmorBear(bonuses), UnitLevel("player")+3);   -- dps reduction by...?
	local damage = 0.01; -- start with theoretical damage of 0.01 points (this makes the point value higher)
	
--	DEFAULT_CHAT_FRAME:AddMessage("dodge: "..dodge);
--	DEFAULT_CHAT_FRAME:AddMessage("amor: "..armor.." | a2: "..(getArmorBear(bonuses) or "empty"));
	
	damage = damage * (1 - dodge);
	damage = damage * (1 - armor);
	
--	DEFAULT_CHAT_FRAME:AddMessage("damage: "..damage);
	
	return (1/damage)-100; -- return a value that increases, the better the mitigation
end

local getAvoidance = function(b)
	local defense = StatLogic:GetEffectFromRating(
				b["DEFENSE_RATING"], CR_DEFENSE_SKILL, DruidStats.pd.level);
	
	return StatLogic:GetDodgeFromAgi(getModAgility(b))
		+ StatLogic:GetEffectFromRating(b["DODGE_RATING"], CR_DODGE, DruidStats.pd.level)
		+ defense * 0.04 * 2; -- dodge + miss
end

local getDPSBear = function(b)
--DEFAULT_CHAT_FRAME:AddMessage("=== Bear DPS for "..b["link"].." ===");
	local iCrit = b["MELEE_CRIT_RATING"] or 0;
	local iExpertise = b["EXPERTISE_RATING"] or 0;
	local GEFR = StatLogic.GetEffectFromRating;

	-- get global haste
	local rHaste = GetCombatRating(CR_HASTE_MELEE);
	local bHaste = GetCombatRatingBonus(CR_HASTE_MELEE);
	-- get global speed without haste rating
	local pSpd = floor((UnitAttackSpeed("player")*100) / (1 - bHaste/100) + 0.5)/100;
	local mSpd = pSpd;
	
	-- get global dps value
	-- from PaperDollFrame.lua:PaperDollFrame_SetDamage:481 
	-- including many simplifications due to cat attack speed
	local minDmg, maxDmg, _, _, physBP, physBN, percent = UnitDamage("player");
	minDmg = (minDmg / percent) - physBP - physBN;
	maxDmg = (maxDmg / percent) - physBP - physBN;

	local baseDamage = (minDmg + maxDmg) * 0.5;
	local pDPS = (baseDamage + physBP + physBN) * percent;
	local mDPS = pDPS;

	local iDPS  = (getAPBear(b) / ATTACK_POWER_MAGIC_NUMBER) * percent;
	-- ATTACK_POWER_MAGIC_NUMBER is 14, but it might change, who knows?
	
	-- get global hit
	local pHit = 95 + GetCombatRatingBonus(CR_HIT_MELEE);
	local mHit = pHit;
	-- get global expertise
	local pExp = 95 + GetExpertisePercent();
	local mExp = pExp;
	-- get global crit
	local pCrit = 100 + GetCritChance();
	local mCrit = pCrit;
	
--DEFAULT_CHAT_FRAME:AddMessage("DPS: pDPS:"..pDPS..", mDPS:"..mDPS..", iDPS:"..iDPS);
--DEFAULT_CHAT_FRAME:AddMessage("DPS: pHit:"..pHit..", pCrit:"..pCrit..", pExp:"..pExp);
--DEFAULT_CHAT_FRAME:AddMessage("HAS: Rating: "..rHaste..", Bonus: "..bHaste..", Speed: "..pSpd);
--DEFAULT_CHAT_FRAME:AddMessage("----------------------------------------------");

	-- reduce player dps/hit/crit/expertise by this item's if it is equipped
	-- increase modified ... by this item's if not equipped
	if IsEquippedItem(b["link"]) then
		pDPS  = pDPS  - iDPS;
		pHit  = pHit  - GEFR(nil, b["MELEE_HIT_RATING"] , CR_HIT_MELEE);
		pCrit = pCrit - GEFR(nil, b["MELEE_CRIT_RATING"], CR_CRIT_MELEE);
		pCrit = pCrit - StatLogic:GetCritFromAgi(b["AGI"] or 0);
		pExp  = pExp  - GEFR(nil, b["EXPERTISE_RATING"] , CR_EXPERTISE) * 0.25;
		
		-- remove "new" Haste from the value
		pSpd  = pSpd  / (1+GEFR(nil, rHaste - (b["MELEE_HASTE_RATING"] or 0), CR_HASTE_MELEE)/100);
		pSpd  = floor(pSpd * 1000 + 0.5)/1000;
		mSpd  = UnitAttackSpeed("player");
	else
		mDPS  = mDPS  + iDPS;
		mHit  = mHit  + GEFR(nil, b["MELEE_HIT_RATING"] , CR_HIT_MELEE);
		mCrit = mCrit + GEFR(nil, b["MELEE_CRIT_RATING"], CR_CRIT_MELEE);
		mCrit = mCrit + StatLogic:GetCritFromAgi(b["AGI"] or 0);
		mExp  = mExp  + GEFR(nil, b["EXPERTISE_RATING"] , CR_EXPERTISE) * 0.25;
		
		-- add the new Haste to the value
		mSpd  = mSpd  / (1+GEFR(nil, rHaste + (b["MELEE_HASTE_RATING"] or 0), CR_HASTE_MELEE)/100);
		mSpd  = floor(mSpd * 1000 + 0.5)/1000;
		pSpd  = UnitAttackSpeed("player");
	end

--DEFAULT_CHAT_FRAME:AddMessage("DPS: pDPS:"..pDPS..", pHit:"..pHit..", pCrit:"..pCrit..", pExp:"..pExp);
--DEFAULT_CHAT_FRAME:AddMessage("DPS: mDPS:"..mDPS..", mHit:"..mHit..", mCrit:"..mCrit..", mExp:"..mExp);
--DEFAULT_CHAT_FRAME:AddMessage("HAS: mSpd: "..mSpd..", pSpd: "..pSpd);

	pDPS = (pDPS / pSpd) * (pHit/100) * (pCrit/100) * (pExp/100) * (pExp/100);
	mDPS = (mDPS / mSpd) * (mHit/100) * (mCrit/100) * (mExp/100) * (mExp/100);
	local dDPS = mDPS - pDPS;
	
--DEFAULT_CHAT_FRAME:AddMessage("DPS: "..pDPS.." || "..mDPS.." || "..dDPS);
	
	if math.abs(dDPS) < 0.001 then
		dDPS = 0;
	end
	
	return dDPS, mDPS;
end


--[[ ========================= ]]--
--[[            CAT            ]]--
--[[ ========================= ]]--
local getAPCat = function(b)
	local ap = b["AP"] or 0;

	if weaponSlots[b["itemType"]] then
		-- weapon AP bonus
		if b["DPS"] and b["DPS"] >= 54.8 then
			-- http://www.wowwiki.com/Feral_attack_power
			ap = ap + floor((b["DPS"] - 54.8) * 14);
		end

		-- Predatory Strikes AP bonus
		ap = ap * DruidStats.pd.f_PS;
	end

	-- From Strength / Agility
	ap = ap + getModStrength(b) * 2 + getModAgility(b);

	-- Heart of the Wild modifier
	ap = ap * (DruidStats.pd.f_HOTW_AP);
	
	-- From the +x Weapon damage (ring-) enchant
	if b["MELEE_DMG"] then
		ap = ap + b["MELEE_DMG"] * 14; -- 14 / 1
	end
	
	return ap;
end

local getDPSCat = function(b)
--DEFAULT_CHAT_FRAME:AddMessage("=== Cat DPS for "..b["link"].." ===");
	local iCrit = b["MELEE_CRIT_RATING"] or 0;
	local iExpertise = b["EXPERTISE_RATING"] or 0;
	local GEFR = StatLogic.GetEffectFromRating;

	-- get global haste
	local rHaste = GetCombatRating(CR_HASTE_MELEE);
	local bHaste = GetCombatRatingBonus(CR_HASTE_MELEE);
	-- get global speed without haste rating
	local pSpd = floor((UnitAttackSpeed("player")*100) / (1 - bHaste/100) + 0.5)/100;
	local mSpd = pSpd;
	
	-- get global dps value
	-- from PaperDollFrame.lua:PaperDollFrame_SetDamage:481 
	-- including many simplifications due to cat attack speed
	local minDmg, maxDmg, _, _, physBP, physBN, percent = UnitDamage("player");
	minDmg = (minDmg / percent) - physBP - physBN;
	maxDmg = (maxDmg / percent) - physBP - physBN;

	local baseDamage = (minDmg + maxDmg) * 0.5;
	local pDPS = (baseDamage + physBP + physBN) * percent;
	local mDPS = pDPS;

	local iDPS  = (getAPCat(b) / ATTACK_POWER_MAGIC_NUMBER) * percent;
	-- ATTACK_POWER_MAGIC_NUMBER is 14, but it might change, who knows?
	
	-- get global hit
	local pHit = 95 + GetCombatRatingBonus(CR_HIT_MELEE);
	local mHit = pHit;
	-- get global expertise
	local pExp = 95 + GetExpertisePercent();
	local mExp = pExp;
	-- get global crit
	local pCrit = 100 + GetCritChance();
	local mCrit = pCrit;
	
--DEFAULT_CHAT_FRAME:AddMessage("DPS: pDPS:"..pDPS..", mDPS:"..mDPS..", iDPS:"..iDPS);
--DEFAULT_CHAT_FRAME:AddMessage("DPS: pHit:"..pHit..", pCrit:"..pCrit..", pExp:"..pExp);
--DEFAULT_CHAT_FRAME:AddMessage("HAS: Rating: "..rHaste..", Bonus: "..bHaste..", Speed: "..pSpd);
--DEFAULT_CHAT_FRAME:AddMessage("----------------------------------------------");

	-- reduce player dps/hit/crit/expertise by this item's if it is equipped
	-- increase modified ... by this item's if not equipped
	if IsEquippedItem(b["link"]) then
		pDPS  = pDPS  - iDPS;
		pHit  = pHit  - GEFR(nil, b["MELEE_HIT_RATING"] , CR_HIT_MELEE);
		pCrit = pCrit - GEFR(nil, b["MELEE_CRIT_RATING"], CR_CRIT_MELEE);
		pCrit = pCrit - StatLogic:GetCritFromAgi(b["AGI"] or 0);
		pExp  = pExp  - GEFR(nil, b["EXPERTISE_RATING"] , CR_EXPERTISE) * 0.25;
		
		-- remove "new" Haste from the value
		pSpd  = pSpd  / (1+GEFR(nil, rHaste - (b["MELEE_HASTE_RATING"] or 0), CR_HASTE_MELEE)/100);
		pSpd  = floor(pSpd * 1000 + 0.5)/1000;
		mSpd  = UnitAttackSpeed("player");
	else
		mDPS  = mDPS  + iDPS;
		mHit  = mHit  + GEFR(nil, b["MELEE_HIT_RATING"] , CR_HIT_MELEE);
		mCrit = mCrit + GEFR(nil, b["MELEE_CRIT_RATING"], CR_CRIT_MELEE);
		mCrit = mCrit + StatLogic:GetCritFromAgi(b["AGI"] or 0);
		mExp  = mExp  + GEFR(nil, b["EXPERTISE_RATING"] , CR_EXPERTISE) * 0.25;
		
		-- add the new Haste to the value
		mSpd  = mSpd  / (1+GEFR(nil, rHaste + (b["MELEE_HASTE_RATING"] or 0), CR_HASTE_MELEE)/100);
		mSpd  = floor(mSpd * 1000 + 0.5)/1000;
		pSpd  = UnitAttackSpeed("player");
	end
	
--DEFAULT_CHAT_FRAME:AddMessage("DPS: pDPS:"..pDPS..", pHit:"..pHit..", pCrit:"..pCrit..", pExp:"..pExp);
--DEFAULT_CHAT_FRAME:AddMessage("DPS: mDPS:"..mDPS..", mHit:"..mHit..", mCrit:"..mCrit..", mExp:"..mExp);
--DEFAULT_CHAT_FRAME:AddMessage("HAS: mSpd: "..mSpd..", pSpd: "..pSpd);

	pDPS = (pDPS / pSpd) * (pHit/100) * (pCrit/100) * (pExp/100) * (pExp/100);
	mDPS = (mDPS / mSpd) * (mHit/100) * (mCrit/100) * (mExp/100) * (mExp/100);
	local dDPS = mDPS - pDPS;
	
--DEFAULT_CHAT_FRAME:AddMessage("DPS: "..pDPS.." || "..mDPS.." || "..dDPS);
	
	if math.abs(dDPS) < 0.001 then
		dDPS = 0;
	end
	
	return dDPS, mDPS;
end

--[[ ========================= ]]--
--[[          MOONKIN          ]]--
--[[ ========================= ]]--
local getArmorMoonkin = function(bonuses)
	local fromBaseArmor = bonuses["ARMOR"] or 0;

	-- Moonkin Fat
	if armorMultiplyTypes[bonuses["itemType"]] then
		fromBaseArmor = fromBaseArmor * DruidStats.pd.f_TH;
		fromBaseArmor = fromBaseArmor * 4.7;
	end

	-- any armor packs or enchants?
	local fromReinforcedArmor = bonuses["ARMOR_BONUS"] or 0;
	
	return fromBaseArmor + fromReinforcedArmor + getModAgility(bonuses)*2;
end

local getAPMoonkin = function(b)
	local ap = b["AP"] or 0;
	-- From Strength
	ap = ap + getModStrength(b) * 2;
	
	-- From Feral Attack Power
	if b["DPS"] then
		ap = ap + ((b["DPS"] or 55)-55) * 14;
	end
	
	return ap;
end

local armor, health, dodge, health_reg, ap, melee_crit, melee_hit, expertise,
      penetration, mana, mana_reg, mana_reg_not_casting, spell_dmg, heal,
      spell_haste, spell_crit;
armor       = StatLogic:GetStatNameFromID("ARMOR");
health      = StatLogic:GetStatNameFromID("HEALTH");
dodge       = StatLogic:GetStatNameFromID("DODGE");
health_reg  = StatLogic:GetStatNameFromID("HEALTH_REG");
ap          = StatLogic:GetStatNameFromID("AP");
melee_crit  = StatLogic:GetStatNameFromID("MELEE_CRIT");
melee_hit   = StatLogic:GetStatNameFromID("MELEE_HIT");
melee_haste = StatLogic:GetStatNameFromID("MELEE_HASTE");
expertise   = StatLogic:GetStatNameFromID("EXPERTISE");
penetration = StatLogic:GetStatNameFromID("ARMOR_PENETRATION");
mana        = StatLogic:GetStatNameFromID("MANA");
mana_reg    = StatLogic:GetStatNameFromID("MANA_REG");
mana_reg_nc = StatLogic:GetStatNameFromID("MANA_REG_NOT_CASTING");
spell_dmg   = StatLogic:GetStatNameFromID("SPELL_DMG");
heal        = StatLogic:GetStatNameFromID("HEAL");
spell_crit  = StatLogic:GetStatNameFromID("SPELL_CRIT");
spell_haste = StatLogic:GetStatNameFromID("SPELL_HASTE");

local colors = {
	defPhys = "FF34CDFF",
	offPhys = "FFFF3333",
	endMagi = "FF33FF33",
	powMagi = "FFFFFF33",
	theoret = "FF999999",
};

local dsformats = {
	["armor"]       = "|c"..colors.defPhys.."%+.0f "..armor.."|r|n",
	["health"]      = "|c"..colors.defPhys.."%+.0f "..health.."|r|n",
	["dodge"]       = "|c"..colors.defPhys.."%+.2f "..gsub(dodge,"%%","%%%%").."|r|n",
	["health_reg"]  = "|c"..colors.defPhys.."%+.1f "..health_reg.."|r|n",
	["ap"]          = "|c"..colors.offPhys.."%+.0f "..ap.."|r|n",
	["melee_crit"]  = "|c"..colors.offPhys.."%+.2f "..gsub(melee_crit,"%%","%%%%").."|r|n",
	["melee_hit"]   = "|c"..colors.offPhys.."%+.2f "..gsub(melee_hit,"%%","%%%%").."|r|n",
	["expertise"]   = "|c"..colors.offPhys.."%+.2f "..gsub(expertise,"%%","%%%%").."|r|n",
	["penetration"] = "|c"..colors.offPhys.."%+.2f "..gsub(penetration,"%%","%%%%").."|r|n",
	["melee_haste"] = "|c"..colors.offPhys.."%+.2f "..gsub(melee_haste,"%%","%%%%").."|r|n",
	["mana"]        = "|c"..colors.endMagi.."%+.0f "..mana.."|r|n",
	["mana_reg"]    = "|c"..colors.endMagi.."%+.1f "..mana_reg.."|r|n",
	["mana_reg_nc"] = "|c"..colors.endMagi.."%+.1f "..mana_reg_nc.."|r|n",
	["spell_dmg"]   = "|c"..colors.powMagi.."%+.0f "..spell_dmg.."|r|n",
	["spell_haste"] = "|c"..colors.powMagi.."%+.2f "..gsub(spell_haste,"%%","%%%%").."|r|n",
	["heal"]        = "|c"..colors.powMagi.."%+.0f "..heal.."|r|n",
	["spell_crit"]  = "|c"..colors.powMagi.."%+.2f "..gsub(spell_crit,"%%","%%%%").."|r|n",
	["heal_tol"]    = "|c"..colors.powMagi.."%+.0f "..heal.." (Tree of Life)|r|n",

	-- theorycraft stuff
	["dps"]         = "|c"..colors.theoret.."%2$.1f DPS (%1$+.1f)*|r|n",
	["mitigation"]  = "|c"..colors.theoret.."%.1f Mitigation Points*|r|n",
	["avoidance"]   = "|c"..colors.theoret.."%.2f%% Avoidance*|r|n",
};

DruidStats.sstats = {
	-- Caster
	[1] = {
		{ f=getArmor,        p=dsformats["armor"] },
		{ f=getHealth,       p=dsformats["health"] },
		{ f=getDodgeChance,  p=dsformats["dodge"] },
		{ f=getHP5,          p=dsformats["health_reg"] },
		{ f=getAP,           p=dsformats["ap"] },
		{ f=getCritChance,   p=dsformats["melee_crit"] },
		{ f=getHitChance,    p=dsformats["melee_hit"] },
		{ f=getHasteMelee,   p=dsformats["melee_haste"] },
		{ f=getExpertise,    p=dsformats["expertise"] },
		{ f=getPenetration,  p=dsformats["penetration"] },
		{ f=getMana,         p=dsformats["mana"] },
		{ f=getMP5C,         p=dsformats["mana_reg"] },
		{ f=getMP5NC,        p=dsformats["mana_reg_nc"] },
		{ f=getSpellDamage,  p=dsformats["spell_dmg"] },
		{ f=getHealing,      p=dsformats["heal"] },
		{ f=getSpellCrit,    p=dsformats["spell_crit"] },
		{ f=getHasteSpell,   p=dsformats["spell_haste"] },
--		{ f=getAvoidance,    p=dsformats["avoidance"] },
	},
	-- (Dire) Bear form
	[2] = {
		{ f=getArmorBear,    p=dsformats["armor"] },
		{ f=getHealthBear,   p=dsformats["health"] },
		{ f=getDodgeChance,  p=dsformats["dodge"] },
		{ f=getHP5,          p=dsformats["health_reg"] },
		{ f=getAPBear,       p=dsformats["ap"] },
		{ f=getCritChance,   p=dsformats["melee_crit"] },
		{ f=getHitChance,    p=dsformats["melee_hit"] },
		{ f=getHasteMelee,   p=dsformats["melee_haste"] },
		{ f=getExpertise,    p=dsformats["expertise"] },
		{ f=getPenetration,  p=dsformats["penetration"] },
		{ f=getMana,         p=dsformats["mana"] },
		{ f=getMP5C,         p=dsformats["mana_reg"] },
		{ f=getMP5NC,        p=dsformats["mana_reg_nc"] },
--		{ f=getSpellDamage,  p=dsformats["spell_dmg"] },
--		{ f=getHealing,      p=dsformats["heal"] },
--		{ f=getSpellCrit,    p=dsformats["spell_crit"] },
--		{ f=getHasteSpell,   p=dsformats["spell_haste"] },
--		{ f=getMitigation,   p=dsformats["mitigation"] },
--		{ f=getDPSBear,      p=dsformats["dps"] },
--		{ f=getAvoidance,    p=dsformats["avoidance"] },
	},
	-- Cat form
	[3] = {
		{ f=getArmor,        p=dsformats["armor"] },
		{ f=getHealth,       p=dsformats["health"] },
		{ f=getDodgeChance,  p=dsformats["dodge"] },
		{ f=getHP5,          p=dsformats["health_reg"] },
		{ f=getAPCat,        p=dsformats["ap"] },
		{ f=getCritChance,   p=dsformats["melee_crit"] },
		{ f=getHitChance,    p=dsformats["melee_hit"] },
		{ f=getHasteMelee,   p=dsformats["melee_haste"] },
		{ f=getExpertise,    p=dsformats["expertise"] },
		{ f=getPenetration,  p=dsformats["penetration"] },
		{ f=getMana,         p=dsformats["mana"] },
		{ f=getMP5C,         p=dsformats["mana_reg"] },
		{ f=getMP5NC,        p=dsformats["mana_reg_nc"] },
--		{ f=getSpellDamage,  p=dsformats["spell_dmg"] },
--		{ f=getHealing,      p=dsformats["heal"] },
--		{ f=getSpellCrit,    p=dsformats["spell_crit"] },
--		{ f=getDPSCat,       p=dsformats["dps"] },
--		{ f=getAvoidance,    p=dsformats["avoidance"] },
	},
	-- Tree of Life form
	[4] = {
		{ f=getArmorTOL,     p=dsformats["armor"] },
		{ f=getHealth,       p=dsformats["health"] },
		{ f=getDodgeChance,  p=dsformats["dodge"] },
		{ f=getHP5,          p=dsformats["health_reg"] },
--		{ f=getAP,           p=dsformats["ap"] },
--		{ f=getCritChance,   p=dsformats["melee_crit"] },
--		{ f=getHitChance,    p=dsformats["melee_hit"] },
--		{ f=getExpertise,    p=dsformats["expertise"] },
--		{ f=getPenetration,  p=dsformats["penetration"] },
		{ f=getMana,         p=dsformats["mana"] },
		{ f=getMP5C,         p=dsformats["mana_reg"] },
		{ f=getMP5NC,        p=dsformats["mana_reg_nc"] },
		{ f=getHealing   ,   p=dsformats["heal"] },
		{ f=getHealingTOL,   p=dsformats["heal_tol"] },
		{ f=getSpellCrit,    p=dsformats["spell_crit"] },
		{ f=getHasteSpell,   p=dsformats["spell_haste"] },
--		{ f=getAvoidance,    p=dsformats["avoidance"] },
	},
	-- Moonkin form
	[5] = {
		{ f=getArmorMoonkin, p=dsformats["armor"] },
		{ f=getHealth,       p=dsformats["health"] },
		{ f=getDodgeChance,  p=dsformats["dodge"] },
		{ f=getHP5,          p=dsformats["health_reg"] },
		{ f=getAPMoonkin,    p=dsformats["ap"] },
		{ f=getCritChance,   p=dsformats["melee_crit"] },
		{ f=getHitChance,    p=dsformats["melee_hit"] },
--		{ f=getExpertise,    p=dsformats["expertise"] },
--		{ f=getPenetration,  p=dsformats["penetration"] },
		{ f=getMana,         p=dsformats["mana"] },
		{ f=getMP5C,         p=dsformats["mana_reg"] },
		{ f=getMP5NC,        p=dsformats["mana_reg_nc"] },
		{ f=getSpellDamage,  p=dsformats["spell_dmg"] },
--		{ f=getHealing,      p=dsformats["heal"] },
		{ f=getSpellCrit,    p=dsformats["spell_crit"] },
		{ f=getHasteSpell,   p=dsformats["spell_haste"] },
--		{ f=getAvoidance,    p=dsformats["avoidance"] },
	},
};
