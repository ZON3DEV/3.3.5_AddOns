-- no druid stats if no calculations file loaded
if not DruidStats then
	return;
end


-- startup stuff that needs local variables
do -- some setup stuff
	
	local s = DruidStats;
	local BI = LibStub("LibBabble-Inventory-3.0"):GetLookupTable();
	-- Valid item sub-types
	s.validSubTypes = {
		[BI["Leather"]]          = true,
		[BI["Cloth"]]            = true,
		[BI["Daggers"]]          = true,
		[BI["Fist Weapons"]]     = true,
		[BI["One-Handed Maces"]] = true,
		[BI["Staves"]]           = true,
		[BI["Two-Handed Maces"]] = true,
		[BI["Polearms"]]         = true,
		[BI["Miscellaneous"]]    = true,
		[BI["Other"]]            = true, -- yay for Alchemist's Stone
		
		-- Elixirs and Food effects
		[BI["Elixir"]]           = true,
		[BI["Flask"]]            = true,
		[BI["Food & Drink"]]     = true,
	};
	-- Valid item types (they will be valid no matter their subtype)
	s.validTypes = {
		[BI["Gem"]]              = true,
	};
	--[[ Items that proved to cause errors in specific locales
	 TODO: implement this 
	 format: [id] = value
	   where id is the item id and value is either a locale or [true] for any
	   locale
	]]
	s.blacklist = {
		[28109] = "deDE",
	};
	
	-- Item ID's of special items
	s.specialItems = {
		-- Elixirs & Flasks
		[33208] = { -- Flask of Chromatic Wonder
			["STR"] = 18,
			["AGI"] = 18,
			["STA"] = 18,
			["INT"] = 18,
			["SPI"] = 18,
		},

		-- Food & Drink
		[27663] = { -- Blackened Sporefish
			["MANA_REG"] = 8,
			["STA"] = 20,
		},
		[27664] = { -- Grilled Mudfish
			["AGI"] = 20,
			["SPI"] = 20,
		},
		[33052] = { -- Fisherman's Feast
			["SPI"] = 20,
			["STA"] = 30,
		},
		[34411] = { -- Hot Apple Cider
			["SPI"] = 20,
			["STA"] = 20,
		},
		[33872] = { -- Spicy Hot Talbuk
			["SPI"] = 20,
			["MELEE_HIT_RATING"] = 20,
		},
		[33825] = { -- Skullfish Soup
			["SPI"] = 20,
			["SPELL_CRIT_RATING"] = 20,
		},
	};
	-- duplicate stats
	s.specialItems[27667] = s.specialItems[33052]; -- Spicy Crawdad
	-- Useless:
	-- Hot Buttered Trout
	-- Stewed Trout

	s.forms = {
		["No Form"]             = 1,
		[(GetSpellInfo(5487))]  = 2, -- Bear Form
		[(GetSpellInfo(9634))]  = 2, -- Dire Bear Form
		[(GetSpellInfo(768))]   = 3, -- Cat Form
		[(GetSpellInfo(33891))] = 4, -- Tree of Life
		[(GetSpellInfo(24858))] = 5, -- Moonkin
		-- unused: default to caster form
		[(GetSpellInfo(783))]   = 1, -- Travel Form
		[(GetSpellInfo(1066))]  = 1, -- Aquatic Form
		[(GetSpellInfo(33943))] = 1, -- Flight Form
		[(GetSpellInfo(40120))] = 1, -- Swift Flight Form
	};
end

local clearCache = function()
	-- Update the player data
	DruidStats:updatePlayerData();
	-- Reset the cache
	for k,v in pairs(DruidStats.itemCache) do
		table.wipe(v)
	end
end

local setCache = function(number)
	local c = DruidStats.itemCache;
	if number and not c[number] then
		c[number] = setmetatable({}, {__mode = "kv"});
	end
end

DruidStats.TooltipList = {
	-- Blizzard UI
	"ItemRefTooltip", "GameTooltip",
	"ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3",
	
	-- EquipCompare
	"ComparisonTooltip1", "ComparisonTooltip2",
	
	-- EQCompare
	"EQCompareTooltip1", "EQCompareTooltip2",
	
	-- LinkWrangler
	"IRR_ItemRefTooltip1", "IRR_ItemCompTooltip1", "IRR_ItemCompTool11",
	"IRR_ItemRefTooltip2", "IRR_ItemCompTooltip2", "IRR_ItemCompTool12",
	"IRR_ItemRefTooltip3", "IRR_ItemCompTooltip3", "IRR_ItemCompTool13",
	"IRR_ItemRefTooltip4", "IRR_ItemCompTooltip4", "IRR_ItemCompTool14",
	"IRR_ItemRefTooltip5", "IRR_ItemCompTooltip5", "IRR_ItemCompTool15",
	
	-- MultiTips
	"ItemRefTooltip2", "ItemRefTooltip3", "ItemRefTooltip4", "ItemRefTooltip5",
	
	-- Armory
	"ArmoryComparisonTooltip1", "ArmoryComparisonTooltip2",
	
	-- AtlasLoot
	"AtlasLootTooltip",
}

DruidStats.pd = {}; -- Player data
DruidStats.pd.talents = {{},{},{}};
DruidStats.itemCache = {};
setCache(1);
setCache(2);
setCache(3);
setCache(4);
setCache(5);

local talentmapping = {
	{ --[1] Balance
		[11] = "cf",       -- Celestial Focus
		[12] = "lg",       -- Lunar Guidance
		[15] = "ds",       -- Dreamstate
		[17] = "bop",      -- Balance of Power
		[18] = "moonkin",  -- Moonkin
		[19] = "imk",      -- Improved Moonkin
		[20] = "iff",      -- Improved Faerie Fire
		[27] = "eam",      -- Earth and Moon      
	},                  
	{ --[2] Feral
		[ 5] = "th",       -- Thick Hide
		[10] = "ps",       -- Predatory Strikes
		[12] = "pp",       -- Primal Precision
		[15] = "ni",       -- Nurturing Instinct
		[17] = "hotw",     -- Heart of the Wild
		[18] = "sotf",     -- Survival of the Fittest
		[22] = "potp",     -- Protector of the Pack  
		[23] = "pi",       -- Predatory Instincts
	},
	{ --[3] Restoration
		[ 1] = "motw",     -- Improved Mark of the Wild
		[ 4] = "nat",      -- Naturalist
		[ 7] = "intensity",-- Intensity
		[ 9] = "masterss", -- Master Shapeshifter
		[17] = "ls",       -- Living Spirit (15% increase to spirit)
		[19] = "np",       -- Natural Perfection
		[23] = "tol",      -- Tree of Life
		[24] = "itol",     -- Improved Tree of Life                 
	},                   
}

function DruidStats:updatePlayerData()
	local pd = self.pd;
	-- get the shapeshift form...
	pd.form = GetShapeshiftForm(true);
	
	if GetShapeshiftForm(true) > 0 then
		local _, name = GetShapeshiftFormInfo(GetShapeshiftForm(true));
		pd.realform = self.forms[name];
		pd.formname = name;
	else
		pd.realform = 1;
		pd.formname = "No Form";
	end
	
	setCache(pd.realform);
	-- /run do local _, n = GetShapeshiftFormInfo(1); print(n); end
	-- /run print(GetShapeshiftForm(true).." - ".. GetShapeshiftForm());
	local talent, _, name, tv;
	for tree=1, GetNumTalentTabs() do
		for talent=1, GetNumTalents(tree) do
			_,_,_,_, tv = GetTalentInfo(tree, talent);
			pd.talents[tree][talent] = tv;
			if talentmapping[tree][talent] then
				pd[talentmapping[tree][talent]] = tv;
			end
		end
	end
	pd.level = UnitLevel("player");
	
	self:calculateTalentFactors(pd);
end

function DruidStats:calculateTalentFactors(pd)
	-- FERAL
	-- intellect factor for Heart of the Wild
	pd.f_HOTW_INT = 1 + (pd.hotw * 0.04);
	-- stamina factor for Heart of the Wild in BEAR FORM
	pd.f_HOTW_STA = 1 + (pd.hotw * 0.02);
	-- attack power factor for Heart of the Wild in CAT FORM
	pd.f_HOTW_AP  = 1 + (pd.hotw * 0.02);
	-- survival of the fittest factor
	pd.f_SOTF     = 1 + (pd.sotf * 0.02);
	-- survival of the fittest armor factor
	pd.f_SOTF_AR  = 1 + (pd.sotf * 0.11);
	-- nurturing instinct outgoing heal factor
	pd.f_NI       = pd.ni * 0.35;
	-- nurturing instinct incoming heal factor
	pd.f_NI_IN    = pd.ni * 0.10;
	-- predatory strikes, weapon attack power modifier
	pd.f_PS       = select(pd.ps+1, 1, 1.07, 1.14, 1.20);
	-- Thick hide
	pd.f_TH       = select(pd.th+1, 1, 1.04, 1.07, 1.1);
	-- Protector of the Pack AP factor
	pd.f_POTP_AP  = 1 + pd.potp * 0.02;
	-- Predatory Instincts
	pd.f_PI       = select(pd.pi+1, 1, 1.03, 1.07, 1.1);
	
	-- celestial focus haste factor
	pd.f_CF       = pd.cf * 0.01
	-- lunar guidance factor
	pd.f_LG       = pd.lg * 0.04;
	-- dreamstate
	pd.f_DS       = select(pd.ds+1, 1, 1.04, 1.07, 1.1);
	-- Balance of Power
	pd.f_BOP      = pd.bop * 2;
	-- Improved Moonkin Form Spelldamage component
	pd.f_IMK_SD   = 1 + (pd.imk * 0.05);
	-- Improved Moonkin Form Haste component
	pd.f_IMK_HA   = 1 + (pd.imk * 0.01);
	-- Improved Faerie Fire (both components)
	pd.f_IFF      = 1 + (pd.iff * 0.01);
	-- Earth and Moon (Spelldamage Component)
	pd.f_EAM_SD   = 1 + (pd.eam * 0.01);
	
	-- Mark of the Wild
	pd.f_MOTW     = 1 + (pd.motw * 0.01);
	-- Naturalist
	pd.f_NAT      = 1 + (pd.nat * 0.02);
	-- Intensity
	pd.f_INT      = select(pd.intensity+1, 0, .17, .33, .5);
	-- Master Shapeshifter (Bear/MK/Tree modifier)
	pd.f_MASTERSSA= 1 + (pd.masterss * 0.02);
	-- Master Shapeshifter (Cat modifier)
	pd.f_MASTERSSB= pd.masterss * 2;
	-- Natural perfection
	pd.f_NP       = pd.np;
	-- living spirit
	pd.f_LS       = 1 + (pd.ls * 0.05);
	-- Improved ToL (Armor Component)
	pd.f_ITOL_AR  = select(pd.itol+1, 1, 1.67, 2.33, 3.0);
	-- Improved ToL (Healing Power Component)
	pd.f_ITOL_HP  = pd.itol * 0.05;
end

function DruidStats.SetItem(tooltip)
	--print(tooltip:GetName(), select(2, tooltip:GetItem()));
	local self = DruidStats;
	if not self.Settings.enabled then
		return;
	end
	-- Get the item
	local _, link = tooltip:GetItem();
	if not link then
		return;
	end
	-- Check if the item is a usable type
	local _,_,_,_,_, Type, subType = GetItemInfo(link);
	if not self.validSubTypes[subType] and not self.validTypes[Type] then
		return;
	end
	-- Check the cache
--	debugprofilestart();
	local form = self.pd.realform or 1;
	local iText = "";
	if self.itemCache[form][link] then
		iText = self.itemCache[form][link];
	else
		-- Special items
		local bonuses;
		local itemid  = tonumber(strmatch(link, "Hitem:(%d+):"));
		if self.specialItems[itemid] ~= nil then
			bonuses = self.specialItems[itemid];
		else
			bonuses = StatLogic:GetSum(link) or {};
		end
		-- parse the data
		for stat, s in pairs(self.sstats[form]) do
			local val, v2, v3 = s.f(bonuses); -- Call the function for the stat
			if val and val ~= 0 then
				iText = iText..string.format(s.p, val, v2, v3);
			end
		end
		-- save to cache
		self.itemCache[form][link] = iText;
		-- debug, hell Im getting mad...
		if self.Settings.debug and not self.sstats[form] then
			tinsert(self.Settings.Debug312Nil, {self.pd.realform, form, link, self.sstats});
		end
	end

	if iText ~= "" then
		tooltip:AddLine("|n<< Druid Stats - "..self.pd.formname.." >>");
		tooltip:AddLine(iText);
	end
--	print("DS-new: "..debugprofilestop().."ms");
end

local fakes2 = {
	-- Balance --
	["cf"]      = 3, -- Celestial Focus
	["lg"]      = 3, -- Lunar Guidance
	["ds"]      = 3, -- Dreamstate
	["bop"]     = 2, -- Balance of Power
	--["moonkin"] = 1, -- Moonkin
	["imk"]     = 3, -- Improved Moonkin
	["iff"]     = 3, -- Improved Faerie Fire
	["eam"]     = 3, -- Earth and Moon
	-- Feral --
	["th"]   = 3, -- Thick Hide
	["ps"]   = 3, -- Predatory Strikes
	["pp"]   = 2, -- Primal Precision
	["ni"]   = 2, -- Nurturing Instinct
	["hotw"] = 5, -- Heart of the Wild
	["sotf"] = 3, -- Survival of the Fittest
	["potp"] = 3, -- Protector of the Pack
	-- Restoration --
	["motw"]      = 2, -- Improved Mark of the Wild
	["nat"]       = 5, -- Naturalist
	["intensity"] = 3, -- Intensity
	["masterss"]  = 2, -- Master Shapeshifter
	["ls"]        = 3, -- Living Spirit (15% increase to spirit)
	["np"]        = 3, -- Natural Perfection
	--["tol"]       = 1, -- Tree of Life
	["itol"]      = 3, -- Improved Tree of Life
	-- other
	["level"] = 80,
}
local fakes, fakesnames;
--[[ Slash Commands ]]--
DruidStats.SlashHandler = function(msg)
	if msg == "on" then
		print("DruidStats: Enabled")
		DruidStats_Settings.enabled = true;
	elseif msg == "off" then
		print("DruidStats: Disabled")
		DruidStats_Settings.enabled = false;
	elseif msg == "unfake" then
		DruidStats:updatePlayerData();
		DruidStats.itemCache = {};
	elseif string.match(msg, "^fake%s") then
		local pd = DruidStats.pd;
		local helpmode = false;
		
		-- create a fake db
		if not fakes then
			fakes = {};
			local names = {};
			for k,v in pairs(talentmapping) do
				for l,w in pairs(v) do
					fakes[w] = select(6, GetTalentInfo(k, l));
					tinsert(names, w.."|cFF999999:"..fakes[w].."|r");
				end
			end
			tinsert(names, "level:|cFF99999980|r");
			fakes["level"] = 80;
			fakesnames = strjoin(", ", unpack(names));
		end
		
		for w in string.gmatch(msg, "[^%s]+") do
			local a,b = strsplit(":", w);
			
			if fakes[a] and not helpmode then
				pd[a] = (b and tonumber(b)) or fakes[a];
			elseif helpmode then
				for k,v in pairs(talentmapping) do
					for l,w in pairs(v) do
						if w == a or a == "ALL" then
							-- " |cff4e96f7|Htalent:830:2|h[Improved Rejuvenation]|h|r"
							print("|cFF00FF00", w, "|rstands for", (GetTalentLink(k,l)));
							helpmode = helpmode+1;
						end
					end
				end
			end
			
			if a == "keywords" or a == "help" then
				helpmode = 1;
			elseif a == "new" then
				DruidStats:updatePlayerData();
			elseif a == "clear" then
				DruidStats:updatePlayerData();
				for k,v in pairs(fakes) do
					pd[k] = 0;
				end
			elseif a == "bear" then
				pd.realform = 2;
				pd.formname = "Fake BEAR";
			elseif a == "cat" then
				pd.realform = 3;
				pd.formname = "Fake CAT";
			elseif a == "tol" then
				pd.realform = 4;
				pd.formname = "Fake TOL";
			elseif a == "mk" or a == "moonkin" then
				pd.realform = 5;
				pd.formname = "Fake MK";
			elseif a:match("#%d+:%d+") then
				
			end
		end
		
		if helpmode == 1 then
			print("DruidStats faking keywords:");
			print("|cFFAAAAAASpecial keywords:|r |cFFFF0000new|r, |cFFFF0000clear|r, |cFFFF0000help|r");
			print("|cFFAAAAAAForms:|r bear, cat, tol, moonkin");
			print("|cFFAAAAAATalents:Maxrank:|r", fakesnames);
			print("You can use a keyword:level syntax for some of the "..
				"keywords, if this is not possible for a specific keyword"..
				" it will be ignored, so it's safe to just try.");
			print("Use /druidstats fake help [keyword keyword ...] for "..
				"information on specific keywords, or use the keyword ALL "..
				"to show all keywords");
		end
		
		setCache(pd.realform);
		-- clearCache():
		for k,v in pairs(DruidStats.itemCache) do
			table.wipe(v)
		end

		DruidStats:calculateTalentFactors(DruidStats.pd);
	elseif msg == "bench" then
		-- DruidStats from global space vs. DruidStats from local space
		print("Bench: Access table via global space VS reference it and access it via local space");
		do
			local m = 1;
			local limit = 10000;
			
			while m < 10 do
				local k = DruidStats;
				local l,g = 0;
				k.benchI = 0;
				debugprofilestart();
				while k.benchI < limit do
					local i = DruidStats;
					local j = 0;
					while i.benchI < limit and j < m do
						i.benchI = i.benchI+1;
						j = j + 1;
					end
				end
				l = debugprofilestop();
				
				k.benchI = 0;
				debugprofilestart();
				while DruidStats.benchI < limit do
					local j = 0;
					while DruidStats.benchI < limit and j < m do
						DruidStats.benchI = DruidStats.benchI+1;
						j = j + 1;
					end
				end
				g = debugprofilestop();

				print("L/G: "..l/g);
				print("Local: "..l.."ms - "..(3*m).." calls per localized loop");
				print("Global: "..g.."ms - "..(3*m).." calls per loop");
				
				m = m+1;
			end
		end
	else
		print("DruidStats: Invalid command, usage: /druidstats on, /druidstats off")
	end
end

SlashCmdList["DRUID_STATS"] = DruidStats.SlashHandler;
SLASH_DRUID_STATS1 = "/druidstats";
SLASH_DRUID_STATS2 = "/ds";

DruidStats_Settings = {};
DruidStats_Settings.debug = false;
DruidStats_Settings.enabled = true;

local updateForm = function()
	local pd = DruidStats.pd;
	-- get the shapeshift form...
	pd.form = GetShapeshiftForm(true);
	
	if GetShapeshiftForm(true) > 0 then
		local _, name = GetShapeshiftFormInfo(GetShapeshiftForm(true));
		pd.realform = DruidStats.forms[name] or 1;
		pd.formname = name or "No Form";
	else
		pd.realform = 1;
		pd.formname = "No Form";
	end
	
	setCache(pd.realform);
end

local hook = function(self, event, name)
	--[[ Hook DruidStats into various tool tips ]]
	for k, name in ipairs(DruidStats.TooltipList) do
		local tooltip = _G[name];
		if tooltip and tooltip:HasScript("OnTooltipSetItem") then
			-- Hook this script
			if tooltip:GetScript("OnTooltipSetItem") then
				tooltip:HookScript("OnTooltipSetItem", DruidStats.SetItem);
			else
				tooltip:SetScript("OnTooltipSetItem", DruidStats.SetItem);
			end
			-- remove the frame from the list so I wont hook it more than once
			DruidStats.TooltipList[k] = nil;
		end
	end
end

local startup = function(self, event, name)
	if (GetNumTalentTabs()) == 0 then
		return; -- if player data is not yet available
	end

	clearCache(self, event, name);
	DruidStats:updatePlayerData();
	DruidStats.isReady = true;
	self:SetScript("OnEvent", hook);
	hook(self, event, name);
	DruidStats.Settings = DruidStats_Settings;
	
	-- frame to catch events that require new parsing of a tooltip
	local DruidStatsFrame2 = CreateFrame("Frame", nil, UIParent);
	DruidStatsFrame2:SetScript("OnEvent", clearCache);
	DruidStatsFrame2:RegisterEvent("VARIABLES_LOADED");         -- Startup
	DruidStatsFrame2:RegisterEvent("CHARACTER_POINTS_CHANGED"); -- Talents changed
	DruidStatsFrame2:RegisterEvent("PLAYER_LEVEL_UP");          -- Leveling
	DruidStatsFrame2:RegisterEvent("UPDATE_SHAPESHIFT_FORMS");  -- When changing the AVAILABLE set of stances/forms
	DruidStatsFrame2:RegisterEvent("UNIT_INVENTORY_CHANGED");   -- When (un)equipping items

	-- frame to catch events that only change the form of the player
	local DruidStatsFrame3 = CreateFrame("Frame", nil, UIParent);
	DruidStatsFrame3:SetScript("OnEvent", updateForm);
	DruidStatsFrame3:RegisterEvent("UPDATE_SHAPESHIFT_FORM");   -- When changing stances/forms
end


-- dynamically create an event catcher frame
local DruidStatsFrame1 = CreateFrame("Frame", nil, UIParent);
DruidStatsFrame1:RegisterEvent("ADDON_LOADED");
DruidStatsFrame1:RegisterEvent("PLAYER_ALIVE"); -- Startup2 - Also fired when resurrecting, but we dont care
DruidStatsFrame1:SetScript("OnEvent", startup);
