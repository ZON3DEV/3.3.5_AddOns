
ALPHA_MAP_VERSION 		= "3.3.03";

-- AlphaMap MapNotes compatible version
AMWM_MAPNOTES_VERSION		= "3.40.20003";
-- symbol
AM_DEGREE					= "\194\176";

-- Constant used to Register AlphaMap with MapNotes to allow note creation on Instance/BG/World Boss Maps
-- This is an example of how other AddOns should also register their Plugins with MapNotes (See code also)
AM_MN_PLUGIN = 	{	name	= "AlphaMap3",
					frame	= "AlphaMapAlphaMapFrame",
					keyVal	= "AlphaMap_MN_Query",
					lclFnc	= "AlphaMap_MN_Localiser",
};

-- The Below style of Plugin Information demonstrates how you can display/change actual Blizzard World Map Notes
-- on your own AddOn's Frames using the Plugin functionality - It will depend on your Frame having the same proportions
-- as the World Map Button in order to display notes in the correct positions.
-- Notes made on the AddOn frame will be displayed on the World Map, and vice versa.
AM_WM_PLUGIN =	{	name	= "WM AlphaMap",			--
					frame	= "AM_WorldMapNotesFrame",	-- Just use a different anchor Frame
					keyVal	= "MapNotes_GetMapKey",		-- SAFEST Use MapNotes own Key Fetching routine
					lclFnc	= "AlphaMap_WM_Localiser",	-- MUST Provide own Localiser to avoid Recursion
					wmflag	= "1",						-- Indicates you want to display World Map Notes via this Plugin
};

-- Constants used in Instance data that don't require localisation
-- (Note : these can be overidden in any localisation file if required)

AM_EXIT_SYMBOL			= "X";
AM_ENTRANCE_SYMBOL		= "X";
AM_CHEST_SYMBOL			= "C";
AM_STAIRS_SYMBOL		= "S";
AM_ROUTE_SYMBOL			= "R";
AM_QUEST_SYMBOL			= "Q";
AM_DFLT_SYMBOL			= "X";
AM_ABBREVIATED			= "..";
AM_BLANK_KEY_SYMBOL		= " ";
				-----@@RRGGBB-----
AM_RED				= "|c00FF1010";		-- default used for hostile mobs, and Exits
AM_GREEN			= "|c0000FF00";		-- default used for neutral/friendly NPCs
AM_BLUE				= "|c005070FF";		-- default used for Entrances, and Stairs/Paths between distinct map areas
AM_GOLD				= "|c00FFD200";		-- default used for Chests
AM_PURPLE			= "|c00FF35A3";
AM_ORANGE			= "|c00FF7945";		-- default used for Quest items/objects
AM_YELLOW			= "|c00FFFF00";
AM_CYAN				= "|cff008888";

AM_DFLT_COLOUR			= AM_GOLD;

AM_NUN				= "NotesUNeed";

AM_AL				= "AtlasLoot Enhanced";

AM_LINKED_DUNGEONS		= {
	DireMaul = {	DMEast = true,
					DMWest = true,
					DMNorth = true
	},
	LBRS = { 	LBRS = true,
				UBRS = true
	},
};


-- 0 : 0.0625 : 0.125 : 0.1875 : 0.25 : 0.3125 : 0.375 : 0.4375 : 0.5 : 0.5625 : 0.625 : 0.6875 : 0.75 : 0.8125 : 0.875 : 0.9375 : 1
--                                       |					      |					   |
--									      |
AM_BGChanging = {	["0.25 : 0.3125 : 0 : 0.0625"] = true,
					["0.5625 : 0.625 : 0 : 0.0625"] = true,
					["0.75 : 0.8125 : 0 : 0.0625"] = true,
					["0.875 : 0.9375 : 0 : 0.0625"] = true,
					["0.0625 : 0.125 : 0.0625 : 0.125"] = true,
					["0.1875 : 0.25 : 0.0625 : 0.125"] = true,
					["0.375 : 0.4375 : 0.0625 : 0.125"] = true,
					["0.5 : 0.5625 : 0.0625 : 0.125"] = true,
					["0.6875 : 0.75 : 0.0625 : 0.125"] = true,
					["0.8125 : 0.875 : 0.0625 : 0.125"] = true,
					["0 : 0.0625 : 0.125 : 0.1875"] = true,
					["0.125 : 0.1875 : 0.125 : 0.1875"] = true,
					["0.3125 : 0.375 : 0.125 : 0.1875"] = true,
					["0.4375 : 0.5 : 0.125 : 0.1875"] = true,
				-- need to dump the legacy at some point
					["0.375 : 0.5 : 0 : 0.125"] = true,
					["0 : 0.125 : 0.125 : 0.25"] = true,
					["0.375 : 0.5 : 0.125 : 0.25"] = true,
					["0.625 : 0.75 : 0.125 : 0.25"] = true,
					["0.125 : 0.25 : 0.25 : 0.375"] = true,
					["0.375 : 0.5 : 0.25 : 0.375"] = true,
					["0.75 : 0.875 : 0.25 : 0.375"] = true,
					["0 : 0.125 : 0.375 : 0.5"] = true,
					["0.375 : 0.5 : 0.375 : 0.5"] = true,
					["0.625 : 0.75 : 0.375 : 0.5"] = true,
					["0 : 0.125 : 0.5 : 0.625"] = true,
					["0.25 : 0.375 : 0.5 : 0.625"] = true,
					["0.625 : 0.75 : 0.5 : 0.625"] = true,
					["0.875 : 1 : 0.5 : 0.625"] = true,
				-- Legacy format to allow for overlapping functionality
					["0.375 : 0.500 : 0 : 0.125"] = true,
					["0 : 0.125 : 0.125 : 0.250"] = true,
					["0.375 : 0.500 : 0.125 : 0.250"] = true,
					["0.625 : 0.750 : 0.125 : 0.250"] = true,
					["0.125 : 0.250 : 0.250 : 0.375"] = true,
					["0.375 : 0.500 : 0.250 : 0.375"] = true,
					["0.750 : 0.875 : 0.250 : 0.375"] = true,
					["0 : 0.125 : 0.375 : 0.500"] = true,
					["0.375 : 0.500 : 0.375 : 0.500"] = true,
					["0.625 : 0.750 : 0.375 : 0.500"] = true,
					["0 : 0.125 : 0.500 : 0.625"] = true,
					["0.250 : 0.375 : 0.500 : 0.625"] = true,
					["0.625 : 0.750 : 0.500 : 0.625"] = true,
					["0.875 : 1.000 : 0.500 : 0.625"] = true,
};


