
-- Register this type as one where AlphaMap should remember Instance progress
AM_Raid_Progress_Types[AM_TYP_INSTANCE] = true;

-- Register the map data with the main AddOn
AlphaMap_RegisterMaps(AM_TYP_INSTANCE, AM_ALPHAMAP_INSTANCES_LIST);


