
This is a plugin AddOn for "AlphaMap (Fan's Update)"

It shows pre-made Minimap textured maps of Instances.

If you have Enabled Mouse Interactive mode in then you can Zoom in/out on particular areas of the map by <ALT>-Left/Right clicking;
Useful when you want to see a particular area in more detail.

You can change the position, scale, transparency of the maps.
You can change the size of on map notes, and hide/show their backgrounds, and change their colours to make them more visible.
You can change the transparency and colour of the background of the maps themselves to see them more clearly.
Settings for each map can be saved separately if needed (see the main AlphaMap FAQ);
For example you might want notes on a white background on one Instance map to make them visible, but notes with a black background on another map.

When you Target named Bosses in Instances, then they will be highlighted on the AlphaMap Instance map, to show where you/they are.
When you kill named Bosses in instances, AlphaMap will change their symbol to a Graveyard symbol, to show what progress your Raid/Party has made.

PLEASE READ THE "AlphaMap FAQ.txt" for more details.

