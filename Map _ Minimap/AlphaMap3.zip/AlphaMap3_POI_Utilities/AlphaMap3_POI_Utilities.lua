

-- The toggling of these POIs on/off is controlled by a variable
-- stored within the main AlphaMap SavedVariables .uLocs
-- A loop through AlphaMapConfigurations saves it as a global AlphaMap variable

-- Templates for these plugins is in the main AlphaMap AddOn


local AlphaMap_POI_Utilities_Frame = CreateFrame("Frame");

-- Global info for Utilities POI DropDowns to use
local POI_inf = {
	-- Define level one elements here
	[1] = {
		{ -- Title
			text = "AlphaMap",
			isTitle = 1,
		},
		{ -- PointyPointy
			text = AM_WAYPOINT,
			dynamicFunc = AMap.PointyPointyPointy;
			func = function()
				if ( ( AMap.pointy ) and ( type(AMap.pointy) == "function" ) ) then
					AMap.pointy( unpack(AMap.pointyP) );
				end
			end,
		},
	},
};

-- Display of the actual POIs on the AlphaMap world maps
local function DisplayUtilitiesLocs(c, z, m, frame)

	local note, noteT;
	local width = frame:GetWidth();
	local height = frame:GetHeight();
	local amUnitScale = AlphaMap_GetUnitScale();
	local x, y;
	local i = 0;
	local lFloor = GetCurrentMapDungeonLevel();

	if ( ( AlphaMapConfig.uLocs ) and ( AM_UTILITIES_LOCS ) and ( AM_UTILITIES_LOCS[m] ) ) then
		for _, poi in ipairs(AM_UTILITIES_LOCS[m]) do
			if ( ( not poi.floor ) or ( poi.floor == lFloor ) ) then
				i = i + 1;
				note = getglobal("AM_POIU_Note_"..i);
				if ( not note ) then
					note = CreateFrame("Button", "AM_POIU_Note_"..i, frame, "AM_GenPOI_Template");
					note:SetScript("OnEnter", function(self)
						local x, y = GetCursorPosition();
						if ( x > 500 ) then
							GameTooltip:SetOwner(this, "ANCHOR_TOPRIGHT");
						else
							GameTooltip:SetOwner(this, "ANCHOR_TOPLEFT");
						end

						GameTooltip:ClearLines();

						GameTooltip:AddLine("AlphaMap3_POI_Utilities")
						GameTooltip:AddLine(self.name);
						local i = 1;
						while( self.tooltip[i] ) do
							GameTooltip:AddLine(self.tooltip[i]);
							i = i + 1;
						end

						AlphaMap_ShowTooltip();
					end)
					note:SetScript("OnLeave", function()
						AlphaMap_HideTooltip();
					end)
					note:SetScript("OnClick", function(self, mouseButton)
						if ( mouseButton == "LeftButton" ) then
							local map = AMap.AlphaMap_GetMap(self.toMap);

							if ( map ) then
								AlphaMapFrame_Update( map );

							elseif ( self.toWorldMap ) then
								local cont, zone = AMap.AlphaMap_GetWorldMap(self.toWorldMap);
								if ( cont ~= "error" ) then
									SetMapZoom(cont, zone);	-- ))((
									AM_WorldMapSelected = true;
									AM_ManualMapChange = true;
									selectedCont = GetCurrentMapContinent();
									selectedZone = GetCurrentMapZone();
									selectedMap = GetMapInfo();
									AlphaMapFrame_Update();
								end
							end
						
						elseif ( mouseButton == "RightButton" ) then
							AMap.POI = self;
							AMap.InitialiseDropdown(POI_inf);
							if ( AMap.dd.bttns > 1 ) then
								ToggleDropDownMenu(1, nil, AMap.dd, "cursor", 0, 0);
							end
						end
					end)
				end
				noteT = getglobal("AM_POIU_Note_"..i.."Texture");
				noteT:SetTexture( poi.icon );

				x = ( poi.x * width ) / amUnitScale;
				y = ( poi.y * height ) / amUnitScale;

				note.name = poi.name;
				note.tooltip = poi.tooltip;
				note.toMap = poi.toMap;
				note.toWorldMap = poi.toWorldMap;
				note.c = c;
				note.z = z;
				note.m = m;
				note.x = poi.x;
				note.y = poi.y;
				note.icon = poi.icon;

				note:ClearAllPoints();
				note:SetScale(amUnitScale);
				note:SetPoint("CENTER", frame, "TOPLEFT", x, -y);
				note:Show();
--				note:SetWidth(32);
--				note:SetHeight(32);
			end
		end
	end

	i = i + 1;
	note = getglobal("AM_POIU_Note_"..i);
	while (note) do
		note:Hide();
		i = i + 1;
		note = getglobal("AM_POIU_Note_"..i);
	end

end


local POIUOld_AlphaMap_ResetAll;

function POIUNew_AlphaMap_ResetAll()
	POIUOld_AlphaMap_ResetAll();
	AlphaMapConfig.uLocs = true;
	for configuration, configurations in pairs(AlphaMapConfigurations) do
		AlphaMapConfigurations[ configuration ].uLocs = AlphaMapConfig.uLocs;
	end
end

-- Variables_Loaded is the only event registered.
local function AlphaMap_POI_Utilities_OnEvent()

	-- Hook the AlphaMap Options Reset Function
	POIUOld_AlphaMap_ResetAll = AlphaMap_ResetAll;
	AlphaMap_ResetAll = POIUNew_AlphaMap_ResetAll;

	-- Set up Saved AlphaMap configuration options
	if ( AlphaMapConfig.uLocs == nil ) then
		AlphaMapConfig.uLocs = true;
	end
	for configuration, configurations in pairs(AlphaMapConfigurations) do
		AlphaMapConfigurations[ configuration ].uLocs = AlphaMapConfig.uLocs;
	end

	-- Insert Utilities Display function code in to the main AlphaMap POI Plugin array
	-- AlphaMap will loop through these functions to display the required POIs
	table.insert(AMap.CustomPOIs, DisplayUtilitiesLocs);

	-- Set up the Control Check Button allowing people to toggle 
	-- display of Utilities Locations off and on from the AlphaMap
	local i = #(AMap.CustomPOIControls) + 1;
	local controlButton = CreateFrame("Button", "AM_POIC"..i, UIParent, "AM_GenPOIControl_Template");
	controlButton.id = i;
	local controlButtonT = getglobal("AM_POIC"..i.."Texture");
	controlButtonT:SetTexture("Interface\\AddOns\\AlphaMap3_POI_Utilities\\Artwork\\NP");
	local controlButtonC = getglobal("AM_POIC"..i.."Check");
	controlButtonC:SetScript("OnShow", function(self)
		self:SetFrameLevel( self:GetParent():GetFrameLevel() + 3 );
		if ( AlphaMapConfig.uLocs ) then
			self:SetChecked(1);
		else
			self:SetChecked(0);
		end
	end)
	controlButtonC:SetScript("OnClick", function(self)
		local checked = this:GetChecked()
		if self then checked = not checked; end
		if ( checked ) then
			PlaySound("igMainMenuOptionCheckBoxOff");
			AlphaMapConfig.uLocs = false;
			this:SetChecked(0);

		else
			PlaySound("igMainMenuOptionCheckBoxOn");
			AlphaMapConfig.uLocs = true;
			this:SetChecked(1);
		end
		for configuration, configurations in pairs(AlphaMapConfigurations) do
			AlphaMapConfigurations[ configuration ].uLocs = AlphaMapConfig.uLocs;
		end
		AlphaMapUnits_Update(1);
	end)
	controlButton:SetScript("OnClick", function(self)
		local v = getglobal(self:GetName() .. "Check");
		if ( v ) then
			this = v;
			v = v:GetScript("OnClick");
			if ( v ) then v(); end
		end
	end)

	-- Insert the Created control button in to the main AlphaMap array
	-- for display when the Control & Alt keys are pressed together
	table.insert(AMap.CustomPOIControls, controlButton);

end


-- Register Variables Loaded Event
AlphaMap_POI_Utilities_Frame:SetScript("OnEvent", AlphaMap_POI_Utilities_OnEvent);
AlphaMap_POI_Utilities_Frame:RegisterEvent("VARIABLES_LOADED");

