
AlphaMap POIs - Utilities v1.00.30000

This Plugin for AlphaMap displays the locations of Utilities on low level Zone & City maps.

FlightMasters, MailBoxes and Repair facilities are displayed graphically on Zone maps.
Tooltips show further information on Inns, Stables, main vendors, etc.

City Maps show more detailed Icons including Inns, Anvils & Forges, Banks, and Auction Houses.

NOTE 1: City Maps don't show Repair facilities, as so many Vendors can repair...

NOTE 2: Dalaran Mail Boxes are not displayed because there are SO many !

This Plugin does NOT show detailed Vendor/Trainer/Quest NPC Locations.
Neither does it show Routes between Flight Masters on Continent / World Maps.

With the AlphaMap visible, hold down the Control & Alt keys to see the Utilities Location control button which can be checked to quickly toggle display of Utility locations off / on.


