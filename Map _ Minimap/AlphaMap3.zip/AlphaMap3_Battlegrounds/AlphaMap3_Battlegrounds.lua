
-- Register BG "types" in the AM_BG_Types array
AM_BG_Types[AM_TYP_BG]	= true;

-- Register the Map Data with the main AddOn
AlphaMap_RegisterMaps(AM_TYP_BG, AM_ALPHAMAP_BATTLEGROUNDS_LIST);

