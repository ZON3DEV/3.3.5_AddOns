

-- Register the map data with the main AddOn

-- I now pass fixed maps to avoid problems encountered when minimap textures are adjusted by client patches...
--AlphaMap_RegisterMaps(AM_TYP_WORLDBOSSES, AM_ALPHAMAP_WORLDBOSSES_LIST, AM_WorldBosses_Minimap_Data);

AlphaMap_RegisterMaps(AM_TYP_WORLDBOSSES, AM_ALPHAMAP_WORLDBOSSES_LIST);

