
AlphaMap POIs - Instances v1.00.30000

This Plugin for AlphaMap displays the locations of Instances on world map continents and zones.

Clicking on the Instance symbol will either open up the relevant AlphaMap Instance map, or zoom in to world map zone for a clearer picture of where the Instances are exactly.

With the AlphaMap visible, hold down the Control & Alt keys to see the Instance Location control button which can be checked to quickly toggle display of Instance locations off / on.


