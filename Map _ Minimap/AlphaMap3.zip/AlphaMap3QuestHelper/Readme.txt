
AlphaQuestHelper
================

AlphaQuestHelper makes QuestHelper Icons and "ants" that normally appear only on the WorldMap, visible on AlphaMap.


Change Log
==========

Changes in v1.01.30100 from v1.01.30000
---------------------------------------

- toc update for WoW v3.1 patch





Changes in v1.01.30000 from v1.01.20400
---------------------------------------

- update for WoW v3 and WotLK



Changes in v1.01.20400 from v1.00.20400
---------------------------------------

- Cartographer compatibility update



v1.00.20400
-----------

- released 04/05/2008
