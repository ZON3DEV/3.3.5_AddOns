
AlphaMap POIs - Travel Agents v1.00.30000

This Plugin for AlphaMap displays the locations of FlightMasters, Zeppelin Towers, Sea Ports, & Portals on world map continents.
Left Clicking on a Travel Icon will display the available routes to other destinations.
Right Clicking on a Travel Icon shows a Menu with extra options :
View - choose between Horde, or Alliance, or Both types of Travel Agents.
Waypoint Arrow - set a POI as your Cartographer or TomTom Waypoint arrow target.

With the AlphaMap visible, hold down the Control & Alt keys to see the Travel Agent control button which can be checked to quickly toggle display of Travel destinations on / off.


