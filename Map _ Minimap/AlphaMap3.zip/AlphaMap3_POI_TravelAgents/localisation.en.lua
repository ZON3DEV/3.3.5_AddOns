

-- Green : |cff22ff22

-- Interface\Minimap\POIIcons.blp

AM_TA_FILTER = "View Filter";
AM_TA_HORDE = "Horde";
AM_TA_ALLIANCE = "Alliance";
AM_TA_ALL = AM_TA_HORDE .. " + " .. AM_TA_ALLIANCE;

AM_TRAVELAGENTS_LOCS = {


-- World Map, & Outland
	["Cosmic"] = {
	},
-- Cosmic ^

-----------------------------------------------------------------------------------------


-- Kalimdor, Eastern Kingdoms, & Northrend
	["WorldMap"] = {
-- 001
		{
			x = 0.87,
			y = 0.233,
			name = "|c00ff0000Silvermoon Orb of Translocation|r",
			tooltip = { " (Sanctum of the Sun)" },
			faction = "Horde",
			links = { 2, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\HOrb",
		},
-- 002
		{
			x = 0.757,
			y = 0.413,
			name = "|c00ff0000Undercity Orb of Translocation|r",
			tooltip = { " (Ruins of Lordaeron. Above Undercity)" },
			faction = "Horde",
			links = { 1, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\HOrb",
		},
-- 003
		{
			x = 0.755,
			y = 0.392,
			name = "|c00ff0000Zeppelin Towers|r",
			tooltip = { " Outside Undercity" },
			faction = "Horde",
			links = { 4, 5, 7, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 004
		{
			x = 0.272,
			y = 0.555,
			name = "|c00ff0000Zeppelin Towers|r",
			tooltip = { " Outside Orgrimmar" },
			faction = "Horde",
			links = { 3, 5, 6, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 005
		{
			x = 0.766,
			y = 0.848,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " Grom'Gol" },
			faction = "Horde",
			links = { 3, 4, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 006
		{
			x = 0.766,
			y = 0.848,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " Borean Tundra" },
			faction = "Horde",
			links = { 7, 4, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 007
		{
			x = 0.766,
			y = 0.848,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " Howling Fjord" },
			faction = "Horde",
			links = { 6, 3, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 008
		{
			x = 0.783,
			y = 0.582,
			name = "|c000000ffMenethil Harbor|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 10, 17, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 009
		{
			x = 0.744,
			y = 0.735,
			name = "|c000000ffStormwind City|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 13, 16,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 0010
		{
			x = 0.27,
			y = 0.695,
			name = "|c000000ffTheramore Isle|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 8,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 011
		{
			x = 0.128,
			y = 0.72,
			name = "|c000000ffThe Forgotten Coast|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 12, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 012
		{
			x = 0.107,
			y = 0.718,
			name = "|c000000ffFeathermoon Stronghold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 11, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 013
		{
			x = 0.161,
			y = 0.401,
			name = "|c000000ffAuberdine|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 9, 14, 15,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 014
		{
			x = 0.047,
			y = 0.409,
			name = "|c000000ffValaar's Landing|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 13, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 015
		{
			x = 0.145,
			y = 0.306,
			name = "|c000000ffRut'theran Village|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 13, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 016
		{
			x = 0.419,
			y = 0.277,
			name = "|c000000ffValliance Keep|r",
			tooltip = { " (Borean Tundra)" },
			faction = "Alliance",
			links = { 9, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 017
		{
			x = 0.636,
			y = 0.33,
			name = "|c000000ffValgarde|r",
			tooltip = { " (Howling Fjord)" },
			faction = "Alliance",
			links = { 8,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 018
		{
			x = 0.83,
			y = 0.848,
			name = "|c0000ff00Dark Portal|r",
			tooltip = { " (To Destiny's Stair, Outland)" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
-- 019
		{
			x = 0.753,
			y = 0.918,
			name = "|c0000ff00Booty Bay|r",
			tooltip = {  },
			links = { 20, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 020
		{
			x = 0.256,
			y = 0.625,
			name = "|c0000ff00Ratchet|r",
			tooltip = {  },
			links = { 19, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 021
		{
			x = 0.432,
			y = 0.26,
			name = "|c0000ff00Unu'pe|r",
			tooltip = {  },
			links = { 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 022
		{
			x = 0.512,
			y = 0.264,
			name = "|c0000ff00Moa'ki Harbor|r",
			tooltip = {  },
			links = { 21, 23, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 023
		{
			x = 0.594,
			y = 0.328,
			name = "|c0000ff00Kamagua|r",
			tooltip = {  },
			links = { 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 024
		{
			x = 0.527,
			y = 0.157,
			name = "|c0000ff00Dalaran|r",
			tooltip = { " (Portals to All major Cities)" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
	},
-- World ^

-----------------------------------------------------------------------------------------



-- Outland
	["Expansion01"] = {
-- 001
		{
			x = 0.396,
			y = 0.293,
			name = "|c00ff0000Thunderlord Stronghold|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, 3, 4, 21, 22, 24, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 002
		{
			x = 0.467,
			y = 0.324,
			name = "|c00ff0000MokNathal Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 003
		{
			x = 0.299,
			y = 0.483,
			name = "|c00ff0000Zabrajin|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 4, 5, 8, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 004
		{
			x = 0.436,
			y = 0.495,
			name = "|c00ff0000Swamprat Post|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 3, 5, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 005
		{
			x = 0.5,
			y = 0.539,
			name = "|c00ff0000Falcon Watch|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 4, 6, 8, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 006
		{
			x = 0.588,
			y = 0.487,
			name = "|c00ff0000Thrallmar|r",
			tooltip = {  },
			faction = "Horde",
			links = { 5, 7, 9, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 007
		{
			x = 0.593,
			y = 0.588,
			name = "|c00ff0000Spinebreaker Post|r",
			tooltip = {  },
			faction = "Horde",
			links = { 6, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 008
		{
			x = 0.335,
			y = 0.617,
			name = "|c00ff0000Garadar|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 5, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 009
		{
			x = 0.48,
			y = 0.724,
			name = "|c00ff0000Stonebreaker Hold|r",
			tooltip = {  },
			faction = "Horde",
			links = { 6, 10, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 010
		{
			x = 0.604,
			y = 0.77,
			name = "|c00ff0000Shadowmoon Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 9, 28, 29, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 011
		{
			x = 0.353,
			y = 0.291,
			name = "|c000000ffSylvanaar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 12, 13, 14, 21, 22, 24, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 012
		{
			x = 0.42,
			y = 0.318,
			name = "|c000000ffToshleys Station|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 11, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 013
		{
			x = 0.304,
			y = 0.425,
			name = "|c000000ffOrebor Harborage|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 11, 14, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 014
		{
			x = 0.4,
			y = 0.497,
			name = "|c000000ffTelredor|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 11, 13, 15, 18, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 015
		{
			x = 0.49,
			y = 0.481,
			name = "|c000000ffTemple of Telhamat|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 14, 16, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 016
		{
			x = 0.573,
			y = 0.566,
			name = "|c000000ffHonor Hold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 15, 17, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 017
		{
			x = 0.66,
			y = 0.475,
			name = "|c000000ffShatter Point|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 16, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 018
		{
			x = 0.33,
			y = 0.726,
			name = "|c000000ffTelaar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 14, 19, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 019
		{
			x = 0.515,
			y = 0.751,
			name = "|c000000ffAllerian Stronghold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 16, 18, 20, 26, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 020
		{
			x = 0.602,
			y = 0.844,
			name = "|c000000ffWildhammer Stronghold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 19, 28, 29, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 021
		{
			x = 0.566,
			y = 0.128,
			name = "|c0000ff00Stormspire|r",
			tooltip = {  },
			links = { 22, 23, 24, 1, 11, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 022
		{
			x = 0.529,
			y = 0.236,
			name = "|c0000ff00Area 52|r",
			tooltip = {  },
			links = { 1, 2, 11, 12, 21, 23, 24, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 023
		{
			x = 0.632,
			y = 0.244,
			name = "|c0000ff00Cosmowrench|r",
			tooltip = {  },
			links = { 21, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 024
		{
			x = 0.391,
			y = 0.238,
			name = "|c0000ff00Evergrove|r",
			tooltip = {  },
			links = { 1, 11, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 025
		{
			x = 0.673,
			y = 0.522,
			name = "|c0000ff00Stair of Destiny|r",
			tooltip = {  },
			links = { 5, 6, 15, 16, 17, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 026
		{
			x = 0.43,
			y = 0.646,
			name = "|c0000ff00Shattrath City|r",
			tooltip = {  },
			links = { 3, 4, 5, 8, 9, 14, 18, 19, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 027
		{
			x = 0.534,
			y = 0.8,
			name = "|c0000ff00Blackwind Landing|r",
			tooltip = { " Skettis Rep & Quests" },
			links = { 9, 10, 19, 20, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 028
		{
			x = 0.683,
			y = 0.759,
			name = "|c0000ff00Altar of the Shatar|r",
			tooltip = { " Aldor" },
			links = { 10, 20, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 029
		{
			x = 0.669,
			y = 0.858,
			name = "|c0000ff00Sanctum of the Stars|r",
			tooltip = { " Scryers" },
			links = { 10, 20, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 030
		{
			x = 0.448,
			y = 0.646,
			name = "|c0000ff00City Portals|r",
			tooltip = { " (Shattrath City)" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
-- 031
		{
			x = 0.691,
			y = 0.524,
			name = "|c0000ff00Teleport from Blasted Lands|r",
			tooltip = {  },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
	},
-- Outland ^

-- Northrend
	["Northrend"] = {
-- 001
		{
			x = 0.176,
			y = 0.664,
			name = "|c00ff0000Warsong Hold|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 4, 36, 37, 38, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 002
		{
			x = 0.176,
			y = 0.64,
			name = "|c00ff0000Zeppelin Landing Pad|r",
			tooltip = { " (To Orgrimmar)" },
			faction = "Horde",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 003
		{
			x = 0.198,
			y = 0.516,
			name = "|c00ff0000Bor'Gorok Outpost|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 4, 36, 37, 39, 40, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 004
		{
			x = 0.288,
			y = 0.57,
			name = "|c00ff0000Taunka'le Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 3, 6, 36, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 005
		{
			x = 0.326,
			y = 0.454,
			name = "|c00ff0000Warsong Camp|r",
			tooltip = { " (Wintergrasp)" },
			faction = "Horde",
			links = { 6, 7, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 006
		{
			x = 0.432,
			y = 0.568,
			name = "|c00ff0000Agmar's Hammer|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 4, 5, 7, 8, 38, 41, 43, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 007
		{
			x = 0.467,
			y = 0.471,
			name = "|c00ff0000Kor'Kron Vanguard|r",
			tooltip = {  },
			faction = "Horde",
			links = { 5, 6, 8, 43, 44, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 008
		{
			x = 0.571,
			y = 0.613,
			name = "|c00ff0000Venomspite|r",
			tooltip = {  },
			faction = "Horde",
			links = { 6, 7, 9, 12, 14, 16, 41, 43, 53, 54, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 009
		{
			x = 0.54,
			y = 0.413,
			name = "|c00ff0000Sunreaver's Command|r",
			tooltip = {  },
			faction = "Horde",
			links = { 7, 8, 10, 43, 44, 50, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 010
		{
			x = 0.567,
			y = 0.233,
			name = "|c00ff0000Grom'marsh Crash Site|r",
			tooltip = {  },
			faction = "Horde",
			links = { 9, 11, 44, 50, 51, 52, 53, 54, 55, 56, 57, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 011
		{
			x = 0.693,
			y = 0.221,
			name = "|c00ff0000Camp Tunka'lo|r",
			tooltip = {  },
			faction = "Horde",
			links = { 10, 50, 51, 52, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 012
		{
			x = 0.651,
			y = 0.611,
			name = "|c00ff0000Conquest Hold|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 13, 14, 15, 54, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 013
		{
			x = 0.782,
			y = 0.559,
			name = "|c00ff0000Camp One'qwah|r",
			tooltip = {  },
			faction = "Horde",
			links = { 12, 15, 17, 54, 55, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 014
		{
			x = 0.681,
			y = 0.699,
			name = "|c00ff0000Apothecary Camp|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 12, 15, 16, 58, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 015
		{
			x = 0.764,
			y = 0.666,
			name = "|c00ff0000Camp Winterhoof|r",
			tooltip = {  },
			faction = "Horde",
			links = { 12, 13, 14, 16, 17, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 016
		{
			x = 0.774,
			y = 0.86,
			name = "|c00ff0000New Agamand|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 14, 15, 17, 58, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 017
		{
			x = 0.866,
			y = 0.749,
			name = "|c00ff0000Vengeance Landing|r",
			tooltip = {  },
			faction = "Horde",
			links = { 13, 15, 16, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 018
		{
			x = 0.866,
			y = 0.724,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " (To Undercity)" },
			faction = "Horde",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 019
		{
			x = 0.23,
			y = 0.681,
			name = "|c000000ffValiance Keep|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 21, 23, 36, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 020
		{
			x = 0.235,
			y = 0.702,
			name = "|c000000ffSea Port|r",
			tooltip = { " (To Stormwind City)" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 021
		{
			x = 0.227,
			y = 0.543,
			name = "|c000000ffFizzcrank Airstrip|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 19, 23, 36, 37, 39, 40, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 022
		{
			x = 0.388,
			y = 0.452,
			name = "|c000000ffValliance Camp|r",
			tooltip = { " (Wintergrasp)" },
			faction = "Alliance",
			links = { 23, 24, 40, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 023
		{
			x = 0.404,
			y = 0.605,
			name = "|c000000ffStar's Rest|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 19, 21, 22, 23, 37, 41, 43, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 024
		{
			x = 0.431,
			y = 0.508,
			name = "|c000000ffFordragon Keep|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 22, 23, 25, 26, 43, 44, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 025
		{
			x = 0.563,
			y = 0.553,
			name = "|c000000ffWintergarde Keep|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 23, 24, 26, 29, 31, 41, 43, 53, 54, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 026
		{
			x = 0.538,
			y = 0.46,
			name = "|c000000ffWindrunner's Overlook|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 25, 27, 43, 44, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 027
		{
			x = 0.546,
			y = 0.32,
			name = "|c000000ffFrosthold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 26, 28, 44, 50, 51, 52, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 028
		{
			x = 0.687,
			y = 0.273,
			name = "|c000000ffBrann Bronzebeard's Camp|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 27, 50, 51, 52, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 029
		{
			x = 0.677,
			y = 0.603,
			name = "|c000000ffAmberpine Lodge|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 25, 30, 31, 32, 54, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 030
		{
			x = 0.759,
			y = 0.493,
			name = "|c000000ffWestfall Brigade Encampment|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 29, 32, 55, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 031
		{
			x = 0.705,
			y = 0.768,
			name = "|c000000ffWestguard Keep|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 25, 30, 32, 33, 58, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 032
		{
			x = 0.814,
			y = 0.677,
			name = "|c000000ffFort Wildevar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 29, 30, 31, 33, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 033
		{
			x = 0.795,
			y = 0.84,
			name = "|c000000ffValgarde|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 31, 32, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 034
		{
			x = 0.809,
			y = 0.838,
			name = "|c000000ffSea Port|r",
			tooltip = { " (To Menethil Harbor)" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 035
		{
			x = 0.143,
			y = 0.584,
			name = "|c0000ff00Transitus Shield|r",
			tooltip = {  },
			links = { 36, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 036
		{
			x = 0.198,
			y = 0.584,
			name = "|c0000ff00Amber Ledge|r",
			tooltip = {  },
			links = { 35, 1, 3, 4, 19, 21, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 037
		{
			x = 0.299,
			y = 0.629,
			name = "|c0000ff00Unu'pe|r",
			tooltip = {  },
			links = { 1, 4, 19, 21, 22, 41, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 038
		{
			x = 0.305,
			y = 0.646,
			name = "|c0000ff00Sea Port|r",
			tooltip = {  },
			links = { 42, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 039
		{
			x = 0.203,
			y = 0.415,
			name = "|c0000ff00Nesingwary Base Camp|r",
			tooltip = {  },
			links = { 3, 21, 40, 49, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 040
		{
			x = 0.262,
			y = 0.415,
			name = "|c0000ff00River's Heart|r",
			tooltip = {  },
			links = { 3, 5, 21, 22, 39, 49, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 041
		{
			x = 0.465,
			y = 0.644,
			name = "|c0000ff00Moa'ki Harbor|r",
			tooltip = {  },
			links = { 6, 8, 22, 24, 37, 58, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 042
		{
			x = 0.465,
			y = 0.673,
			name = "|c0000ff00Sea Port|r",
			tooltip = {  },
			links = { 38, 59, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 043
		{
			x = 0.505,
			y = 0.568,
			name = "|c0000ff00Wyrmrest Temple|r",
			tooltip = {  },
			links = { 6, 7, 8, 9, 22, 23, 24, 25, 41, 44, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 044
		{
			x = 0.493,
			y = 0.405,
			name = "|c0000ff00Dalaran|r",
			tooltip = {  },
			links = { 7, 8, 9, 23, 25, 26, 27, 41, 43, 46, 53, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 045
		{
			x = 0.476,
			y = 0.405,
			name = "|c0000ff00City Portals|r",
			tooltip = { " (Dalaran)" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
-- 046
		{
			x = 0.502,
			y = 0.359,
			name = "|c0000ff00The Argent Vanguard|r",
			tooltip = {  },
			links = { 9, 10, 27, 44, 47, 48, 50, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 047
		{
			x = 0.477,
			y = 0.349,
			name = "|c0000ff00Crusader's Pinnacle|r",
			tooltip = { " (Access through Quests)" },
			links = { 46, 48, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 048
		{
			x = 0.369,
			y = 0.178,
			name = "|c0000ff00The Shadow Vault|r",
			tooltip = { " (Access through Quests)" },
			links = { 46, 47, 49, 51, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 049
		{
			x = 0.284,
			y = 0.262,
			name = "|c0000ff00Death's Rise|r",
			tooltip = { " (Access through Quests)" },
			links = { 39, 40, 48, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 050
		{
			x = 0.591,
			y = 0.363,
			name = "|c0000ff00K3|r",
			tooltip = {  },
			links = { 9, 10, 11, 26, 27, 28, 44, 46, 51, 52, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 051
		{
			x = 0.527,
			y = 0.17,
			name = "|c0000ff00Bouldercrag's Refuge|r",
			tooltip = {  },
			links = { 10, 11, 27, 28, 48, 50, 52, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 052
		{
			x = 0.601,
			y = 0.128,
			name = "|c0000ff00Ulduar|r",
			tooltip = {  },
			links = { 10, 11, 27, 28, 51, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 053
		{
			x = 0.603,
			y = 0.454,
			name = "|c0000ff00Ebon Watch|r",
			tooltip = {  },
			links = { 8, 9, 10, 25, 26, 27, 43, 44, 52, 54, 55, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 054
		{
			x = 0.645,
			y = 0.477,
			name = "|c0000ff00Light's Breach|r",
			tooltip = {  },
			links = { 8, 12, 13, 25, 29, 30, 50, 53, 55, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 055
		{
			x = 0.681,
			y = 0.44,
			name = "|c0000ff00The Argent Strand|r",
			tooltip = {  },
			links = { 13, 30, 53, 54, 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 056
		{
			x = 0.725,
			y = 0.411,
			name = "|c0000ff00Zim'Torga|r",
			tooltip = {  },
			links = { 11, 28, 13, 30, 52, 57, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 057
		{
			x = 0.751,
			y = 0.322,
			name = "|c0000ff00Gundrak|r",
			tooltip = {  },
			links = { 56, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 058
		{
			x = 0.691,
			y = 0.892,
			name = "|c0000ff00Kamagua|r",
			tooltip = {  },
			links = { 14, 16, 31, 41, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 059
		{
			x = 0.674,
			y = 0.892,
			name = "|c0000ff00Sea Port|r",
			tooltip = {  },
			links = { 42, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
	},
-- Northrend ^

-- Kalimdor
	["Kalimdor"] = {
-- 001
		{
			x = 0.522,
			y = 0.211,
			name = "|c00ff0000Moonglade|r",
			tooltip = { " (Horde)" },
			faction = "Horde",
			links = { 2, 38, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 002
		{
			x = 0.474,
			y = 0.295,
			name = "|c00ff0000Bloodvenom Post|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 3, 4, 6, 10, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 003
		{
			x = 0.59,
			y = 0.378,
			name = "|c00ff0000Valormok|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, 5, 6, 10, 11, 38, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 004
		{
			x = 0.433,
			y = 0.392,
			name = "|c00ff0000Zoram'gar Outpost|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, 5, 9, 10, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 005
		{
			x = 0.538,
			y = 0.413,
			name = "|c00ff0000Splintertree Outpost|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 4, 6, 10, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 006
		{
			x = 0.582,
			y = 0.448,
			name = "|c00ff0000Orgrimmar|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, 3, 5, 10, 11, 15, 38, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 007
		{
			x = 0.593,
			y = 0.493,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " Outside Orgrimmar\n To Undercity, & Grom'gol" },
			faction = "Horde",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 008
		{
			x = 0.576,
			y = 0.493,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " Outside Orgrimmar\n To Borean Tundra" },
			faction = "Horde",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 009
		{
			x = 0.449,
			y = 0.502,
			name = "|c00ff0000Sun Rock Retreat|r",
			tooltip = {  },
			faction = "Horde",
			links = { 4, 10, 11, 12, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 010
		{
			x = 0.528,
			y = 0.537,
			name = "|c00ff0000Crossroads|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, 3, 4, 5, 6, 9, 11, 13, 14, 15, 16, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 011
		{
			x = 0.468,
			y = 0.566,
			name = "|c00ff0000Thunder Bluff|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 6, 9, 10, 12, 13, 14, 15, 16, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 012
		{
			x = 0.382,
			y = 0.592,
			name = "|c00ff0000Shadowprey Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 9, 11, 13, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 013
		{
			x = 0.453,
			y = 0.697,
			name = "|c00ff0000Camp Mojache|r",
			tooltip = {  },
			faction = "Horde",
			links = { 10, 11, 12, 16, 43, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 014
		{
			x = 0.507,
			y = 0.652,
			name = "|c00ff0000Camp Taurajo|r",
			tooltip = {  },
			faction = "Horde",
			links = { 10, 11, 13, 14, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 015
		{
			x = 0.545,
			y = 0.644,
			name = "|c00ff0000Brackenwall Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 6, 10, 11, 42, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 016
		{
			x = 0.528,
			y = 0.745,
			name = "|c00ff0000Freewind Post|r",
			tooltip = {  },
			faction = "Horde",
			links = { 10, 11, 13, 14, 42, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 017
		{
			x = 0.538,
			y = 0.223,
			name = "|c000000ffMoonglade|r",
			tooltip = { " (Alliance)" },
			faction = "Alliance",
			links = { 24, 25, 38, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 018
		{
			x = 0.422,
			y = 0.184,
			name = "|c000000ffSea Port|r",
			tooltip = { " Sail to Darkshore" },
			faction = "Alliance",
			links = { 23, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 019
		{
			x = 0.422,
			y = 0.161,
			name = "|c000000ffRut'theran Village|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 020
		{
			x = 0.304,
			y = 0.192,
			name = "|c000000ffBlood Watch|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 021
		{
			x = 0.292,
			y = 0.281,
			name = "|c000000ffValaar's Landing|r",
			tooltip = { " Sail to Darkshore" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 022
		{
			x = 0.309,
			y = 0.271,
			name = "|c000000ffThe Exodar|r",
			tooltip = { " Flight Point Outside City" },
			faction = "Alliance",
			links = { 20,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 023
		{
			x = 0.437,
			y = 0.279,
			name = "|c000000ffAuberdine Sea Port|r",
			tooltip = { " Sail to Teldrassil, Azuremyst Isle, & Stormwind" },
			faction = "Alliance",
			links = { 18, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 024
		{
			x = 0.45,
			y = 0.279,
			name = "|c000000ffAuberdine|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 17, 19, 25, 26, 27, 28, 29, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 025
		{
			x = 0.509,
			y = 0.264,
			name = "|c000000ffTalonbranch Glade|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 17, 24, 38, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 026
		{
			x = 0.409,
			y = 0.419,
			name = "|c000000ffStonetalon Peak|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 27, 30, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 027
		{
			x = 0.485,
			y = 0.421,
			name = "|c000000ffAstranaar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 26, 28, 29, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 028
		{
			x = 0.555,
			y = 0.401,
			name = "|c000000ffForest Song|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 27, 29, 39, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 029
		{
			x = 0.576,
			y = 0.421,
			name = "|c000000ffTalrendis Point|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 25, 27, 28, 35, 38, 40, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 030
		{
			x = 0.432,
			y = 0.528,
			name = "|c000000ffNijel's Point|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 26, 32, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 031
		{
			x = 0.373,
			y = 0.691,
			name = "|c000000ffFeathermoon Sea Port|r",
			tooltip = { " Sail to The Forgotton Coast (Feralas)" },
			faction = "Alliance",
			links = { 33, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 032
		{
			x = 0.373,
			y = 0.714,
			name = "|c000000ffFeathermoon Stronghold|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 30, 34, 43, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 033
		{
			x = 0.398,
			y = 0.706,
			name = "|c000000ffThe Forgotten Coast|r",
			tooltip = { " Sail to Feathermoon Stronghold\n (Feralas)" },
			faction = "Alliance",
			links = { 31, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 034
		{
			x = 0.476,
			y = 0.732,
			name = "|c000000ffThalanaar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 32, 35, 42, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 035
		{
			x = 0.582,
			y = 0.669,
			name = "|c000000ffTheramore|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 29, 30, 34, 40, 42, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 036
		{
			x = 0.597,
			y = 0.669,
			name = "|c000000ffSea Port|r",
			tooltip = { " Sail To Menethil Harbour" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 037
		{
			x = 0.533,
			y = 0.182,
			name = "|c0000ff00Moonglade (Druids Only)|r",
			tooltip = {  },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
-- 038
		{
			x = 0.589,
			y = 0.233,
			name = "|c0000ff00Everlook|r",
			tooltip = {  },
			links = { 1, 2, 3, 6, 25, 29, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 039
		{
			x = 0.492,
			y = 0.349,
			name = "|c0000ff00Emerald Sanctuary|r",
			tooltip = {  },
			links = { 2, 4, 5, 25, 27, 28, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 040
		{
			x = 0.558,
			y = 0.566,
			name = "|c0000ff00Ratchet|r",
			tooltip = {  },
			links = { 10, 29, 35,  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 041
		{
			x = 0.572,
			y = 0.566,
			name = "|c0000ff00Sea Port|r",
			tooltip = { " Sail To Booty Bay" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 042
		{
			x = 0.554,
			y = 0.702,
			name = "|c0000ff00Mudsprocket|r",
			tooltip = {  },
			links = { 15, 16, 34, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 043
		{
			x = 0.436,
			y = 0.834,
			name = "|c0000ff00Cenarion Hold|r",
			tooltip = {  },
			links = { 13, 32, 44, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 044
		{
			x = 0.5,
			y = 0.788,
			name = "|c0000ff00Marshal's Refuge|r",
			tooltip = {  },
			links = { 43, 45, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 045
		{
			x = 0.564,
			y = 0.823,
			name = "|c0000ff00Gadgetzan|r",
			tooltip = {  },
			links = { 6, 10, 11, 13, 14, 15, 16, 34, 35, 42, 43, 44, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
	},
-- Kalimdor ^

-- Azeroth
	["Azeroth"] = {
-- 001
		{
			x = 0.56,
			y = 0.163,
			name = "|c00ff0000Silvermoon City|r",
			tooltip = {  },
			faction = "Horde",
			links = { 2, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 002
		{
			x = 0.558,
			y = 0.24,
			name = "|c00ff0000Tranquillien|r",
			tooltip = {  },
			faction = "Horde",
			links = { 1, 34, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 003
		{
			x = 0.436,
			y = 0.349,
			name = "|c00ff0000Undercity|r",
			tooltip = {  },
			faction = "Horde",
			links = { 4, 5, 6, 7, 8, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 004
		{
			x = 0.405,
			y = 0.388,
			name = "|c00ff0000The Sepulcher|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 5, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 005
		{
			x = 0.461,
			y = 0.427,
			name = "|c00ff0000Tarren Mill|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 4, 6, 7, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 006
		{
			x = 0.555,
			y = 0.436,
			name = "|c00ff0000Revantusk Village|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 5, 7, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 007
		{
			x = 0.533,
			y = 0.448,
			name = "|c00ff0000Hammerfall|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 5, 6, 8, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 008
		{
			x = 0.507,
			y = 0.656,
			name = "|c00ff0000Kargath|r",
			tooltip = {  },
			faction = "Horde",
			links = { 3, 7, 9, 10, 11, 36, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 009
		{
			x = 0.505,
			y = 0.695,
			name = "|c00ff0000Flame Crest|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 10, 36, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 010
		{
			x = 0.527,
			y = 0.798,
			name = "|c00ff0000Stonard|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 9, 11, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 011
		{
			x = 0.446,
			y = 0.867,
			name = "|c00ff0000Grom'Gol Outpost|r",
			tooltip = {  },
			faction = "Horde",
			links = { 8, 10, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMHorde",
		},
-- 012
		{
			x = 0.56,
			y = 0.141,
			name = "|c00ff0000Silvermoon - Orb of Translocation|r",
			tooltip = { " To Undercity" },
			faction = "Horde",
			links = { 13, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\HOrb",
		},
-- 013
		{
			x = 0.456,
			y = 0.338,
			name = "|c00ff0000Undercity - Orb of Translocation|r",
			tooltip = { " To Silvermoon City" },
			faction = "Horde",
			links = { 12, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\HOrb",
		},
-- 014
		{
			x = 0.427,
			y = 0.333,
			name = "|c00ff0000Zeppelin Towers|r",
			tooltip = { " To Grom'Gol & Orgrimmar & Howling Fjord" },
			faction = "Horde",
			links = { 15, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 015
		{
			x = 0.432,
			y = 0.867,
			name = "|c00ff0000Zeppelin Tower|r",
			tooltip = { " To Undercity & Orgrimmar" },
			faction = "Horde",
			links = { 14, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 016
		{
			x = 0.489,
			y = 0.357,
			name = "|c000000ffChillwind Camp|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 17, 18, 21, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 017
		{
			x = 0.502,
			y = 0.405,
			name = "|c000000ffAerie Peak|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 16, 18, 19, 21, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 018
		{
			x = 0.443,
			y = 0.446,
			name = "|c000000ffSouthshore|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 18, 19, 21, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 019
		{
			x = 0.51,
			y = 0.462,
			name = "|c000000ffRefuge Point|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 17, 18, 20, 21, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 020
		{
			x = 0.476,
			y = 0.535,
			name = "|c000000ffMenethil Harbour|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 18, 19, 21, 22, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 021
		{
			x = 0.439,
			y = 0.57,
			name = "|c000000ffIronforge|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 16, 17, 18, 19, 20, 22, 24, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 022
		{
			x = 0.518,
			y = 0.611,
			name = "|c000000ffThelsamar|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 19, 20, 21, 36, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 023
		{
			x = 0.505,
			y = 0.724,
			name = "|c000000ffMorgan's Vigil|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 25, 29, 36, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 024
		{
			x = 0.428,
			y = 0.73,
			name = "|c000000ffStormwind|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 21, 23, 25, 26, 27, 28, 29, 36, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 025
		{
			x = 0.5,
			y = 0.745,
			name = "|c000000ffLakeshire|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 23, 24, 26, 27, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 026
		{
			x = 0.414,
			y = 0.805,
			name = "|c000000ffSentinel Hill|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 25, 27, 28, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 027
		{
			x = 0.472,
			y = 0.805,
			name = "|c000000ffDarkshire|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 25, 26, 28, 29, 37, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 028
		{
			x = 0.439,
			y = 0.838,
			name = "|c000000ffRebel Camp|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 24, 26, 27, 37 },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 029
		{
			x = 0.529,
			y = 0.829,
			name = "|c000000ffNethergarde Keep|r",
			tooltip = {  },
			faction = "Alliance",
			links = { 23, 24, 27, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMAlliance",
		},
-- 030
		{
			x = 0.439,
			y = 0.6,
			name = "|c000000ffTram|r",
			tooltip = { " To Stormwind" },
			faction = "Alliance",
			links = { 31, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\AOrb",
		},
-- 031
		{
			x = 0.428,
			y = 0.71,
			name = "|c000000ffTram|r",
			tooltip = { " To Ironforge" },
			faction = "Alliance",
			links = { 30, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\AOrb",
		},
-- 032
		{
			x = 0.465,
			y = 0.549,
			name = "|c000000ffSea Port|r",
			tooltip = { " Sail To Theramore & Howling Fjord" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 033
		{
			x = 0.405,
			y = 0.73,
			name = "|c000000ffStormwind - Sea Port|r",
			tooltip = { " Sail To Auberdine & Borean Tundra" },
			faction = "Alliance",
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 034
		{
			x = 0.577,
			y = 0.26,
			name = "|c0000ff00Zul'Aman|r",
			tooltip = {  },
			links = { 2, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 035
		{
			x = 0.572,
			y = 0.34,
			name = "|c0000ff00Light's Hope Chapel|r",
			tooltip = {  },
			links = { 2, 3, 6, 16, 17, 21, 34, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 036
		{
			x = 0.48,
			y = 0.658,
			name = "|c0000ff00Thorium Point|r",
			tooltip = {  },
			links = { 8, 9, 21, 22, 23, 24, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 037
		{
			x = 0.436,
			y = 0.933,
			name = "|c0000ff00Booty Bay|r",
			tooltip = {  },
			links = { 8, 10, 11, 24, 26, 27, 28, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
-- 038
		{
			x = 0.423,
			y = 0.933,
			name = "|c0000ff00Sea Port|r",
			tooltip = { " To Ratchet" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\Anchor",
		},
-- 039
		{
			x = 0.532,
			y = 0.858,
			name = "|c0000ff00Portal to Outland|r",
			tooltip = { " To Hellfire Peninsula" },
			links = {  },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\NOrb",
		},
-- 040
		{
			x = 0.591,
			y = 0.335,
			name = "|c0000ff00Ebon Hold|r",
			tooltip = {  },
			links = { 2, 3, 6, 16, 17, 35, },
			icon = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral",
		},
	},
-- Azeroth ^

-----------------------------------------------------------------------------------------



-- Kalimdor
	["Ashenvale"] = {
	},
	["Aszhara"] = {
	},
	["AzuremystIsle"] = {
	},
	["BloodmystIsle"] = {
	},
	["Darkshore"] = {
	},
	["Desolace"] = {
	},
	["Durotar"] = {
	},
	["Dustwallow"] = {
	},
	["Felwood"] = {
	},
	["Feralas"] = {
	},
	["Moonglade"] = {
	},
	["Mulgore"] = {
	},
	["Silithus"] = {
	},
	["StonetalonMountains"] = {
	},
	["Tanaris"] = {
	},
	["Teldrassil"] = {
	},
	["Barrens"] = {
	},
	["ThousandNeedles"] = {
	},
	["UngoroCrater"] = {
	},
	["Winterspring"] = {
	},

-- Cities
	["Darnassis"] = {
	},
	["Ogrimmar"] = {
	},
	["TheExodar"] = {
	},
	["ThunderBluff"] = {
	},
-- Kalimdor ^

-----------------------------------------------------------------------------------------



-- Eastern Kingdoms
	["Alterac"] = {
	},
	["Arathi"] = {
	},
	["Badlands"] = {
	},
	["BlastedLands"] = {
	},
	["BurningSteppes"] = {
	},
	["DeadwindPass"] = {
	},
	["DunMorogh"] = {
	},
	["Duskwood"] = {
	},
	["EasternPlaguelands"] = {
	},
	["Elwynn"] = {
	},
	["EversongWoods"] = {
	},
	["Ghostlands"] = {
	},
	["Hilsbrad"] = {
	},
	["LochModan"] = {
	},
	["Redridge"] = {
	},
	["SearingGorge"] = {
	},
	["Silverpine"] = {
	},
	["Stranglethorn"] = {
	},
	["Sunwell"] = {
	},
	["SwampOfSorrows"] = {
	},
	["Hinterlands"] = {
	},
	["Tirisfal"] = {
	},
	["WesternPlaguelands"] = {
	},
	["Westfall"] = {
	},
	["Wetlands"] = {
	},

-- Cities
	["Ironforge"] = {
	},
	["SilvermoonCity"] = {
	},
	["Stormwind"] = {
	},
	["Undercity"] = {
	},
-- Eastern Kingdoms ^

-----------------------------------------------------------------------------------------



-- Outland
	["BladesEdgeMountains"] = {
	},
	["Hellfire"] = {
	},
	["Nagrand"] = {
	},
	["Netherstorm"] = {
	},
	["ShadowmoonValley"] = {
	},
	["TerokkarForest"] = {
	},
	["Zangarmarsh"] = {
	},

-- Cities
	["ShattrathCity"] = {
	},
-- Outland ^

-----------------------------------------------------------------------------------------



-- Northrend
	["BoreanTundra"] = {
	},
	["CrystalsongForest"] = {
	},
	["Dragonblight"] = {
	},
	["GrizzlyHills"] = {
	},
	["HowlingFjord"] = {
	},
	["IcecrownGlacier"] = {
	},
	["LakeWintergrasp"] = {
	},
	["SholazarBasin"] = {
	},
	["TheStormPeaks"] = {
	},
	["ZulDrak"] = {
	},

-- Cities
	["Dalaran"] = {
	},
-- Notrhrend ^

};
---------------------------------------------------------------------------------