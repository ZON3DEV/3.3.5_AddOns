

-- The toggling of these POIs on/off is controlled by a variable
-- stored within the main AlphaMap SavedVariables .taLocs
-- A loop through AlphaMapConfigurations saves it as a global AlphaMap variable

-- Templates for these plugins is in the main AlphaMap AddOn


local AlphaMap_POI_TravelAgents_Frame = CreateFrame("Frame");

local view;
local amUnitScale;
local selectedPOI = {};
local positiveSlopeTexture = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\LineTemplatePositive256";
local negativeSlopeTexture = "Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\LineTemplateNegative256";
local abs, min = math.abs, math.min;

-- Info for TravelAgents POI DropDowns to use
local POI_inf = {
	-- Define level one elements here
	[1] = {
		{ -- Title
			text = "AlphaMap3",
			isTitle = 1,
		},
		{ -- Change View Filter
			text = AM_TA_FILTER,
			hasArrow = true,
			value = "filter",
		},
		{ -- PointyPointy
			text = AM_WAYPOINT,
			dynamicFunc = AMap.PointyPointyPointy;
			func = function()
				if ( ( AMap.pointy ) and ( type(AMap.pointy) == "function" ) ) then
					AMap.pointy( unpack(AMap.pointyP) );
				end
			end,
		},
	},
	[2] = {
		filter = {
			{
				dynamicFunc = function()
					if ( view == "Horde" ) then
						return AM_TA_HORDE, true, nil, nil;
					else
						return AM_TA_HORDE, nil, nil, nil;
					end
				end,
				func = function()
					selectedPOI = {};
					view = "Horde";
					AlphaMapUnits_Update(1);
				end,
			},
			{
				dynamicFunc = function()
					if ( view == "Alliance" ) then
						return AM_TA_ALLIANCE, true, nil, nil;
					else
						return AM_TA_ALLIANCE, nil, nil, nil;
					end
				end,
				func = function()
					selectedPOI = {};
					view = "Alliance";
					AlphaMapUnits_Update(1);
				end,
			},
			{
				dynamicFunc = function()
					if ( view == "All" ) then
						return AM_TA_ALL, true, nil, nil;
					else
						return AM_TA_ALL, nil, nil, nil;
					end
				end,
				func = function()
					selectedPOI = {};
					view = "All";
					AlphaMapUnits_Update(1);
				end,
			},
		},
	},
};

local function poiVisible(typ)
	if ( ( view == "All" ) or ( not typ ) or ( view == typ ) ) then
		return true;
	else
		return nil;
	end
end

local function drawLine(line, lineFrame, width, height, x1, y1, x2, y2)
	if ( ( not x1 ) or ( not x2 ) or ( not y1 ) or ( not y2 ) ) then
		return;
	end

	local xOffset = ( (min(x1,x2) * width ) );
	local yOffset = -( (min(y1,y2) * height) );

	local deltax = ( abs((x1 - x2) * width)  );
	local deltay = ( abs((y1 - y2) * height) );

	local lowerpixel = min(deltax, deltay);
	lowerpixel = lowerpixel / 256;
	if ( lowerpixel > 1 ) then
		lowerpixel = 1;
	end

	if ( deltax == 0 ) then
		deltax = 2;
		line:SetTexture(0, 0, 0);
		line:SetTexCoord(0, 1, 0, 1);

	elseif ( deltay == 0 ) then
		deltay = 2;
		line:SetTexture(0, 0, 0);
		line:SetTexCoord(0, 1, 0, 1);

	elseif ( x1 - x2 < 0 ) then
		if y1 - y2 < 0 then
			line:SetTexture(negativeSlopeTexture);
			line:SetTexCoord(0, lowerpixel, 0, lowerpixel);
		else
			line:SetTexture(positiveSlopeTexture);
			line:SetTexCoord(0, lowerpixel, 1-lowerpixel, 1);
		end

	else
		if ( y1 - y2 < 0 ) then
			line:SetTexture(positiveSlopeTexture);
			line:SetTexCoord(0, lowerpixel, 1-lowerpixel, 1);
		else
			line:SetTexture(negativeSlopeTexture);
			line:SetTexCoord(0, lowerpixel, 0, lowerpixel);
		end
	end

	line:SetWidth(deltax);
	line:SetHeight(deltay);
	line:ClearAllPoints();
	line:SetPoint("TOPLEFT", lineFrame, "TOPLEFT", xOffset, yOffset);
	line:Show();
end

-- Display of the actual POIs on the AlphaMap world maps
local function DisplayTravelAgentsLocs(c, z, m, frame, lFloor)

	local note, noteT, line;
	local width = frame:GetWidth();
	local height = frame:GetHeight();
	local x, y;
	local i, l = 0, 0;
	if ( lFloor == nil ) then
		lFloor = GetCurrentMapDungeonLevel();
	end

	amUnitScale = AlphaMap_GetUnitScale();

	-- Horde / Alliance player ? Defines default view
	if ( not view ) then
		view = UnitFactionGroup("player");
	end

	if ( ( AlphaMapConfig.taLocs ) and ( AM_TRAVELAGENTS_LOCS ) and ( AM_TRAVELAGENTS_LOCS[m] ) ) then

		for indx, poi in ipairs(AM_TRAVELAGENTS_LOCS[m]) do

			-- Faction Filtering
			if ( poiVisible(poi.faction) ) then
				if ( ( not poi.floor ) or ( poi.floor == lFloor ) ) then
					i = i + 1;
					note = getglobal("AM_POITA_Note_"..i);
					if ( not note ) then
						note = CreateFrame("Button", "AM_POITA_Note_"..i, frame, "AM_GenPOI_Template");
						note:SetScript("OnEnter", function(self)
							local x, y = GetCursorPosition();
							if ( x > 500 ) then
								GameTooltip:SetOwner(this, "ANCHOR_TOPRIGHT");
							else
								GameTooltip:SetOwner(this, "ANCHOR_TOPLEFT");
							end

							GameTooltip:ClearLines();

							GameTooltip:AddLine("AlphaMap_POI_TravelAgents");
							GameTooltip:AddLine(self.name);
							local i = 1;
							while( self.tooltip[i] ) do
								GameTooltip:AddDoubleLine(self.tooltip[i], self.tooltip[i+1]);
								i = i + 2;
							end

							AlphaMap_ShowTooltip();
						end)
						note:SetScript("OnLeave", function()
							AlphaMap_HideTooltip();
						end)
						note:SetScript("OnClick", function(self, mouseButton)
							if ( mouseButton == "LeftButton" ) then
								if ( ( selectedPOI.m == self.m ) and ( selectedPOI.i == self.indx ) ) then
									selectedPOI = {};

								else
									selectedPOI = {};
									if ( ( self.links ) and ( #(self.links) > 0 ) ) then
										-- Draw links from this Travel Agent to other Destinations
										selectedPOI.m = self.m;
										selectedPOI.i = self.indx;
									end
								end
								AlphaMapUnits_Update(1);
							
							elseif ( mouseButton == "RightButton" ) then
								AMap.POI = self;
								AMap.InitialiseDropdown(POI_inf);
								if ( AMap.dd.bttns > 1 ) then
									ToggleDropDownMenu(1, nil, AMap.dd, "cursor", 0, 0);
								end
							end
						end)
					end
					noteT = getglobal("AM_POITA_Note_"..i.."Texture");
					noteT:SetTexture( poi.icon );

					x = ( poi.x * width ) / amUnitScale;
					y = ( poi.y * height ) / amUnitScale;

					note.name = poi.name;
					note.tooltip = poi.tooltip;
					note.links = poi.links;
					note.indx = indx;
					note.c = c;
					note.z = z;
					note.m = m;
					note.x = poi.x;
					note.y = poi.y;
					note.icon = poi.icon;

					note:ClearAllPoints();
					note:SetScale(amUnitScale);
					note:SetPoint("CENTER", frame, "TOPLEFT", x, -y);
					note:Show();
				end
			end

		end

		-- Draw Routes from Selected Travel Agent (Only allowing one selection at a time atm...)
		-- Changing the view (i.e. Horde/Alliance/etc.) will DE-select any selected Travel Agent
		local departure, destination;
		if ( m == selectedPOI.m ) then
			departure = AM_TRAVELAGENTS_LOCS[m][selectedPOI.i];
			if ( ( departure ) and ( poiVisible(departure.faction) ) ) then
				for _, link in ipairs(departure.links) do
					if ( link ~= selectedPOI.i ) then	-- can't test so putting extra checks in (don't link to self)
						destination = AM_TRAVELAGENTS_LOCS[m][link];
						if ( ( destination ) and ( poiVisible(destination.faction) ) ) then
							l = l + 1;
							line = getglobal("AM_POITA_Line"..l);
							if ( not line ) then
								line = frame:CreateTexture( ("AM_POITA_Line"..l), "ARTWORK");
								if ( not line ) then break; end
							end
							drawLine(line, frame, width, height, departure.x, departure.y, destination.x, destination.y);
						end
					end
				end
			end
		end

	end

	i = i + 1;
	note = getglobal("AM_POITA_Note_"..i);
	while (note) do
		note:Hide();
		i = i + 1;
		note = getglobal("AM_POITA_Note_"..i);
	end

	l = l + 1;
	line = getglobal("AM_POITA_Line"..l);
	while (line) do
		line:Hide();
		l = l + 1;
		line = getglobal("AM_POITA_Line"..l);
	end

end


local  POIIOld_AlphaMap_ResetAll;
local function POIINew_AlphaMap_ResetAll()
	POIIOld_AlphaMap_ResetAll();
	AlphaMapConfig.taLocs = true;
	for configuration, configurations in pairs(AlphaMapConfigurations) do
		AlphaMapConfigurations[ configuration ].taLocs = AlphaMapConfig.taLocs;
	end
end

-- Variables_Loaded is the only event registered.
local function AlphaMap_POI_TravelAgents_OnEvent()

	-- Hook the AlphaMap Options Reset Function
	POIIOld_AlphaMap_ResetAll = AlphaMap_ResetAll;
	AlphaMap_ResetAll = POIINew_AlphaMap_ResetAll;

	-- Set up Saved AlphaMap configuration options
	if ( AlphaMapConfig.taLocs == nil ) then
		AlphaMapConfig.taLocs = true;
	end
	for configuration, configurations in pairs(AlphaMapConfigurations) do
		AlphaMapConfigurations[ configuration ].taLocs = AlphaMapConfig.taLocs;
	end

	-- Insert TravelAgents Display function code in to the main AlphaMap POI Plugin array
	-- AlphaMap will loop through these functions to display the required POIs
	table.insert(AMap.CustomPOIs, DisplayTravelAgentsLocs);

	-- Set up the Control Check Button allowing people to toggle 
	-- display of TravelAgents Locations off and on from the AlphaMap
	local i = #(AMap.CustomPOIControls) + 1;
	local controlButton = CreateFrame("Button", "AM_POIC"..i, UIParent, "AM_GenPOIControl_Template");
	controlButton.id = i;
	local controlButtonT = getglobal("AM_POIC"..i.."Texture");
	controlButtonT:SetTexture("Interface\\AddOns\\AlphaMap3_POI_TravelAgents\\Artwork\\FMNeutral");
	local controlButtonC = getglobal("AM_POIC"..i.."Check");
	controlButtonC:SetScript("OnShow", function(self)
		self:SetFrameLevel( self:GetParent():GetFrameLevel() + 3 );
		if ( AlphaMapConfig.taLocs ) then
			self:SetChecked(1);
		else
			self:SetChecked(0);
		end
	end)
	controlButtonC:SetScript("OnClick", function(self)
		local checked = this:GetChecked()
		if self then checked = not checked; end
		if ( checked ) then
			PlaySound("igMainMenuOptionCheckBoxOff");
			AlphaMapConfig.taLocs = false;
			this:SetChecked(0);

		else
			PlaySound("igMainMenuOptionCheckBoxOn");
			AlphaMapConfig.taLocs = true;
			this:SetChecked(1);
		end
		for configuration, configurations in pairs(AlphaMapConfigurations) do
			AlphaMapConfigurations[ configuration ].taLocs = AlphaMapConfig.taLocs;
		end
		AlphaMapUnits_Update(1);
	end)
	controlButton:SetScript("OnClick", function(self)
		local v = getglobal(self:GetName() .. "Check");
		if ( v ) then
			this = v;
			v = v:GetScript("OnClick");
			if ( v ) then v(); end
		end
	end)

	-- Insert the Created control button in to the main AlphaMap array
	-- for display when the Control & Alt keys are pressed together
	table.insert(AMap.CustomPOIControls, controlButton);

end


-- Register Variables Loaded Event
AlphaMap_POI_TravelAgents_Frame:SetScript("OnEvent", AlphaMap_POI_TravelAgents_OnEvent);
AlphaMap_POI_TravelAgents_Frame:RegisterEvent("VARIABLES_LOADED");

