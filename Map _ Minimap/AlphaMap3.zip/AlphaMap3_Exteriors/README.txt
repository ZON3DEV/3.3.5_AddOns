
This is a plugin AddOn for "AlphaMap (Fan's Update)"

It shows pre-made Minimap textured maps of Instance Exteriors and cave systems like Black Rock Mountain, Caverns of Time, etc.

It will show Raid and/or Party members on the map.
(Especially useful with the "PartySpotter" AddOn installed).

If you have Enabled Mouse Interactive mode then you can Zoom in/out on particular areas of the map by <ALT>-Left/Right clicking;
Useful when you want to see a particular area in more detail.


