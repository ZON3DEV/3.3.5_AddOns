
-- Register the map data with the main AddOn
AlphaMap_RegisterMaps(AM_TYP_EXTERIORS, AM_ALPHAMAP_EXTERIORS_LIST);


