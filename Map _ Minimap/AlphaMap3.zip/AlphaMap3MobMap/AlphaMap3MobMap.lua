


local AlphaMobMap_Frame = CreateFrame("Frame");
local mmFrame = MobMapDotParentFrame;
local updateLimit, updateTimer = 0.2, 0;

local mmFrameOriP = WorldMapPositioningGuide;

local function amVisible(tFrame)
	if ( ( AlphaMapFrame:IsVisible() ) 
	 and ( not AlphaMapAlphaMapFrame:IsVisible() ) 
	 and ( not tFrame:IsVisible() ) ) then
		return true;
	end
end



-- HOOKS
local amOri_MobMapDotFrame_OnClick;			-- MobMapDotFrame_OnClick Hook to enable MapNote creation
local amOri_MobMap_ScanTarget;				-- MobMap_ScanTarget Hook to prevent MobMap constantly changing map
local amOri_MobMap_Display;					-- Ensure AlphaMap triggers WorldMap functionality
local amOri_MobMap_SwitchMapAndDisplay;
local amOri_MobMap_GetPlayerCoordinates;
local amOri_MobMap_DisplayDotTooltip;
local amOri_MobMap_HideDotTooltip;
local amOri_MobMap_MakeSureMapIsVisible;	-- make sure WorldMapFrame is ONLY Opened via the Blizzard ToggleFrame function, and NOT by WorldMapFrame:Show()

local function amNew_MobMap_MakeSureMapIsVisible(...)
	if ( not WorldMapFrame:IsVisible() ) then
		if ( IsShiftKeyDown() ) then
			WorldMapFrame:Show();
			ToggleFrame( WorldMapFrame );
			ToggleFrame( WorldMapFrame );
			ToggleFrame( WorldMapFrame );
			ToggleFrame( WorldMapFrame );

		elseif ( AlphaMapAlphaMapFrame:IsVisible() ) then
			amAlphaMapMap = nil;
			AlphaMapFrame_Update();

		else
			ToggleAlphaMap();
			if ( not AlphaMapFrame:IsVisible() ) then
				ToggleAlphaMap();
			end
		end
	end
--	amOri_MobMap_MakeSureMapIsVisible(...);
end

local function amNew_MobMapDotFrame_OnClick(self, ...)
	if ( IsControlKeyDown() ) then
		local z = mobmap_zoneindex[ MobMap_GetCurrentMapZoneName() ];
		if ( z ) then
			MN_ThottInterface_Legacy( z.c, z.z, self.xcoord, self.ycoord, MobMapButtonFrameCurrentMob:GetText(), "AlphaMobMap" );
		end

	else
		amOri_MobMapDotFrame_OnClick(self, ...);
	end
end

local function amNew_MobMap_ScanTarget(...)
	local tmpF = WorldMapFrame.IsVisible;
	if ( ( AlphaMapFrame:IsVisible() ) or ( WorldMapFrame:IsVisible() ) ) then
		WorldMapFrame.IsVisible = function()
			return true;
		end
	else
		WorldMapFrame.IsVisible = function()
			return false;
		end
	end
	amOri_MobMap_ScanTarget(...);
	WorldMapFrame.IsVisible = tmpF;
end

local function amNew_MobMap_Display(...)
	if ( ( WorldMapFrame ~= AlphaMapFrame ) and ( amVisible(WorldMapFrame) ) ) then
		local tmpF = WorldMapFrame;
		WorldMapFrame = AlphaMapFrame;
		amOri_MobMap_Display(...);
		WorldMapFrame = tmpF;
	else
		amOri_MobMap_Display(...);
	end
end

local function amNew_MobMap_SwitchMapAndDisplay(...)
	if ( ( WorldMapFrame ~= AlphaMapFrame ) and ( amVisible(WorldMapFrame) ) ) then
		local tmpF = WorldMapFrame;
		WorldMapFrame = AlphaMapFrame;
		amOri_MobMap_SwitchMapAndDisplay(...);
		WorldMapFrame = tmpF;
	else
		amOri_MobMap_SwitchMapAndDisplay(...);
	end
end

local function amNew_MobMap_GetPlayerCoordinates(...)
	local tmpF = WorldMapFrame.IsVisible;
	if ( ( AlphaMapFrame:IsVisible() ) or ( WorldMapFrame:IsVisible() ) ) then
		WorldMapFrame.IsVisible = function()
			return true;
		end
	else
		WorldMapFrame.IsVisible = function()
			return false;
		end
	end
	local x, y, zn, zl = amOri_MobMap_GetPlayerCoordinates(...);
	WorldMapFrame.IsVisible = tmpF;
	
	return x, y, zn, zl;
end

local function amNew_MobMap_DisplayDotTooltip(self, ...)
	if ( not WorldMapButton:IsVisible() ) then
		if ( self.idtable ) then
			GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");
			GameTooltip:AddDoubleLine("Position:",self.xcoord..","..self.ycoord,1,1,1,1,1,1);
			local k,v;
			for k,v in pairs(self.idtable) do
				GameTooltip:AddLine(MobMap_GetMobName(v));
			end		
			GameTooltip:Show();
		end
		if ( self.ihidtable ) then
			GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");
			GameTooltip:AddDoubleLine("Position:",self.xcoord..","..self.ycoord,1,1,1,1,1,1);
			local k,v;
			for k,v in pairs(self.ihidtable) do
				local itemname=MobMap_GetItemNameByIHID(v);
				local itemid, quality = MobMap_GetItemDataByIHID(v);
				GameTooltip:AddLine(MobMap_ConstructColorizedItemName(quality, itemname));
			end		
			GameTooltip:Show();
		end
		if ( self.freetext ) then
			GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");
			GameTooltip:AddDoubleLine("Position:",self.xcoord..","..self.ycoord,1,1,1,1,1,1);
			GameTooltip:AddLine(self.freetext);
			GameTooltip:Show();
		end
	else
		amOri_MobMap_DisplayDotTooltip(self, ...);
	end
end

local function amNew_MobMap_HideDotTooltip(...)
	GameTooltip:Hide();
	amOri_MobMap_HideDotTooltip(...);
end
--HOOKS



-- MAIN FUNCTIONS
local function AlphaMobMap_OnEvent(_, event)

	if ( event == "VARIABLES_LOADED" ) then

		mmFrame:SetParent(WorldMapPositioningGuide);
		mmFrame:SetFrameStrata(WorldMapPositioningGuide:GetFrameStrata());
--		mmFrame:SetScale(WorldMapFrame:GetScale());
		mmFrame:ClearAllPoints();
		mmFrame:SetAllPoints(WorldMapPositioningGuide);

		-- MobMapDotParentFrame:SetScript("OnUpdate"..... to base scale/alpha on parent, and not WorldMapFrame...
		mmFrame:SetScript("OnUpdate", function(self, elapsed)
			self:SetAlpha(1.0);
			MobMap_ProcessDotEffects(self, elapsed);
		end)

		-- Hooks
		if ( MN_ThottInterface_Legacy ) then
			amOri_MobMapDotFrame_OnClick = MobMapDotFrame_OnClick;
			MobMapDotFrame_OnClick = amNew_MobMapDotFrame_OnClick;
		end
		amOri_MobMap_ScanTarget = MobMap_ScanTarget;
		MobMap_ScanTarget = amNew_MobMap_ScanTarget;
		amOri_MobMap_Display = MobMap_Display;
		MobMap_Display = amNew_MobMap_Display;
		amOri_MobMap_SwitchMapAndDisplay = MobMap_SwitchMapAndDisplay;
		MobMap_SwitchMapAndDisplay = amNew_MobMap_SwitchMapAndDisplay;
		amOri_MobMap_GetPlayerCoordinates = MobMap_GetPlayerCoordinates;
		MobMap_GetPlayerCoordinates = amNew_MobMap_GetPlayerCoordinates;
		amOri_MobMap_DisplayDotTooltip = MobMap_DisplayDotTooltip;
		MobMap_DisplayDotTooltip = amNew_MobMap_DisplayDotTooltip;
		amOri_MobMap_HideDotTooltip = MobMap_HideDotTooltip;
		MobMap_HideDotTooltip = amNew_MobMap_HideDotTooltip;
		amOri_MobMap_MakeSureMapIsVisible = MobMap_MakeSureMapIsVisible;
		MobMap_MakeSureMapIsVisible = amNew_MobMap_MakeSureMapIsVisible;

	elseif ( event == "WORLD_MAP_UPDATE" ) then
		if  ( ( mobmap_enabled ) 
		 and  ( amVisible(WorldMapFrame) ) 
		 and  ( MobMapMobSearchFrame or MobMapPickupListFrame or MobMapQuestListFrame or mobmap_currentlyshown ) ) then
			local z = MobMap_GetCurrentMapZoneName();
			if ( mobmap_lastzone ~= z ) then
				mobmap_lastzone = z;
				MobMap_Display();
			end
		end
	end
end

-- atm, AlphaMap is the only other AddOn trying to display MobMap off the World Map, so I've left it implemented this way ;p
local function AlphaMobMap_OnUpdate(_, elapsed)
	updateTimer = updateTimer + elapsed;

	if ( updateTimer > updateLimit ) then
		local mmFrameP = mmFrame:GetParent();
		if ( amVisible(mmFrameOriP) ) then
			if ( ( mmFrameP ~= AlphaMapFrame ) and ( mobmap_enabled ) ) then
				mmFrame:ClearAllPoints();
				mmFrame:SetParent(AlphaMapFrame);
				mmFrame:SetFrameLevel( AlphaMapFrame:GetFrameLevel() + 3 );
				mmFrame:SetPoint("TOPLEFT", AlphaMapFrame, "TOPLEFT", 0, 68);		-- ?  68 / AlphaMapFrame:GetScale()  ? --
				mmFrame:Show();
			end

		elseif ( ( mmFrameP ~= mmFrameOriP ) and ( mobmap_enabled ) ) then
			mmFrame:ClearAllPoints();
			mmFrame:SetParent(mmFrameOriP);
			mmFrame:SetFrameLevel( mmFrameOriP:GetFrameLevel() + 2 );
			mmFrame:SetAllPoints();
			mmFrame:Show();
		end
	end
end

AlphaMobMap_Frame:SetScript("OnEvent", AlphaMobMap_OnEvent);
AlphaMobMap_Frame:SetScript("OnUpdate", AlphaMobMap_OnUpdate);
AlphaMobMap_Frame:RegisterEvent("VARIABLES_LOADED");
AlphaMobMap_Frame:RegisterEvent("WORLD_MAP_UPDATE");
