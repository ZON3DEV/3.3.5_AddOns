
AlphaMobMap
===========

AlphaMobMap makes MobMap icons that normally appear only on the WorldMap, visible on AlphaMap.

If you have "MapNotes (Fan's Update)" installed [v4.14.20300 or later], then you can create temporary or permanent MapNotes to track via the WorldMap and/or Minimap.

1.) <CTRL>-Click on a MobMap note to create a MapNote



Change Log
==========

v2.00.30000
-----------

- much more memory efficient & processor efficient re-write based on latest MobMap version

- released 03/03/2009



v1.00.20300
-----------

- released 02/02/2008
