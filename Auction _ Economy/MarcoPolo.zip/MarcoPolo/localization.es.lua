local _, L = ...;
if GetLocale() == "esES" or GetLocale() == "esMX" then
    L["Version"] = "Versión";
    L["Sintax: /mp [Item link] amount"] = "Sintaxis: /mp [Enlace del producto] cantidad";
    L["loaded"] = "cargada";
    L["Your gray have been sold"] = "Tus grises se han vendido por";
    L["Aquired"] = "Adquirido";
    L["You don't have enough gold to buy"] = "No tiene suficiente dinero para comprar";
    L["you're missing"] = "te falta";
    L["Armor repair cost"] = "Coste de reparación de la armadura";
    L["You don't have enough gold to repair!"] = "¡No tienes suficiente oro para reparar!";
    L["You need"] = "Necesitas";
end
