local _, L = ...;
if GetLocale() == "frFR" then
    L["Version"] = "Version";
    L["Sintax: /mp [Item link] amount"] = "Syntaxe: /mp [Lien du produit] quantité";
    L["loaded"] = "chargé";
    L["Your gray have been sold"] = "Gris vendus";
    L["Aquired"] = "Acquis";
    L["You don't have enough gold to buy"] = "Vous n'avez pas assez d'argent pour acheter";
    L["you're missing"] = "Il vous manque";
    L["Armor repair cost"] = "Coût de réparation de l'armure";
    L["You don't have enough gold to repair!"] = "Vous n'avez pas assez d'argent pour réparer!";
    L["You need"] = "Vous avez besoin de";
end
