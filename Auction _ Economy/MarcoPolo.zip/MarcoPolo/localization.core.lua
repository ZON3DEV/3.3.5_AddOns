local MarcoPolo, L = ...; 
local function defaultFunc(L, key)
    -- Cuando no exista localización devolvemos la cadena por defecto que está en inglés
    return key;
end
setmetatable(L, {__index=defaultFunc});
