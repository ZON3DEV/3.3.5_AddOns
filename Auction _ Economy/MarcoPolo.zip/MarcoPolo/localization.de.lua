-- Sorry for the "googled" translation
local _, L = ...;
if GetLocale() == "deDE" then
    L["Version"] = "Version";
    L["Sintax: /mp [Item link] amount"] = "Syntax: / mp [product link] zahl";
    L["loaded"] = "berechnet";
    L["Your gray have been sold"] = "Ihre grauen verkauft worden";
    L["Aquired"] = "Erworben";
    L["You don't have enough gold to buy"] = "Nicht genug Geld zum Kauf";
    L["you're missing"] = "Ihnen fehlen";
    L["Armor repair cost"] = "Kosten für die Behebung Rüstung";
    L["You don't have enough gold to repair!"] = "Sie haben nicht genug Gold, um zu reparieren!";
    L["You need"] = "Sie müssen";
end
