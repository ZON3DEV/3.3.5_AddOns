--[[
	MarcoPolo.lua
		Merchant automation
--]]

--[[
	Copyright (c) 2010 Philippe Mingo
	All rights reserved.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		  this list of conditions and the following disclaimer.
		* Redistributions in binary form must reproduce the above copyright
		  notice, this list of conditions and the following disclaimer in the 
		  documentation and/or other materials provided with the distribution.
		* Neither the name of the author nor the names of its contributors may 
		  be used to endorse or promote products derived from this software 
		  without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
	IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
	ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
	LIABLE FORANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
	CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
	POSSIBILITY OF SUCH DAMAGE.
--]]

local function dsp(...)

	local text = "|cff33ff99MarcoPolo|r:"
	local i;
	
	for i = 1, select("#", ...) do
		text = text .. " " .. tostring( select( i, ... ) )
	end
	print(text)
	
end

SLASH_MARCOPOLO1, SLASH_MARCOPOLO2 = '/mp', '/marcopolo';

local _, L = ...;

local sVersion = " 0.0.08 ";

local function gestor( msg, editbox )

    local cmd, txt, par = msg:match("^.*%|.*|Hitem:(%d*).*%[(.*)%]|h.*%|%r%s*(.*)$");

    if par == nil then
        par = 0;
    end
    
    if cmd == nil or txt == nil then
        -- no viene un enlace
        dsp( L["Version"] .. sVersion ); 
        dsp( L["Sintax: /mp [Item link] amount"] );
        -- Mostramos la configuración
        for k,c in pairs( MarcoPoloConfig ) do dsp( GetItemInfo( k ) .. " : " .. c .. " (" .. GetItemCount( k ) .. ")" ) end        
    else
        dsp( "(" .. txt .. ") (" .. par .. ")" );
        if tonumber( par ) == 0 then
            -- Se quiere eliminar un elemento de configuración
            MarcoPoloConfig[cmd] = nil;
        else
            MarcoPoloConfig[cmd] = par;
        end
    end
    
    -- prn = gsub(msg, "\124", "\124\124");
    -- dsp( prn );
    
end

SlashCmdList["MARCOPOLO"] = gestor; 

function mpInicio() 

    -- Interceptamos el evento del mercader
	this:RegisterEvent( "MERCHANT_SHOW" );
	-- Y el del final de carga del evento para iniciar la configuración
	this:RegisterEvent( "ADDON_LOADED" );
	
	dsp( L["Version"] .. sVersion .. L["loaded"] );
	
end

function mpEvento(event, arg1)

	local i = 0;
	local j = 0;
	local iMercancias = 0;
	local iPrecio = 0;
	local iRareza = 0;
	local iTotal = 0;
	local iCantidad = 0;
	local sNombre = "";
	local sWrk = "";
	local lObj;
	local iStack = 0;
	local iPaquetes = 0;
	local iUnidades = 0;
	local iLote = 0;
	local iDisp = 0;
	local iMod = 0;

    -- Comprobamos si han cargado las variables persistentes
    if event == "ADDON_LOADED" then        
        if arg1 == "MarcoPolo" then
            if MarcoPoloConfig == nil then
                MarcoPoloConfig = {};
            end	        
        end
    -- Comprobamos si estamos con un mercader
	elseif event == "MERCHANT_SHOW" then
       	
       	-- Vendemos los grises
		repeat
			if GetContainerNumSlots( i ) ~= nil then
				caslots = GetContainerNumSlots( i );

				j = 1;
				repeat
					lObj = GetContainerItemLink( i, j );
					if lObj ~= nil then
					    iCantidad = select( 2, GetContainerItemInfo( i, j ) );
                        _, _, iRareza, _, _, _, _, _, _, _, iPrecio = GetItemInfo( lObj ); 						
						if( iRareza == 0 and iPrecio ~= nil and iPrecio ~= 0 ) then
							UseContainerItem( i, j );
							iTotal = iTotal + ( iPrecio * iCantidad ); 
						end
					end
					j = j + 1;
				until j >= caslots + 1;
			end
			i = i + 1;
		until i >= 5		

        -- Si hemos vendido algo mostramos el importe
        if iTotal > 0 then
    		dsp( L["Your gray have been sold"] .. " " .. pastaTXT( iTotal ) );
    		iTotal = 0;    	
		end	

        -- Comprobamos si tenemos que comprar algo
        iMercancias = GetMerchantNumItems();
        for k,c in pairs( MarcoPoloConfig ) do
            iCantidad = c - GetItemCount( k );
            if iCantidad > 0 then
                sNombre, _, _, _, _, _, _, iStack = GetItemInfo( k );                    
                for i = 1, iMercancias do
                    sWrk, _, iPrecio, iLote, iDisp = GetMerchantItemInfo( i );
                    if sWrk == sNombre then
                        if GetMoney() >= iPrecio * iCantidad / iLote then
                            -- Compramos
                            iPaquetes = math.floor( iCantidad / iStack );
                            iUnidades = iCantidad % iStack;
                            while iPaquetes > 0 do
                                BuyMerchantItem( i, iStack / iLote );
                                iPaquetes = iPaquetes - 1;
                            end
                            if iUnidades > 0 then
                                -- Hacemos un múltiplo del stack de venta
                                iMod = math.ceil( iUnidades / iLote ) * iLote;
                                iCantidad = iCantidad - iUnidades + iMod;                                                                                    
                                BuyMerchantItem( i, iMod / iLote );
                            end
                            dsp( L["Aquired"] .. " " .. iCantidad .. " x " .. sNombre .. " " .. pastaTXT( iPrecio * iCantidad / iLote ) );
                        else
                            dsp( L["You don't have enough gold to buy"] .. " " .. iCantidad .. " x " .. sNombre .. " " .. L["you're missing"] .. " " .. pastaTXT( ( iPrecio * iCantidad / iLote ) - GetMoney() ) );
                        end
                    end
                end 
            end 
        end
	
	    -- Comprobamos si el mercader puede reparar
		if CanMerchantRepair() == 1 then
			iTotal, canRepair = GetRepairAllCost();
			-- Y comprobamos si tenemos algo por reparar
			if iTotal > 0 then
				if canRepair == 1 then
					RepairAllItems();
                    dsp( L["Armor repair cost"] .. " : " .. pastaTXT( iTotal ) ); 
					iTotal = 0;
				else
				    iPrecio = iTotal - GetMoney();
                    dsp( L["You don't have enough gold to repair!"] .. " " .. L["You need"] .. " " .. pastaTXT( iTotal ) ); 
				end
			end
		end
		
	end
end

function pastaTXT( valor )

    local iCobre = valor % 100;
    local iPlata = math.floor( ( valor % 10000 ) / 100 );
    local iOro = math.floor( valor / 10000 );

	if iOro > 0 then
		return format( GOLD_AMOUNT_TEXTURE .. " " .. SILVER_AMOUNT_TEXTURE .. " " .. COPPER_AMOUNT_TEXTURE, iOro, 0, 0, iPlata, 0, 0, iOro, 0, 0)
	elseif iPlata > 0 then
		return format( SILVER_AMOUNT_TEXTURE .. " " .. COPPER_AMOUNT_TEXTURE, iPlata, 0, 0, iCobre, 0, 0)
	else
		return format( COPPER_AMOUNT_TEXTURE, iCobre, 0, 0)
	end

end


