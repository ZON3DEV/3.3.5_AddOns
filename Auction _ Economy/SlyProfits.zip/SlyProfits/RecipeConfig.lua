﻿-------------------------------------------------------------------------------
-- RecipeConfig.lua
--
-- Configuration Window to control recipes
-------------------------------------------------------------------------------

local AceGUI = LibStub("AceGUI-3.0");
local theFrame = nil;
local SelectedRecItems = {};
local SelectedRecItemsCount = 0;
local LastRecClick = nil;

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("SlyProfits")

function FlaskCalc:ConfigRecipes()
    self:CreateRecipeWindow();
    theFrame:Show();
    theFrame:SetFrameLevel(2000);
    self:ConfigRecipeFrame_Update();
    --frame:Show();
end

function FlaskCalc:CreateRecipeWindow()
    if theFrame == nil then
        theFrame=CreateFrame("Frame",nil,UIParent);

        theFrame:ClearAllPoints();
        theFrame:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT");
        theFrame:SetHeight(432);
        theFrame:SetWidth(384);

        theFrame.BookIcon=theFrame:CreateTexture(nil,"BACKGROUND",nil);
        theFrame.BookIcon:SetTexture("Interface\\QuestFrame\\UI-QuestLog-BookIcon");
        theFrame.BookIcon:SetHeight(64);
        theFrame.BookIcon:SetWidth(64);
        theFrame.BookIcon:SetPoint("TOPLEFT",theFrame,"TOPLEFT",12,-6);

        theFrame.TopLeftBorder=theFrame:CreateTexture(nil,"ARTWORK",nil);
        theFrame.TopLeftBorder:SetTexture("Interface\\LFGFrame\\LFMFrame");
        theFrame.TopLeftBorder:SetHeight(512);
        theFrame.TopLeftBorder:SetWidth(512);
        theFrame.TopLeftBorder:SetPoint("TOPLEFT",theFrame,"TOPLEFT");

        theFrame.Title=theFrame:CreateFontString(nil,"ARTWORK","GameFontHighlight");
        theFrame.Title:SetPoint("TOP",theFrame,"TOP",0,-15);
        theFrame.Title:SetHeight(14);
        theFrame.Title:SetWidth(300);
        --theFrame.Title:SetTextColor(1.0,1.0,1.0,1.0);
        theFrame.Title:SetText("SlyProfits");

        theFrame.ProfsFiltered=CreateFrame("CheckButton","RecipeProfsFiltered",theFrame,"OptionsSmallCheckButtonTemplate");
        theFrame.ProfsFiltered:SetPoint("TOPLEFT",theFrame,"TOPLEFT",85,-35);
        theFrame.ProfsFiltered:SetScript("OnClick",function() FlaskCalc:ProfsFilteredClicked() end);
        theFrame.ProfsFiltered:SetChecked(self.db.profile.filterProfs);
        local ProfsFilteredText = _G["RecipeProfsFilteredText"];
        ProfsFilteredText:SetText(L["Filter Recipes By Current Profession"]);

        theFrame.ProfsFrame=CreateFrame("Frame",nil,theFrame,"RecipesFilterCheckBackground");

        theFrame.Alchemy=CreateFrame("CheckButton","RecipeAlchemyFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Alchemy:SetPoint("TOPLEFT",theFrame,"TOPLEFT",25,-72);
        theFrame.Alchemy:SetChecked(self.db.profile.showAlchemy);
        theFrame.AlchemyText = _G["RecipeAlchemyFilteredText"];
        theFrame.AlchemyText:SetText(GetSpellInfo(2259));

        theFrame.Blacksmithing=CreateFrame("CheckButton","RecipeBlacksmithingFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Blacksmithing:SetPoint("LEFT",theFrame.Alchemy,"RIGHT",55,0);
        theFrame.Blacksmithing:SetChecked(self.db.profile.showBlacksmithing);
        theFrame.BlacksmithingText = _G["RecipeBlacksmithingFilteredText"];
        theFrame.BlacksmithingText:SetText(GetSpellInfo(3100));

        theFrame.Cooking=CreateFrame("CheckButton","RecipeCookingFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Cooking:SetPoint("LEFT",theFrame.Blacksmithing,"RIGHT",55,0);
        theFrame.Cooking:SetChecked(self.db.profile.showCooking);
        theFrame.CookingText = _G["RecipeCookingFilteredText"];
        theFrame.CookingText:SetText(GetSpellInfo(2550));

        theFrame.Enchanting=CreateFrame("CheckButton","RecipeEnchantingFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Enchanting:SetPoint("LEFT",theFrame.Cooking,"RIGHT",55,0);

        theFrame.Enchanting:SetChecked(self.db.profile.showEnchanting);
        theFrame.EnchantingText = _G["RecipeEnchantingFilteredText"];
        theFrame.EnchantingText:SetText(GetSpellInfo(7411));

        theFrame.Engineering=CreateFrame("CheckButton","RecipeEngineeringFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Engineering:SetPoint("TOPLEFT",theFrame.Alchemy,"BOTTOMLEFT",0,7);
        theFrame.Engineering:SetChecked(self.db.profile.showEngineering);
        theFrame.EngineeringText = _G["RecipeEngineeringFilteredText"];
        theFrame.EngineeringText:SetText(GetSpellInfo(4036));

        theFrame.Inscription=CreateFrame("CheckButton","RecipeInscriptionFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Inscription:SetPoint("LEFT",theFrame.Engineering,"RIGHT",55,0);
        theFrame.Inscription:SetChecked(self.db.profile.showInscription);
        theFrame.InscriptionText = _G["RecipeInscriptionFilteredText"];
        theFrame.InscriptionText:SetText(GetSpellInfo(45357));

        theFrame.Jewelcrafting=CreateFrame("CheckButton","RecipeJewelcraftingFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Jewelcrafting:SetPoint("LEFT",theFrame.Inscription,"RIGHT",55,0);
        theFrame.Jewelcrafting:SetChecked(self.db.profile.showJewelcrafting);
        theFrame.JewelcraftingText = _G["RecipeJewelcraftingFilteredText"];
        theFrame.JewelcraftingText:SetText(GetSpellInfo(25229));

        theFrame.Leatherworking=CreateFrame("CheckButton","RecipeLeatherworkingFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Leatherworking:SetPoint("LEFT",theFrame.Jewelcrafting,"RIGHT",55,0);
        theFrame.Leatherworking:SetChecked(self.db.profile.showLeatherworking);
        theFrame.LeatherworkingText = _G["RecipeLeatherworkingFilteredText"];
        theFrame.LeatherworkingText:SetText(GetSpellInfo(2108));

        theFrame.Tailoring=CreateFrame("CheckButton","RecipeTailoringFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Tailoring:SetPoint("TOPLEFT",theFrame.Engineering,"BOTTOMLEFT",0,7);
        theFrame.Tailoring:SetChecked(self.db.profile.showTailoring);
        theFrame.TailoringText = _G["RecipeTailoringFilteredText"];
        theFrame.TailoringText:SetText(GetSpellInfo(3908));

        theFrame.Mining=CreateFrame("CheckButton","RecipeMiningFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Mining:SetPoint("LEFT",theFrame.Tailoring,"RIGHT",55,0);
        theFrame.Mining:SetChecked(self.db.profile.showMining);
        theFrame.MiningText = _G["RecipeMiningFilteredText"];
        theFrame.MiningText:SetText(GetSpellInfo(3564));

        theFrame.FirstAid=CreateFrame("CheckButton","RecipeFirstAidFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.FirstAid:SetPoint("LEFT",theFrame.Mining,"RIGHT",55,0);
        theFrame.FirstAid:SetChecked(self.db.profile.showFirstAid);
        theFrame.FirstAidText = _G["RecipeFirstAidFilteredText"];
        theFrame.FirstAidText:SetText(GetSpellInfo(45542));

        theFrame.Misc=CreateFrame("CheckButton","RecipeMiscFiltered",theFrame,"ProfessionCheckButtonTemplate");
        theFrame.Misc:SetPoint("LEFT",theFrame.FirstAid,"RIGHT",55,0);
        theFrame.Misc:SetScript("OnClick",function() FlaskCalc:CheckboxMiscClicked() end);
        theFrame.Misc:SetChecked(self.db.profile.showMisc);
        theFrame.MiscText = _G["RecipeMiscFilteredText"];
        theFrame.MiscText:SetText("Misc");



        theFrame.MatsBox=theFrame:CreateFontString(nil,"ARTWORK","GameFontHighlightSmall");
        theFrame.MatsBox:SetPoint("BOTTOMLEFT",theFrame,"BOTTOMLEFT",27,33);
        theFrame.MatsBox:SetHeight(14);
        theFrame.MatsBox:SetWidth(320);
        --theFrame.Title:SetTextColor(1.0,1.0,1.0,1.0);
        theFrame.MatsBox:SetText("");

        theFrame:EnableMouse(true);
        theFrame:SetMovable(true);

        theFrame.ScrollFrame=CreateFrame("ScrollFrame","RecipeScroller",theFrame,"RecipeScrollFrame");

        theFrame.RecipeHeaders=CreateFrame("Frame",nil,theFrame);
        theFrame.RecipeHeaders:SetWidth(300);
        theFrame.RecipeHeaders:SetHeight(21);
        theFrame.RecipeHeaders:SetPoint("TOPLEFT",theFrame,"TOPLEFT",25,-135);

        theFrame.Recipes = {};
        local previous = theFrame.RecipeHeaders;
        for i = 1,10 do
            local RecipeEntry = CreateFrame("Button","RecipeButton"..i,theFrame,"RecipeItemTemplate");

            table.insert(theFrame.Recipes,RecipeEntry);
            RecipeEntry:SetPoint("TOPLEFT",previous,"BOTTOMLEFT",0,0);
            RecipeEntry:SetID(i);
            previous = RecipeEntry;
        end

        theFrame.CloseCross=CreateFrame("Button",nil,theFrame,"UIPanelCloseButton");
        theFrame.CloseCross:SetPoint("TOPRIGHT",theFrame,"TOPRIGHT",-26,-8);
        theFrame.CloseCross:SetScript("OnClick",function() FlaskCalc:HideRecipeConfig() end);

        theFrame.EnableButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.EnableButton:SetWidth(60)
        theFrame.EnableButton:SetHeight(25)
        theFrame.EnableButton:SetPoint("BOTTOMLEFT",theFrame,"BOTTOMLEFT",25,4);
        theFrame.EnableButton:SetScript("OnClick",function() FlaskCalc:EnableButton_OnClick(); end);
        theFrame.EnableButton:SetText("Enable")

        theFrame.DisableButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.DisableButton:SetWidth(60)
        theFrame.DisableButton:SetHeight(25)
        theFrame.DisableButton:SetPoint("LEFT",theFrame.EnableButton,"RIGHT",-1,0);
        theFrame.DisableButton:SetScript("OnClick",function() FlaskCalc:DisableButton_OnClick(); end);
        theFrame.DisableButton:SetText("Disable")

        theFrame.DeleteButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.DeleteButton:SetWidth(60)
        theFrame.DeleteButton:SetHeight(25)
        theFrame.DeleteButton:SetPoint("LEFT",theFrame.DisableButton,"RIGHT",-1,0);
        theFrame.DeleteButton:SetScript("OnClick",function() FlaskCalc:DeleteButton_OnClick(); end);
        theFrame.DeleteButton:SetText("Delete")

        theFrame.EditButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.EditButton:SetWidth(45)
        theFrame.EditButton:SetHeight(25)
        theFrame.EditButton:SetPoint("LEFT",theFrame.DeleteButton,"RIGHT",-1,0);
        theFrame.EditButton:SetScript("OnClick",function() FlaskCalc:EditButton_OnClick(); end);
        theFrame.EditButton:SetText("Edit")

        theFrame.NewButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.NewButton:SetWidth(45)
        theFrame.NewButton:SetHeight(25)
        theFrame.NewButton:SetPoint("LEFT",theFrame.EditButton,"RIGHT",-1,0);
        --theFrame.NewButton:SetPoint("RIGHT",theFrame.ImportButton,"LEFT",0,0);
        theFrame.NewButton:SetScript("OnClick",function() FlaskCalc:NewButton_OnClick(); end);
        theFrame.NewButton:SetText("New")

        theFrame.ImportButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.ImportButton:SetWidth(60)
        theFrame.ImportButton:SetHeight(25)
        theFrame.ImportButton:SetPoint("BOTTOMRIGHT",theFrame,"BOTTOMRIGHT",-35,4);
        theFrame.ImportButton:SetScript("OnClick",function() FlaskCalc:ImportButton_OnClick(); end);
        theFrame.ImportButton:SetText("Import")



        --[[
        theFrame.CloseButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.CloseButton:SetWidth(115)
        theFrame.CloseButton:SetHeight(25)
        theFrame.CloseButton:SetPoint("BOTTOMRIGHT",theFrame,"BOTTOMRIGHT",-35,4);
        theFrame.CloseButton:SetScript("OnClick",function() theFrame:Hide() end);
        theFrame.CloseButton:SetText("Close")
        --]]
        theFrame:SetScript("OnMouseDown", function(this)
                        if ( ( ( not this.isLocked ) or ( this.isLocked == 0 ) ) and ( arg1 == "LeftButton" ) ) then
                        theFrame:SetFrameLevel(2000);
                        this:StartMoving();
                        this.isMoving = true;
                        end
                        end);
        theFrame:SetScript("OnMouseUp", function(this)
                        if ( this.isMoving ) then
                        this:StopMovingOrSizing();
                        this.isMoving = false;
                        end
                        end);
        theFrame:SetScript("OnShow", function(this)
                        theFrame:SetFrameLevel(2000);
                        end);

        theFrame:SetScript("OnHide", function(this)
                        if ( this.isMoving ) then
                        this:StopMovingOrSizing();
                        this.isMoving = false;
                        end
                        end);
    else
        SelectedRecItems = {};
        SelectedRecItemsCount = 0;
    end
    theFrame:Hide()
end

function FlaskCalc:DeleteButton_OnClick()
    if SelectedRecItemsCount ~= 0 then
        local AllRecipes = FlaskCalc:GetFilteredList();
        for i = 1,getn(AllRecipes) do
            if SelectedRecItems[AllRecipes[i]] == true then
                FlaskCalc:DeleteRecipe(AllRecipes[i]);
                if FlaskCalc:IsEditOpen() then
                    FlaskCalc:HideViewRecipes();
                end
            end
        end
        FlaskCalc:ConfigRecipeFrame_Update();

        if FlaskCalc:IsImportOpen() then
            FlaskCalc:ImportRecipeFrame_Update();
        end

        SelectedRecItems = {};
        SelectedRecItemsCount = 0;
    end
end

function FlaskCalc:ProfsFilteredClicked()
    self.db.profile.filterProfs = (theFrame.ProfsFiltered:GetChecked() ~= nil);
    FlaskCalc:ConfigRecipeFrame_Update();
end

function FlaskCalc:CheckboxClicked()
    self.db.profile.showAlchemy = (theFrame.Alchemy:GetChecked() ~= nil);
    self.db.profile.showBlacksmithing = (theFrame.Blacksmithing:GetChecked() ~= nil);
    self.db.profile.showCooking = (theFrame.Cooking:GetChecked() ~= nil);
    self.db.profile.showEnchanting = (theFrame.Enchanting:GetChecked() ~= nil);
    self.db.profile.showEngineering = (theFrame.Engineering:GetChecked() ~= nil);
    self.db.profile.showInscription = (theFrame.Inscription:GetChecked() ~= nil);
    self.db.profile.showJewelcrafting = (theFrame.Jewelcrafting:GetChecked() ~= nil);
    self.db.profile.showLeatherworking = (theFrame.Leatherworking:GetChecked() ~= nil);
    self.db.profile.showTailoring = (theFrame.Tailoring:GetChecked() ~= nil);
    self.db.profile.showMining = (theFrame.Mining:GetChecked() ~= nil);
    self.db.profile.showFirstAid = (theFrame.FirstAid:GetChecked() ~= nil);
    FlaskCalc:ConfigRecipeFrame_Update();
end

function FlaskCalc:CheckboxMiscClicked()
    self.db.profile.showMisc = (theFrame.Misc:GetChecked() ~= nil);
    FlaskCalc:ConfigRecipeFrame_Update();
end

function FlaskCalc:EnableButton_OnClick()
    if SelectedRecItemsCount ~= 0 then
        local AllRecipes = FlaskCalc:GetFilteredList();
        for i = 1,getn(AllRecipes) do
            if SelectedRecItems[AllRecipes[i]] == true then
                self.db.profile.disabledIDs[AllRecipes[i].ID] = false;
            end
        end
    end
    FlaskCalc:ConfigRecipeFrame_Update();
end

function FlaskCalc:DisableButton_OnClick()
    if SelectedRecItemsCount ~= 0 then
        local AllRecipes = FlaskCalc:GetFilteredList();
        for i = 1,getn(AllRecipes) do
            if SelectedRecItems[AllRecipes[i]] == true then
                self.db.profile.disabledIDs[AllRecipes[i].ID] = true;
            end
        end
    end
    FlaskCalc:ConfigRecipeFrame_Update();
end

function FlaskCalc:EditButton_OnClick()
    if SelectedRecItemsCount == 1 then
        FlaskCalc:HideImportRecipes();
        FlaskCalc:ViewRecipes(theFrame);

        local selectedRec = nil;
        -- get first and only item
        for i,v in pairs(SelectedRecItems) do
            selectedRec = i;
        end
        FlaskCalc:EditMode(selectedRec);
        self:ConfigRecipeFrame_Update();
    end
end

function FlaskCalc:NewButton_OnClick()
    FlaskCalc:HideImportRecipes();
    FlaskCalc:ViewRecipes(theFrame);
    FlaskCalc:NewMode();
    self:ConfigRecipeFrame_Update();
end

function FlaskCalc:ImportButton_OnClick()
    FlaskCalc:HideViewRecipes();
    FlaskCalc:ImportRecipes(theFrame);
    self:ConfigRecipeFrame_Update();
end

function FlaskCalc:RecipeButton_OnClick(id)
    if FlaskCalc:IsEditOpen() == true then
        FlaskCalc:HideViewRecipes();
    end
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    local AllRecipes = FlaskCalc:GetFilteredList();

    if LastRecClick ~= nil and IsShiftKeyDown() then
      -- Shift is down and we have a previous click.
      -- Add all items in this range to the selection.
        local lower = offset + id;
        local upper = offset + id;
        if not IsControlKeyDown() then
            SelectedRecItems = {};
            SelectedRecItemsCount = 0;
        end
        if LastRecClick < offset + id then
            lower = LastRecClick;
        else
            upper = LastRecClick;
        end

        local i;
        for i = lower, upper do
            SelectedRecItems[AllRecipes[i]] = true;
            SelectedRecItemsCount = SelectedRecItemsCount + 1;
        end
    else
        -- No shift, or first click; add only the current item to the selection.
        -- If control is down, toggle the item.
        LastRecClick = offset + id;
        if not IsControlKeyDown() then
            SelectedRecItems = {};
            SelectedRecItemsCount = 0;
        end
        local listing = AllRecipes[offset + id];
        if IsControlKeyDown() and SelectedRecItems[listing] then
            SelectedRecItems[listing] = nil;
            SelectedRecItemsCount = SelectedRecItemsCount - 1;
        else
            SelectedRecItems[listing] = true;
            SelectedRecItemsCount = SelectedRecItemsCount + 1;
        end
    end

    self:ConfigRecipeFrame_Update();
end

-- Show tooltip
function FlaskCalc:RecipeButton_OnEnter(Button)
    local ButtonId = Button:GetID();
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    local AllRecipes = FlaskCalc:GetFilteredList();
    local hover = AllRecipes[offset+ButtonId];
    GameTooltip:SetOwner(Button, "ANCHOR_RIGHT")
    if IsModifierKeyDown() then
        -- show original Blizzard item tooltip
        if hover.ItemLink ~= nil then
        GameTooltip:SetHyperlink(hover.ItemLink)
        end
    else
        -- show own tooltip (with crafting info)
        GameTooltip:SetText(hover.Profession..": "..hover.Name, 1, 1, 1);
        GameTooltip:AddLine(L["Makes"]..": "..hover.Quantity, nil, nil, nil, 1);
        GameTooltip:AddLine(L["Desired Stack Size"]..": "..hover.DesiredAmount, nil, nil, nil, 1);
        GameTooltip:AddLine(L["Mats"]..": ", nil, nil, nil, 1);
        for i = 1,getn(hover.Mats) do
            GameTooltip:AddLine("     "..hover.Mats[i][2].."x "..hover.Mats[i][1], nil, nil, nil, 1);
        end
    end
    GameTooltip:Show();
end

function FlaskCalc:ConfigRecipeFrame_Update()
    local AllRecipes = FlaskCalc:GetFilteredList();
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    theFrame.EnableButton:Disable();
    theFrame.DisableButton:Disable();
    theFrame.EditButton:Disable();
    theFrame.DeleteButton:Disable();
    if FlaskCalc:IsImportOpen() == true then
        theFrame.ImportButton:Disable();
    else
        theFrame.ImportButton:Enable();
    end

    if FlaskCalc:IsNewOpen() == true then
        theFrame.NewButton:Disable();
    else
        theFrame.NewButton:Enable();
    end
    if theFrame.ProfsFiltered:GetChecked() then
        local prof = GetSpellInfo(2259);
        if prof ~= nil then
            theFrame.Alchemy:SetChecked(true);
        else
            theFrame.Alchemy:SetChecked(false);
        end
        theFrame.Alchemy:Disable();
        theFrame.AlchemyText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(3100);
        if prof ~= nil then
            theFrame.Blacksmithing:SetChecked(true);
        else
            theFrame.Blacksmithing:SetChecked(false);
        end
        theFrame.Blacksmithing:Disable();
        theFrame.BlacksmithingText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(2550);
        if prof ~= nil then
            theFrame.Cooking:SetChecked(true);
        else
            theFrame.Cooking:SetChecked(false);
        end
        theFrame.Cooking:Disable();
        theFrame.CookingText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(7411);
        if prof ~= nil then
            theFrame.Enchanting:SetChecked(true);
        else
            theFrame.Enchanting:SetChecked(false);
        end
        theFrame.Enchanting:Disable();
        theFrame.EnchantingText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(4036);
        if prof ~= nil then
            theFrame.Engineering:SetChecked(true);
        else
            theFrame.Engineering:SetChecked(false);
        end
        theFrame.Engineering:Disable();
        theFrame.EngineeringText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(45357);
        if prof ~= nil then
            theFrame.Inscription:SetChecked(true);
        else
            theFrame.Inscription:SetChecked(false);
        end
        theFrame.Inscription:Disable();
        theFrame.InscriptionText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(25229);
        if prof ~= nil then
            theFrame.Jewelcrafting:SetChecked(true);
        else
            theFrame.Jewelcrafting:SetChecked(false);
        end
        theFrame.Jewelcrafting:Disable();
        theFrame.JewelcraftingText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(2108);
        if prof ~= nil then
            theFrame.Leatherworking:SetChecked(true);
        else
            theFrame.Leatherworking:SetChecked(false);
        end
        theFrame.Leatherworking:Disable();
        theFrame.LeatherworkingText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(3908);
        if prof ~= nil then
            theFrame.Tailoring:SetChecked(true);
        else
            theFrame.Tailoring:SetChecked(false);
        end
        theFrame.Tailoring:Disable();
        theFrame.TailoringText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(3564);
        if prof ~= nil then
            theFrame.Mining:SetChecked(true);
        else
            theFrame.Mining:SetChecked(false);
        end
        theFrame.Mining:Disable();
        theFrame.MiningText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);

        prof = GetSpellInfo(45542);
        if prof ~= nil then
            theFrame.FirstAid:SetChecked(true);
        else
            theFrame.FirstAid:SetChecked(false);
        end
        theFrame.FirstAid:Disable();
        theFrame.FirstAidText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);
    else
        theFrame.Alchemy:SetChecked(self.db.profile.showAlchemy);
        theFrame.Alchemy:Enable();
        theFrame.AlchemyText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Blacksmithing:SetChecked(self.db.profile.showBlacksmithing);
        theFrame.Blacksmithing:Enable();
        theFrame.BlacksmithingText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Cooking:SetChecked(self.db.profile.showCooking);
        theFrame.Cooking:Enable();
        theFrame.CookingText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Enchanting:SetChecked(self.db.profile.showEnchanting);
        theFrame.Enchanting:Enable();
        theFrame.EnchantingText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Engineering:SetChecked(self.db.profile.showEngineering);
        theFrame.Engineering:Enable();
        theFrame.EngineeringText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Inscription:SetChecked(self.db.profile.showInscription);
        theFrame.Inscription:Enable();
        theFrame.InscriptionText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Jewelcrafting:SetChecked(self.db.profile.showJewelcrafting);
        theFrame.Jewelcrafting:Enable();
        theFrame.JewelcraftingText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Leatherworking:SetChecked(self.db.profile.showLeatherworking);
        theFrame.Leatherworking:Enable();
        theFrame.LeatherworkingText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Tailoring:SetChecked(self.db.profile.showTailoring);
        theFrame.Tailoring:Enable();
        theFrame.TailoringText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Mining:SetChecked(self.db.profile.showMining);
        theFrame.Mining:Enable();
        theFrame.MiningText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.FirstAid:SetChecked(self.db.profile.showFirstAid);
        theFrame.FirstAid:Enable();
        theFrame.FirstAidText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
    end

    theFrame.Misc:SetChecked(self.db.profile.showMisc);
    theFrame.Misc:Enable();
    theFrame.MiscText:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);


    theFrame.MatsBox:SetText("");
    local missing = 0;
    for i = 1,10 do
        local RecipeEntry = theFrame.Recipes[i];
        local index = offset + i + missing;
        if index <= getn(AllRecipes) then
            local tradeskill = AllRecipes[index];

            local RecipeButtonDetail = _G["RecipeButton".. i .. "Detail"];
            local RecipeButtonDetailName = _G["RecipeButton".. i .. "DetailName"];
            RecipeButtonDetail:Show();
            RecipeEntry:Show();

            --IsTradeSkillLinked()
            if FlaskCalc:IsDisabled(tradeskill) == true then
                RecipeButtonDetailName:SetText("|c88888888" .. tradeskill.Profession..": "..tradeskill.Name .. "|r");
            else
                RecipeButtonDetailName:SetText("|cffffffff" .. tradeskill.Profession..": "..tradeskill.Name .. "|r");
            end

            if SelectedRecItems[tradeskill] == true then
                RecipeEntry:LockHighlight();
            else
                RecipeEntry:UnlockHighlight();
            end
        else
            RecipeEntry:Hide();
        end
    end

    if SelectedRecItemsCount ~= 0 then
        theFrame.EnableButton:Enable();
        theFrame.DisableButton:Enable();
        theFrame.DeleteButton:Enable();
    end

    if SelectedRecItemsCount == 1 then
        local selectedRec = nil;
        -- get first and only item
        for i,v in pairs(SelectedRecItems) do
            selectedRec = i;
        end

        if FlaskCalc:IsFilteredOut(selectedRec) == false then
            if FlaskCalc:IsEditOpen(selectedRec) == true then
                theFrame.EditButton:Disable();
            else
                theFrame.EditButton:Enable();
            end

            local MatString = "";
            local MatVendorString = "";
            local first = true;
            for matId = 1, getn(selectedRec.Mats) do
                local matName = selectedRec.Mats[matId][1];
                local matNumber = selectedRec.Mats[matId][2];

                if FlaskCalc:GetVendorPrice(matName) == 0 then
                    if first ~= true then
                        MatString = MatString .. ", ";
                    end
                    first = false;
                    MatString = MatString .. matNumber .. "x ".. matName;
                else
                    if getn(selectedRec.Mats) > 1 then
                        MatVendorString = MatVendorString .. ", ";
                    end
                    MatVendorString = MatVendorString .. "("..matNumber .. "x ".. matName .. ")";
                end
            end
            theFrame.MatsBox:SetText(MatString..MatVendorString);
        end
    end
    FauxScrollFrame_Update(theFrame.ScrollFrame, table.getn(AllRecipes),10, 21);
end

function FlaskCalc:HideRecipeConfig()
    theFrame:Hide();
    FlaskCalc:HideImportRecipes();
    FlaskCalc:HideViewRecipes();
end
