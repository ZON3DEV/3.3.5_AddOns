-- Please note the Code contained in this file has been modified and adapted as needed - May 2009.
-- The original credit for the unmodified addon belongs to the auctionlite addon author MerialKilrogg
-- The auctionlite code was available under GPLv2 license and as such this code is available under GPLv2
-------------------------------------------------------------------------------
-- FlaskFrame.lua
--
-- Implements the "Flask" tab.
-------------------------------------------------------------------------------

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("SlyProfits")

-- Constants for display elements.
local DISPLAY_SIZE = 15;
local ROW_HEIGHT = 21;

-- Various states for the flask frame.
-- inital state, never shown to users
local FLASK_MODE_NONE        = 1;
-- first state the user sees upon entering the tab, tell them to click the button
local FLASK_MODE_INTRO       = 2;
-- The loading/results state
local FLASK_MODE_SCAN       = 3;

-- Current state of the flask frame.
local FlaskMode = FLASK_MODE_NONE;

-- Information about current scan progress.
local StartTime = nil;
local LastTime = nil;
local LastRemaining = nil;
local currentSearch = 0;
local searchNum = 0;
local previous = 0;

local DETAIL_MODE = 1;
local MATS_MODE = 2;

local VIEW_MODE = DETAIL_MODE;
local scanNeeded = name;

-- Data to be shown in detail view.
local DetailData = {};

-- Data to be shown in mat view.
local MatsData = {};

-- Search data for the various item types
local SearchData = {};
local Queries = {};
local PurchaseQueries = {};
local purchaseNum = 0;
local purchase_delay = 2;
local currentPurchase = 1;
local CurrentPurchaseOrder ={};

-- Selected item in detail view and index of last item clicked.
local SelectedDetail = nil;
local SelectedMat = nil;
local currentmats = nil;
local currentrecipes = nil;
local initSlider = nil
local initSliderStep = nil;
local initSliderMin  = nil;
local initSliderMax  = nil;
local initSliderCurrent = nil;

-- Sorting order
local sortAsc = true;


-- Data for the calculation thread / coroutine
-- This performs the calculation for the data just scanned from the AH
local counter = 0
local throttle = 0.1
local doCalculation = false
local thread = nil


function FlaskCalc:CreateFlaskFrame()
  -- Create our tab.
  local index = self:CreateTab("SlyProfits", AuctionFrameFlask);

  -- Set all strings in the UI.
  FlaskTitle:SetText("SlyProfits");
  FlaskScanButton:SetText("Scan");
  AdvancedModeCheckButtonText:SetText(L["Advanced Mode"]);
  OnlyNeededCheckButtonText:SetText(L["Use Inventory"]);

  -- Loading Page
  FlaskStatusText:SetText(L["Searching"]..":");
  FlaskElapsedText:SetText(L["Time Elapsed"]..":");
  FlaskRemainingText:SetText(L["Time Remaining"]..":");
  FlaskCancelSearchButton:SetText("Cancel");

  -- Results page
  FlaskItemButton:SetText(L["Item"]);
  ProfitAllButton:SetText(L["Profit Total"]);
  CostAllButton:SetText(L["Cost Total"]);
  FlaskAllButton:SetText(L["Buyout Total"]);
  FlaskEachButton:SetText(L["Buyout Per Item"]);

  MatFlaskItemButton:SetText(L["Item"]);
  MatProfitAllButton:SetText(L["Profit Total"]);
  MatCostAllButton:SetText(L["Cost Total"]);
  MatFlaskAllButton:SetText(L["Buyout Total"]);
  MatFlaskEachButton:SetText(L["Buyout Per Item"]);
  -- Make sure it's pristine.
  self:ClearFlaskFrame();
  return index;
end


function FlaskCalc:ClearFlaskFrame(partial)

  if not partial then
    FlaskMode = FLASK_MODE_INTRO;
    SelectedItems = {};
    LastClick = nil;
    FlaskScanButton:Enable();
  end
  self:ResetSearch();

  FlaskMessageText:Hide();
  FlaskStatus:Hide();
  FauxScrollFrame_SetOffset(FlaskScrollFrame, 0);
  FlaskScrollFrameScrollBar:SetValue(0);

  -- First clear everything.
  local i;
  for i = 1, DISPLAY_SIZE do
    local buttonName = "FlaskItem" .. i;

    local button = _G[buttonName];
    local buttonDetail = _G[buttonName .. "Detail"];

    button:Hide();
    buttonDetail:Hide();
  end

  self:AuctionFrameFlask_Update();
end
function FlaskCalc:ResetSearch()
  StartTime = nil;
  LastTime = nil;
  LastRemaining = nil;
end
function FlaskCalc:FlaskCancelSearchButton_OnClick()
  self:CancelQuery();
  self:ResetSearch();
  FlaskScanButton:Enable();
  self:AuctionFrameFlask_Update();
end

function FlaskCalc:FlaskCountSlider_OnValueChanged()
    local value = FlaskCountSlider:GetValue();

    if SelectedDetail ~= nil then
        FlaskCalc:UpdateEntry(SelectedDetail,value);
        local item = SelectedDetail;
        if item.alternatives ~= nil and getn(item.alternatives) ~= 0 then
            for i=1,getn(item.alternatives) do
                FlaskCalc:UpdateEntry(item.alternatives[i],value);
            end
            if self.db.profile.advanced then
                local initItem = item;
                for altId = 1,getn(item.alternatives) do
                    if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                        item = initItem.alternatives[altId];
                    elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                        item = initItem.alternatives[altId];
                    end
                end
            end
        end
        FlaskCalc:GenerateMatsDisplay(item.Recipe,false);
    else
        self:Print("Selected Detail is nil");
    end

end

function FlaskCalc:GetNearestStep(value,step)
    local remaining = mod(value,step);
    if remaining < step/2 then
        value = value - remaining;
    else
        value = value +step - remaining;
    end
    return value;
end

function FlaskCalc:AuctionFrameFlask_Update()

  -- First clear everything.
  local i;
  for i = 1, DISPLAY_SIZE do
    local buttonName = "FlaskItem" .. i;

    local button = _G[buttonName];
    local buttonDetail = _G[buttonName .. "Detail"];

    button:Hide();
    buttonDetail:Hide();
  end

  FlaskHeader:Hide();
  MatFlaskHeader:Hide();
  FlaskStatus:Hide();
  OnlyNeededCheckButton:Disable();
  OnlyNeededCheckButtonText:SetTextColor(GRAY_FONT_COLOR.r,GRAY_FONT_COLOR.g,GRAY_FONT_COLOR.b);
  FlaskMatsLabel:Hide();
  FlaskBuyMatsButton:Disable();
  FlaskViewMatsButton:Disable();
  FlaskViewRecipesButton:Disable();
  AdvancedModeCheckButton:SetChecked(self.db.profile.advanced);
  OnlyNeededCheckButton:SetChecked(self.db.profile.inventory);

  -- If we have no items, say so.
  FlaskMessageText:Show();
  if FlaskMode == FLASK_MODE_INTRO then
    FlaskMessageText:SetText("click \"Scan\"");
    FlaskCountSlider:Hide();
    VIEW_MODE = DETAIL_MODE;
  else
    if currentSearch > searchNum then
        if VIEW_MODE == MATS_MODE then
            OnlyNeededCheckButton:Enable();
            OnlyNeededCheckButtonText:SetTextColor(NORMAL_FONT_COLOR.r,NORMAL_FONT_COLOR.g,NORMAL_FONT_COLOR.b);
            FlaskViewRecipesButton:Enable();
            self:AuctionFrameFlask_UpdateMats();
        else
            FlaskCountSlider:Hide();
            self:AuctionFrameFlask_UpdateDetail();
        end

    else
        FlaskCountSlider:Hide();
    end
    FlaskMessageText:Hide();
  end

end


function FlaskCalc:GetProfitAll(item)
    if self.db.profile.advanced and item.alternatives and getn(item.alternatives) ~= 0 then
        local initItem = item;
        for altId = 1,getn(item.alternatives) do
            if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                item = initItem.alternatives[altId];
            elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                item = initItem.alternatives[altId];
            end
        end
    end

   local itemBuyout = item.buyout;
   if FlaskCalc:ProcModelled(item.name) then
       if self.db.profile.advanced then
           local procArray = FlaskCalc:AdjustForProcs(item.name,item.buyout,item.count,item.quantity);
           itemBuyout = procArray[1];
       end
   end

   local itemCost = item.cost;
   if self.db.profile.advanced and item.resale ~= nil then
       itemCost = itemCost - item.resale;
   end
   if itemCost > 0 then
       if (0.95*itemBuyout) - itemCost > 0 then
           return math.floor((0.95*itemBuyout) - itemCost);
       else
           return 0;
       end
   else
       return 0;
   end
end

-- Profit Total sorting
function FlaskCalc:ProfitAllButton_OnClick()
    sortAsc = not sortAsc;

    local function sort_func(a, b)
        if sortAsc then
            return FlaskCalc:GetProfitAll(a) < FlaskCalc:GetProfitAll(b);
        else
            return FlaskCalc:GetProfitAll(a) > FlaskCalc:GetProfitAll(b);
        end
    end
   table.sort(DetailData, sort_func);

   FlaskCalc:AuctionFrameFlask_UpdateDetail();
end


function FlaskCalc:FlaskItemButton_OnClick()
    sortAsc = not sortAsc;

    local function sort_func(a, b)
       if sortAsc then
            return a.name > b.name;
        else
            return a.name < b.name;
        end
   end

   table.sort(DetailData, sort_func);

   FlaskCalc:AuctionFrameFlask_UpdateDetail();
end


function FlaskCalc:CostAllButton_OnClick()
    sortAsc = not sortAsc;

   local function sort_func(a, b)
      local itemCost_a = a.cost;
      local itemCost_b = b.cost;

      if self.db.profile.advanced and a.resale ~= nil then
          itemCost_a = itemCost_a - a.resale;
      end
       if self.db.profile.advanced and b.resale ~= nil then
          itemCost_b = itemCost_b - b.resale;
      end

        if sortAsc then
            return itemCost_a > itemCost_b;
        else
            return itemCost_a < itemCost_b;
        end
   end
   table.sort(DetailData, sort_func);

   FlaskCalc:AuctionFrameFlask_UpdateDetail();
end


function FlaskCalc:FlaskAllButton_OnClick()
    sortAsc = not sortAsc;

   local function sort_func(a, b)
        if sortAsc then
            return a.buyout > b.buyout;
        else
            return a.buyout < b.buyout;
        end
    end
    table.sort(DetailData, sort_func);

   FlaskCalc:AuctionFrameFlask_UpdateDetail();
end


function FlaskCalc:FlaskEachButton_OnClick()
    sortAsc = not sortAsc;

   local function sort_func(a, b)
      if sortAsc then
           return a.buyout/a.count > b.buyout/b.count
       else
           return a.buyout/a.count < b.buyout/b.count
       end
    end
    table.sort(DetailData, sort_func);

   FlaskCalc:AuctionFrameFlask_UpdateDetail();
end

-- Update frame with the results (overview, recipe level)
function FlaskCalc:AuctionFrameFlask_UpdateDetail()
    local offset = FauxScrollFrame_GetOffset(FlaskScrollFrame);

    local i;
    for i = 1, DISPLAY_SIZE do
        local item = DetailData[offset + i];

        if item ~= nil then

            -- use the alternative with the lowest price instead of the original recipe
            if self.db.profile.advanced and item.alternatives and getn(item.alternatives) ~= 0 then
                local initItem = item;
                for altId = 1,getn(item.alternatives) do
                    if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                        item = initItem.alternatives[altId];
                    elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                        item = initItem.alternatives[altId];
                    end
                end
            end
            local buttonName = "FlaskItem" .. i;
            local button = _G[buttonName];

            local warning = _G[buttonName .. "Warning"];

            local buttonDetailName = buttonName .. "Detail";
            local buttonDetail     = _G[buttonDetailName];

            local countText        = _G[buttonDetailName .. "Count"];
            local nameText         = _G[buttonDetailName .. "Name"];
            local buyoutEachFrame  = _G[buttonDetailName .. "BuyoutEachFrame"];
            local buyoutFrame      = _G[buttonDetailName .. "BuyoutFrame"];
            local costFrame        = _G[buttonDetailName .. "CostFrame"];
            local profitFrame      = _G[buttonDetailName .. "ProfitFrame"];
            local noBuyout         = _G[buttonDetailName .. "NoBuyout"];
            local historyBuyout    = _G[buttonDetailName .. "HistoryBuyout"];
            local noBuyoutEach     = _G[buttonDetailName .. "NoBuyoutEach"];
            local noCost           = _G[buttonDetailName .. "NoCost"];
            local noProfit         = _G[buttonDetailName .. "NoProfit"];


            local itemBuyout = item.buyout;
            local itemCount = item.count;
            if FlaskCalc:ProcModelled(item.name) then
                if self.db.profile.advanced then
                    local procArray = FlaskCalc:AdjustForProcs(item.name,item.buyout,item.count,item.quantity);
                    itemBuyout = procArray[1];
                    itemCount =  procArray[2];
                end
            end


            countText:SetText("|cffffffff".. itemCount .."x|r");
            nameText:SetText("|cffffffff" .. item.name .. "|r");
            historyBuyout:Hide();
            button:Enable();
            button:UnlockHighlight();
            if item.buyout > 0 then
                if item.history == true then
                    historyBuyout:Show();
                end

                MoneyFrame_Update(buyoutEachFrame, math.floor(itemBuyout / itemCount));
                buyoutEachFrame:Show();
                noBuyout:Hide();
                noBuyoutEach:Hide();
                MoneyFrame_Update(buyoutFrame, math.floor(itemBuyout));
                buyoutFrame:Show();
            else
                noBuyout:SetText("[No Auctions Found]");
                noBuyout:Show();
                noBuyoutEach:SetText("[No Auctions Found]");
                noBuyoutEach:Show();
                MoneyFrame_Update(buyoutEachFrame, 0);
                buyoutEachFrame:Hide();
                MoneyFrame_Update(buyoutFrame, 0);
                buyoutFrame:Hide();
            end
            local itemCost = item.cost;
            if self.db.profile.advanced and item.resale ~= nil then
                itemCost = itemCost - item.resale;
            end
            if itemCost > 0 then
                if (0.95*itemBuyout) - itemCost > 0 then
                    noProfit:Hide();
                    MoneyFrame_Update(profitFrame, math.floor((0.95*itemBuyout) - itemCost));
                    profitFrame:Show();
                else
                    noProfit:SetText("[No Profit Calculated]");
                    noProfit:Show();
                    MoneyFrame_Update(profitFrame,0);
                    profitFrame:Hide();
                end
                if SelectedDetail ~= nil and SelectedDetail.ID == item.ID then
                    button:LockHighlight();
                    FlaskViewMatsButton:Enable();
                else
                    button:UnlockHighlight();
                end
                costFrame:Show();
                MoneyFrame_Update(costFrame, math.floor(itemCost));
                noCost:Hide();
            else
                noProfit:SetText("[No Profit Calculated]");
                noProfit:Show();
                profitFrame:Hide();
                noCost:SetText("[No Cost Calculated]");
                noCost:Show();
                MoneyFrame_Update(costFrame,0);
                costFrame:Hide();
            end

            warning:SetAlpha(0);

            buttonDetail:Show();
            button:Show();
        end
    end

    FauxScrollFrame_Update(FlaskScrollFrame, table.getn(DetailData),DISPLAY_SIZE, ROW_HEIGHT);

    if table.getn(DetailData) > 0 then
        FlaskHeader:Show();
        ProfitAllButton:Show();
        CostAllButton:Show();
    end
end

function FlaskCalc:AdjustForProcs(name,buyoutTotal,count,quantity)

   -- Elixir Master Proc
   local FLASKID = 46377;  -- "Flask of Endless Rage"
   local ELIXIRID = 3390;  -- "Elixir of Lesser Agility"
   local flaskName = GetItemInfo(FLASKID);
   local elixirName = GetItemInfo(ELIXIRID);
   local firstwordend = string.find(name," ");
   local firstword;

   -- TODO: not in all languages the item name starts with "Flask" or "Fläschchen"
   if  firstwordend ~= nil then
      firstwordend = firstwordend-1;
   else
      firstwordend = string.len(name);
   end

    firstword = string.sub(name,1,firstwordend);

   -- TODO: Not optimal solution.
   -- Might not work the first time tried, but should work the second time when data is received from server.
   if flaskName == nil then
      GameTooltip:SetHyperlink("|Hitem:"..FLASKID.."|hbla|h");
      flaskName = "Flask";
   else
      flaskName = string.sub(flaskName,1,string.find(flaskName," ")-1);
   end
   if elixirName == nil then
      GameTooltip:SetHyperlink("|Hitem:"..ELIXIRID.."|hbla|h");
      elixirName = "Elixir";
   else
      elixirName = string.sub(elixirName,1,string.find(elixirName," ")-1);
   end

    if firstword ~= flaskName and firstword ~= elixirName then
        return {buyoutTotal,count};
    else
        local crafts = count/quantity;
        local newcount = count + (floor(crafts*0.3)*quantity);
        newcount = newcount + (floor(crafts*0.03)*quantity);
        newcount = newcount + (floor(crafts*0.003)*quantity);
        newcount = newcount + (floor(crafts*0.0003)*quantity);
        newcount = newcount + (floor(crafts*0.00003)*quantity);
        return {(buyoutTotal/count)*newcount,newcount};
    end
end

function FlaskCalc:ProcModelled(name)
   -- Elixir Master Proc
   local FLASKID = 46377;  -- "Flask of Endless Rage"
   local ELIXIRID = 3390;  -- "Elixir of Lesser Agility"
   local flaskName = GetItemInfo(FLASKID);
   local elixirName = GetItemInfo(ELIXIRID);
   local firstwordend = string.find(name," ");
   local firstword;

   if  firstwordend ~= nil then
      firstwordend = firstwordend-1;
   else
      firstwordend = string.len(name);
   end

    firstword = string.sub(name,1,firstwordend);

   -- TODO: Not optimal solution.
   -- Might not work the first time tried, but should work the second time when data is received from server.
   if flaskName == nil then
      GameTooltip:SetHyperlink("|Hitem:"..FLASKID.."|hbla|h");
      flaskName = "Flask";
   else
      flaskName = string.sub(flaskName,1,string.find(flaskName," ")-1);
   end
   if elixirName == nil then
      GameTooltip:SetHyperlink("|Hitem:"..ELIXIRID.."|hbla|h");
      elixirName = "Elixir";
   else
      elixirName = string.sub(elixirName,1,string.find(elixirName," ")-1);
   end

    if firstword == flaskName or firstword == elixirName then
      return true;
    else
        return false;
    end
end

function FlaskCalc:AuctionFrameFlask_UpdateMatsSelected()
    local item = SelectedDetail;
    if self.db.profile.advanced and item.alternatives and getn(item.alternatives) ~= 0 then
        local initItem = item;
        for altId = 1,getn(item.alternatives) do
            if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                item = initItem.alternatives[altId];
            elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                item = initItem.alternatives[altId];
            end
        end
    end
    if item ~= nil then
        local buttonName = "FlaskItem2";
        local button = _G[buttonName];

        local warning = _G[buttonName .. "Warning"];

        local buttonDetailName = buttonName .. "Detail";
        local buttonDetail     = _G[buttonDetailName];

        local countText        = _G[buttonDetailName .. "Count"];
        local nameText         = _G[buttonDetailName .. "Name"];
        local buyoutEachFrame  = _G[buttonDetailName .. "BuyoutEachFrame"];
        local buyoutFrame      = _G[buttonDetailName .. "BuyoutFrame"];
        local costFrame        = _G[buttonDetailName .. "CostFrame"];
        local profitFrame      = _G[buttonDetailName .. "ProfitFrame"];
        local noBuyout         = _G[buttonDetailName .. "NoBuyout"];
        local historyBuyout    = _G[buttonDetailName .. "HistoryBuyout"];
        local noBuyoutEach     = _G[buttonDetailName .. "NoBuyoutEach"];
        local noCost           = _G[buttonDetailName .. "NoCost"];
        local noProfit         = _G[buttonDetailName .. "NoProfit"];

        local itemBuyout = item.buyout;
        local itemCount = item.count;
        if self.db.profile.advanced then
            if FlaskCalc:ProcModelled(item.name) then
                local procArray = FlaskCalc:AdjustForProcs(item.name,item.buyout,item.count,item.quantity);
                itemBuyout = procArray[1];
                itemCount =  procArray[2];
            end
        end

        button:Disable();
        countText:SetText("|cffffffff".. itemCount .."x|r");
        nameText:SetText("|cffffffff" .. item.name .. "|r");
        historyBuyout:Hide();
        if itemBuyout > 0 then
            if item.history == true then
                historyBuyout:Show();
            end

            MoneyFrame_Update(buyoutEachFrame, math.floor(itemBuyout / itemCount));
            buyoutEachFrame:Show();
            noBuyout:Hide();
            noBuyoutEach:Hide();
            MoneyFrame_Update(buyoutFrame, math.floor(itemBuyout));
            buyoutFrame:Show();
        else
            noBuyout:SetText("[No Auctions Found]");
            noBuyout:Show();
            noBuyoutEach:SetText("[No Auctions Found]");
            noBuyoutEach:Show();
            MoneyFrame_Update(buyoutEachFrame,0);
            buyoutEachFrame:Hide();
            MoneyFrame_Update(buyoutFrame,0);
            buyoutFrame:Hide();
        end
        local itemCost = item.cost;
        if self.db.profile.advanced and item.resale then
            itemCost = itemCost - item.resale;
        end
        if itemCost > 0 then
            if (0.95*itemBuyout) - itemCost > 0 then
                noProfit:Hide();
                MoneyFrame_Update(profitFrame, math.floor((0.95*itemBuyout) - itemCost));
                profitFrame:Show();
            else
                noProfit:SetText("[No Profit possible]");
                noProfit:Show();
                MoneyFrame_Update(profitFrame,0);
                profitFrame:Hide();
            end
            costFrame:Show();
            MoneyFrame_Update(costFrame, math.floor(itemCost));
            noCost:Hide();
        else
            noProfit:SetText("[No Profit Calculated]");
            noProfit:Show();
            profitFrame:Hide();
            noCost:SetText("[No Cost Calculated]");
            noCost:Show();
            MoneyFrame_Update(costFrame,0);
            costFrame:Hide();
        end


        warning:SetAlpha(0);

        buttonDetail:Show();
        button:Show();
    end
end


function FlaskCalc:AuctionFrameFlask_UpdateMats()

    FlaskCalc:AuctionFrameFlask_UpdateMatsSelected();
    FlaskMatsLabel:Show();
    local i;
    local count = 0;

    for i = 4, DISPLAY_SIZE do
        local item = MatsData[i-3];
        if item ~= nil and item.buyout > 0 then
            count = count+1;
            local buttonName = "FlaskItem" .. i;
            local button = _G[buttonName];

            local warning = _G[buttonName .. "Warning"];

            local buttonDetailName = buttonName .. "Detail";
            local buttonDetail     = _G[buttonDetailName];
            local historyBuyout    = _G[buttonDetailName .. "HistoryBuyout"];
            local countText        = _G[buttonDetailName .. "Count"];
            local nameText         = _G[buttonDetailName .. "Name"];
            local buyoutEachFrame  = _G[buttonDetailName .. "BuyoutEachFrame"];
            local buyoutFrame      = _G[buttonDetailName .. "BuyoutFrame"];
            local costFrame        = _G[buttonDetailName .. "CostFrame"];
            local profitFrame      = _G[buttonDetailName .. "ProfitFrame"];
            local noBuyout         = _G[buttonDetailName .. "NoBuyout"];
            local noBuyoutEach     = _G[buttonDetailName .. "NoBuyoutEach"];
            local noCost           = _G[buttonDetailName .. "NoCost"];
            local noProfit         = _G[buttonDetailName .. "NoProfit"];
            costFrame:Hide();
            profitFrame:Hide();
            noBuyout:Hide();
            noBuyoutEach:Hide();
            noCost:Hide();
            noProfit:Hide();
            historyBuyout:Hide();

            button:Enable();
            countText:SetText("|cffffffff".. item.count .."x|r");
            nameText:SetText("|cffffffff" .. item.name .. "|r");

            MoneyFrame_Update(buyoutEachFrame, math.floor(item.buyout / item.count));
            buyoutEachFrame:Show();


            MoneyFrame_Update(buyoutFrame, math.floor(item.buyout));
            buyoutFrame:Show();
            if SelectedMat == item then
                button:LockHighlight();
                FlaskBuyMatsButton:Enable();
            else
                button:UnlockHighlight();
            end

            warning:SetAlpha(0);

            buttonDetail:Show();
            button:Show();
            FlaskCountSlider:Show();
            FlaskCountSliderThumb:Show();
        end
    end
    if initSlider and initSliderMin and initSliderCurrent and initSliderStep then
        initSlider = false;
        FlaskCountSlider:SetMinMaxValues(initSliderMin, initSliderMax);
        FlaskCountSlider:SetValue(initSliderCurrent);
        FlaskCountSlider:SetValueStep(initSliderStep);
        initSliderMin = nil;
        initSliderMax = nil;
        initSliderCurrent = nil;
        initSliderStep = nil;
    end
    FauxScrollFrame_Update(FlaskScrollFrame, table.getn(MatsData),
                         DISPLAY_SIZE-3, ROW_HEIGHT);

    if count > 0 then
        MatFlaskHeader:Show();
        ProfitAllButton:Hide();
        CostAllButton:Hide();
    end
end

function FlaskCalc:AuctionFrameFlask_OnUpdate()
  local canSend = CanSendAuctionQuery("list") and not self:QueryInProgress();
  if canSend then
    FlaskScanButton:Enable();
  else
    FlaskScanButton:Disable();
  end


  if StartTime ~= nil then
    self:UpdateProgressSearch();
  end
end
function FlaskCalc:FlaskButton_OnClick(id)
    local offset = FauxScrollFrame_GetOffset(FlaskScrollFrame);

    if VIEW_MODE == DETAIL_MODE then
        SelectedDetail = nil;


        local listing = DetailData[offset + id];
        if IsControlKeyDown() and SelectedDetail == listing then
            SelectedDetail = nil;
        else
            SelectedDetail = listing;
        end
    else
        SelectedMat = nil;
        local listing = MatsData[offset+id-3];
        if IsControlKeyDown() and SelectedMats == listing then
            SelectedMat = nil;
        else
            SelectedMat = listing;
        end
    end

    self:AuctionFrameFlask_Update();
end

function FlaskCalc:FlaskButton_OnEnter(button)
    if VIEW_MODE == DETAIL_MODE then
        local id = button:GetID();
        local offset = FauxScrollFrame_GetOffset(FlaskScrollFrame);
        local item = DetailData[offset + id];
        if self.db.profile.advanced and item.alternatives and getn(item.alternatives) ~= 0 then
            local initItem = item;
            for altId = 1,getn(item.alternatives) do
                if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                    item = initItem.alternatives[altId];
                elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                    item = initItem.alternatives[altId];
                end
            end
        end
        local hover = item;
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        GameTooltip:SetText(hover.Profession..": "..hover.name, 1, 1, 1);
        GameTooltip:AddLine("Count: "..hover.count, nil, nil, nil, 1);
        for i = 1,getn(hover.Mats) do
            if FlaskCalc:GetVendorPrice(hover.Mats[i][1]) == 0 then
                GameTooltip:AddLine(hover.Mats[i][2].."x "..hover.Mats[i][1], nil, nil, nil, 1);
            else
                GameTooltip:AddLine("("..hover.Mats[i][2].."x "..hover.Mats[i][1]..")", nil, nil, nil, 1);
            end
            if hover.Mats[i][3] > 0 then
                SetTooltipMoney(GameTooltip, hover.Mats[i][3]);
            else
                GameTooltip:AddLine("--NONE FOUND--", nil, nil, nil, 1);
            end
        end
        GameTooltip:Show();
    end
end


function FlaskCalc:FlaskBuyMatsButton_OnClick()
    if SelectedMat ~= nil then
        local order = self:GetLowestCostOrder(SearchData[SelectedMat.name].data,SelectedMat.count);
        if order ~= {} then
            local cost = self:GetOrderCost(order);
            local count = self:GetOrderCount(order);
            if GetMoney() < cost then
                message("Insuffient Funds");
            else
                self:BuyItems(SelectedMat.name,order,cost,count);
            end
        else
            message("Cannot Find Enough Items to Purchase");
        end
    end
end

function FlaskCalc:FlaskViewMatsButton_OnClick()

    if SelectedDetail ~= nil then
        local item = SelectedDetail;
        if self.db.profile.advanced and item.alternatives and getn(item.alternatives) ~= 0 then
            local initItem = item;
            for altId = 1,getn(item.alternatives) do
                if initItem.alternatives[altId].cost ~= 0 and item.cost > initItem.alternatives[altId].cost then
                    item = initItem.alternatives[altId];
                elseif initItem.alternatives[altId].cost ~= 0 and item.cost == 0 then
                    item = initItem.alternatives[altId];
                end
            end
        end
        FlaskCalc:GenerateMatsDisplay(item.Recipe,true);
    else
        self:Print("Selected Detail is nil");
    end
end


function FlaskCalc:GenerateMatsDisplay(Recipe,Init)
    VIEW_MODE = MATS_MODE;
    MatsData = {};
    SelectedMat = nil;
    local ordercost = 0;
    local itemCount = Recipe.DesiredAmount;
    local quantity = Recipe.Quantity;

    previous = itemCount;
    for matId = 1, getn(Recipe.Mats) do
        local mat = {};
        mat.name = Recipe.Mats[matId][1];
        if FlaskCalc:GetVendorPrice(mat.name) == 0 then
            mat.count = Recipe.Mats[matId][2]*(itemCount/quantity);
            local itemID = nil;
            local matLink = nil;
            if SearchData[mat.name] ~= nil then
                matLink = SearchData[mat.name].link
            end
            if matLink ~= nil then
                local _,_,itemString = string.find(matLink, "^|c%x+|H(.+)|h%[.*%]");

            --local itemID = Altoholic:GetIDFromLink(itemString)
                _, itemID = strsplit(":", itemString);
                itemID = tonumber(itemID);
            end
            if self.db.profile.inventory and Altoholic and itemID ~= nil then
                mat.count = mat.count-Altoholic:GetItemCount(itemID);
            elseif self.db.profile.inventory then
                mat.count = mat.count-GetItemCount(matLink,true);
            end

            if mat.count > 0 then
                local matOrder = self:GetLowestCostOrder(SearchData[mat.name].data,mat.count);
                mat.buyout = self:GetLowestCost(SearchData[mat.name].data,mat.count,matOrder);
                mat.resale = self:GetOrderResale(SearchData[mat.name].data,mat.count,matOrder);
                table.insert(MatsData,mat);
            end
        end
    end
    if Init == true then
        local max = FlaskCalc:MaximumPossible(Recipe,true);
        initSlider = true;

        initSliderStep = quantity;
        initSliderMin  = quantity;
        initSliderMax = max - mod(max,quantity);
        initSliderCurrent = itemCount;
        FauxScrollFrame_SetOffset(FlaskScrollFrame, 0);
    end
    self:AuctionFrameFlask_Update();
end

function FlaskCalc:AdvancedModeCheckButton_OnClick()
    self.db.profile.advanced = AdvancedModeCheckButton:GetChecked();
    if VIEW_MODE == MATS_MODE then
        FlaskCalc:FlaskViewMatsButton_OnClick();
    elseif currentSearch > searchNum then
        self:AuctionFrameFlask_Update();
    end
end
function FlaskCalc:AdvancedModeCheckButton_OnEnter(button)
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:SetText(L["Calculates the resale of excess mats, nested recipes and elixir master procs"]);
    GameTooltip:Show();
end
function FlaskCalc:OnlyNeededCheckButton_OnClick()
    self.db.profile.inventory = OnlyNeededCheckButton:GetChecked();

    if VIEW_MODE == MATS_MODE then
        FlaskCalc:FlaskViewMatsButton_OnClick();
    elseif currentSearch > searchNum then
        self:AuctionFrameFlask_Update();
    end
end

function FlaskCalc:OnlyNeededCheckButton_OnEnter(button)
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    if Altoholic then
        GameTooltip:SetText("Adjusts the total mat of each mat needed by the amount already owned (According to Altoholic)");
    else
        GameTooltip:SetText("Adjusts the total number of each mat needed by the amount already owned (According to Bags/Bank)");
    end
    GameTooltip:Show();
end
function FlaskCalc:FlaskViewRecipesButton_OnClick()
    VIEW_MODE = DETAIL_MODE;
    FauxScrollFrame_SetOffset(FlaskScrollFrame, 0);
    self:AuctionFrameFlask_Update();

end

function FlaskCalc:BuyItems(name,order,cost,count)
    -- Submit the query.  If it goes through, save it here too.
    local query = {
        name = name,
        wait = true,
        list = order,
        isBuyout = true,
        finish = function(data)
            self:Print("Finished Purchasing");
            scanNeeded = name;
        end,
    };
    CurrentPurchaseOrder = {};
    CurrentPurchaseOrder.Name = name;
    CurrentPurchaseOrder.Cost = cost;
    CurrentPurchaseOrder.Count = count;
    local queryResult = self:StartQuery(query);
end


function FlaskCalc:FlaskTicker(elapsed)
   if scanNeeded ~= nil then
        self:StartScanItem(scanNeeded);
        scanNeeded = nil;
    end

    -- perform calculation after the AH scan
    if doCalculation == true then
      counter = counter + elapsed
      if counter >= throttle then
         counter = counter - throttle

         if coroutine.status(thread) ~= "dead" then
            coroutine.resume(thread)
            if coroutine.status(thread) == "dead" then
                -- Calculation is finished
                FlaskCalc:CalculationFinished()
            end
         end
      end
    end
end


-- Display the AH search progress
function FlaskCalc:UpdateProgressSearch(pct)
  -- Record a start time if we don't have one already.
  if StartTime == nil then
    StartTime = math.floor(time());
  end

  -- Update the display every second.
  local currentTime = math.floor(time());
  if LastTime == nil or currentTime > LastTime then
    LastTime = currentTime;
    local Progress = 0;
    if currentSearch > 0 then
       Progress = (currentSearch/searchNum)*100;
    end
    -- If we have some data, compute the time remaining.
    local elapsed = currentTime - StartTime;

    if Progress ~= 0 then
        local remaining = math.floor((100 * elapsed / Progress) - elapsed);
        FlaskRemainingData:SetText(self:PrintTime(remaining));
    else
        FlaskRemainingData:SetText("---");
    end

    -- Update the percentage.

    FlaskStatusText:SetText("Searching:");
    FlaskStatusData:SetText(tostring(math.floor(Progress)) .. "%");

    -- Update the elapsed time and show the whole pane.
    FlaskElapsedData:SetText(self:PrintTime(elapsed));
    FlaskStatus:Show();
  end
end


-- Display the calculation progress
function FlaskCalc:UpdateProgressCalculation(percentage)
    -- Record a start time if we don't have one already.
    if StartTime == nil then
        StartTime = math.floor(time());
    end

    -- Update the display.
    local currentTime = math.floor(time());
   -- If we have some data, compute the time remaining.
   local elapsed = currentTime - StartTime;

   if percentage ~= 0 then
       local remaining = math.floor((100 * elapsed / percentage) - elapsed);
       FlaskRemainingData:SetText(self:PrintTime(remaining));
   else
       FlaskRemainingData:SetText("---");
   end

   -- Update the percentage.

   FlaskStatusText:SetText("Calculating:");
   FlaskStatusData:SetText(tostring(math.floor(percentage)) .. "%");

   -- Update the elapsed time and show the whole pane.
   FlaskElapsedData:SetText(self:PrintTime(elapsed));
   FlaskStatus:Show();

end


-- called when scan button is pressed
function FlaskCalc:StartScan()
    --SelectedDetail = nil;

    VIEW_MODE = DETAIL_MODE;
    FlaskMode = FLASK_MODE_SCAN;
    FlaskScanButton:Disable();

    currentmats = FlaskCalc:GetUniqueListOfMats();
    currentrecipes = FlaskCalc:GetRecipes();

    Queries = {};
    SearchData = {};
    currentSearch = 0;
    searchNum = getn(currentmats);
    for matId = 1,getn(currentmats) do
        local matName = currentmats[matId];
        if FlaskCalc:GetVendorPrice(matName) == 0 then
            table.insert(Queries,{
                name = matName,
                wait = true,
                update = function(pct) FlaskCalc:UpdateProgressSearch(pct) end,
                finish = function(data) FlaskCalc:SetSearchData(data) end,
            });
            SearchData[matName] = {};
        else
            searchNum = searchNum -1;
        end
    end

    self:NextSearch();
    self:ClearFlaskFrame(true);
end

function FlaskCalc:StartScanItem(name)
    FlaskMode = FLASK_MODE_SCAN;
    FlaskScanButton:Disable();

    Queries = {};
    currentSearch = 0;

    table.insert(Queries,{
        name = name,
        wait = true,
        update = function(pct) end,
        finish = function(data) FlaskCalc:SetSearchData(data) end,
    });
    searchNum = getn(Queries);
    SearchData[name] = {};

    self:NextSearch();
end

function FlaskCalc:SetSearchData(results)

  local lastLink = nil;
  local lastName = nil;

  -- Sort everything and assemble the summary data.
  for link, result in pairs(results) do
    result.link = link;
    result.name = self:SplitLink(link);

    lastLink = link;
    lastName = result.name;
    if lastLink ~= nil then
        local itemData = results[lastLink].data;
        local CurrentItemData = {};

        for i=1,getn(itemData) do

            local item = itemData[i];
            if item.buyout > 0 then
                table.insert(CurrentItemData,item);
            end
        end

        if lastName ~= nil then
            SearchData[lastName] = {};
            SearchData[lastName].data = CurrentItemData;
            SearchData[lastName].link = lastLink;
        end
    end
  end

  self:NextSearch();
end


function FlaskCalc:NextSearch()
    currentSearch = currentSearch+1;
    if currentSearch <= searchNum then
        local query = Queries[currentSearch];
        local queryResult = self:StartQuery(query);

        if queryResult == false then
            self:ScanFinished();
        end
    else
        self:ScanFinished();
    end
end


function FlaskCalc:ScanFinished()
  -- Clean up the display.
  Queries = {};

  -- Reset current query info.
  self:ResetSearch();

  self:BuildDetail();
end


function FlaskCalc:BuildDetail()
    doCalculation = true
    thread = coroutine.create(BuildDetailSub)
    coroutine.resume(thread)
end


-- coroutine to perform calculations on the scanned AH data
function BuildDetailSub()
    local CurrentSelected = SelectedDetail;
    SelectedDetail  = nil;
    DetailData = {};
    local item = {};
    local Recipes = currentrecipes;
    for recipeId = 1, getn(Recipes) do

        -- create entry for this recipe
        local count = FlaskCalc:MaximumPossible(Recipes[recipeId],true);
        if(FlaskCalc:CreateEntry(Recipes[recipeId], count) == nil) then
            return;
        else
            item = FlaskCalc:CreateEntry(Recipes[recipeId],count);
        end

        -- create entries for alternatives
        item.alternatives = FlaskCalc:CreateAlternatives(Recipes[recipeId],count);

        --Add alternatives to the list to be displayed
        table.insert(DetailData,item);
        if CurrentSelected ~= nil and item.name == CurrentSelected.name then
            SelectedDetail = item;
        end

        -- Display the progress of the calculation
        FlaskCalc:UpdateProgressCalculation((recipeId/getn(Recipes))*100)

        coroutine.yield()
    end
 end


-- called when the calculation following the scan is finished
function FlaskCalc:CalculationFinished()
    doCalculation = false

    FlaskMessageText:Hide();
    FlaskStatus:Hide();

    FlaskScanButton:Enable();

    -- show results when calculation is finished
    if VIEW_MODE == MATS_MODE then
        FlaskCalc:FlaskViewMatsButton_OnClick();
    else
        self:AuctionFrameFlask_Update();
    end
end


-- Create alternatives for a recipe
-- Avoid list is used to prevent circular dependencies,
-- e.g. Crystallized Fire can be created by Eternal Fire which can be created by Crystallized Fire, ...
function FlaskCalc:CreateAlternatives(Recipe,count)
    local AlternativeRecipes = {};
    local Avoid = {};
    table.insert(Avoid,Recipe.Name);
    AlternativeRecipes = FlaskCalc:CreateAlternativeRecipes(AlternativeRecipes,Recipe,Avoid);

-- Temporarily only do one iteration.
-- For the second iteration we should check that only alternatives are searched for the items
-- that have been created as alternatives in the first iteration and not also for items that existed before
-- Currently no problem, double entries are prevented by the check of the avoid list in the function
-- MatchingRecipes, but runtime optimization is possible here
--    for i = 1,2 do
        -- create copy, otherwise array looped through in the loop would be modified within the loop
        -- --> unknown behavior?
        local constAlternativeRecipes = AlternativeRecipes;
        for altId = 1,getn(constAlternativeRecipes) do
            local AltRecipe = constAlternativeRecipes[altId]
            table.insert(Avoid,AltRecipe.Name);
            AlternativeRecipes = FlaskCalc:CreateAlternativeRecipes(AlternativeRecipes,AltRecipe,Avoid);
        end
--    end

    local AlternativeItems = {};
    for altId = 1,getn(AlternativeRecipes) do
        table.insert(AlternativeItems,FlaskCalc:CreateEntry(AlternativeRecipes[altId],count));
    end
    return AlternativeItems;
end



--[[
-- TODO: check if really all alternatives need to be checked
-- there seems to be no dependency between the maximum possible amount (maximum over
-- all alternatives) and and the alternative chosen depending on price
function FlaskCalc:MaximumPossible(Recipe)
    local max = 0;
    local recipeMin = nil;

    for matId = 1, getn(Recipe.Mats) do
        local mat = {};
        mat.name = Recipe.Mats[matId][1];
        if FlaskCalc:GetVendorPrice(mat.name) == 0 then
            local multiple = FlaskCalc:GetTotalMultiple(SearchData[mat.name].data,Recipe.Mats[matId][2])
            if recipeMin == nil then
                recipeMin = multiple;
            elseif multiple < recipeMin then
                recipeMin = multiple;
            end
        else
            -- Vendor price available.
            -- Item can be bought at a vendor and is therefore usually not limited.
            -- set dummy value for recipeMin
            if recipeMin == nil then
                recipeMin = 1000000;
            end
        end
    end

    max = recipeMin * Recipe.Quantity;
    return max;
end
]]--


function FlaskCalc:MaximumPossible(Recipe,includeAlternatives)
    local max = 0;
    local RecipeList = {};

    if includeAlternatives == true then
        local Avoid = {};
        table.insert(Avoid,Recipe.Name);
        RecipeList = FlaskCalc:CreateAlternativeRecipes(RecipeList,Recipe,Avoid);


        for i = 1,2 do
            local altNum = getn(RecipeList)
            for altId = 1,altNum do
                local AltRecipe = RecipeList[altNum]
                table.insert(Avoid,RecipeList.Name);
                RecipeList = FlaskCalc:CreateAlternativeRecipes(RecipeList,AltRecipe,Avoid);
            end
        end
    end

    table.insert(RecipeList,Recipe);
    local InitRecipe = Recipe;
    for i = 1,getn(RecipeList) do
        Recipe = RecipeList[i];
        local recipeMin = nil;
        for matId = 1, getn(Recipe.Mats) do
            local mat = {};
            mat.name = Recipe.Mats[matId][1];
            if FlaskCalc:GetVendorPrice(mat.name) == 0 then
                local multiple = FlaskCalc:GetTotalMultiple(SearchData[mat.name].data,Recipe.Mats[matId][2])
                if recipeMin == nil then
                    recipeMin = multiple;
                elseif multiple < recipeMin then
                    recipeMin = multiple;
                end
            else
                -- Vendor price available.
                -- Item can be bought at a vendor and is therefore usually not limited.
                -- set dummy value for recipeMin
                if recipeMin == nil then
                    recipeMin = 100000;
                end
            end
        end
        if max < recipeMin then
            max = recipeMin;
        end
    end

    max = max * InitRecipe.Quantity;
    return max;
end


-- Create recipe (if available) for an item with alternative mats
function FlaskCalc:CreateAlternativeRecipes(AlternativeRecipes,Recipe,Avoid)
    -- try to find recipes for each mat of the original recipe
    for matId = 1,getn(Recipe.Mats) do
        local matName = Recipe.Mats[matId][1];
        local matching = FlaskCalc:MatchingRecipes(matName,Avoid);
        -- create for each match a new, alternative recipe where the original mat is
        -- replaced by the mats for the newly found recipe to create the original mat.
        for matchId = 1,getn(matching) do
            local MatchRecipe = matching[matchId];
            local AltRecipe = {};

           --[[
            for altId = 1,getn(AlternativeRecipes) do
                AltRecipe = FlaskCalc:CloneRecipe(AlternativeRecipes[altId]);
                AltRecipe = FlaskCalc:MergeMats(MatchRecipe,AltRecipe,Recipe.Mats[matId]);

                 -- this is where the error might be
                 -- not sure what the whole for loop is supposed to do...

                table.insert(AlternativeRecipes,AltRecipe);
            end
            ]]--


            AltRecipe = FlaskCalc:CloneRecipe(Recipe);
            AltRecipe = FlaskCalc:MergeMats(MatchRecipe,AltRecipe,Recipe.Mats[matId]);
            table.insert(AlternativeRecipes,AltRecipe);
        end
    end
    return AlternativeRecipes;
end

-- Merge mats
-- from: recipe that was found to create one of one of the mats of the original recipe
-- to: the newly created clone of the original recipe
-- Merge because we found a recipe (RecipeAddFrom) for the mat (Mat) required for the
-- (clone of the) original recipe (RecipeAddTo)
function FlaskCalc:MergeMats(RecipeAddFrom,RecipeAddTo,Mat)
    local CraftsNeeded = math.ceil(Mat[2]/RecipeAddFrom.Quantity);
    -- add new mat
    for fromID = 1,getn(RecipeAddFrom.Mats) do
        local found = false;
        for toID = 1,getn(RecipeAddTo.Mats) do
            -- if mat is already used in recipe, only increase the necessary amount
            if RecipeAddFrom.Mats[fromID][1] == RecipeAddTo.Mats[toID][1] then
                local NewAmount = CraftsNeeded*RecipeAddFrom.Mats[fromID][2];
                RecipeAddTo.Mats[toID][2] = RecipeAddTo.Mats[toID][2] + NewAmount;
                found = true;
            end
        end
        -- if mat is not already used in the recipe, add it as new mat
        if found == false then
            local NewAmount = CraftsNeeded*RecipeAddFrom.Mats[fromID][2];
            table.insert(RecipeAddTo.Mats,{RecipeAddFrom.Mats[fromID][1],NewAmount});
        end
    end
    -- remove the mat where we found an alternative for (and where we have added the
    -- alternative mats in the previous step)
    for matID = 1,getn(RecipeAddTo.Mats) do
        if RecipeAddTo.Mats[matID][1] == Mat[1] then
            table.remove(RecipeAddTo.Mats,matID);
            break;
        end
    end
    return RecipeAddTo;
end

function FlaskCalc:UpdateEntry(item,Count)
    item.count = Count;
    item.Recipe.DesiredAmount = Count;
    item.Mats = {};
    item.cost = 0;
    item.resale = 0;
    local missingMats = 0
    local Recipe = item.Recipe;
    for matId = 1, getn(Recipe.Mats) do
        local mat = Recipe.Mats[matId][1];
        local matQuantity = Recipe.Mats[matId][2];
        matQuantity = matQuantity*(item.count/item.quantity);
        if FlaskCalc:GetVendorPrice(mat) == 0 then
            local matOrder = self:GetLowestCostOrder(SearchData[mat].data,matQuantity);
            local matCost = self:GetLowestCost(SearchData[mat].data,matQuantity,matOrder);
            local matResale = self:GetOrderResale(SearchData[mat].data,matQuantity,matOrder);
            table.insert(item.Mats,{mat,matQuantity,matCost,matResale});
            if matCost == 0 then
                missingMats = missingMats+1;
            else
                item.cost = item.cost + matCost;
                item.resale = item.resale + matResale;
            end
        else
            table.insert(item.Mats,{mat,matQuantity,(FlaskCalc:GetVendorPrice(mat)* matQuantity),0});
            item.cost = item.cost + (FlaskCalc:GetVendorPrice(mat)* matQuantity);
        end
    end
    if missingMats ~= 0 then
        item.cost = 0
        item.resale = 0;
    end
    item.buyout = item.count*self:GetLowestBuyout(SearchData[item.name].data);
    if item.buyout == 0 then
        local link = Recipe.ItemLink;
        if AucAdvanced and AucAdvanced.Version and link then
            item.buyout = item.count*AucAdvanced.API.GetMarketValue(link, AucAdvanced.GetFaction());
            item.history = true;
        end
    end
end

-- create entry in list to be displayed
-- Recipe: recipe object
-- count: number of items to be created from recipe
function FlaskCalc:CreateEntry(Recipe,count)
    local item = {};
    item.Recipe = Recipe;
    item.ID = Recipe.ID;
    item.name = Recipe.Name;

    item.count = Recipe.DesiredAmount;
    if SearchData[item.name] == nil then
        self:Print(Recipe.Name);
    end
    item.link = SearchData[item.name].link;
    item.quantity = Recipe.Quantity;
    item.Profession = Recipe.Profession;
    item.cost = 0;
    item.resale = 0;
    item.Mats = {};

    local missingMats = 0;

    if count == nil then
    else
        item.count = min(item.count,count);
    end
    for matId = 1, getn(Recipe.Mats) do
        local mat = Recipe.Mats[matId][1];
        local matQuantity = Recipe.Mats[matId][2];
        matQuantity = matQuantity*(item.count/item.quantity);
        if FlaskCalc:GetVendorPrice(mat) == 0 then
            local matOrder = self:GetLowestCostOrder(SearchData[mat].data,matQuantity);
            local matCost = self:GetLowestCost(SearchData[mat].data,matQuantity,matOrder);
            local matResale = self:GetOrderResale(SearchData[mat].data,matQuantity,matOrder);
            table.insert(item.Mats,{mat,matQuantity,matCost,matResale});
            if matCost == 0 then
                missingMats = missingMats+1;
            else
                item.cost = item.cost + matCost;
                item.resale = item.resale + matResale;
            end
        else
            table.insert(item.Mats,{mat,matQuantity,(FlaskCalc:GetVendorPrice(mat)* matQuantity),0});
            item.cost = item.cost + (FlaskCalc:GetVendorPrice(mat)* matQuantity);
        end
    end
    if missingMats ~= 0 then
        item.cost = 0
        item.resale = 0;
    end
    item.buyout = item.count*self:GetLowestBuyout(SearchData[item.name].data);
    if item.buyout == 0 then
        local link = Recipe.ItemLink;
        if AucAdvanced and AucAdvanced.Version and link then

         if(AucAdvanced.API.GetMarketValue(link, AucAdvanced.GetFaction()) == nil) then
            item.buyout = 0;
         else
            item.buyout = item.count*AucAdvanced.API.GetMarketValue(link, AucAdvanced.GetFaction());
            item.history = true;
         end
        end
    end
    return item;
end

function FlaskCalc:PrintEntry(Entry)
    local MatString = "";
    for i = 1,getn(Entry.Mats) do
        MatString = string.format("%s%s @ %s, ",MatString,Entry.Mats[i][1],Entry.Mats[i][3]);
    end
    local printEntry = string.format("%s x %s sale @ %s, cost @ %s , Mats:%s",Entry.count,Entry.name,Entry.buyout,Entry.cost,MatString);
    self:Print(printEntry);
end

function FlaskCalc:GetLowestBuyout(itemData)
    if itemData == nil then
        return 0;
    end
    local lowestBuyout = 0;
    for i=1,getn(itemData) do
        item = itemData[i];
        if lowestBuyout == 0 then
            lowestBuyout = math.floor(item.buyout/item.count);
        elseif item.buyout/item.count <= lowestBuyout then
            lowestBuyout = math.floor(item.buyout/item.count);
        end
    end
    return lowestBuyout;
end

function FlaskCalc:GetLowestCost(itemData,requested,order)
    local total = 0;
    if order == nil then
        order = self:GetLowestCostOrder(itemData,requested);
    end
    if order ~= nil then
        for i = 1,getn(order) do
            total = total + order[i].buyout;
        end
    end
    return total;
end

function FlaskCalc:GetOrderResale(itemData,requested,order)
    if order == nil then
        order = self:GetLowestCostOrder(itemData,requested);
    end
    if order ~= nil and getn(order) > 0 then

        local count = FlaskCalc:GetOrderCount(order);
        if count == requested then
            return 0;
        else
            local extra = count - requested;
            local lastOrderEntry = order[getn(order)];
            local lastOrderPricePerItem = lastOrderEntry.buyout/lastOrderEntry.count;
            return lastOrderPricePerItem*extra*0.95;
        end
    else
        return 0;
    end

end

function FlaskCalc:GetOrderCost(order)
    local total = 0;
    for i = 1,getn(order) do
        total = total + order[i].buyout;
    end

    return total;
end

function FlaskCalc:GetOrderCount(order)
    local total = 0;
    for i = 1,getn(order) do
        total = total + order[i].count;
    end

    return total;
end

function FlaskCalc:GetTotalMultiple(itemData,multiple)
    local order = {};
    -- Make a list of all items from other sellers with nonzero buyout.
    -- Also figure out how many items we have available in all.
    if itemData == nil then
        return 0;
    end
    local available = {};
    local cheapest = nil;
    local cheapestOwned = nil;
    local total = 0;
    local listing;
    local lowestCost = 0;
    for _, listing in ipairs(itemData) do
      if listing.buyout > 0 then
        local price = listing.buyout / listing.count;
        if listing.owner == UnitName("player") then
          -- Remember the cheapest auction that we own.
          if cheapestOwned == nil or price < cheapestOwned then
            cheapestOwned = price;
          end
        else
          -- Remember the cheapest auction that we don't own.
          if cheapest == nil or price < cheapest then
            cheapest = price;
          end
          -- Keep track of all other auctions with buyouts.
          table.insert(available, listing);
          total = total + listing.count;
        end
      end
    end
    return floor(total/multiple);
end

function FlaskCalc:GetLowestCostOrder(itemData,requested)

    local order = {};
    -- Make a list of all items from other sellers with nonzero buyout.
    -- Also figure out how many items we have available in all.
    if itemData == nil then
        return {};
    end
    local available = {};
    local cheapest = nil;
    local cheapestOwned = nil;
    local total = 0;
    local listing;
    local lowestCost = 0;
    for _, listing in ipairs(itemData) do
      if listing.buyout > 0 then
        local price = listing.buyout / listing.count;
        if listing.owner == UnitName("player") then
          -- Remember the cheapest auction that we own.
          if cheapestOwned == nil or price < cheapestOwned then
            cheapestOwned = price;
          end
        else
          -- Remember the cheapest auction that we don't own.
          if cheapest == nil or price < cheapest then
            cheapest = price;
          end
          -- Keep track of all other auctions with buyouts.
          table.insert(available, listing);
          total = total + listing.count;
        end
      end
    end

    -- Are there enough items for sale to satisfy the request?
    if total < requested then
      return {};
    else
      -- Yep.  So now we have to figure out what to buy.  We use an
      -- adaptation of the standard dynamic programming algorithm for
      -- 0-1 knapsack.

      -- The state for this algorithm is as follows:
      --   results: For any n, what's the best price we can get for exactly
      --            n items, and what listings do we have to buy to do so?
      --   indices: A list of valid indices for results, in descending order.
      -- We initialize these with 0, our base case.
      local results = { [0] = { price = 0 } };
      local indices = { 0 };

      -- Determine the maximum number of items we want to consider buying.
      -- This is the number requested plus the maximum stack size available
      -- in the AH.  We don't need to consider anything large than this,
      -- because if we could fill the user's order for a larger count, then
      -- we must be able to remove one listing to fill the user's order for
      -- less money overall.
      local maxCount = 0;
      local listing;
      for _, listing in ipairs(available) do
        if listing.count > maxCount then
          maxCount = listing.count;
        end
      end
      maxCount = maxCount + requested;

      -- Sort by count, which improves the speed of the algorithm below.
      table.sort(available, function(a, b) return a.count > b.count end);

      -- Save our start time.
      local start = time();

      -- Consider each listing in turn.  At each step, the results table
      -- will have the best results for the set of listings we've considered
      -- so far.
      local timeout = false;
      local listing;
      for _, listing in ipairs(available) do
        -- If we've taken more than 1-2 seconds, bail.
        if start + 1 < time() then
          timeout = true;
          break;
        end
        -- Iterate over all counts where we have results so far, in
        -- descending order so that we can update in place.
        local count;
        for _, count in ipairs(indices) do
          local info = results[count];
          local newCount = count + listing.count;
          assert(info ~= nil);
          -- Add this listing to the best result at this stack size.
          -- Do we care about the resulting set of items?
          if newCount < maxCount then
            -- If this is the first option at this new stack size, or if it's
            -- cheaper than our previous best effort, update the data.
            local newInfo = results[newCount];
            local newPrice = info.price + listing.buyout;
            if newInfo == nil or newPrice < newInfo.price then
              -- The new data consists of the current result's listings plus
              -- the listing we just added.
              results[newCount] = {
                price = newPrice,
                listing = listing,
                info = info,
              };
            end
            -- If we added a new index to the results table, add it to our
            -- list of indices too, and make sure it's still sorted.
            if newInfo == nil then
              table.insert(indices, newCount);
              table.sort(indices, function(a, b) return a > b end);
            end
          end
        end
      end

      if timeout then
        -- We hit a timeout, so just do things the fast way.
        -- First sort by per-item buyout.
        local sort = function(a, b)
          return a.buyout / a.count < b.buyout / b.count;
        end
        table.sort(available, sort);

        -- Get the cheapest items until the order is filled.
        local selected = {};
        local count = 0;
        local i = 1;
        while i < table.getn(available) and count < requested do
          local listing = available[i];
          table.insert(selected, listing);
          count = count + listing.count;
          i = i + 1;
        end

        -- Go over the selected items in reverse order and remove any
        -- that aren't actually necessary.
        local i = table.getn(selected);
        while i > 0 do
          local listing = selected[i];
          if count - listing.count >= requested then
            table.remove(selected, i);
            count = count - listing.count;
          end
          i = i - 1;
        end

        -- Update the selected items list as appropriate.
        local listing;
        for _, listing in ipairs(selected) do
          lowestCost = lowestCost + listing.price;
          table.insert(order,listing);
        end
      else
        -- We've computed our best options for all stack sizes.

        -- Figure out the resale value for this item.  We use the lesser
        -- of the cheapest price and the historical price.
        local resale = cheapest - 1;

        -- Now find the cheapest way to buy the requested number of items.
        local bestCount = nil;
        local bestInfo = nil;
        local count;
        local info;
        for count, info in pairs(results) do
          if count >= requested then
            -- Is this the best option we've seen?
            if bestInfo == nil or info.price < bestInfo.price or
               (info.price == bestInfo.price and count > bestCount) then
              bestCount = count;
              bestInfo = info;
            end
          end
        end

        -- Update SelectedItems with the final results.  We should always
        -- find a result here, but we'll be defensive anyway.

        while bestInfo ~= nil and bestInfo.listing ~= nil do
          lowestCost = lowestCost + bestInfo.listing.price;
          table.insert(order,bestInfo.listing);
          bestInfo = bestInfo.info;
        end
      end
    end
    return order;
end

-- The query system needs us to approve purchases.
function FlaskCalc:RequestApproval()
  -- Implicit approval
  StaticPopupDialogs["ORDER_CONFIRM_PURCHASE"] = {
        text = "Approve the purchase of "..CurrentPurchaseOrder.Count.."x " .. CurrentPurchaseOrder.Name,
        button1 = "Yes",
        button2 = "No",
        OnAccept = function()
            self:QueryApprove();
        end,
        OnCancel = function()
            self:Print("Cancelling Purchase at Users Request");
        end,
        OnShow = function(self)
            MoneyFrame_Update(self.moneyFrame, CurrentPurchaseOrder.Cost);
        end,
        timeout = 0,
        whileDead = 1,
        hasMoneyFrame = 1,
        hideOnEscape = 1
    };
  StaticPopup_Show ("ORDER_CONFIRM_PURCHASE");

end
