﻿-------------------------------------------------------------------------------
-- Recipes.lua
--
-- Sets up all of the recipes and mats for the recipes
-------------------------------------------------------------------------------

-- Set our constants
--Crystallized/Eternal
local CAIR = 37700;
local EAIR = 35623;
local CEARTH = 37701;
local EEARTH = 35624;
local CSHADOW = 37703;
local ESHADOW = 35627;
local CLIFE = 37704;
local ELIFE = 35625;
local CFIRE = 37702;
local EFIRE = 36860;
local CWATER = 37705;
local EWATER = 35622;


local RecipesInit = {};
table.insert(RecipesInit,{["ID"]="0001",["itemID"]=46377,["Name"]="Flask of Endless Rage",     ["Profession"]=GetSpellInfo(2259),["Quantity"]=2,["DesiredAmount"]=20,["Mats"]={{["itemID"]=40411,"Enchanted Vial",1},{["itemID"]=36908,"Frost Lotus",1},{["itemID"]=36905,"Lichbloom",7},{["itemID"]=36901,"Goldclover",3}         }});
table.insert(RecipesInit,{["ID"]="0002",["itemID"]=46378,["Name"]="Flask of Pure Mojo",        ["Profession"]=GetSpellInfo(2259),["Quantity"]=2,["DesiredAmount"]=20,["Mats"]={{["itemID"]=40411,"Enchanted Vial",1},{["itemID"]=36908,"Frost Lotus",1},{["itemID"]=36906,"Icethorn",7}, {["itemID"]=40195,"Pygmy Oil",3}          }});
table.insert(RecipesInit,{["ID"]="0003",["itemID"]=46379,["Name"]="Flask of Stoneblood",       ["Profession"]=GetSpellInfo(2259),["Quantity"]=2,["DesiredAmount"]=20,["Mats"]={{["itemID"]=40411,"Enchanted Vial",1},{["itemID"]=36908,"Frost Lotus",1},{["itemID"]=36905,"Lichbloom",7},{["itemID"]=CLIFE,"Crystallized Life",3}  }});
table.insert(RecipesInit,{["ID"]="0004",["itemID"]=46376,["Name"]="Flask of the Frost Wyrm",   ["Profession"]=GetSpellInfo(2259),["Quantity"]=2,["DesiredAmount"]=20,["Mats"]={{["itemID"]=40411,"Enchanted Vial",1},{["itemID"]=36908,"Frost Lotus",1},{["itemID"]=36905,"Lichbloom",5},{["itemID"]=36906,"Icethorn",5}}});
table.insert(RecipesInit,{["ID"]="0005",["itemID"]=33448,["Name"]="Runic Mana Potion",         ["Profession"]=GetSpellInfo(2259),["Quantity"]=1,["DesiredAmount"]=20,["Mats"]={{["itemID"]=18256,"Imbued Vial",1},{["itemID"]=36905,"Lichbloom",2},  {["itemID"]=36901,"Goldclover",1}                         }});
table.insert(RecipesInit,{["ID"]="0006",["itemID"]=33447,["Name"]="Runic Healing Potion",      ["Profession"]=GetSpellInfo(2259),["Quantity"]=1,["DesiredAmount"]=20,["Mats"]={{["itemID"]=18256,"Imbued Vial",1},{["itemID"]=36906,"Icethorn",2},   {["itemID"]=36901,"Goldclover",1}                         }});
table.insert(RecipesInit,{["ID"]="0007",["itemID"]=40211,["Name"]="Potion of Speed",           ["Profession"]=GetSpellInfo(2259),["Quantity"]=1,["DesiredAmount"]=20,["Mats"]={{["itemID"]=18256,"Imbued Vial",1},{["itemID"]=36903,"Adder's Tongue",2},{["itemID"]=40195,"Pygmy Oil",1}                         }});
table.insert(RecipesInit,{["ID"]="0008",["itemID"]=40212,["Name"]="Potion of Wild Magic",      ["Profession"]=GetSpellInfo(2259),["Quantity"]=1,["DesiredAmount"]=20,["Mats"]={{["itemID"]=18256,"Imbued Vial",1},{["itemID"]=36905,"Lichbloom",2},   {["itemID"]=40195,"Pygmy Oil",1}                         }});
table.insert(RecipesInit,{["ID"]="0039",["itemID"]=40195,["Name"]="Pygmy Oil",                 ["Profession"]=GetSpellInfo(2259),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=40199,"Pygmy Suckerfish",1}}});
table.insert(RecipesInit,{["ID"]="0037",["itemID"]=21840,["Name"]="Bolt of Netherweave",       ["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=21877,"Netherweave Cloth",5}}});
table.insert(RecipesInit,{["ID"]="0038",["itemID"]=21842,["Name"]="Bolt of Imbued Netherweave",["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=21840,"Bolt of Netherweave",3},{["itemID"]=22445,"Arcane Dust",2}}});
table.insert(RecipesInit,{["ID"]="0009",["itemID"]=21841,["Name"]="Netherweave Bag",           ["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=21840,"Bolt of Netherweave ",4}                                   }});
table.insert(RecipesInit,{["ID"]="0010",["itemID"]=21843,["Name"]="Imbued Netherweave Bag",    ["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=21842,"Bolt of Imbued Netherweave",4},{["itemID"]=22446,"Greater Planar Essence",1},{"Netherweb Spider Silk",2}}});
table.insert(RecipesInit,{["ID"]="0011",["itemID"]=41602,["Name"]="Brilliant Spellthread",     ["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=ELIFE,"Eternal Life",4},{["itemID"]=42253,"Iceweb Spider Silk",4},{["itemID"]=43102,"Frozen Orb",1}}});
table.insert(RecipesInit,{["ID"]="0012",["itemID"]=41604,["Name"]="Sapphire Spellthread",      ["Profession"]=GetSpellInfo(3908),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=EFIRE,"Eternal Fire",4},{["itemID"]=42253,"Iceweb Spider Silk",4},{["itemID"]=43102,"Frozen Orb",1}}});
table.insert(RecipesInit,{["ID"]="0013",["itemID"]=41611,["Name"]="Eternal Belt Buckle",       ["Profession"]=GetSpellInfo(3100),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=36913,"Saronite Bar",4},{["itemID"]=EEARTH,"Eternal Earth",1},{["itemID"]=EWATER,"Eternal Water",1},{["itemID"]=ESHADOW,"Eternal Shadow",1}}});
table.insert(RecipesInit,{["ID"]="0014",["itemID"]=41976,["Name"]="Titanium Weapon Chain",     ["Profession"]=GetSpellInfo(3100),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=36913,"Saronite Bar",2},{["itemID"]=41163,"Titanium Bar",1}}});
table.insert(RecipesInit,{["ID"]="0015",["itemID"]=42500,["Name"]="Titanium Shield Spike",     ["Profession"]=GetSpellInfo(3100),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=36913,"Saronite Bar",2},{["itemID"]=41163,"Titanium Bar",1}}});
table.insert(RecipesInit,{["ID"]="0016",["itemID"]=44936,["Name"]="Titanium Plating",          ["Profession"]=GetSpellInfo(3100),["Quantity"]=1,["DesiredAmount"]=5, ["Mats"]={{["itemID"]=ESHADOW,"Eternal Shadow",4},{["itemID"]=41163,"Titanium Bar",4}}});
table.insert(RecipesInit,{["ID"]="0017",["itemID"]=44963,["Name"]="Earthen Leg Armor",         ["Profession"]=GetSpellInfo(2108),["Quantity"]=1,["DesiredAmount"]=1, ["Mats"]={{["itemID"]=44128,"Arctic Fur",2},{["itemID"]=EEARTH,"Eternal Earth",4},{["itemID"]=43102,"Frozen Orb",1}}});
table.insert(RecipesInit,{["ID"]="0018",["itemID"]=38373,["Name"]="Frosthide Leg Armor",       ["Profession"]=GetSpellInfo(2108),["Quantity"]=1,["DesiredAmount"]=1, ["Mats"]={{["itemID"]=44128,"Arctic Fur",2},{["itemID"]=38558,"Nerubian Chitin",2},{["itemID"]=43102,"Frozen Orb",1}}});
table.insert(RecipesInit,{["ID"]="0019",["itemID"]=38374,["Name"]="Icescale Leg Armor",        ["Profession"]=GetSpellInfo(2108),["Quantity"]=1,["DesiredAmount"]=1, ["Mats"]={{["itemID"]=44128,"Arctic Fur",2},{["itemID"]=38557,"Icy Dragonscale",2},{["itemID"]=43102,"Frozen Orb",1}}});
table.insert(RecipesInit,{["ID"]="0020",["itemID"]=42546,["Name"]="Mana Injector Kit",         ["Profession"]=GetSpellInfo(4036),["Quantity"]=5,["DesiredAmount"]=20,["Mats"]={{["itemID"]=36913,"Saronite Bar",12},{["itemID"]=CWATER,"Crystallized Water",2}}});
table.insert(RecipesInit,{["ID"]="0021",["itemID"]=43015,["Name"]="Fish Feast",                ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=41806,"Mussleback Sculpin",2},{["itemID"]=41809,"Glacial Salmon",2},{["itemID"]=41813,"Nettlefish",2},{["itemID"]=43007,"Northern Spices",1}}});
table.insert(RecipesInit,{["ID"]="0022",["itemID"]=34753,["Name"]="Great Feast",               ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=34736,"Chunk o' Mammoth",1},{["itemID"]=43009,"Shoveltusk Flank",1},{["itemID"]=43010,"Worm Meat",1},{["itemID"]=43013,"Chilled Meat",2}}});
table.insert(RecipesInit,{["ID"]="0023",["itemID"]=34767,["Name"]="Firecracker Salmon",        ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=41809,"Glacial Salmon",1},{["itemID"]=43007,"Northern Spices",1}}});
table.insert(RecipesInit,{["ID"]="0024",["itemID"]=34755,["Name"]="Tender Shoveltusk Steak",   ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=43009,"Shoveltusk Flank",2},{["itemID"]=43007,"Northern Spices",1}}});
table.insert(RecipesInit,{["ID"]="0025",["itemID"]=43000,["Name"]="Dragonfin Filet",           ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=41807,"Dragonfin Angelfish",1},{["itemID"]=43007,"Northern Spices",1}}});
table.insert(RecipesInit,{["ID"]="0026",["itemID"]=42996,["Name"]="Snapper Extreme",           ["Profession"]=GetSpellInfo(2550),["Quantity"]=1,["DesiredAmount"]=10,["Mats"]={{["itemID"]=41808,"Bonescale Snapper",3},{["itemID"]=43007,"Northern Spices",1}}});

table.insert(RecipesInit,{
                    ["DesiredAmount"] = 1,
                    ["Quantity"] = 1,
                    ["Name"] = "Eternal Life",
                    ["Profession"] = "Misc",
                    ["ID"] = "0027",
                    ["itemID"] = ELIFE,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = CLIFE,
                            "Crystallized Life", -- [1]
                            "10", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 1,
                    ["Quantity"] = 1,
                    ["Name"] = "Eternal Fire",
                    ["Profession"] = "Misc",
                    ["ID"] = "0028",
                    ["itemID"] = EFIRE,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = CFIRE,
                            "Crystallized Fire", -- [1]
                            "10", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 3,
                    ["Quantity"] = 1,
                    ["Name"] = "Eternal Shadow",
                    ["Profession"] = "Misc",
                    ["ID"] = "0029",
                    ["itemID"] = ESHADOW,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = CSHADOW,
                            "Crystallized Shadow", -- [1]
                            "10", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 1,
                    ["Mats"] = {
                        {
                            ["itemID"] = CEARTH,
                            "Crystallized Earth", -- [1]
                            "10", -- [2]
                        }, -- [1]
                    },
                    ["Name"] = "Eternal Earth",
                    ["Profession"] = "Misc",
                    ["ID"] = "0030",
                    ["itemID"] = EEARTH,
                    ["StaticCostPerItem"] = 0,
                    ["Quantity"] = "1",
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = "1",
                    ["Quantity"] = "1",
                    ["Name"] = "Eternal Air",
                    ["Profession"] = "Misc",
                    ["ID"] = "0031",
                    ["itemID"] = EAIR,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = CAIR,
                            "Crystallized Air", -- [1]
                            "10", -- [2]
                        }, -- [1]
                    },
                });

table.insert(RecipesInit,{
                    ["DesiredAmount"] = "10",
                    ["Quantity"] = "10",
                    ["Name"] = "Crystallized Life",
                    ["Profession"] = "Misc",
                    ["ID"] = "0032",
                    ["itemID"] = CLIFE,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = ELIFE,
                            "Eternal Life", -- [1]
                            "1", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 10,
                    ["Quantity"] = "10",
                    ["Name"] = "Crystallized Fire",
                    ["Profession"] = "Misc",
                    ["ID"] = "0033",
                    ["itemID"] = CFIRE,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = EFIRE,
                            "Eternal Fire", -- [1]
                            "1", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 10,
                    ["Quantity"] = "10",
                    ["Name"] = "Crystallized Shadow",
                    ["Profession"] = "Misc",
                    ["ID"] = "0034",
                    ["itemID"] = CSHADOW,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = ESHADOW,
                            "Eternal Shadow", -- [1]
                            "1", -- [2]
                        }, -- [1]
                    },
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = 10,
                    ["Mats"] = {
                        {
                            ["itemID"] = EEARTH,
                            "Eternal Earth", -- [1]
                            "1", -- [2]
                        }, -- [1]
                    },
                    ["Name"] = "Crystallized Earth",
                    ["Profession"] = "Misc",
                    ["ID"] = "0035",
                    ["itemID"] = CEARTH,
                    ["StaticCostPerItem"] = 0,
                    ["Quantity"] = "10",
                });
table.insert(RecipesInit,{
                    ["DesiredAmount"] = "10",
                    ["Quantity"] = "10",
                    ["Name"] = "Crystallized Air",
                    ["Profession"] = "Misc",
                    ["ID"] = "0036",
                    ["itemID"] = CAIR,
                    ["StaticCostPerItem"] = 0,
                    ["Mats"] = {
                        {
                            ["itemID"] = EAIR,
                            "Eternal Air", -- [1]
                            "1", -- [2]
                        }, -- [1]
                    },
                });

local pairing = {};
-- example :
-- pairing["Enchant 2H Weapon - Agility"] = "Scroll of Enchant 2H Weapon - Agility"; 38896
pairing["27837"] =  -- Enchant 2H Weapon - Agility
38896; -- Scroll of Enchant 2H Weapon - Agility
pairing["13937"] =  -- Enchant 2H Weapon - Greater Impact
38845; -- Scroll of Enchant 2H Weapon - Greater Impact
pairing["44630"] =  -- Enchant 2H Weapon - Greater Savagery
38992; -- Scroll of Enchant 2H Weapon - Greater Savagery
pairing["13695"] =  -- Enchant 2H Weapon - Impact
38822; -- Scroll of Enchant 2H Weapon - Impact
pairing["13529"] =  -- Enchant 2H Weapon - Lesser Impact
38796; -- Scroll of Enchant 2H Weapon - Lesser Impact
pairing["7793"] =  -- Enchant 2H Weapon - Lesser Intellect
38781; -- Scroll of Enchant 2H Weapon - Lesser Intellect
pairing["13380"] =  -- Enchant 2H Weapon - Lesser Spirit
38788; -- Scroll of Enchant 2H Weapon - Lesser Spirit
pairing["27977"] =  -- Enchant 2H Weapon - Major Agility
38922; -- Scroll of Enchant 2H Weapon - Major Agility
pairing["20036"] =  -- Enchant 2H Weapon - Major Intellect
38875; -- Scroll of Enchant 2H Weapon - Major Intellect
pairing["20035"] =  -- Enchant 2H Weapon - Major Spirit
38874; -- Scroll of Enchant 2H Weapon - Major Spirit
pairing["60691"] =  -- Enchant 2H Weapon - Massacre
44463; -- Scroll of Enchant 2H Weapon - Massacre
pairing["7745"] =  -- Enchant 2H Weapon - Minor Impact
38772; -- Scroll of Enchant 2H Weapon - Minor Impact
pairing["27971"] =  -- Enchant 2H Weapon - Savagery
38919; -- Scroll of Enchant 2H Weapon - Savagery
pairing["44595"] =  -- Enchant 2H Weapon - Scourgebane
38981; -- Scroll of Enchant 2H Weapon - Scourgebane
pairing["20030"] =  -- Enchant 2H Weapon - Superior Impact
38869; -- Scroll of Enchant 2H Weapon - Superior Impact



pairing["27951"] =  -- Enchant Boots - Dexterity
37603; -- Scroll of Enchant Boots - Dexterity
pairing["7863"] =  -- Enchant Boots - Minor Stamina
38785; -- Scroll of Enchant Boots - Minor Stamina
pairing["7867"] =  -- Enchant Boots - Minor Agility
38786; -- Scroll of Enchant Boots - Minor Agility
pairing["13637"] =  -- Enchant Boots - Lesser Agility
38807; -- Scroll of Enchant Boots - Lesser Agility
pairing["13644"] =  -- Enchant Boots - Lesser Stamina
38810; -- Scroll of Enchant Boots - Lesser Stamina
pairing["13687"] =  -- Enchant Boots - Lesser Spirit
38819; -- Scroll of Enchant Boots - Lesser Spirit
pairing["13836"] =  -- Enchant Boots - Stamina
38830; -- Scroll of Enchant Boots - Stamina
pairing["13890"] =  -- Enchant Boots - Minor Speed
38837; -- Scroll of Enchant Boots - Minor Speed
pairing["13935"] =  -- Enchant Boots - Agility
38844; -- Scroll of Enchant Boots - Agility
pairing["20020"] =  -- Enchant Boots - Greater Stamina
38862; -- Scroll of Enchant Boots - Greater Stamina
pairing["20023"] =  -- Enchant Boots - Greater Agility
38863; -- Scroll of Enchant Boots - Greater Agility
pairing["20024"] =  -- Enchant Boots - Spirit
38864; -- Scroll of Enchant Boots - Spirit
pairing["27948"] =  -- Enchant Boots - Vitality
38908; -- Scroll of Enchant Boots - Vitality
pairing["27950"] =  -- Enchant Boots - Fortitude
38909; -- Scroll of Enchant Boots - Fortitude
pairing["27954"] =  -- Enchant Boots - Surefooted
38910; -- Scroll of Enchant Boots - Surefooted
pairing["34007"] =  -- Enchant Boots - Cat's Swiftness
38943; -- Scroll of Enchant Boots - Cat's Swiftness
pairing["34008"] =  -- Enchant Boots - Boar's Speed
38944; -- Scroll of Enchant Boots - Boar's Speed
pairing["44508"] =  -- Enchant Boots - Greater Spirit
38961; -- Scroll of Enchant Boots - Greater Spirit
pairing["44528"] =  -- Enchant Boots - Greater Fortitude
38966; -- Scroll of Enchant Boots - Greater Fortitude
pairing["44584"] =  -- Enchant Boots - Greater Vitality
38974; -- Scroll of Enchant Boots - Greater Vitality
pairing["44589"] =  -- Enchant Boots - Superior Agility
38976; -- Scroll of Enchant Boots - Superior Agility
pairing["60623"] =  -- Enchant Boots - Icewalker
38986; -- Scroll of Enchant Boots - Icewalker
pairing["47901"] =  -- Enchant Boots - Tuskarr's Vitality
39006; -- Scroll of Enchant Boots - Tuskarr's Vitality
pairing["60606"] =  -- Enchant Boots - Assault
44449; -- Scroll of Enchant Boots - Assault
pairing["60763"] =  -- Enchant Boots - Greater Assault
44469; -- Scroll of Enchant Boots - Greater Assault
pairing["63746"] =  -- Enchant Boots - Lesser Accuracy
45628; -- Scroll of Enchant Boots - Lesser Accuracy




pairing["34002"] =  -- Enchant Bracer - Assault
38938; -- Scroll of Enchant Bracer - Assault
pairing["27899"] =  -- Enchant Bracer - Brawn
38897; -- Scroll of Enchant Bracer - Brawn
pairing["13931"] =  -- Enchant Bracer - Deflection
38842; -- Scroll of Enchant Bracer - Deflection
pairing["44598"] =  -- Enchant Bracers - Expertise
38984; -- Scroll of Enchant Bracer - Expertise
pairing["27914"] =  -- Enchant Bracer - Fortitude
38902; -- Scroll of Enchant Bracer - Fortitude
pairing["20008"] =  -- Enchant Bracer - Greater Intellect
38852; -- Scroll of Enchant Bracer - Greater Intellect
pairing["13846"] =  -- Enchant Bracer - Greater Spirit
38832; -- Scroll of Enchant Bracer - Greater Spirit
pairing["13945"] =  -- Enchant Bracer - Greater Stamina
38849; -- Scroll of Enchant Bracer - Greater Stamina
pairing["13939"] =  -- Enchant Bracer - Greater Strength
38846; -- Scroll of Enchant Bracer - Greater Strength
pairing["23802"] =  -- Enchant Bracer - Healing Power
38882; -- Scroll of Enchant Bracer - Healing Power
pairing["13822"] =  -- Enchant Bracer - Intellect
38829; -- Scroll of Enchant Bracer - Intellect
pairing["13646"] =  -- Enchant Bracer - Lesser Deflection
38811; -- Scroll of Enchant Bracer - Lesser Deflection
pairing["13622"] =  -- Enchant Bracer - Lesser Intellect
38803; -- Scroll of Enchant Bracer - Lesser Intellect
pairing["7859"] =  -- Enchant Bracer - Lesser Spirit
38783; -- Scroll of Enchant Bracer - Lesser Spirit
pairing["13501"] =  -- Enchant Bracer - Lesser Stamina
38793; -- Scroll of Enchant Bracer - Lesser Stamina
pairing["13536"] =  -- Enchant Bracer - Lesser Strength
38797; -- Scroll of Enchant Bracer - Lesser Strength
pairing["27906"] =  -- Enchant Bracer - Major Defense
38899; -- Scroll of Enchant Bracer - Major Defense
pairing["34001"] =  -- Enchant Bracer - Major Intellect
38937; -- Scroll of Enchant Bracer - Major Intellect
pairing["23801"] =  -- Enchant Bracer - Mana Regeneration
38881; -- Scroll of Enchant Bracer - Mana Regeneration
pairing["7779"] =  -- Enchant Bracer - Minor Agility
38777; -- Scroll of Enchant Bracer - Minor Agility
pairing["7428"] =  -- Enchant Bracer - Minor Deflection
38768; -- Scroll of Enchant Bracer - Minor Deflection
pairing["7418"] =  -- Enchant Bracer - Minor Health
38679; -- Scroll of Enchant Bracer - Minor Health
pairing["7766"] =  -- Enchant Bracer - Minor Spirit
38774; -- Scroll of Enchant Bracer - Minor Spirit
pairing["7457"] =  -- Enchant Bracer - Minor Stamina
38771; -- Scroll of Enchant Bracer - Minor Stamina
pairing["7782"] =  -- Enchant Bracer - Minor Strength
38778; -- Scroll of Enchant Bracer - Minor Strength
pairing["27913"] =  -- Enchant Bracer - Restore Mana Prime
38901; -- Scroll of Enchant Bracer - Restore Mana Prime
pairing["27917"] =  -- Enchant Bracer - Spellpower
38903; -- Scroll of Enchant Bracer - Spellpower
pairing["13642"] =  -- Enchant Bracer - Spirit
38809; -- Scroll of Enchant Bracer - Spirit
pairing["13648"] =  -- Enchant Bracer - Stamina
38812; -- Scroll of Enchant Bracer - Stamina
pairing["27905"] =  -- Enchant Bracer - Stats
38898; -- Scroll of Enchant Bracer - Stats
pairing["13661"] =  -- Enchant Bracer - Strength
38817; -- Scroll of Enchant Bracer - Strength
pairing["27911"] =  -- Enchant Bracer - Superior Healing
38900; -- Scroll of Enchant Bracer - Superior Healing
pairing["20009"] =  -- Enchant Bracer - Superior Spirit
38853; -- Scroll of Enchant Bracer - Superior Spirit
pairing["20011"] =  -- Enchant Bracer - Superior Stamina
38855; -- Scroll of Enchant Bracer - Superior Stamina
pairing["20010"] =  -- Enchant Bracer - Superior Strength
38854; -- Scroll of Enchant Bracer - Superior Strength
pairing["44575"] = -- Enchant Bracers - Greater Assault
44815; -- Scroll of Enchant Bracers - Greater Assault
pairing["44635"] = -- Enchant Bracers - Greater Spellpower
38997; -- Scroll of Enchant Bracers - Greater Spellpower
pairing["44616"] = -- Enchant Bracers - Greater Stats
38987; -- Scroll of Enchant Bracers - Greater Stats
pairing["44593"] = -- Enchant Bracers - Major Spirit
38980; -- Scroll of Enchant Bracers - Major Spirit
pairing["62256"] = -- Enchant Bracers - Major Stamina
44947; -- Scroll of Enchant Bracer - Major Stamina
pairing["60616"] = -- Enchant Bracers - Striking
38971; -- Scroll of Enchant Bracers - Striking
pairing["60767"] = -- Enchant Bracers - Superior Spellpower
44470; -- Scroll of Enchant Bracer - Superior Spellpower

-- Creating tradeskill not found
--38996; -- Scroll of Enchant Bracers - Major Healing

pairing["44555"] =  -- Enchant Bracers - Exceptional Intellect
38968; -- Scroll of Enchant Bracers - Exceptional Intellect




pairing["46594"] =  -- Enchant Chest - Defense
38999; -- Scroll of Enchant Chest - Defense
pairing["27957"] =  -- Enchant Chest - Exceptional Health
38911; -- Scroll of Enchant Chest - Exceptional Health
pairing["27958"] =  -- Enchant Chest - Exceptional Mana
38912; -- Scroll of Enchant Chest - Exceptional Mana
pairing["44588"] =  -- Enchant Chest - Exceptional Resilience
38975; -- Scroll of Enchant Chest - Exceptional Resilience
pairing["27960"] =  -- Enchant Chest - Exceptional Stats
38913; -- Scroll of Enchant Chest - Exceptional Stats
pairing["47766"] =  -- Enchant Chest - Greater Defense
39002; -- Scroll of Enchant Chest - Greater Defense
pairing["13640"] =  -- Enchant Chest - Greater Health
38808; -- Scroll of Enchant Chest - Greater Health
pairing["13663"] =  -- Enchant Chest - Greater Mana
38818; -- Scroll of Enchant Chest - Greater Mana
pairing["44509"] =  -- Enchant Chest - Greater Mana Restoration
38962; -- Scroll of Enchant Chest - Greater Mana Restoration
pairing["20025"] =  -- Enchant Chest - Greater Stats
38865; -- Scroll of Enchant Chest - Greater Stats
pairing["7857"] =  -- Enchant Chest - Health
38782; -- Scroll of Enchant Chest - Health
pairing["13538"] =  -- Enchant Chest - Lesser Absorption
38798; -- Scroll of Enchant Chest - Lesser Absorption
pairing["7748"] =  -- Enchant Chest - Lesser Health
38773; -- Scroll of Enchant Chest - Lesser Health
pairing["7776"] =  -- Enchant Chest - Lesser Mana
38776; -- Scroll of Enchant Chest - Lesser Mana
pairing["13700"] =  -- Enchant Chest - Lesser Stats
38824; -- Scroll of Enchant Chest - Lesser Stats
pairing["20026"] =  -- Enchant Chest - Major Health
38866; -- Scroll of Enchant Chest - Major Health
pairing["20028"] =  -- Enchant Chest - Major Mana
38867; -- Scroll of Enchant Chest - Major Mana
pairing["33992"] =  -- Enchant Chest - Major Resilience
38930; -- Scroll of Enchant Chest - Major Resilience
pairing["33990"] =  -- Enchant Chest - Major Spirit
38928; -- Scroll of Enchant Chest - Major Spirit
pairing["13607"] =  -- Enchant Chest - Mana
38799; -- Scroll of Enchant Chest - Mana
pairing["44492"] =  -- Enchant Chest - Mighty Health
38955; -- Scroll of Enchant Chest - Mighty Health
pairing["7426"] =  -- Enchant Chest - Minor Absorption
38767; -- Scroll of Enchant Chest - Minor Absorption
pairing["7420"] =  -- Enchant Chest - Minor Health
38766; -- Scroll of Enchant Chest - Minor Health
pairing["7443"] =  -- Enchant Chest - Minor Mana
38769; -- Scroll of Enchant Chest - Minor Mana
pairing["13626"] =  -- Enchant Chest - Minor Stats
38804; -- Scroll of Enchant Chest - Minor Stats
pairing["60692"] =  -- Enchant Chest - Powerful Stats
44465; -- Scroll of Enchant Chest - Powerful Stats
pairing["33991"] =  -- Enchant Chest - Restore Mana Prime
38929; -- Scroll of Enchant Chest - Restore Mana Prime
pairing["13941"] =  -- Enchant Chest - Stats
38847; -- Scroll of Enchant Chest - Stats
pairing["47900"] =  -- Enchant Chest - Super Health
39005; -- Scroll of Enchant Chest - Super Health
pairing["44623"] =  -- Enchant Chest - Super Stats
38989; -- Scroll of Enchant Chest - Super Stats
pairing["13858"] =  -- Enchant Chest - Superior Health
38833; -- Scroll of Enchant Chest - Superior Health
pairing["13917"] =  -- Enchant Chest - Superior Mana
38841; -- Scroll of Enchant Chest - Superior Mana




pairing["13635"] =  -- Enchant Cloak - Defense
38806; -- Scroll of Enchant Cloak - Defense
pairing["25086"] =  -- Enchant Cloak - Dodge
38895; -- Scroll of Enchant Cloak - Dodge
pairing["13657"] =  -- Enchant Cloak - Fire Resistance
38815; -- Scroll of Enchant Cloak - Fire Resistance
pairing["34004"] =  -- Enchant Cloak - Greater Agility
38940; -- Scroll of Enchant Cloak - Greater Agility
pairing["34005"] =  -- Enchant Cloak - Greater Arcane Resistance
38941; -- Scroll of Enchant Cloak - Greater Arcane Resistance
pairing["13746"] =  -- Enchant Cloak - Greater Defense
38825; -- Scroll of Enchant Cloak - Greater Defense
pairing["25081"] =  -- Enchant Cloak - Greater Fire Resistance
38891; -- Scroll of Enchant Cloak - Greater Fire Resistance
pairing["25082"] =  -- Enchant Cloak - Greater Nature Resistance
38892; -- Scroll of Enchant Cloak - Greater Nature Resistance
pairing["20014"] =  -- Enchant Cloak - Greater Resistance
38858; -- Scroll of Enchant Cloak - Greater Resistance
pairing["34006"] =  -- Enchant Cloak - Greater Shadow Resistance
38942; -- Scroll of Enchant Cloak - Greater Shadow Resistance
pairing["47898"] =  -- Enchant Cloak - Greater Speed
39003; -- Scroll of Enchant Cloak - Haste
pairing["13882"] =  -- Enchant Cloak - Lesser Agility
38835; -- Scroll of Enchant Cloak - Lesser Agility
pairing["7861"] =  -- Enchant Cloak - Lesser Fire Resistance
38784; -- Scroll of Enchant Cloak - Lesser Fire Resistance
pairing["13421"] =  -- Enchant Cloak - Lesser Protection
38790; -- Scroll of Enchant Cloak - Lesser Protection
pairing["13522"] =  -- Enchant Cloak - Lesser Shadow Resistance
38795; -- Scroll of Enchant Cloak - Lesser Shadow Resistance
pairing["60663"] =  -- Enchant Cloak - Major Agility
44457; -- Scroll of Enchant Cloak - Major Agility
pairing["27961"] =  -- Enchant Cloak - Major Armor
38914; -- Scroll of Enchant Cloak - Major Armor
pairing["27962"] =  -- Enchant Cloak - Major Resistance
38915; -- Scroll of Enchant Cloak - Major Resistance
pairing["47672"] =  -- Enchant Cloak - Mighty Armor
39001; -- Scroll of Enchant Cloak - Mighty Armor
pairing["13419"] =  -- Enchant Cloak - Minor Agility
38789; -- Scroll of Enchant Cloak - Minor Agility
pairing["7771"] =  -- Enchant Cloak - Minor Protection
38775; -- Scroll of Enchant Cloak - Minor Protection
pairing["7454"] =  -- Enchant Cloak - Minor Resistance
38770; -- Scroll of Enchant Cloak - Minor Resistance
pairing["13794"] =  -- Enchant Cloak - Resistance
38826; -- Scroll of Enchant Cloak - Resistance
pairing["44631"] =  -- Enchant Cloak - Shadow Armor
38993; -- Scroll of Enchant Cloak - Shadow Armor
pairing["60609"] =  -- Enchant Cloak - Speed
44456; -- Scroll of Enchant Cloak - Speed
pairing["34003"] =  -- Enchant Cloak - Spell Penetration
38939; -- Scroll of Enchant Cloak - Spell Penetration
pairing["44582"] =  -- Enchant Cloak - Spell Piercing
38973; -- Scroll of Enchant Cloak - Spell Piercing
pairing["25083"] =  -- Enchant Cloak - Stealth
38893; -- Scroll of Enchant Cloak - Stealth
pairing["47051"] =  -- Enchant Cloak - Steelweave
39000; -- Scroll of Enchant Cloak - Steelweave
pairing["25084"] =  -- Enchant Cloak - Subtlety
38894; -- Scroll of Enchant Cloak - Subtlety
pairing["44500"] =  -- Enchant Cloak - Superior Agility
38959; -- Scroll of Enchant Cloak - Superior Agility
pairing["44596"] =  -- Enchant Cloak - Superior Arcane Resistance
38982; -- Scroll of Enchant Cloak - Superior Arcane Resistance
pairing["20015"] =  -- Enchant Cloak - Superior Defense
38859; -- Scroll of Enchant Cloak - Superior Defense
pairing["44556"] =  -- Enchant Cloak - Superior Fire Resistance
38969; -- Scroll of Enchant Cloak - Superior Fire Resistance
pairing["44483"] =  -- Enchant Cloak - Superior Frost Resistance
38950; -- Scroll of Enchant Cloak - Superior Frost Resistance
pairing["44494"] =  -- Enchant Cloak - Superior Nature Resistance
38956; -- Scroll of Enchant Cloak - Superior Nature Resistance
pairing["44590"] =  -- Enchant Cloak - Superior Shadow Resistance
38977; -- Scroll of Enchant Cloak - Superior Shadow Resistance
pairing["44591"] =  -- Enchant Cloak - Titanweave
38978; -- Scroll of Enchant Cloak - Titanweave
pairing["47899"] =  -- Enchant Cloak - Wisdom
39004; -- Scroll of Enchant Cloak - Wisdom



pairing["13868"] =  -- Enchant Gloves - Advanced Herbalism
38834; -- Scroll of Enchant Gloves - Advanced Herbalism
pairing["13841"] =  -- Enchant Gloves - Advanced Mining
38831; -- Scroll of Enchant Gloves - Advanced Mining
pairing["13815"] =  -- Enchant Gloves - Agility
38827; -- Scroll of Enchant Gloves - Agility
pairing["44625"] =  -- Enchant Gloves - Armsman
38990; -- Scroll of Enchant Gloves - Armsman
pairing["33996"] =  -- Enchant Gloves - Assault
38934; -- Scroll of Enchant Gloves - Assault
pairing["33993"] =  -- Enchant Gloves - Blasting
38931; -- Scroll of Enchant Gloves - Blasting
pairing["60668"] =  -- Enchant Gloves - Crusher
44458; -- Scroll of Enchant Gloves - Crusher

-- Creating tradeskill not found
--38970; -- Scroll of Enchant Gloves - Exceptional Healing

pairing["44592"] =  -- Enchant Gloves - Exceptional Spellpower
38979; -- Scroll of Enchant Gloves - Exceptional Spellpower
pairing["44484"] =  -- Enchant Gloves - Expertise
38951; -- Scroll of Enchant Gloves - Expertise
pairing["25078"] =  -- Enchant Gloves - Fire Power
38888; -- Scroll of Enchant Gloves - Fire Power
pairing["13620"] =  -- Enchant Gloves - Fishing
38802; -- Scroll of Enchant Gloves - Fishing
pairing["25074"] =  -- Enchant Gloves - Frost Power
38887; -- Scroll of Enchant Gloves - Frost Power
pairing["44506"] =  -- Enchant Gloves - Gatherer
38960; -- Scroll of Enchant Gloves - Gatherer
pairing["20012"] =  -- Enchant Gloves - Greater Agility
38856; -- Scroll of Enchant Gloves - Greater Agility
pairing["44513"] =  -- Enchant Gloves - Greater Assault
38964; -- Scroll of Enchant Gloves - Greater Assault
pairing["44612"] =  -- Enchant Gloves - Greater Blasting
38985; -- Scroll of Enchant Gloves - Greater Blasting
pairing["20013"] =  -- Enchant Gloves - Greater Strength
38857; -- Scroll of Enchant Gloves - Greater Strength
pairing["25079"] =  -- Enchant Gloves - Healing Power
38889; -- Scroll of Enchant Gloves - Healing Power
pairing["13617"] =  -- Enchant Gloves - Herbalism
38801; -- Scroll of Enchant Gloves - Herbalism
pairing["44529"] =  -- Enchant Gloves - Major Agility
38967; -- Scroll of Enchant Gloves - Major Agility
pairing["33999"] =  -- Enchant Gloves - Major Healing
38936; -- Scroll of Enchant Gloves - Major Healing
pairing["33997"] =  -- Enchant Gloves - Major Spellpower
38935; -- Scroll of Enchant Gloves - Major Spellpower
pairing["33995"] =  -- Enchant Gloves - Major Strength
38933; -- Scroll of Enchant Gloves - Major Strength
pairing["13612"] =  -- Enchant Gloves - Mining
38800; -- Scroll of Enchant Gloves - Mining
pairing["13948"] =  -- Enchant Gloves - Minor Haste
38851; -- Scroll of Enchant Gloves - Minor Haste
pairing["33994"] =  -- Enchant Gloves - Precise Strikes
38932; -- Scroll of Enchant Gloves - Precise Strikes
pairing["44488"] =  -- Enchant Gloves - Precision
38953; -- Scroll of Enchant Gloves - Precision
pairing["13947"] =  -- Enchant Gloves - Riding Skill
38850; -- Scroll of Enchant Gloves - Riding Skill
pairing["25073"] =  -- Enchant Gloves - Shadow Power
38886; -- Scroll of Enchant Gloves - Shadow Power
pairing["13698"] =  -- Enchant Gloves - Skinning
38823; -- Scroll of Enchant Gloves - Skinning
pairing["13887"] =  -- Enchant Gloves - Strength
38836; -- Scroll of Enchant Gloves - Strength
pairing["25080"] =  -- Enchant Gloves - Superior Agility
38890; -- Scroll of Enchant Gloves - Superior Agility
pairing["25072"] =  -- Enchant Gloves - Threat
38885; -- Scroll of Enchant Gloves - Threat



-- No scrolls for rings
--44645 -- Enchant Ring - Assault
--44636 -- Enchant Ring - Greater Spellpower
--27926 -- Enchant Ring - Healing Power
--27924 -- Enchant Ring - Spellpower
--59636 -- Enchant Ring - Stamina
--27927 -- Enchant Ring - Stats
--27920 -- Enchant Ring - Striking



pairing["44489"] =  -- Enchant Shield - Defense
38954; -- Scroll of Enchant Shield - Defense

-- Creating tradeskill not found
--38983 -- Scroll of Enchant Shield - Exceptional Stamina

pairing["13933"] =  -- Enchant Shield - Frost Resistance
38843; -- Scroll of Enchant Shield - Frost Resistance
pairing["60653"] =  -- Enchant Shield - Greater Intellect
44455; -- Scroll of Enchant Shield - Greater Intellect
pairing["13905"] =  -- Enchant Shield - Greater Spirit
38839; -- Scroll of Enchant Shield - Greater Spirit
pairing["20017"] =  -- Enchant Shield - Greater Stamina
38861; -- Scroll of Enchant Shield - Greater Stamina
pairing["27945"] =  -- Enchant Shield - Intellect
38905; -- Scroll of Enchant Shield - Intellect
pairing["13689"] =  -- Enchant Shield - Lesser Block
38820; -- Scroll of Enchant Shield - Lesser Block
pairing["13464"] =  -- Enchant Shield - Lesser Protection
38791; -- Scroll of Enchant Shield - Lesser Protection
pairing["13485"] =  -- Enchant Shield - Lesser Spirit
38792; -- Scroll of Enchant Shield - Lesser Spirit
pairing["13631"] =  -- Enchant Shield - Lesser Stamina
38805; -- Scroll of Enchant Shield - Lesser Stamina
pairing["34009"] =  -- Enchant Shield - Major Stamina
38945; -- Scroll of Enchant Shield - Major Stamina
pairing["13378"] =  -- Enchant Shield - Minor Stamina
38787; -- Scroll of Enchant Shield - Minor Stamina
pairing["44383"] =  -- Enchant Shield - Resilience
38949; -- Scroll of Enchant Shield - Resilience
pairing["27947"] =  -- Enchant Shield - Resistance
38907; -- Scroll of Enchant Shield - Resistance
pairing["27946"] =  -- Enchant Shield - Shield Block
38906; -- Scroll of Enchant Shield - Shield Block
pairing["13659"] =  -- Enchant Shield - Spirit
38816; -- Scroll of Enchant Shield - Spirit
pairing["13817"] =  -- Enchant Shield - Stamina
38828; -- Scroll of Enchant Shield - Stamina
pairing["27944"] =  -- Enchant Shield - Tough Shield
38904; -- Scroll of Enchant Shield - Tough Shield
pairing["20016"] =  -- Enchant Shield - Vitality
38860; -- Scroll of Enchant Shield - Vitality



pairing["62948"] =  -- Enchant Staff - Greater Spellpower
45056; -- Scroll of Enchant Staff - Greater Spellpower
pairing["62959"] =  -- Enchant Staff - Spellpower
45060; -- Scroll of Enchant Staff - Spellpower




pairing["59619"] =  -- Enchant Weapon - Accuracy
44497; -- Scroll of Enchant Weapon - Accuracy
pairing["23800"] =  -- Enchant Weapon - Agility
38880; -- Scroll of Enchant Weapon - Agility
pairing["28004"] =  -- Enchant Weapon - Battlemaster
38927; -- Scroll of Enchant Weapon - Battlemaster
pairing["59621"] =  -- Enchant Weapon - Berserking
44493; -- Scroll of Enchant Weapon - Berserking
pairing["59625"] =  -- Enchant Weapon - Black Magic
43987; -- Scroll of Enchant Weapon - Black Magic
pairing["64441"] =  -- Enchant Weapon - Blade Ward
46026; -- Scroll of Enchant Weapon - Blade Ward
pairing["64579"] =  -- Enchant Weapon - Blood Draining
46098; -- Scroll of Enchant Weapon - Blood Draining
pairing["20034"] =  -- Enchant Weapon - Crusader
38873; -- Scroll of Enchant Weapon - Crusader
pairing["46578"] =  -- Enchant Weapon - Deathfrost
38998; -- Scroll of Enchant Weapon - Deathfrost
pairing["13915"] =  -- Enchant Weapon - Demonslaying
38840; -- Scroll of Enchant Weapon - Demonslaying
pairing["44633"] =  -- Enchant Weapon - Exceptional Agility
38995; -- Scroll of Enchant Weapon - Exceptional Agility
pairing["44629"] =  -- Enchant Weapon - Exceptional Spellpower
38991; -- Scroll of Enchant Weapon - Exceptional Spellpower
pairing["44510"] =  -- Enchant Weapon - Exceptional Spirit
38963; -- Scroll of Enchant Weapon - Exceptional Spirit
pairing["42974"] =  -- Enchant Weapon - Executioner
38948; -- Scroll of Enchant Weapon - Executioner
pairing["13898"] =  -- Enchant Weapon - Fiery Weapon
38838; -- Scroll of Enchant Weapon - Fiery Weapon
pairing["44621"] =  -- Enchant Weapon - Giant Slayer
38988; -- Scroll of Enchant Weapon - Giant Slayer
pairing["42620"] =  -- Enchant Weapon - Greater Agility
38947; -- Scroll of Enchant Weapon - Greater Agility
pairing["60621"] =  -- Enchant Weapon - Greater Potency
44453; -- Scroll of Enchant Weapon - Greater Potency
pairing["13943"] =  -- Enchant Weapon - Greater Striking
38848; -- Scroll of Enchant Weapon - Greater Striking
pairing["22750"] =  -- Enchant Weapon - Healing Power
38878; -- Scroll of Enchant Weapon - Healing Power
pairing["44524"] =  -- Enchant Weapon - Icebreaker
38965; -- Scroll of Enchant Weapon - Icebreaker
pairing["20029"] =  -- Enchant Weapon - Icy Chill
38868; -- Scroll of Enchant Weapon - Icy Chill
pairing["13653"] =  -- Enchant Weapon - Lesser Beastslayer
38813; -- Scroll of Enchant Weapon - Lesser Beastslayer
pairing["13655"] =  -- Enchant Weapon - Lesser Elemental Slayer
38814; -- Scroll of Enchant Weapon - Lesser Elemental Slayer
pairing["13503"] =  -- Enchant Weapon - Lesser Striking
38794; -- Scroll of Enchant Weapon - Lesser Striking
pairing["20032"] =  -- Enchant Weapon - Lifestealing
38871; -- Scroll of Enchant Weapon - Lifestealing
pairing["44576"] =  -- Enchant Weapon - Lifeward
38972; -- Scroll of Enchant Weapon - Lifeward
pairing["34010"] =  -- Enchant Weapon - Major Healing
38946; -- Scroll of Enchant Weapon - Major Healing
pairing["27968"] =  -- Enchant Weapon - Major Intellect
38918; -- Scroll of Enchant Weapon - Major Intellect
pairing["27975"] =  -- Enchant Weapon - Major Spellpower
38921; -- Scroll of Enchant Weapon - Major Spellpower
pairing["27967"] =  -- Enchant Weapon - Major Striking
38917; -- Scroll of Enchant Weapon - Major Striking
pairing["23804"] =  -- Enchant Weapon - Mighty Intellect
38884; -- Scroll of Enchant Weapon - Mighty Intellect
pairing["60714"] =  -- Enchant Weapon - Mighty Spellpower
44467; -- Scroll of Enchant Weapon - Mighty Spellpower
pairing["23803"] =  -- Enchant Weapon - Mighty Spirit
38883; -- Scroll of Enchant Weapon - Mighty Spirit
pairing["7786"] =  -- Enchant Weapon - Minor Beastslayer
38779; -- Scroll of Enchant Weapon - Minor Beastslayer
pairing["7788"] =  -- Enchant Weapon - Minor Striking
38780; -- Scroll of Enchant Weapon - Minor Striking
pairing["27984"] =  -- Enchant Weapon - Mongoose
38925; -- Scroll of Enchant Weapon - Mongoose
pairing["27972"] =  -- Enchant Weapon - Potency
38920; -- Scroll of Enchant Weapon - Potency
pairing["27982"] =  -- Enchant Weapon - Soulfrost
38924; -- Scroll of Enchant Weapon - Soulfrost
pairing["22749"] =  -- Enchant Weapon - Spellpower
38877; -- Scroll of Enchant Weapon - Spellpower
pairing["28003"] =  -- Enchant Weapon - Spellsurge
38926; -- Scroll of Enchant Weapon - Spellsurge
pairing["23799"] =  -- Enchant Weapon - Strength
38879; -- Scroll of Enchant Weapon - Strength
pairing["13693"] =  -- Enchant Weapon - Striking
38821; -- Scroll of Enchant Weapon - Striking
pairing["27981"] =  -- Enchant Weapon - Sunfire
38923; -- Scroll of Enchant Weapon - Sunfire
pairing["60707"] =  -- Enchant Weapon - Superior Potency
44466; -- Scroll of Enchant Weapon - Superior Potency
pairing["20031"] =  -- Enchant Weapon - Superior Striking
38870; -- Scroll of Enchant Weapon - Superior Striking
pairing["62257"] =  -- Enchant Weapon - Titanguard
44946; -- Scroll of Enchant Weapon - Titanguard
pairing["20033"] =  -- Enchant Weapon - Unholy Weapon
38872; -- Scroll of Enchant Weapon - Unholy Weapon
pairing["21931"] =  -- Enchant Weapon - Winter's Might
38876; -- Scroll of Enchant Weapon - Winter's Might



-- Not yet available
--38994 -- Scroll of Enchant Weapon - Exceptional Healing
--38958 -- Scroll of Enchant Weapon - Exceptional Intellect
--38957 -- Scroll of Enchant Weapon - Exceptional Striking





local Recipes = nil;
local CurrentFiltering = true;
function FlaskCalc:GetRecipes()
    FlaskCalc:SetupRecipes();
    return Recipes;
end

function FlaskCalc:IsOveridden(RecipeID)
    if tonumber(RecipeID) < 1000 then
        local CustomRecipes = self.db.profile.customRecipes;
        if CustomRecipes ~= nil then
            for i = 1, getn(CustomRecipes) do
                if CustomRecipes[i].ID == RecipeID then
                    return true;
                end
            end
        end
    end
    return false;
end

function FlaskCalc:GetAllRecipes()
    self:RemoveBadEntries();

    local AllRecipes = self.db.profile.customRecipes;
    local Recipes = {};

    for i = 1, getn(AllRecipes) do
        if self.db.profile.hiddenIDs[AllRecipes[i].ID] == nil then
            table.insert(Recipes, AllRecipes[i]);
        end
    end

    return Recipes;
end

function FlaskCalc:GetUniqueListOfMats()

    FlaskCalc:SetupRecipes();

    local mats = {};
    local found = {};
    for recipeId = 1,getn(Recipes) do
        for matId = 1,getn(Recipes[recipeId].Mats) do
            if found[Recipes[recipeId].Name] == nil then
                found[Recipes[recipeId].Name] = true;
                table.insert(mats,Recipes[recipeId].Name);
            end
            if found[Recipes[recipeId].Mats[matId][1]] == nil then
                found[Recipes[recipeId].Mats[matId][1]] = true;
                table.insert(mats,Recipes[recipeId].Mats[matId][1]);
            end
        end
    end
    return mats;
end

function FlaskCalc:GetUniqueListOfAllMats()

    local AllRecipes = FlaskCalc:GetAllRecipes();
    local mats = {};
    local found = {};
    for recipeId = 1,getn(AllRecipes) do
        for matId = 1,getn(AllRecipes[recipeId].Mats) do
            if found[AllRecipes[recipeId].Name] == nil then
                found[AllRecipes[recipeId].Name] = true;
                table.insert(mats,AllRecipes[recipeId].Name);
            end
            if found[AllRecipes[recipeId].Mats[matId][1]] == nil then
                found[AllRecipes[recipeId].Mats[matId][1]] = true;
                table.insert(mats,AllRecipes[recipeId].Mats[matId][1]);
            end
        end
    end
    return mats;
end

function FlaskCalc:InitializeRecipeList()
    self:RemoveBadEntries();
    local CustomRecipes = self.db.profile.customRecipes;
    local Processed = {};
    if CustomRecipes ~= nil then
        for i = 1, getn(CustomRecipes) do

           -- TODO: Think about sorting mats

            Processed[CustomRecipes[i].ID] = true;
        end
    end


   local RecipesInit = FlaskCalc:GetRecipesInit();
    for i = 1, getn(RecipesInit) do

        local itemName;
        local itemLink;
        local bad = false;

        if RecipesInit[i].itemID ~= nil then
            itemName, itemLink = GetItemInfo (RecipesInit[i].itemID);
            if itemName == nil then
                -- get item info from the server.
                -- actually this should be done earlier to make sure data is avaliable when needed,
                -- but in this way it works at least the next time you try
                GameTooltip:SetHyperlink("|Hitem:"..RecipesInit[i].itemID.."|hbla|h");

                bad = true;
            else
                RecipesInit[i].Name = itemName;
                RecipesInit[i].Link = itemLink;
            end
        end

        for k = 1, getn(RecipesInit[i].Mats) do
            if RecipesInit[i].Mats[k].itemID ~= nil then
                itemName, itemLink = GetItemInfo (RecipesInit[i].Mats[k].itemID);
                if itemName == nil then
                    -- get item info from the server.
                    -- actually this should be done earlier to make sure data is avaliable when needed,
                    -- but in this way it works at least the next time you try
                    GameTooltip:SetHyperlink("|Hitem:"..RecipesInit[i].Mats[k].itemID.."|hbla|h")

                    bad = true;
                else
                    RecipesInit[i].Mats[k][1] = itemName;
                end
            end
        end

        if Processed[RecipesInit[i].ID] == nil and bad == false then
            table.sort(RecipesInit[i].Mats,function(a,b)
                    return string.lower(a[1]) < string.lower(b[1]);
                end);
            table.insert(self.db.profile.customRecipes,RecipesInit[i]);
        end
    end

    -- Sort all items in the list
    table.sort(self.db.profile.customRecipes,function(a,b)
        return string.lower(a.Profession..": "..a.Name) < string.lower(b.Profession..": "..b.Name);
    end);
end

function FlaskCalc:SetupRecipes()
    Recipes = {};
    local AllRecipes = FlaskCalc:GetAllRecipes();
    for recipeId = 1,getn(AllRecipes) do
        if FlaskCalc:IsFilteredOut(AllRecipes[recipeId]) == false and FlaskCalc:IsDisabled(AllRecipes[recipeId]) == false then
            table.insert(Recipes,AllRecipes[recipeId]);
        end
    end
end

function FlaskCalc:FlaskMerchantRecord()
    local priceData = self.db.profile.vendorPrice;
    local numItems = GetMerchantNumItems();
    local Mats = FlaskCalc:GetUniqueListOfAllMats();
    local MatPresent = {};
    for matId = 1, getn(Mats) do
            MatPresent[Mats[matId]] = true;
    end
    for i =  1, numItems do
        local name, texture, price, quantity, numAvailable, isUsable, extendedCost = GetMerchantItemInfo(i);
        if name ~= nil and extendedCost ~= 1 then
            -- only get price for items that are used as mats in the existing recipes
            if MatPresent[name] == true then
                self.db.profile.vendorPrice[name] = price/quantity;
            end
        end
    end
end

function FlaskCalc:IsUnique(Recipe)
    if FlaskCalc:CloneCount(Recipe) == 0 then
        return true;
    else
        return false;
    end
end

function FlaskCalc:CloneCount(Recipe)
    local TempRecipes = FlaskCalc:GetAllRecipes();
    local cloneCount = 0;
    for recipeId = 1,getn(TempRecipes) do
        local unique = true;
        CurrentRecipe = TempRecipes[recipeId];
        if CurrentRecipe.Name == Recipe.Name and CurrentRecipe.Profession == Recipe.Profession and CurrentRecipe.Quantity == Recipe.Quantity then
            local matUnique = true;

            -- make sure that items are also detected as non-unique when the mats are listed in a different order
            if getn(Recipe.Mats) == getn(CurrentRecipe.Mats) then

                local identicalMatsCounter = 0;
                for matId = 1,getn(Recipe.Mats) do

                    for currentMatId = 1,getn(CurrentRecipe.Mats) do
                        if Recipe.Mats[matId] and CurrentRecipe.Mats[currentMatId] and Recipe.Mats[matId][1] == CurrentRecipe.Mats[currentMatId][1] and Recipe.Mats[matId][2] == CurrentRecipe.Mats[currentMatId][2] then
                            identicalMatsCounter = identicalMatsCounter+1;
                        end
                    end
                end


                if identicalMatsCounter == getn(Recipe.Mats) then
                    matUnique = false;
                end

            end

            if not matUnique then
                unique = false;
            end
        end
        if not unique then
            cloneCount = cloneCount+1;
        end
    end
    return cloneCount;
end

function FlaskCalc:CloneRecipe(Old)
    local New = {};

    New.ID = Old.ID;

    New.Name = Old.Name
    if New.Name == nil then
        self:Print(Old.ID);
    end
    New.Profession = Old.Profession;
    New.Link = Old.Link;
    New.HasCooldown = Old.HasCooldown;
    New.Quantity = Old.Quantity;
    New.DesiredAmount = Old.DesiredAmount;
    New.Mats = {};
    for i = 1,getn(Old.Mats) do
        table.insert(New.Mats,{Old.Mats[i][1],Old.Mats[i][2]});
    end
    return New;
end


function FlaskCalc:GetVendorPrice(MatName)
    if self.db.profile.vendorPrice[MatName] == nil then
        return 0;
    else
        return math.ceil(self.db.profile.vendorPrice[MatName]);
    end
end

function FlaskCalc:IsFilteredOut(Recipe)
    if self.db.profile.filterProfs and Recipe.Profession ~= "Misc" then
        local profession = Recipe.Profession;
        local name = GetSpellInfo(profession);
        if name == nil then
            -- Check if profession is mining. In this case we have to check if one of
            -- the player's professions is smelting (due to a change in 4.0)
            if profession == GetSpellInfo(3564) then
                local smeltingName = GetSpellInfo(2656);
                name = GetSpellInfo(smeltingName);
                if name ~= nil then
                    return false;
                end
            end
            return true;
        else
            return false;
        end
    else
        local p = Recipe.Profession;
        local showProfession = true;
        if p == GetSpellInfo(2259) then
            showProfession = self.db.profile.showAlchemy;
        elseif p == GetSpellInfo(3100) then
            showProfession = self.db.profile.showBlacksmithing;
        elseif p == GetSpellInfo(2550) then
            showProfession = self.db.profile.showCooking;
        elseif p == GetSpellInfo(7411) then
            showProfession = self.db.profile.showEnchanting;
        elseif p == GetSpellInfo(4036) then
            showProfession = self.db.profile.showEngineering;
        elseif p == GetSpellInfo(45357) then
            showProfession = self.db.profile.showInscription;
        elseif p == GetSpellInfo(25229) then
            showProfession = self.db.profile.showJewelcrafting;
        elseif p == GetSpellInfo(2108) then
            showProfession = self.db.profile.showLeatherworking;
        elseif p == GetSpellInfo(3908) then
            showProfession = self.db.profile.showTailoring;
        elseif p == GetSpellInfo(3564) then
            showProfession = self.db.profile.showMining;
        elseif p == GetSpellInfo(45542) then
            showProfession = self.db.profile.showFirstAid;
        elseif p == "Misc" then
            showProfession = self.db.profile.showMisc;
        end
        if showProfession == nil or showProfession then
            return false;
        else
            return true;
        end
    end
end

function FlaskCalc:IsDisabled(Recipe)
    if self.db.profile.disabledIDs[Recipe.ID] == true then
        return true;
    else
        return false;
    end
end

function FlaskCalc:GetNumFiltered()
    local tempRecipes = FlaskCalc:GetAllRecipes();
    local filtered = 0;
    for i = 1, getn(tempRecipes) do
        if FlaskCalc:IsFilteredOut(tempRecipes[i]) then
            filtered = filtered+1;
        end
    end
    return filtered;
end

function FlaskCalc:GetFilteredList()
    local tempRecipes = FlaskCalc:GetAllRecipes();
    local notfiltered = {};
    for i = 1, getn(tempRecipes) do
        if FlaskCalc:IsFilteredOut(tempRecipes[i]) ~= true then
            table.insert(notfiltered,tempRecipes[i]);
        end
    end
    return notfiltered;
end

function FlaskCalc:DeleteRecipe(Recipe)
    if self.db.profile.customRecipes ~= nil then
        for i = 1, getn(self.db.profile.customRecipes) do
            if self.db.profile.customRecipes[i] ~= nil and self.db.profile.customRecipes[i].ID == Recipe.ID then

                -- if custom recipe, delete it
                -- if init recipe, hide it
                local found = false;
                for i = 1, getn(RecipesInit) do
                    if RecipesInit[i].ID == Recipe.ID then
                        found = true;
                    end
                end

                if found == true then
                self.db.profile.hiddenIDs[Recipe.ID] = true;
                else
                    table.remove(self.db.profile.customRecipes,i);
                end
            end
        end
    end

    -- when recipe is deleted, also delete the "hide" information
    if self.db.profile.disabledIDs ~= nil then
        for i,v in pairs(self.db.profile.disabledIDs) do
            if self.db.profile.disabledIDs[i] ~= nil and i == Recipe.ID then
                self.db.profile.disabledIDs[i] = nil;
            end
        end
    end

end

-- find recipes in local list for a given item
function FlaskCalc:MatchingRecipes(Name,Avoiding)
    local Matching = {};
    local currentRecipes = FlaskCalc:GetRecipes();
    for i = 1, getn(currentRecipes) do
        if Name == currentRecipes[i].Name and (currentRecipes[i].HasCooldown == false or currentRecipes[i].HasCooldown == nil) then
            local valid = true;
            -- check if one of the recipe's mats is in the avoid list
            for j = 1,getn(currentRecipes[i].Mats) do
                for k = 1,getn(Avoiding) do
                    local Avoid = Avoiding[k];
                    if currentRecipes[i].Mats[j][1] == Avoid then
                        valid = false;
                    end
                end
            end
            if valid == true then
                table.insert(Matching,currentRecipes[i]);
            end
        end
    end
    return Matching;
end

function FlaskCalc:GetRecipesInit()
    return RecipesInit;
end

function FlaskCalc:FindResult(spellId)
    return pairing[spellId];
end
