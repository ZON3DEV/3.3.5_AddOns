--[[
    SlyProfits Localization file: Traditional Chinese
--]]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "zhTW")
if not L then return end

-- L["Advanced Mode"] = ""
-- L["At least one mat must be specified, Please Correct"] = ""
-- L["Buyout Per Item"] = ""
-- L["Buyout Total"] = ""
-- L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = ""
-- L["Cost Total"] = ""
-- L["Create"] = ""
-- L["Create a New Recipe"] = ""
-- L["Desired Stack Size"] = ""
-- L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = ""
-- L["Desired Stack Size must be a valid number, Please Correct"] = ""
-- L["Editing Recipe"] = ""
-- L["Filter Recipes By Current Profession"] = ""
-- L["Import Tradeskills into SlyProfits"] = ""
-- L["Item"] = ""
-- L["Makes"] = ""
-- L["Makes Per Craft"] = ""
-- L["Makes Per Craft must be a valid number, Please Correct"] = ""
-- L["Mats"] = ""
-- L["Name"] = ""
-- L["No Data Found"] = ""
-- L["Please open the profession you wish to import"] = ""
-- L["Profession"] = ""
-- L["Profession Data"] = ""
-- L["Profit Total"] = ""
-- L["Recipe profession must be selected, Please Correct"] = ""
-- L["Save"] = ""
-- L["Searching"] = ""
-- L["Time Elapsed"] = ""
-- L["Time Remaining"] = ""
-- L["Use Inventory"] = ""
-- L["has Cooldown?"] = ""
