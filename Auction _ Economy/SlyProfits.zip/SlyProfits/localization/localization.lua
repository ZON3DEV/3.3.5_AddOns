--[[
    SlyProfits Localization file: English
		This file must be present to have partial translations
--]]


local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "enUS", true, debug)

L["Advanced Mode"] = true
L["At least one mat must be specified, Please Correct"] = true
L["Buyout Per Item"] = true
L["Buyout Total"] = true
L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = true
L["Cost Total"] = true
L["Create"] = true
L["Create a New Recipe"] = true
L["Desired Stack Size"] = true
L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = true
L["Desired Stack Size must be a valid number, Please Correct"] = true
L["Editing Recipe"] = true
L["Filter Recipes By Current Profession"] = true
L["Import Tradeskills into SlyProfits"] = true
L["Item"] = true
L["Makes"] = true
L["Makes Per Craft"] = true
L["Makes Per Craft must be a valid number, Please Correct"] = true
L["Mats"] = true
L["Name"] = true
L["No Data Found"] = true
L["Please open the profession you wish to import"] = true
L["Profession"] = true
L["Profession Data"] = true
L["Profit Total"] = true
L["Recipe profession must be selected, Please Correct"] = true
L["Save"] = true
L["Searching"] = true
L["Time Elapsed"] = true
L["Time Remaining"] = true
L["Use Inventory"] = true
L["has Cooldown?"] = true

