--[[
    SlyProfits Localization file: Russian
--]]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "ruRU")
if not L then return end

L["Advanced Mode"] = "Расширенный режим" -- Needs review
L["At least one mat must be specified, Please Correct"] = "Должен быть указан хотябы один материал. Пожалуйста скорректируйте" -- Needs review
L["Buyout Per Item"] = "цена выкупа одной единицы" -- Needs review
L["Buyout Total"] = "Цена выкупа Всего" -- Needs review
L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = "Вычислить выручку от перепродажи лишних материалов, промежуточных рецептов и элексиров" -- Needs review
L["Cost Total"] = "Цена всего" -- Needs review
L["Create"] = "Создать" -- Needs review
L["Create a New Recipe"] = "Создать новый рецепт" -- Needs review
L["Desired Stack Size"] = "Желаемый Размер Пачки" -- Needs review
L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = "Желаемый размер пачки должен быть множителем Кол-ва изготовляемых предметов за один крафт. Пожалуйста скорректируйте" -- Needs review
L["Desired Stack Size must be a valid number, Please Correct"] = "Желаемый размер пачки долен быть числом. Пожалуйста скорректируйте" -- Needs review
L["Editing Recipe"] = "Редактирование рецепта" -- Needs review
L["Filter Recipes By Current Profession"] = "Фильтровать рецепты по текущей профессии" -- Needs review
L["Import Tradeskills into SlyProfits"] = "Импортировать умения в SlyProfits" -- Needs review
L["Item"] = "Предмет" -- Needs review
L["Makes"] = "Кол-во" -- Needs review
L["Makes Per Craft"] = "Кол-во изготовляемых предметов за один крафт" -- Needs review
L["Makes Per Craft must be a valid number, Please Correct"] = "Кол-во вещей должно быть цифрой, Пожалуйста скорректируйте" -- Needs review
L["Mats"] = "Материалы" -- Needs review
L["Name"] = "Название" -- Needs review
L["No Data Found"] = "информация не найдена" -- Needs review
L["Please open the profession you wish to import"] = "Откройте окно Профессии которую вы хотите импортировать " -- Needs review
L["Profession"] = "Профессия" -- Needs review
L["Profession Data"] = "Данные Профессии" -- Needs review
L["Profit Total"] = "Выручка Всего" -- Needs review
L["Recipe profession must be selected, Please Correct"] = "Профессия должна быть выбрана. Пожалуйста скорректируйте" -- Needs review
L["Save"] = "Сохранить" -- Needs review
L["Searching"] = "Поиск" -- Needs review
L["Time Elapsed"] = "Затрачено времени" -- Needs review
L["Time Remaining"] = "Осталось Времени" -- Needs review
L["Use Inventory"] = "Использовать инвентарь" -- Needs review
L["has Cooldown?"] = "есть время восстановления?" -- Needs review
