-- Please note the Code contained in this file has been modified and adapted as needed - May 2009.
-- The original credit for the unmodified addon belongs to the auctionlite addon author MerialKilrogg
-- The auctionlite code was available under GPLv2 license and as such this code is available under GPLv2
-------------------------------------------------------------------------------
-- AuctionFrame.lua
--
-- UI functions for modifying the parent auction frame.
-------------------------------------------------------------------------------

-- Index of our tab in the auction frame.
local FlaskTabIndex = nil;

-- Currently open AH tab.
local CurrentTab = nil;

-- Use this update event to do a bunch of housekeeping.
function FlaskCalc:AuctionFrame_OnUpdate(elapsed)
  -- Continue pending auction queries.
  self:QueryUpdate();
  self:FlaskTicker(elapsed);
end

-- Handle tab clicks by showing or hiding our frame as appropriate.
function FlaskCalc:AuctionFrameTab_OnClick_Hook(tab, arg)
  local index = (tab and tab:GetID()) or arg;

  CurrentTab = index;

  AuctionFrameFlask:Hide();

  if index == FlaskTabIndex then
    AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-TopLeft");
    AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-Top");
    AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-TopRight");
    AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-BotLeft");
    AuctionFrameBot:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-Bot");
    AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Bid-BotRight");
    AuctionFrameFlask:Show();
  end
end


-- Adds our hook to the main auction frame's update handler.
function FlaskCalc:HookAuctionFrameUpdate()
  local frameUpdate = AuctionFrame:GetScript("OnUpdate");
  AuctionFrame:SetScript("OnUpdate", function(self, elapsed)
    if frameUpdate ~= nil then
      frameUpdate();
    end
    FlaskCalc:AuctionFrame_OnUpdate(elapsed);
  end);
end

-- Clean up if the auction house is closed.
function FlaskCalc:AUCTION_HOUSE_CLOSED()
  --self:ClearFlaskFrame();

  collectgarbage("collect");
end

function FlaskCalc:TRADE_SKILL_SHOW()
  FlaskCalc:FlaskTradeSkillRecord();
end


function FlaskCalc:MERCHANT_SHOW()
  FlaskCalc:FlaskMerchantRecord();
end

-- Add the tab.
function FlaskCalc:AddAuctionFrameTab()
  FlaskTabIndex = self:CreateFlaskFrame();
end

-- Create a new tab on the auction frame.  Caller provides the name of the
-- tab and the frame object to which it will be linked.
function FlaskCalc:CreateTab(name, frame)
  -- Find a free index.
  local tabIndex = 1;
  while getglobal("AuctionFrameTab" .. tabIndex) ~= nil do
    tabIndex = tabIndex + 1;
  end

  -- Create the tab itself.
  local tab = CreateFrame("Button", "AuctionFrameTab" .. tabIndex,
                          AuctionFrame, "AuctionTabTemplate");
  tab:SetID(tabIndex);
  tab:SetText(name);
  tab:SetPoint("TOPLEFT", "AuctionFrameTab" .. (tabIndex - 1),
               "TOPRIGHT", -8, 0);

  -- Link it into the auction frame.
  PanelTemplates_DeselectTab(tab);
  PanelTemplates_SetNumTabs(AuctionFrame, tabIndex);

  frame:SetParent(AuctionFrame);
  frame:SetPoint("TOPLEFT", AuctionFrame, "TOPLEFT", 0, 0);

  return tabIndex;
end
