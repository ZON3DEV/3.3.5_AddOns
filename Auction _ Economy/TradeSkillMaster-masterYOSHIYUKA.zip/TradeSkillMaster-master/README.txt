This is a downgrade of the TradeSkillMaster add-on and it's various modules. Originally meant to be used with the latest retail patch of World of Warcraft, this is an effort to get TSM working for pre-4.x Wrath of the Lich King patches.
I did not create this add-on (or it's modules) but have made edits to resolve various errors and I'm in the process of patching various bugs.

To Install: 
Copy TradeSkillMaster to your Interface/Addons folder as this is the core addon and is required.
Likewise, copy any of the TradeSkillMaster_[module name] folders to Interface/Addons for the core to be able to use them. 

At the moment, the core, Account, and ItemTracker modules are the only functioning pieces of the suite.

Please log any issues you run in to in the issue tracker. Thank you.