AuctionMaster

Please have a look at http://wow.curse.com/downloads/wow-addons/details/vendor.aspx for a detailed description and usage information.

Addon developers who want to use some AuctionMaster functionality should have a look at the Readme.txt file in the src/api directory.
