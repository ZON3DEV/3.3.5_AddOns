-- This file is populated automatically by the TradeSkillMaster Application
-- and should not be manually modified.
local TSM = select(2, ...)
TSM.AppData = {
}