﻿-- Author      : Arturo
-- Create Date : 9/27/2009 5:23:39 AM

if( GetLocale() == "esMX" ) or GetLocale() == "esES" then
	GDHELPER="Guild Donation Helper 1.1.0";
	GDHELPER_EMAIL = "Correo";
	GDHELPER_BANKDEPOSITS = "Total Depositos Bancarios";
	GDHELPER_QUOTE="Cuota";
	GDHELPER_COMERCE="Actividad Comercial";
	GDHELPER_QUESTREWARDS="Recompensas al hacer misiones";
	GDHELPER_CHATSPAM="Mostrar mensajes de actividad";
	GDHELPER_MAINTITLE="Opciones de Donacion";
	GDHELPER_UPDATE="Actualizar";
	GDHELPER_SYNC="Solicitando información a ";
	GDHELPER_SMALLCHANGES="Pequeños aportes";
	GDHELPER_HELP="Resumen de recolección:";
	GDHELPER_USERS="Lista de Hermandad";
	GDHELPER_TABSUMMARY="Resumen";
	GDHELPER_TABGUILD="Clan";
	GDHELPER_CMDCLOSE="Cerrar";
	GDHELPER_CMDSAVE="Aceptar";
	GDHELPER_TAX="Porcentaje de donacion";
	GD_GUILD="Clan";
	GD_ME="Yo";
	GD_TOTAL="Total";
	GDHELPER_LOADED="Cargado. Use '/gdh' para ver opciones";
	GDHELPER_REQUESTTAX="Solicitando tasa a los miembros de hermandad Miembros: ";
	GD_SLASH_TITLE="******* Opciones Guild Donation**************";
	GD_SLASH_SHOW_MINIWINDOW="Digite '/gdh show' para ver la ventana de cuota";
	GD_SLASH_SHOW_OPTIONS="Digite '/gdh options' para ver las opciones de donacion";
	GD_SLASH_SHOW_TAX="Digite '/gdh rate' para ver la tasa actual de donacion";
	GD_SLASH_SHOW_AMOUNT="Digite '/gdh tax' para ver que tanto debera pagar al banco en la proxima visita";
	GD_SLASH_SHOW_TOTAL="Digite '/gdh total' para ver el total pagado";	
	GD_SLASH_SHOW_WHO_USING="Digite '/gdh who' para ver que miembros de hermandad usan el addon";
	GD_SLASH_SHOW_CURRENTTAX="Tasa actual es ";
	GD_SLASH_SHOW_TOTALPAYED="Total Pagado ";
	GD_SLASH_SHOW_PENDING="Acumulado pendiente ";
	GDHELPER_GUILD_ISNECESARY="Es necesario estar en una hermandad";
	GDHELPER_MENUSET="/gdh set : Sincroniza con la hermandad";
	GDHELPER_MENUGET="/gdh get [PlayerName] : Pide informacion del jugador";
	GDHELPER_MENUDEBUG="/gdh degub: Activa o desactiva el modo depuración";
	GD_OPTIONS="Opciones";
	GDHELPER_MENUSHOW="/gdh show :Mostrar mini";
	GDH_SYNC="Sinc";
	GDH_PLAYERS="Jugadores";
	GDHELPER_CREDIT="Crédito";
	GDHELPER_QUOTA="Cuota";
	GDHELPER_CREDITTAX="Tasa de préstamo:";
	GDHELPER_PAYMENTTAX="Tasa de pago:";
end