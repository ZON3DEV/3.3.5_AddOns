﻿-- Author      : Arturo
-- Create Date : 9/27/2009 5:23:39 AM

if( GetLocale() == "deDE" )  then
	GDHELPER="Guild Donation Helper 1.1.0";
	GD_GUILD = "Gilde";
	GDHELPER_BANKDEPOSITS = "Bankeinzahlung";
	GDHELPER_QUOTE="Quota";
	GDHELPER_CHATSPAM = "Chatnachrichten";
	GDHELPER_UPDATE="Update";
	GDHELPER_CMDCLOSE = "Speichern";
	GDHELPER_CMDSAVE = "Speichern";
	GDHELPER_COMERCE = "Verk\195\164ufer";
	GDHELPER_EMAIL = "Briefe";
	GDHELPER_SYNC="Sending information...";
	GDHELPER_GUILD_ISNECESARY = "Du musst einer Gilde beitreten.";
	GDHELPER_HELP="Collecting Summary:";
	GDHELPER_USERS="Guild list";
	GDHELPER_TABSUMMARY="Summary";
	GDHELPER_TABGUILD="Guild";
	GDHELPER_LOADED = "GDH geladen. Gib \"/gdh\" ein; um die Optionen anzuzeigen.";
	GDHELPER_MAINTITLE = "GuildDonation Optionen";
	GDHELPER_QUESTREWARDS = "Questbelohnungen";
	GDHELPER_REQUESTTAX = "Steuer von Gildenmitgliedern anfordern:";
	GDHELPER_SMALLCHANGES = "gepl\195\188ndertes Geld";
	GDHELPER_TAX = "Prozentsatz der Steuern";
	GD_ME = "Selbst";
	GD_TOTAL="Total";
	GD_SLASH_SHOW_AMOUNT = "Gib \"/gdh tax\" ein; um zu sehen wieviel Steuern beim n\195\164chsten Gildenbankbesuch bezahlt werden.";
	GD_SLASH_SHOW_CURRENTTAX = "Aktueller Prozentsatz an Steuern ist";
	GD_SLASH_SHOW_MINIWINDOW = "Gib \"/gdh show\" ein; um das Ministeuernfenster anzuzeigen.";
	GD_SLASH_SHOW_OPTIONS = "Gib \"/gdh options\" ein; um das Optionenfenster anzuzeigen.";
	GD_SLASH_SHOW_PENDING = "Bevorstehende Abgaben";
	GD_SLASH_SHOW_TAX = "Gib \"/gdh rate\" ein; um den aktuellen Prozentsatz an Steuern zu sehen.";
	GD_SLASH_SHOW_TOTAL = "Gib \"/gdh total\" ein; um die insgesamt gezahlten Steuern zu sehen.";
	GD_SLASH_SHOW_TOTALPAYED = "Insgesamt gezahlte Steuern";
	GD_SLASH_SHOW_WHO_USING = "Gib \"/gdh who\" ein; um die Gildenmitglieder anzuzeigen; die GuildDonation benutzen.";
	GD_SLASH_TITLE = "**************Optionen GuildDonation**************"
	GDHELPER_MENUSET="/gdh set : Sync information with Guild";
	GDHELPER_MENUGET="/gdh get [PlayerName] : Retrieve information from player";
	GDHELPER_MENUDEBUG="/gdh degub: Enable/disable debug mode";
	GD_OPTIONS="Options";
	GDHELPER_MENUSHOW="/gdh show :Show MiniWindow";
	GDH_SYNC="Sync";
	GDH_PLAYERS="Players";
	GDHELPER_CREDIT="Credit";
	GDHELPER_QUOTA="Quota";
	GDHELPER_CREDITTAX="Credit Tax:";
	GDHELPER_PAYMENTTAX="Payment Tax:";
end