﻿-- Author      : Mart
-- Create Date : 3/27/2010 4:24:18 PM
local isOrderAsc=true;
function cmdClose_OnClick()	
	
	GuildDonationHelper:ShowSystemMessage("FrmOptions:cmdClose_OnClick");
	
	PlaySound("UChatScrollButton");
	
	local checked=chkShowActivity:GetChecked();
	
	if(checked~=nil) then
		PARAMETER["showActivity"]=1;
	else
		PARAMETER["showActivity"]=0;
	end
	
	PARAMETER["paymentTax"]=ExtractPaymentTax(txtPaymentTax:GetText());
	
	--Cierra la ventana de opciones
	FrmOptions:Hide();	
end

function ExtractPaymentTax(text)
	local finded = text:match("%d+");

	if(finded==nil) then
		finded=50;
	else
		finded=finded+0;
		
		if(finded>100 or finded<=0) then
			finded=50;	
		end
	end
	return finded;
end

--Recarga la tabla con la informacion de la tabla de personajes
function Rebind()
	GuildDonationHelper:ShowSystemMessage("FrmOptions:Rebind Usuarios:"..# PARAMETER["userList"]);
	local line; -- 1 through 20 of our window to scroll
	local startIndex; -- an index into our data calculated from the scroll offset
	local offSet=FauxScrollFrame_GetOffset(UsersScrollBar);
  
  if(PARAMETER["userList"]~= nil) then
	  local totalRows=# PARAMETER["userList"]; 
	  
	  FauxScrollFrame_Update(UsersScrollBar,totalRows,20,16);	  
	  
	  for line=1,20 do
		startIndex = line + offSet;
	    
		if startIndex <= totalRows then
	    
			local registry		= PARAMETER["userList"][startIndex];
						
			getglobal("cellName"..line):SetText(registry["player"]);
			getglobal("cellValue"..line):SetText(GetCoinTextureString(registry["totalHistoryPayed"]));
			getglobal("cellQuote"..line):SetText(GetCoinTextureString(registry["totalMoney"]));
			getglobal("cellTax"..line):SetText(registry["taxAmount"].."%");
			
			--Compatibilidad con versiones anteriores
			if(registry["totalCredit"] ~=nil) then
				getglobal("cellCredit"..line):SetText(GetCoinTextureString(registry["totalCredit"]));
			else
				registry["totalCredit"]=0;
			end

			getglobal("cellName"..line):Show();
			getglobal("cellValue"..line):Show();
			getglobal("cellQuote"..line):Show();
			getglobal("cellTax"..line):Show();
			getglobal("cellCredit"..line):Show();
		else
			getglobal("cellName"..line):Hide();
			getglobal("cellValue"..line):Hide();
			getglobal("cellQuote"..line):Hide();
			getglobal("cellTax"..line):Hide();
			getglobal("cellCredit"..line):Hide();
		end
	  end
	  
	  lblTotalPlayers:SetText(totalRows.." "..GDH_PLAYERS);
	  
		local sumCuote=0;
		local sumTotal=0;
		local sumCredit=0;
	  
		for i=1,totalRows do
		  local row		= PARAMETER["userList"][i];
		  
		  sumCuote		= sumCuote + row["totalMoney"];
		  sumTotal		= sumTotal + row["totalHistoryPayed"];
		  sumCredit		=sumCredit + row["totalCredit"];
		end
	  	
	  	--Total de creditos
	  	lblTotalCredit:SetText(GetCoinTextureString(sumCredit)); 
	  	
		--Coloca el total de la cuota
		lblTotalCuote:SetText(GetCoinTextureString(sumCuote));

		--Coloca el total donado
		lblTotalPayed:SetText(GetCoinTextureString(sumTotal));
  end
end

function UserList_OnClick(controlId)
	
	GuildDonationHelper:ShowSystemMessage("FrmOptions:UserList_OnClick");
	
	local name=getglobal("cellName"..controlId):GetText();
	GuildDonationHelper:SendCommMessage(CHANNELNAME.."REQUEST", "REPORT", "WHISPER",name);
end

--Inicializar la ventana de opciones
function GuildDonationHelper:FrmOptions_Init()
	self:ShowSystemMessage("FrmOptions:FrmOptions_Init");
	
	PlaySound("UChatScrollButton");
			
	tinsert(UISpecialFrames,"FrmOptions");
	this.elapsed = 0;
	PanelTemplates_SetNumTabs(FrmOptions, 3);
	PanelTemplates_SetTab(FrmOptions, 1);	
	UsersScrollBar:Show();
	
	TabSummary:Show();
	TabUserList:Hide();	
	TabCredit:Hide();	
		
	--Carga la tasa de impuesto actual
	lblActualTax:SetText(PARAMETER["taxAmount"].."%");
	
	--Total de dinero aportado	
	lblTotal:SetText(GetCoinTextureString(PARAMETER["totalHistoryPayed"]));
	
	--Dinero aportado colectando
	lblSmallChanges:SetText(GetCoinTextureString(PARAMETER["totalSmallChanges"]));
	
	--Total de dinero recaudado por comercio
	lblComerce:SetText(GetCoinTextureString(PARAMETER["totalComerce"]));
	
	--Total recaudado por correos electronicos
	lblEmail:SetText(GetCoinTextureString(PARAMETER["totalMail"]));
	
	--Total recaudado por misiones
	lblQuestRewards:SetText(GetCoinTextureString(PARAMETER["totalQuest"]));
	
	if(PARAMETER["showActivity"]==1) then
		--Opcion para mostrar actividad del addon	
		chkShowActivity:SetChecked(1);	
	else
		chkShowActivity:SetChecked(0);
	end
		
	--Cuota actual que debe el jugador
	lblQuote:SetText(GetCoinTextureString(PARAMETER["totalMoney"]));
	
	lblTotalCreditResume:SetText(GetCoinTextureString(PARAMETER["totalCredit"]));
	lblCreditTax:SetText(PARAMETER["creditTax"].."%");
	txtPaymentTax:SetText(PARAMETER["paymentTax"]);
	
	Rebind();	
end

function GuildDonationHelper:UpdateUserTable()	
	Rebind();
end

--Ordenamiento de los datos
function SortUsersBy(option)

	GuildDonationHelper:ShowSystemMessage("FrmOptions:SortUsersBy "..option);
	
	if(isOrderAsc) then
		isOrderAsc=false;
		if(option=="player") then
			--Ordena por nombre
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.player < n2.player end);
		end

		if(option=="total") then	
			--Ordena por nombre
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalHistoryPayed < n2.totalHistoryPayed end);
		end
		
		if(option=="quote") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalMoney < n2.totalMoney end);
		end
		
		if(option=="tax") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.taxAmount < n2.taxAmount end);
		end
		if(option=="credit") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalCredit < n2.totalCredit end);
		end
	else
		isOrderAsc=true;
		if(option=="player") then
			--Ordena por nombre
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.player > n2.player end);
		end

		if(option=="total") then	
			--Ordena por nombre
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalHistoryPayed > n2.totalHistoryPayed end);
		end
		
		if(option=="quote") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalMoney > n2.totalMoney end);
		end
		
		if(option=="tax") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.taxAmount > n2.taxAmount end);
		end
		
		if(option=="credit") then
			table.sort (PARAMETER["userList"],function (n1, n2) return n1.totalCredit > n2.totalCredit end);
		end
	end
	Rebind();
end

--Actualiza toda la lista de usuarios
function Syncronize()

	--Depura ls lista de usuarios quitando los que no estan en la hermandad
	if(PARAMETER["userList"]~= nil) then			
		local totalrows= #PARAMETER["userList"];
		local actualRow = totalrows;
		
		while(actualRow>0 ) do
			local row		= PARAMETER["userList"][actualRow];
			local playerName=row.player;
			
			local index=FindInGuildNames(playerName);
						
			if(index==nil) then
				GuildDonationHelper:ShowSystemMessage("Deleting to: "..playerName);
				table.remove(PARAMETER["userList"],actualRow);	
			end						
			actualRow = actualRow-1;
		end			
	end
	
	--Envia un mensaje en la hermandad para que notifiquen el estado del Gdh
	GuildDonationHelper:SendCommMessage(CHANNELNAME.."REQUEST", "REPORT", "GUILD");
end

--Busca si un nombre se encuentra en la lista de nombres de hermandad
function FindInGuildNames(playerName)	
	
	GuildDonationHelper:ShowSystemMessage("Searching: "..playerName .. " in "..#GuildNames .." players");
	
	local index=nil;	
	for i=1,#GuildNames do		
		
		if(GuildNames[i]==playerName)		then		
			index= i;
		end
	end
	return index;
end

---Muestra mensaje si esta activado la opcion para mostrar mensajes
function ChatMessage(message)
	if(PARAMETER["showActivity"]==1) then
		DEFAULT_CHAT_FRAME:AddMessage("GuildDonationHelper:"..message);	
	end
end