-- Korean text strings

Localization.RegisterAddonStrings("koKR", "Auc-Searcher-WeightsWatcher",
  {
    -- Config
    MAIN_TITLE        = "WeightsWatcher는 업그레이드를 고려 항목에 대한 검색";
    OPTIONS           = "옵션 :";
    HELP_ID           = "WeightsWatcher이 검색";
    HELP_QUESTION     = "이 검색자가 어떤 역할을합니까?";
    HELP_ANSWER       = "이 검색자가 귀하의 현재 시설 항목에 대한 업그레이드를 찾습니다 WeightsWatcher의 부가에 정의 된 무게를 사용합니다.";
    CONFIG_HEADER     = "WeightsWatcher 검색 조건";
    WEIGHT_SELECT      = "WeightsWatcher 무게";
    WEIGHT_SELECT_TIP  = "항목 값을 결정하는 데 사용됩니다 WeightsWatcher 무게.";
    USEABLE_ONLY      = "사용 가능한 항목 만";
    USEABLE_ONLY_TIP  = "당신의 캐릭터가 사용할 수있는 항목 만.";
    AFFORD_ONLY       = "만, 여유가 수";
    AFFORD_ONLY_TIP   = "당신이 현재 무엇을 살것인지를 보여 줍니다.";
    USE_BUYOUT        = "인수를 사용하여";
    USE_BUYOUT_TIP    = "경매 가격을 확인할 때 인수 대신 입찰가를 사용합니다.";
    USE_BESTPRICE        = "가격을 기준으로 점수를 조정합니다.";
    USE_BESTPRICE_TIP    = "항목의 가격에 의해 반환 된 점수를 조정합니다. 유사한 항목은 저렴 항목은 목록에서 높을 것입니다.";
    USE_UNENCHANTED     = "Unenchanted 값을 사용";
    USE_UNENCHANTED_TIP = "계산에 대한 unenchanted 값을 사용합니다. 선택하지 않을 경우, 항목 값은 항목이 최선의 매력을 가지고 있다고 생각할 것입니다.";
    FORCE2H_WEAP      = "만 양손 무기";
    FORCE2H_TIP       = "무기를 비교했을 때 만 양손 무기를 고려합니다.";
    INCLUDE_IN_SEARCH = "검색 할 때 다음 슬롯을 포함 :";
    SHOW_HEAD         = "머리";
    SHOW_NECK         = "목";
    SHOW_SHOULDER     = "어깨";
    SHOW_BACK         = "등";
    SHOW_CHEST        = "가슴";
    SHOW_WRIST        = "손목";
    SHOW_HANDS        = "손";
    SHOW_WAIST        = "허리";
    SHOW_LEGS         = "다리";
    SHOW_FEET         = "발";
    SHOW_FINGER       = "손가락";
    SHOW_TRINKET      = "장신구";
    SHOW_WEAPON       = "무기";
    SHOW_OFFHAND      = "보조장비";
    SHOW_RANGED       = "원거리 장비";

    --Armor Preference
    ARMORPREF_SELECT_TIP = "갑옷을 검색하면 검색 결과에서 선택한 갑옷 유형을 보여줍니다. 다른 모든 갑옷 유형을 필터링 할 수 있습니다.";
    ARMOR_PREFERENCE = "갑옷 환경 설정";
    NO_PREF   = "어떤 환경 설정 없음";
    CLOTH     = "천";
    LEATHER   = "가죽";
    MAIL      = "사슬";
    PLATE     = "판금";

    --Item Types
    ARMOR   = "방어구";
    SHIELDS = "방패";
    MISC    = "기타";

    -- Two Handed sub-string
    TWOHAND = "양손"; 
    
    -- Two Handed Weapons
    STAVES = "지팡이류";
    POLEARMS = "장창류";
    -- CROSSBOWS
    -- GUNS
    -- BOWS

    -- Ranged
    BOWS = "활류";
    GUNS = "총기류";
    WANDS = "마법봉류";
    CROSSBOWS = "석궁류";
    THROWN = "투척 무기"; -- may be removed

    -- Messages
    NOT_WANTED  = "항목 슬롯 원하지 않는";
    NOT_UPGRADE = "담보 값이 너무 낮습니다.";

    REASON_BUY = "사다";
    REASON_BID = "매기다";
  },
nil, true) -- Protected
