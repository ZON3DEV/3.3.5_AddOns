-- Latin American Spanish text strings

Localization.RegisterAddonStrings("esMX", "Auc-Searcher-WeightsWatcher",
  {
    -- Config
    MAIN_TITLE        = "Buscar elementos que WeightsWatcher considera una actualización";
    OPTIONS           = "Opciones:";
    HELP_ID           = "Buscador WeightsWatcher";
    HELP_QUESTION     = "¿Qué significa este buscador a hacer?";
    HELP_ANSWER       = "Este buscador utilizará una escala que ha sido definido en el addon WeightsWatcher para localizar actualizaciones de tus items equipados.";
    CONFIG_HEADER     = "Criterios de búsqueda WeightsWatcher";
    WEIGHT_SELECT      = "WeightsWatcher escala";
    WEIGHT_SELECT_TIP  = "La escala WeightsWatcher que se utiliza para determinar el valor del elemento";
    USEABLE_ONLY      = "Artículos utilizables sólo";
    USEABLE_ONLY_TIP  = "Sólo los elementos que tu personaje puede utilizar.";
    AFFORD_ONLY       = "Sólo lo que me puedo permitir";
    AFFORD_ONLY_TIP   = "Sólo muestra lo que actualmente puede permitirse el lujo de comprar.";
    USE_BUYOUT        = "Utilice compra";
    USE_BUYOUT_TIP    = "Utilice compra en lugar de la oferta al comprobar los precios de subasta.";
    USE_BESTPRICE       = "Ajuste puntuación basada en el precio.";
    USE_BESTPRICE_TIP   = "Ajustar la puntuación devuelta por el precio del artículo. Para elementos similares, el material más barato será más alta en la lista.";
    USE_UNENCHANTED     = "Utilice valores sin encantamientos";
    USE_UNENCHANTED_TIP = "Utilice valores sin encantamientos para los cálculos. Si no se marca, valores de los elementos se incluyen encantamientos actuales.";
    FORCE2H_WEAP      = "Sólo armas a dos manos.";
    FORCE2H_TIP       = "Al comparar las armas, sólo se consideran armas a dos manos.";
    INCLUDE_IN_SEARCH = "Incluya estas ranuras al buscar:";
    SHOW_HEAD         = "Cabeza";
    SHOW_NECK         = "Cuello";
    SHOW_SHOULDER     = "Hombros";
    SHOW_BACK         = "Espalda";
    SHOW_CHEST        = "Torso";
    SHOW_WRIST        = "Muñeca";
    SHOW_HANDS        = "Manos";
    SHOW_WAIST        = "Cintura";
    SHOW_LEGS         = "Piernas";
    SHOW_FEET         = "Pies";
    SHOW_FINGER       = "Dedo";
    SHOW_TRINKET      = "Abalorio";
    SHOW_WEAPON       = "Arma";
    SHOW_OFFHAND      = "Mano Izquierda";
    SHOW_RANGED       = "Rango";

    --Armor Preference
    ARMORPREF_SELECT_TIP = "Durante la búsqueda de armas, sólo muestran el tipo de armadura seleccionada en los resultados de búsqueda. Filtrar todos los tipos de armadura otros.";
    ARMOR_PREFERENCE = "Armadura de Preferencia";
    NO_PREF   = "No tengo preferencias";
    CLOTH     = "Tela";
    LEATHER   = "Cuero";
    MAIL      = "Mallas";
    PLATE     = "Placas";

    --Item Types
    ARMOR   = "Armadura";
    SHIELDS = "Escudos";
    MISC    = "Miscelánea";

    -- Two Handed sub-string
    TWOHAND = "Dos Manos";
    
    -- Two Handed Weapons
    STAVES = "Bastones";
    POLEARMS = "Armas de asta";
    -- CROSSBOWS
    -- GUNS
    -- BOWS

    -- Ranged
    DAGGERS = "Dagas";
    BOWS = "Arcos";
    GUNS = "Pistolas";
    WANDS = "Varitas";
    CROSSBOWS = "Ballestas";
    THROWN = "Arrojadiza"; -- may be removed

    -- Messages
    NOT_WANTED  = "Espacio de objeto no quería";
    NOT_UPGRADE = "WeightsWatcher valor es demasiado bajo.";

    REASON_BUY = "comprar";
    REASON_BID = "ofrecer";
  },
nil, true) -- Protected
