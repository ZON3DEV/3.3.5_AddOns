-- English text strings

Localization.RegisterAddonStrings("enUS", "Auc-Searcher-WeightsWatcher",
  {
    -- Config
    MAIN_TITLE        = "Search for items which WeightsWatcher considers an upgrade"; --update
    OPTIONS           = "Options:";
    HELP_ID           = "WeightsWatcher Searcher"; --update
    HELP_QUESTION     = "What does this searcher do?";
    HELP_ANSWER       = "This searcher will use a weight that has been defined in the WeightsWatcher addon to locate upgrades for your currently equipped items."; --update
    CONFIG_HEADER     = "WeightsWatcher Search Criteria"; --update
    WEIGHT_SELECT      = "WeightsWatcher weight"; --update
    WEIGHT_SELECT_TIP  = "The WeightsWatcher weight that will be used to determine the item value"; --update
    USEABLE_ONLY      = "Useable items only";
    USEABLE_ONLY_TIP  = "Only items that your character can use.";
    AFFORD_ONLY       = "Only what I can afford";
    AFFORD_ONLY_TIP   = "Only show what you can currently afford to buy.";
    USE_BUYOUT        = "Use buyout";
    USE_BUYOUT_TIP    = "Use buyout instead of bid when checking auction prices.";
    USE_BESTPRICE       = "Adjust score based on price.";
    USE_BESTPRICE_TIP   = "Adjust the score returned by the price of the item.  For similar items, the cheaper item will be higher on the list.";
    USE_UNENCHANTED     = "Use Unenchanted Values";
    USE_UNENCHANTED_TIP = "Use unenchanted values for calculations. If not checked, item values will assume that item has best possible enchantements."; --update
    FORCE2H_WEAP      = "Only 2-Handed Weapons";
    FORCE2H_TIP       = "When comparing weapons, only consider 2-Handed Weapons.";
    INCLUDE_IN_SEARCH = "Include these slots when searching:";
    SHOW_HEAD         = "Head";
    SHOW_NECK         = "Neck";
    SHOW_SHOULDER     = "Shoulder";
    SHOW_BACK         = "Back";
    SHOW_CHEST        = "Chest";
    SHOW_WRIST        = "Wrist";
    SHOW_HANDS        = "Hands";
    SHOW_WAIST        = "Waist";
    SHOW_LEGS         = "Legs";
    SHOW_FEET         = "Feet";
    SHOW_FINGER       = "Finger";
    SHOW_TRINKET      = "Trinket";
    SHOW_WEAPON       = "Weapon";
    SHOW_OFFHAND      = "Off-Hand";
    SHOW_RANGED       = "Ranged";

    --Armor Preference
    ARMOR_PREFERENCE = "Armor Preference";
    ARMORPREF_SELECT_TIP = "Only show the selected armor type in search results.  Filter out all other armor types.";
    NO_PREF   = "No Preference";
    CLOTH     = "Cloth";
    LEATHER   = "Leather";
    MAIL      = "Mail";
    PLATE     = "Plate";

    --Item Types
    ARMOR   = "Armor";
    SHIELDS = "Shields";
    MISC    = "Miscellaneous";

    -- Two Handed sub-string
    TWOHAND = "Two-Hand";
    
    -- Two Handed Weapons
    STAVES = "Staves";
    POLEARMS = "Polearms";
    -- CROSSBOWS
    -- GUNS
    -- BOWS

    -- Ranged
    DAGGERS = "Daggers";
    BOWS = "Bows";
    GUNS = "Guns";
    WANDS = "Wands";
    CROSSBOWS = "Crossbows";
    THROWN = "Thrown"; -- may be removed

    -- Messages
    NOT_WANTED  = "Item slot not wanted";
    NOT_UPGRADE = "WeightsWatcher value is too low."; --update

    REASON_BUY = "buy";
    REASON_BID = "bid";
  },
nil, true) -- Protected
