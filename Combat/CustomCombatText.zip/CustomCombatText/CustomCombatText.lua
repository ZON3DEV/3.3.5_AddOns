
CustomCombatText = CreateFrame("Frame", "CustomCombatText");

local damagefont_FONT_NUMBER = "Interface\\AddOns\\CustomCombatText\\font.ttf";

function CustomCombatText:ApplySystemFonts()

DAMAGE_TEXT_FONT = damagefont_FONT_NUMBER;

end

CustomCombatText:SetScript("OnEvent",
		    function() 
		       if (event == "ADDON_LOADED") then
			  CustomCombatText:ApplySystemFonts()
		       end
		    end);
CustomCombatText:RegisterEvent("ADDON_LOADED");

CustomCombatText:ApplySystemFonts()