CustomCombatText is a simple addon that enables you to change the default blizzard floating combat text font
into a font of your choice.

How to: find a font you like, say at Dafont.com, download it and change its name into font.ttf (must be ttf format)
Exchange it with the one in the CustomCombatText folder.

Install: as any normal addon. Download the ZIP and extract the CustomCombatText folder into
World of Warcraft/interface/addons
Default location=   C:\Program files\World of Warcraft\Interface\AddOns


Enjoy!
 

Mds