after extracting:
1) put the "MikScrollingBattleText.lua" file into your WTF\Account\AccountName\SavedVariables" directory.
2) Put everything else into Interface/addons directory as usual.