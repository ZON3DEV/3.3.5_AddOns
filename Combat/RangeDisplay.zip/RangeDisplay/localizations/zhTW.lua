-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay", "zhTW")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock frames"] = "|cffeda55fCtrl+點擊|r鎖定所有框架"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖拽|r 移動位置"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55f點擊|r鎖定/解鎖框架"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右擊|r打開設置視窗"
L["focus"] = "焦點"
L["pet"] = "寵物"
L["playertarget"] = "目標"

