-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay", "frFR")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock frames"] = " |cffeda55fCtrl + Clic gauche|r pour verrouiller"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = " |cffeda55fClic gauche|r pour verrouiller/déverrouiller les frames"
L["|cffeda55fRight Click|r to open the configuration window"] = " |cffeda55fClic droit|r pour ouvrir la fenêtre de configuration"
L["|cffeda55fShift + Left Click|r to toggle sound"] = " |cffeda55fShift + Clic gauche|r pour activer/désactiver le son"
L["focus"] = "Focus"
L["pet"] = "Familier"
L["playertarget"] = "Cible"

