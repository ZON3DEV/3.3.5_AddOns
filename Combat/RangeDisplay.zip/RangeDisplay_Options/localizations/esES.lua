-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay_Options", "esES")
if not L then return end

L["Border Color"] = "Color del Borde"
L["Border Texture"] = "Textura del Borde"
L["Border Thickness"] = "Espesor del Borde"
L["Color"] = "Color"
L["Copy section settings to other units"] = "Copiar ajustes de la sección a otras unidades"
L["Default section"] = "Sección predeterminada"
L["Enabled"] = "Habilitado"
L["Enable this color section"] = "Habilitar esta sección de color"
L["Font"] = "Fuente"
L["Font outline"] = "Contorno de la Fuente"
L["Font size"] = "Tamaño de la Fuente"
L["Height"] = "Alto"

