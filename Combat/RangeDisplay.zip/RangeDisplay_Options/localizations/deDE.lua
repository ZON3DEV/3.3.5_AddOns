-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay_Options", "deDE")
if not L then return end

L["Anchor to Mouse"] = "An der Maus verankern"
L["Auto adjust"] = "Autom. justieren"
L["Auto hide"] = "Autom. ausblenden"
L["Background Color"] = "Hintergrundfarbe"
L["Background Options"] = "Hintergrund-Optionen"
L["Background Texture"] = "Hintergrundtextur"
L["Color"] = "Farbe"
L["Enabled"] = "Aktiviert"
L["Enemy only"] = "Nur Feinde"
L["Font"] = "Schriftart"
L["Font outline"] = "Schriftstil"
L["Font size"] = "Schriftgröße"
L["Height"] = "Höhe"
L["High"] = "Hoch"
L["Locked"] = "Gesperrt"
L["Lock/Unlock display frame"] = "Anzeige sperren/entsperren"
L["Low"] = "Niedrig"
L["Max range only"] = "Nur. maximale Reichweite"
L["Medium"] = "Mittel"
L["Mute"] = "Stumm"
L["None"] = "Keine"
L["Normal"] = "Normal"
L["Play a sound when entering this range"] = "Einen Sound abspielen wenn man diese Reichweite betritt"
L["Show range for enemy targets only"] = "Zeige nur Reichweiten für feindliche Ziele"
L["Text"] = "Text"
L["Thick"] = "Fett"
L["Toggle sound"] = "Sound ein/ausschalten"
L["Use Text"] = "Text verwenden"
L["Use warning sound for enemy targets only"] = "Warnsound nur für gegnerische Ziele verwenden"
L["Warning Sound"] = "Warnsound"
L["Width"] = "Breite"

