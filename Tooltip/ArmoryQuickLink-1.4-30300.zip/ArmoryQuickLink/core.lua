-- Credits: Tekkub, AnduinLothar
-- stitching together bits and pieces from tekPlayerMenu, ReURL

local Armories = {
	[1] = {label = "1: Blizzard", base = ".wowarmory.com/character-sheet.xml?r="},
	[2] = {label = "2: Armory Lite", base = "http://armorylite.com/"},
	[3] = {label = "3: Be Imba", base = "http://be.imba.hu/?"},
	[4] = {label = "4: WoW Armory - Light", base = "http://www.armory-light.com/"},
	[5] = {label = "5: Warcrafter", base = ".warcrafter.net/"},
	[6] = {label = "6: WoW Heroes", base = "http://wow-heroes.com/index.php?zone="},
	[7] = {label = "7: QuickArmory", base = "http://www.quickarmory.com/?n="},
	[8] = {label = "8: PuG Checker", base = "http://www.pugchecker.com/index.php?name="},
	[9] = {label = "9: TrackWarcraft", base = "http://www.trackwarcraft.com/char/"},
	[10] = {label = "10: Elitist Armory", base = "http://elitistarmory.com/"},
}

ArmoryQL_Config = {};

UnitPopupButtons["AQL"]={text = "QuickLink", dist = 0};
table.insert(UnitPopupMenus["FRIEND"], #(UnitPopupMenus["FRIEND"])-1, "AQL");

local function urlEscape(url)
	return string.gsub(url, "([^A-Za-z0-9_:/?&=.-])", 
		function(ch)
			return string.format("%%%02x", string.byte(ch))
		end)
end

local function constructUrl(name)
	if not name or name == "" then return end
	
	local zone, server, tempurl, url;
	
	zone = GetCVar("realmList"); 
	if zone then
		zone = string.split(".", zone);
		if not zone or zone == "" then
			DEFAULT_CHAT_FRAME:AddMessage("|CFFCC33FFArmory QuickLink:|r Couldn't find realm list!");
			return;
		end
	end
	
	server = GetCVar("realmName");
	if not server or server == "" then
		DEFAULT_CHAT_FRAME:AddMessage("|CFFCC33FFArmory QuickLink:|r Couldn't find server!");
		return;
	end
		
	if not (string.lower(zone) == "eu" or string.lower(zone) == "us") then
		DEFAULT_CHAT_FRAME:AddMessage("|CFFCC33FFArmory QuickLink:|r ["..string.upper(zone).."] is not a supported Realm List.");
		return;
	end
	
	if not ArmoryQL_Config.ArmoryID then
		ArmoryQL_Config.ArmoryID = 1;
	end
	
	if ArmoryQL_Config.ArmoryID == 1 then -- Blizzard
		if zone == "us" then
			tempurl = "http://www"..Armories[ArmoryQL_Config.ArmoryID].base..server.."&n=";
		elseif zone == "eu" then
			tempurl = "http://eu"..Armories[ArmoryQL_Config.ArmoryID].base..server.."&n=";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..name;
		end
	elseif ArmoryQL_Config.ArmoryID ==2 then -- ArmoryLite
		if zone == "us" or zone == "eu" then
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..string.lower(zone).."/"..string.lower(server).."/";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..string.lower(name);
		end
	elseif ArmoryQL_Config.ArmoryID ==3 then -- BeImba
		if zone == "us" or zone == "eu" then
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base.."zone="..string.upper(zone).."&realm="..server.."&character=";
		else
			tempurl = nil
		end
		if tempurl then
			url = tempurl..name;
		end
	elseif ArmoryQL_Config.ArmoryID ==4 then -- WoWArmoryLight
		if zone == "us" or zone == "eu" then
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..string.lower(zone).."/"..string.lower(server).."/";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..name;
		end
	elseif ArmoryQL_Config.ArmoryID ==5 then -- Warcrafter
		if zone == "us" or zone == "eu" then
			local lserver = string.gsub(server, "([^A-Za-z]", "")
			tempurl = "http://"..string.lower(lserver).."-"..string.lower(zone)..Armories[ArmoryQL_Config.ArmoryID].base;
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..name;
		end
	elseif ArmoryQL_Config.ArmoryID ==6 then -- WoW heroes
		if zone == "us" or zone == "eu" then
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..string.lower(zone).."&server="..server.."&name=";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..name;
		end
	elseif ArmoryQL_Config.ArmoryID ==7 then -- quickarmory
		if zone == "eu" then
			server = string.upper(zone).."-"..server;
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..name.."&r=";
		elseif zone == "us" then
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..name.."&r=";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..server;
		end
	elseif ArmoryQL_Config.ArmoryID ==8 then -- pugchecker
		if zone == "eu" or zone == "us" then
			server = server.."-"..string.upper(zone);
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base..name.."&server=";
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl..server;
		end
	elseif ArmoryQL_Config.ArmoryID ==9 then -- trackwarcraft
		if zone == "eu" or zone == "us" then		
			server = string.lower(server);
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base.. zone .. "/" .. server .. "/" .. name;
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl;
		end
	elseif ArmoryQL_Config.ArmoryID ==10 then -- elitist armory
		if zone == "eu" or zone == "us" then		
			zone = string.upper(zone);
			tempurl = Armories[ArmoryQL_Config.ArmoryID].base.. zone .. "/" .. server .. "/" .. name;
		else
			tempurl = nil;
		end
		if tempurl then
			url = tempurl;
		end
	end
	
	if url then
		url = urlEscape(url);
	end 
	
	return url;
end

local function ShowUrl(name)
	if not name then return end
	local url = constructUrl(name);
	if url then
		if (not ChatFrameEditBox:IsShown()) then
			ChatFrameEditBox:Show();
			ChatFrameEditBox:Insert(url);
		else
			ChatFrameEditBox:Insert(url);
		end
		ChatFrameEditBox:HighlightText();
	end
end

hooksecurefunc("UnitPopup_HideButtons", function(self)
	local dropdownMenu = UIDROPDOWNMENU_INIT_MENU
	for k,v in pairs(UnitPopupMenus[dropdownMenu.which]) do
		if v == "AQL" then 
			UnitPopupShown[k] = (dropdownMenu.name == UnitName("player") and 0) or 1 
		end
	end
end)

hooksecurefunc("UnitPopup_OnClick", function(self)
	local dropdownFrame = UIDROPDOWNMENU_INIT_MENU
	local button = self.value
	if button == "AQL" then
		ShowUrl(dropdownFrame.name);
	end
end)


local pName;
local AQLMenuTable = {{text = "QuickLink", checked = nil, notCheckable = 1, func = function() ShowUrl(pName) end,},}
local AQLDropDownMenu = CreateFrame("Frame", "AQLDropDownMenu", nil, "UIDropDownMenuTemplate")

do
	for i=1, NUM_LFR_LIST_BUTTONS do
			_G["LFRBrowseFrameListButton"..i]:HookScript("OnMouseUp", function(self, button) 
				if button == "RightButton" then 
					pName = _G["LFRBrowseFrameListButton"..self:GetID().."Name"]:GetText();
					EasyMenu(AQLMenuTable, AQLDropDownMenu, self, 50, 0, "MENU", 3)
				end
			end);
	end
end

local function ArmoryQuickLink_Help()
	DEFAULT_CHAT_FRAME:AddMessage("|CFFCC33FFArmory QuickLink|r: /aql x (selects profiler)");
	for i=1,#(Armories) do
		DEFAULT_CHAT_FRAME:AddMessage(Armories[i].label);
	end
end

local function ArmoryQuickLink_Slash(cmd)
	if not cmd or cmd == "" then
		ArmoryQuickLink_Help();
		return;
	end
	local id = tonumber(cmd);
	if not id then
		ArmoryQuickLink_Help();
		return;
	end
	if not Armories[id] then
		ArmoryQuickLink_Help();
		return;
	end
	ArmoryQL_Config.ArmoryID = id;
	DEFAULT_CHAT_FRAME:AddMessage("|CFFCC33FFArmory QuickLink|r - "..Armories[id].label);
end

SLASH_ARMORYQUICKLINK1 = "/armoryquicklink";
SLASH_ARMORYQUICKLINK2 = "/aql";
SlashCmdList["ARMORYQUICKLINK"] = ArmoryQuickLink_Slash;