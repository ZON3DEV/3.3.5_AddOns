BagSaver will help you keep your bags as clean as possible.
I wrote this addon after having enough of my bags being full as I'm levelling/doing dailies/instancing. The goal of the addon will be to keep your bag slots clear of things you don't want, and assist you when your bag does somehow become full in finding the optimal (read: least valuable) item to discard to make room for something better.

All suggestions and feature requests are welcome!

Current features are:
Automated selling of gray items whenever a vendor window is opened
Automated selling of soulbound items that could not ever be equipped (i.e. quest reward staff taken by a Rogue to sell)
Automated selling of soulbound armor that is below your primary armor type (cloth, leather, mail, plate)
Finding the least valuable stack in your inventory for youwhen your bags are full and need a slot for new loot. 

Future features are:
Integration with economy addons for computing item value

Slash commands (/bagsaver or /bs):
/bs config:	Open addon config menu (also found in Addon tab in Blizzard's Interface menu)
/bs reset:	Resets your config to defaults


ChangeLog:
0.4.1
--------------------------------
Updated TOC for 3.3
Added display of total value of sold items after auto-sell

0.4
--------------------------------
Final release of 0.4b2

0.4b2
--------------------------------
There were potential bugs with how BagSaver displayed the least valuable items in your inventory. These bugs have been fixed.
Least valuable item windows will now close when a slot opens up in your inventory.

0.4b
--------------------------------
New feature: BagSaver can now sell soulbound armor that is below your primary armor type (cloth, leather, mail, plate), off by default
Revision of least valuable stack feature: Now will only show you least valuable gray and white stack
BagSaver now displays the value of any item it sells or shows to you
Minor code refactoring/cleanup

0.3.1
--------------------------------
Improved implementation of Least Valuable stack feature:
Now shows three least valuable items
Does not use inflexible frame tech =)

0.3
--------------------------------
Initial implementation of finding the least valuable stack in your inventory for you to discard when your bags are full

0.2
--------------------------------
Proper release of previous betas
Made config UI a little more swizzy - dependent option checkboxes will disable themselves when their dependant option is disabled

0.2b2
--------------------------------
Weapon type identification was slightly off for daggers, wands, fishing poles, etc. This has been fixed.
Addon incorrectly thought Hunters can use wands. This has been fixed.

0.2b1
--------------------------------
Items are now listed and sold in order of rarity, from least rare (gray) to most rare. This will make it easier to buy back something of value that you didn't mean to sell.

0.2b
--------------------------------
Implemented the ability to consider soulbound items you could never use as junk for auto-selling
Refactored original code
Made inventory searching ignore items with no sell cost

0.1
--------------------------------
Initial release
Supports auto-sell of gray items to vendor
Basic config menu implemented