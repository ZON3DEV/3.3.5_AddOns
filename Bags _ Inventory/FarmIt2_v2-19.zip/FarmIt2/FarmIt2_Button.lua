﻿--------------------------------------------------------------------------------
--  BUTTON RELATED CODE
--
--[[
	The goal of this code is to have the item buttons be autonomous units.
	We want the mod to be as flexible as possible.

	inherits="ItemButtonTemplate"
]]--
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Button.lua loaded."); end


--------------------------------------------------------------------------------
--  TOOLTIP
--------------------------------------------------------------------------------
function FI_Tooltip( self )
	local bid = FI_FrameToID( self:GetName() );
	if FI_DEBUG then print("You hovered button ID: "..bid); end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	if button.item then
		GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");

		local sName, sLink, iQuality, iLevel, iMinLevel, sType, sSubType, iStackSize = GetItemInfo(button.item);
		if sLink then
			GameTooltip:SetHyperlink(sLink);
			
			if not IsAddOnLoaded("iTip") then
				GameTooltip:AddLine("\n"..sType.." ("..sSubType..")");
				GameTooltip:AddLine("Stack Size:  "..iStackSize, 1,1,1);
				GameTooltip:AddLine("Item Level "..iLevel, 1,1,1);
				GameTooltip:AddLine("Item ID:  "..button.item, 1,1,1);
			end
		end
		
		GameTooltip:AddLine("\n".."Bank Included:  "..strupper(tostring(button.bank)));
		if (button.objective > 0) then
			GameTooltip:AddLine("Objective Complete:  "..strupper(tostring(button.success)));
		end
		GameTooltip:AddLine("Button ID:  "..button.id, 1,1,1);
		
		GameTooltip:Show();
	end
end


--------------------------------------------------------------------------------
--  MOUSE CLICK!
--------------------------------------------------------------------------------
function FI_Click( self, click, down )
	local f_name = self:GetName();
	if FI_DEBUG then print("You CLICKED the "..click.." ("..tostring(down)..") on frame: "..f_name); end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = FI_FrameToID(f_name)}, true);

	if CursorHasItem() then
		------------------------------------------------------------
		-- NEW ITEM
		------------------------------------------------------------
		local itemType, itemID, itemLink = GetCursorInfo();
		if (itemType == "item") then
			-- save new item to button record
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {item = itemID});
			-- apply data to slot
			FI_SetButton(button.id);
			-- clear item from cursor
			ClearCursor();
		end

	elseif (click == "LeftButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- INCLUDE BANK
			------------------------------------------------------------
			FI_ToggleBank(button.id);
		
		elseif IsControlKeyDown() then
			------------------------------------------------------------
			-- SET OBJECTIVE
			------------------------------------------------------------
			FI_EditObjective(button.id);
		
		elseif FI_SELECTED then
			------------------------------------------------------------
			-- MOVE
			------------------------------------------------------------
			if (button.id == FI_SELECTED) then
				-- cancel the selection (same slot was clicked)
				FI_Deselect();
			else
				FI_MoveItem(FI_SELECTED, button.id);
			end
			
		elseif button.item then
			------------------------------------------------------------
			-- SELECT ITEM
			------------------------------------------------------------
			FI_Select(button.id);
		end

	elseif (click == "RightButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- CLEAR SLOT
			------------------------------------------------------------
			if button.item then
				FI_ClearButton(button.id);
				PlaySound("gsTitleOptionOK");
			end

		else
			------------------------------------------------------------
			-- USE ITEM
			------------------------------------------------------------
			-- Right-click "use" action on actual item is handled by SecureActionButton_OnClick()
			-- See FarmIt2_Button.xml, FI_ButtonFrames, and FI_SetButton
			if button.item then
				-- make sure we actually have the item in our inventory
				if GetItemSpell(button.item) and (GetItemCount(button.item) > 0) then
					-- inform user that Right-Click action was received
					local itemName, itemLink = GetItemInfo(button.item);
					if itemLink then
						FI_Message("Using "..itemLink);
					end
				end
			end
		end
	end
	-- /mouse buttons
end

--------------------------------------------------------------------------------
--  ITEM BUTTON STUFFS
--------------------------------------------------------------------------------
function FI_SetButton( bid, newItem )
	local button;
	
	-- update itemID before setting button elements
	if newItem then
		FI_ClearButton(bid);
		button = FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {item = newItem});
	else
		button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	end
	
	if button.item then
		local f_name = "FI_Button_"..button.id;

		-- set secure template action
		local itemName = GetItemInfo(button.item); --if this fails, FI_UpdateButton should fix it
		if itemName then
			_G[f_name]:SetAttribute("macrotext", "/use "..itemName);
		end
		
		-- set icon
		_G[f_name.."_Icon"]:SetTexture( GetItemIcon(button.item) ); --if this fails, FI_UpdateButton should fix it

		-- bank inclusion indicator
		if button.bank then
			-- yellowness (not to be confused with darkness, then redness, then whiteness)
			_G[f_name.."_Count"]:SetVertexColor(FI_SV_CONFIG.Bank.color[1], FI_SV_CONFIG.Bank.color[2], FI_SV_CONFIG.Bank.color[3]);
		end
		
		-- set objective?
		if (button.objective == 0) or CursorHasItem() then
			-- no objective in data -or- we are in the middle of placing a new item
			FI_ClearObjective(button.id);
		elseif (button.objective > 0) then
			-- there is an objective in the data, apply it to the interface
			FI_SetObjective(button.id);
		end
		
		FI_UpdateButton(button.id);

		if FI_DEBUG then
			local itemName, itemLink = GetItemInfo(button.item);
			print( "FI_SetButton:  Button ID "..button.id.." set to "..itemLink );
		end
	end
end

function FI_ClearButton( bid )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	-- reset button data
	local i = FI_DB.find(FI_SVPC_DATA.Buttons, {id = button.id}, true);
	FI_SVPC_DATA.Buttons[i] = table.copy(FI_DEFAULTS.DB.Button);
	-- preserve the ID's
	FI_SVPC_DATA.Buttons[i]["id"] = button.id;
	FI_SVPC_DATA.Buttons[i]["group"] = button.group;

	FI_ClearObjective(button.id);
	
	-- reset graphical elements
	local f_name = "FI_Button_"..button.id;
	_G[f_name.."_Icon"]:SetTexture("");
	_G[f_name.."_Count"]:SetText(0);
	_G[f_name.."_Count"]:SetVertexColor(1,1,1);
	
	-- clear secure template action
	_G[f_name]:SetAttribute("macrotext", nil);
end

function FI_Select( bid )
	-- copy to "clipboard"
	FI_SELECTED = bid;

	PlaySound("igAbilityIconPickup");

	-- selection indicator
	_G["FI_Button_"..FI_SELECTED.."_Glow"]:Show();

	if FI_DEBUG then print("Button ID #"..bid.." SELECTED for moving..."); end
end

-- pass true to disable sound
function FI_Deselect( mute )
	-- turn off selection indicator
	_G["FI_Button_"..FI_SELECTED.."_Glow"]:Hide();

	-- clear the "clipboard"
	FI_SELECTED = false;

	if not mute then
		PlaySound("igAbilityIconDrop");
	end
end

-- added in v2.0 beta2
function FI_MoveItem( bid1, bid2 )
	FI_MOVING = true;
	
	local source = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid1}, true);
	local target = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid2}, true);

	-- move the selected button data
	if FI_DEBUG then print("FI_MoveItem:  Moving ItemID "..source.item); end
	FI_DB.copy(FI_SVPC_DATA.Buttons, {id = source.id}, {id = target.id}); --preserves the primary key ("id" field)
	-- make sure the destination button keeps its *group* id
	FI_DB.update(FI_SVPC_DATA.Buttons, {id = target.id}, {group = target.group});
	
	-- load new button data in destination (target) slot
	FI_SetButton(target.id);
	
	-- clear original (source) button
	FI_ClearButton(source.id);

	-- swapping contents with a populated button?
	if target.item then
		if FI_DEBUG then print("FI_MoveItem:  Swapping places with ItemID "..target.item); end
		
		-- get table index of source button
		local index = FI_DB.find(FI_SVPC_DATA.Buttons, {id = source.id}, true);

		-- copy target button data over source button
		FI_SVPC_DATA.Buttons[index] = table.copy(target);
		-- keep the original IDs so things dont get all discombobulated (technical term)
		FI_SVPC_DATA.Buttons[index]["id"] = source.id;
		FI_SVPC_DATA.Buttons[index]["group"] = source.group;

		-- load button data
		FI_SetButton(source.id);
	end
	
	FI_Deselect();
	
	FI_MOVING = false;
end

--------------------------------------------------------------------------------
--  BANK INVENTORY
--------------------------------------------------------------------------------
function FI_ToggleBank( bid )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	local f_name = "FI_Button_"..button.id;
	
	if button.item then
		-- change setting
		button = FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {bank = FI_Toggle(button.bank)});

		-- use banky color if true
		if button.bank then
			_G[f_name.."_Count"]:SetVertexColor(1,1,0);
		else
			_G[f_name.."_Count"]:SetVertexColor(1,1,1);
		end

		-- refresh item count
		FI_UpdateButton(button.id);
		
		PlaySound("TalentScreenClose");
		FI_Message("ButtonID "..button.id..":  Include Bank = "..strupper(tostring(button.bank)));
	end
end

--------------------------------------------------------------------------------
--  PROGRESS TRACKING
--------------------------------------------------------------------------------
function FI_Progress( button, silent )
	if FI_DEBUG then print("Progress tracking triggered on ButtonID: "..button.id.." (previous count: "..button.lastcount..", new count: "..button.count..")"); end
	local error_msg = "Progress notification FAILED on ButtonID "..button.id.." due to missing itemLink!";
	local debug_msg = "";

	local f_name = "FI_Button_"..button.id;
	local notify,throttle,message,color,sound;
	
	-- OBJECTIVE PROGRESS
	if (button.objective > 0) then
		notify = FI_SV_CONFIG.Objective.notify;
		
		if (button.count < button.objective) then
			throttle = true;
			debug_msg = "LESS THAN";
			color = FI_SV_CONFIG.Objective.color;
			
			-- reset notification flag
			if button.success then
				button = FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {success = false});
			end
			-- update interface
			_G[f_name.."_Objective"]:SetVertexColor(color[1], color[2], color[3]);
			
			local itemName, itemLink = GetItemInfo(button.item);
			if itemLink then
				-- notification format
				message = "Farming progress:  "..itemLink.." ("..button.count.."/"..button.objective..")";
			elseif FI_DEBUG then
				print(error_msg);
			end
			
		elseif (button.count >= button.objective) and (button.success == false) then
			throttle = false;
			debug_msg = "EQUAL OR GREATER THAN";
			color = FI_SV_CONFIG.Objective.color2;
			sound = "QUESTCOMPLETED";
			
			-- update notification flag
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {success = true});
			-- update interface
			_G[f_name.."_Objective"]:SetVertexColor(color[1], color[2], color[3]);

			local itemName, itemLink = GetItemInfo(button.item);
			if itemLink then
				-- notification format
				message = "Farming for "..itemLink.." complete! ("..button.objective.."/"..button.objective..")";
			elseif FI_DEBUG then
				print(error_msg);
			end
		
		else
			-- greater than objective, already notified
			throttle = true;
			debug_msg = "GREATER THAN";
			color = FI_SV_CONFIG.Objective.color2;
			
			-- check notification flag
			if (button.success == false) then
				button = FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {success = true});
			end
			-- update interface
			_G[f_name.."_Objective"]:SetVertexColor(color[1], color[2], color[3]);

			local itemName, itemLink = GetItemInfo(button.item);
			if itemLink then
				-- notification format
				message = "Farming progress:  "..itemLink.." ("..button.count.."/"..button.objective..")";
			elseif FI_DEBUG then
				print(error_msg);
			end
		end
		
		-- set color of numeric text on button
		--_G[f_name.."_Objective"]:SetVertexColor(color[1], color[2], color[3]);
	
	-- STANDARD PROGRESS
	elseif (button.count > button.lastcount) then
		throttle = true;
		notify = FI_SV_CONFIG.Progress.notify;
		color = FI_SV_CONFIG.Progress.color;
		
		local itemName, itemLink = GetItemInfo(button.item);
		if itemLink then
			message = "Farming progress:  "..itemLink.."x"..button.count;
		elseif FI_DEBUG then
			print(error_msg);
		end
	end
	
	if notify and not silent then
		local bid;
		if throttle then bid = button.id; else bid = nil; end
		
		FI_Notify(message, color, sound, bid);
	end

	-- insert log entry
	local log_entry = {
		["item"] = button.item, --PK (not unique)
		["timestamp"] = time(), --seconds since "epoch"
		--["count"] = GetItemCount(button.item), --store "pure" count (no bank) for consistent farming data lines
	}
	table.insert(FI_SV_DATA.Log, log_entry);

	if FI_DEBUG then print("FI_Progress:  Item quantity "..button.count.." is "..debug_msg.." objective ("..button.objective..") for BID "..button.id); end
end

-- expects a button id, and (optionally) an editbox object
function FI_SetObjective( bid, editbox, amount )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	if button.item then
		local input = false;
		local duplicate = false;

		-- capture input if present
		if editbox then
			input = editbox:GetNumber();
		elseif amount then
			input = tonumber(amount);
			if FI_DEBUG then print("FI_SetObjective:  Command line input = "..input); end
		end

		-- set new objective
		if input then
			if (input == button.objective) then
				duplicate = true;
				if FI_DEBUG then print("FI_SetObjective:  Duplicate objective ("..input.." == "..button.objective..") for ButtonID "..bid); end
			else
				button = FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {objective = input});
				if FI_DEBUG then print("FI_SetObjective:  "..input.." for ButtonID "..bid); end
			end
		end
		
		if (duplicate == false) then
			local f_name = "FI_Button_"..button.id;
			local message,sound;
			local color = {1,1,1};
			
			if (button.objective > 0) then
				-- update interface
				_G[f_name.."_Objective"]:SetText(button.objective);
				_G[f_name.."_Objective"]:Show();
				
				if FI_SV_CONFIG.Objective.notify and (FI_LOADING == false) then
					local itemName, itemLink = GetItemInfo(button.item);
					if itemLink then
						message = "Farming objective set:  "..itemLink.."x"..button.objective;
						sound = "QUESTADDED";
					elseif FI_DEBUG then
						print("'Objective Set' notification FAILED on ButtonID "..button.id.." due to missing itemLink!");
					end
				end
			else
				-- update interface
				_G[f_name.."_Objective"]:SetText(0);
				_G[f_name.."_Objective"]:Hide();

				if editbox then
					-- inform user we are erasing an objective
					if button.success then
						message = "Farming objective removed.";
						sound = false;
					else
						message = "Farming objective abandoned.";
						sound = "igQuestLogAbandonQuest";
					end
				end
			end
			
			-- check current progress
			FI_Progress(button, true);
			
			if FI_SV_CONFIG.Objective.notify then
				-- display notification
				FI_Notify(message, color, sound);
			end
		end
	end
end

function FI_EditObjective( bid )
	-- hide other edit boxes
	for i,b in ipairs(FI_SVPC_DATA.Buttons) do
		_G["FI_Button_"..b.id.."_Edit"]:Hide();
	end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	local f_name = "FI_Button_"..button.id;

	-- set editbox to current value
	_G[f_name.."_Edit"]:SetText(button.objective);

	-- show editbox
	_G[f_name.."_Edit"]:Show();
	_G[f_name.."_Edit"]:HighlightText();
end

function FI_ClearObjective( bid )
	local f_name = "FI_Button_"..bid;
	local color = FI_SV_CONFIG.Objective.color;

	-- reset objective related data
	FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {objective = 0, success = false});

	-- reset graphical elements
	_G[f_name.."_Objective"]:SetText(0);
	_G[f_name.."_Objective"]:SetVertexColor(color[1], color[2], color[3]);
	_G[f_name.."_Objective"]:Hide();
end
