if GetLocale() ~= "esES" then return end
MrPlowGlobalStrings = {
	["Armor"] = "Armor",
	["Consumable"] = "Consumable",
	["Container"] = "Container",
	["Gem"] = "Gem",
	["Key"] = "Key",
	["Miscellaneous"] = "Miscellaneous",
	["Projectile"] = "Projectile",
	["Quest"] = "Quest",
	["Quiver"] = "Quiver",
	["Reagent"] = "Reagent",
	["Recipe"] = "Recipe",
	["Trade Goods"] = "Trade Goods",
	["Weapon"] = "Weapon",
}
