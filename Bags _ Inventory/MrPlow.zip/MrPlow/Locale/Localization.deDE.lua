local L = LibStub("AceLocale-3.0"):NewLocale("MrPlow", "deDE")
if not L then return end

L["Armor"] = "Rüstung"
L["Consumable"] = "Verbrauchbar"
L["Container"] = "Behälter"
L["Gem"] = "Gem" -- Needs review
L["Key"] = "Schlüssel"
L["Miscellaneous"] = "Verschiedenes"
L["Projectile"] = "Projektil"
L["Quest"] = "Quest"
L["Quiver"] = "Köcher"
L["Reagent"] = "Reagenz"
L["Recipe"] = "Rezept"
L["Trade Goods"] = "Handwerkswaren"
L["Weapon"] = "Waffe"


