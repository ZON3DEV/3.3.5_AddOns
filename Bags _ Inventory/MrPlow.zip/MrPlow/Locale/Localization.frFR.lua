local L = LibStub("AceLocale-3.0"):NewLocale("MrPlow", "frFR")
if not L then return end

L["Armor"] = "Armure"
L["Consumable"] = "Consommables"
L["Container"] = "Sac"
L["Gem"] = "Gemme"
L["Key"] = "Clé"
L["Miscellaneous"] = "Divers"
L["Projectile"] = "Projectile"
L["Quest"] = "Quête"
L["Quiver"] = "Carquois"
L["Reagent"] = "Réactif"
L["Recipe"] = "Recette"
L["Trade Goods"] = "Fournitures d'artisanat"
L["Weapon"] = "Arme"

