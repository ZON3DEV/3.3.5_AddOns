-- Looters Mana Potion Data

LooterManas = {
	[2455] = true, -- Minor Mana Potion
	[3385] = true, -- Lesser Mana Potion
	[3827] = true, -- Mana Potion
	[6149] = true, -- Greater Mana Potion
	[13443] = true, -- Superior Mana Potion
	[13444] = true, -- Major Mana Potion
	[22832] = true, -- Super Mana Potion
	[33448] = true -- Runic Mana Potion
}