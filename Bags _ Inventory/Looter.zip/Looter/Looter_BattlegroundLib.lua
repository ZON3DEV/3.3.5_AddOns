-- Looters Battleground Data

LooterBattleground = {
	[17642] = true, -- Alterac Ram Hide
	[17643] = true, -- Frostwolf Hide
	[17542] = true, -- Coldtooth Supplies
	[17522] = true, -- Irondeep Supplies
	[17306] = true, -- Stormpike Soldier's Blood
	[17422] = true, -- Armor Scraps
	[17326] = true, -- Stormpike Soldier's Flesh
	[17504] = true, -- Frostwolf Commander's Medal
	[17327] = true, -- Stormpike Lieutenant's Flesh
	[17328] = true, -- Stormpike Commander's Flesh
	[17502] = true, -- Frostwolf Soldier's Medal
	[17503] = true, -- Frostwolf Lieutenant's Medal
	[17423] = true, -- Storm Crystal
	[18148] = true -- Skull of Korrak
}