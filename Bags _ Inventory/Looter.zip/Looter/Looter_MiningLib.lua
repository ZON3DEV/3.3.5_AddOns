-- Looter Mining Data

LooterMining = {
	-- Ores & Stones(Mining)
	[2770] = true, -- Copper Ore
	[2771] = true, -- Tin Ore
	[2775] = true, -- Silver Ore
	[2772] = true, -- Iron Ore
	[2776] = true, -- Gold Ore
	[3858] = true, -- Mithril Ore
	[10620] = true, -- Thorium Ore
	[7911] = true, -- Truesilver Ore
	[23424] = true, -- Fel Iron Ore
	[23425] = true, -- Adamantine Ore
	[23426] = true, -- Khorium Ore
	[23427] = true, -- Eternium Ore
	[36909] = true, -- Cobalt Ore
	[36912] = true, -- Saronite Ore
	[36910] = true, -- Titanium Ore
	
	[2835] = true, -- Rough Stone
	[2836] = true, -- Coarse Stone
	[2838] = true, -- Heavy Stone
	[7912] = true, -- Solid Stone
	[12365] = true -- Dense Stone
}