-- Looters Health Potion Data

LooterHealths = {
	[118] = true, -- Minor Healing Potion
	[858] = true, -- Lesser Healing Potion
	[929] = true, -- Healing Potion
	[1710] = true, -- Greater Healing Potion
	[3928] = true, -- Superior Healing Potion
	[13446] = true, -- Major Healing Potion
	[22829] = true, -- Super Healing Potion
	[33447] = true -- Runic Healing Potion 
}