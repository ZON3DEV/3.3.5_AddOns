-- Looters Extra Profession Data

LooterGeneralProfession = {
	-- Herbalism
	[9262] = true, -- Black Vitriol
	-- Firstaid
	[1475] = true, -- Small Venom Sac
	[1288] = true, -- Large Venom Sac
	[19441] = true, -- Huge Venom Sac
	-- Tailoring
	[3182] = true, -- Spider's Silk
	[4337] = true, -- Thick Spider's Silk
	[10285] = true, -- Shadow Silk
	[14227] = true, -- Ironweb Spider Silk
	[21881] = true, -- Netherweb Spider Silk
	-- Leatherworking
	[4289] = true, -- Salt
	[8150] = true, -- Deeprock Salt
	-- General
	[7069] = true, -- Elemental Air
	[7067] = true, -- Elemental Earth
	[7068] = true, -- Elemental Fire
	[7070] = true, -- Elemental Water
	[7081] = true, -- Breath of Wind
	[7075] = true, -- Core of Earth
	[7079] = true, -- Globe of Water
	[7077] = true, -- Heart of Fire
	[10286] = true, -- Heart of the Wild
	[7972] = true, -- Ichor of Undeath
	[7082] = true, -- Essence of Air
	[7076] = true, -- Essence of Earth
	[7078] = true, -- Essence of Fire
	[12808] = true, -- Essence of Undeath
	[7080] = true, -- Essence of Water
	[12803] = true, -- Living Essence
	[22451] = true, -- Primal Air
	[22452] = true, -- Primal Earth
	[21884] = true, -- Primal Fire
	[21886] = true, -- Primal Life
	[22457] = true, -- Primal Mana
	[22456] = true, -- Primal Shadow
	[21885] = true, -- Primal Water
	[22572] = true, -- Mote of Air
	[22573] = true, -- Mote of Earth
	[22574] = true, -- Mote of Fire
	[22575] = true, -- Mote of Life
	[22576] = true, -- Mote of Mana
	[22577] = true, -- Mote of Shadow
	[22578] = true, -- Mote of Water
	[35623] = true, -- Eternal Air
	[35624] = true, -- Eternal Earth
	[36860] = true, -- Eternal Fire
	[35625] = true, -- Eternal Life
	[35627] = true, -- Eternal Shadow
	[35622] = true, -- Eternal Water
	[37700] = true, -- Crystalized Air
	[37701] = true, -- Crystalized Earth
	[37702] = true, -- Crystalized Fire
	[37704] = true, -- Crystalized Life
	[37703] = true, -- Crystalied Shadow
	[37705] = true -- Crystalized Water
}