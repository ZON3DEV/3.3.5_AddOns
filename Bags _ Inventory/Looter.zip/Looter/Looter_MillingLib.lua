-- Looters milling (inscription) Data

LooterMilling = {
	[39151] = true, -- Alabaster Pigment
	[39334] = true, -- Dusky Pigment
	[43103] = true, -- Verdant Pigment
	[39338] = true, -- Golden Pigment
	[43104] = true, -- Burnt Pigment
	[39339] = true, -- Emerald Pigment
	[43105] = true, -- Indigo Pigment
	[39340] = true, -- Violet Pigment
	[43106] = true, -- Ruby Pigment
	[39341] = true, -- Silvery Pigment
	[43107] = true, -- Sapphire Pigment
	[39342] = true, -- Nether Pigment
	[43108] = true, -- Ebon Pigment
	[39343] = true, -- Azure Pigment
	[43109] = true -- Icy Pigment
}