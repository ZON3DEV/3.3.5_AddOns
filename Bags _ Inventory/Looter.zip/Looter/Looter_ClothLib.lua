-- Looters Cloth Data

LooterCloths = {
	-- Cloths (Tailoring)
	[2589] = true, -- Linen Cloth
	[2592] = true, -- Wool Cloth
	[4306] = true, -- Silk Cloth
	[4338] = true, -- Mageweave Cloth
	[14256] = true, -- Felcloth
	[14047] = true, -- Runecloth
	[14342] = true, -- Mooncloth
	[21877] = true, -- Netherweave Cloth
	[33470] = true -- Frostweave Cloth
}