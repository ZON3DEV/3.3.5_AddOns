local function vaultTip(tip)
        local _, link = tip:GetItem()

        if VaultDB:find("[-]"..link:gmatch("item:(%d+):")().."[-]") then
                tip:AppendText("|n|cffee55eeVault Protected|r|n ")
        else    tip:AppendText("|n ") end
end

LibStub("LibTipHooker-1.1"):Hook(vaultTip, "item")