Vault.InterfaceOptionsFrame_Hide_Hook = InterfaceOptionsFrame.Hide

Vault.Options                         = {
        type                          = "group",
        args                          = {
                add_name              = {
                        order         = 1,
                        type          = "header",
                        name          = "Add Vault Item"
                },
                add_desc              = {
                        order         = 2,
                        type          = "description",
                        name          = "Drag an item from your inventory and click on the button below to add the icon to your vault. You can dismiss the icon from your cursor after that by pressing escape."
                },
                add_desc_blank        = {
                        order         = 3,
                        type          = "description",
                        name          = " "
                },
                add_item              = {
                        order         = 4,
                        type          = "execute",
                        name          = "Drag an item here and click to add it.",
                        width         = "full",
                        desc          = "",
                        descStyle     = "inline",
                        func          = function()
                                local type, _, link = GetCursorInfo()

                                if type == "item" and link then
                                        if VaultDB:find("[-]"..link:gmatch("item:(%d+):")().."[-]") then
                                                Vault.Options.args.add_item.name = "That item's in your vault already!"

                                                return

                                        end

                                        Vault.Overseer(link, IsAltKeyDown())

                                        Vault.Options.args.add_item.name = "Item successfully added!"
                                else
                                        Vault.Options.args.add_item.name = "Grab an item first!"
                                        Vault.Intercom("", "There is no item attached to your cursor.")
                                end
                        end
                },
                add_footer            = {
                        order         = 5,
                        type          = "description",
                        name          = " "
                },
                remove_name           = {
                        order         = 6,
                        type          = "header",
                        name          = "Remove Vault Item"
                },
                remove_desc           = {
                        order         = 7,
                        type          = "description",
                        name          = "Click on an item name in the list below to remove that item from your vault."
                },
                remove_item           = {
                        order         = 8,
                        type          = "select",
                        style         = "radio",
                        name          = "",
                        width         = "full",
                        values        = function()
                                Vault.TempDB = {}

                                for item in VaultDB:gmatch("%d+") do
                                        Vault.TempDB[item] = GetItemInfo(item)
                                end

                                return Vault.TempDB
                        end,
                        set         = function(_, key)
                                Vault.TempDB[key] = nil

                                VaultDB = "-"

                                for key in pairs(Vault.TempDB) do
                                        VaultDB = VaultDB..key.."-"
                                end

                                Vault.TempDB = nil
                        end
                },
                remove_footer         = {
                        order         = 9,
                        type          = "description",
                        name          = " "
                },
                wipe_name             = {
                        order         = 10,
                        type          = "header",
                        name          = "Empty Vault"
                },
                wipe_desc             = {
                        order         = 11,
                        type          = "description",
                        name          = "WARNING: By clicking the button below you will remove every item from this character's vault."
                },
                wipe_desc_blank       = {
                        order         = 12,
                        type          = "description",
                        name          = " "
                },
                wipe                  = {
                        order         = 13,
                        type          = "execute",
                        width         = "full",
                        desc          = "",
                        descStyle     = "inline",
                        func          = function()
                                Vault.Options.args.wipe.name = "Your vault is now empty!"

                                Vault.Purge()
                        end
                },
                wipe_footer           = {
                        order         = 14,
                        type          = "description",
                        name          = " "
                },
                restore_name          = {
                        order         = 15,
                        type          = "header",
                        name          = "Restore Backup"
                },
                restore_desc          = {
                        order         = 16,
                        type          = "description",
                        name          = "Clicking this button will restore your vault from a backup."
                },
                restore_desc_blank    = {
                        order         = 17,
                        type          = "description",
                        name          = " "
                },
                restore               = {
                        order         = 18,
                        type          = "execute",
                        name          = "Click here to restore the backup.",
                        width         = "full",
                        desc          = "",
                        descStyle     = "inline",
                        func          = function()
                                Vault.Options.args.restore.name = "Backup restored!"

                                Vault.Restore()
                        end
                }
        }
}

function InterfaceOptionsFrame.Hide(object)
	Vault.TempDB                     = nil
        Vault.Options.args.add_item.name = "Drag an item here and click to add it."
        Vault.Options.args.wipe.name     = "Click here to empty the vault."
        Vault.Options.args.restore.name  = "Click here to restore the backup."

        Vault.InterfaceOptionsFrame_Hide_Hook(object)        
end

LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("Vault", Vault.Options)
LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Vault", "Vault")