function Vault.Commander(text)
        if text == "wipe" then Vault.Purge()

        elseif text == "restore" then Vault.Restore()

        elseif not text or not text:find("Hitem") or text == "help" then
                Vault.Intercom("", "The slash command is used in the following way:")
                Vault.Intercom("/vault [Item Link]", " - adds or removes an item from the vault, acting as a toggle.")
                Vault.Intercom("/vault check [Item Link]", " - checks whether an item is in your vault.")
                Vault.Intercom("/vault wipe", " - empties your character's vault of all item entries.")
                Vault.Intercom("/vault restore", " - restores your vault from its last backup state.")
                Vault.Intercom("/vault help", " - displays this help information.")

        elseif text:find("Hitem") and text:find("check") then
                text = text:gsub("check ", "")

                Vault.Overseer(text, true)

        else Vault.Overseer(text) end
end

SLASH_VAULT1       = "/vault"
SlashCmdList.VAULT = Vault.Commander