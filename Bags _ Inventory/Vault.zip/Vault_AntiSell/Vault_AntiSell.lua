function Vault.MERCHANT_UPDATE()
        if GetNumBuybackItems() == 0 then return end

        for i = 1, GetNumBuybackItems() do
                local _, name = GetItemInfo(GetBuybackItemInfo(i))
                local id      = name:gmatch("item:(%d+):")()

                if VaultDB:find("[-]"..id.."[-]") then
                        Vault.Intercom(name, " was bought back by your vault, as it's protected.")

                        BuybackItem(i)
                end
        end
end

Vault:RegisterEvent"MERCHANT_UPDATE"
