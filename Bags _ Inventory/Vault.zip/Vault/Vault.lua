Vault = CreateFrame("Button", "Vault")

function Vault.Intercom(item, text)
        DEFAULT_CHAT_FRAME:AddMessage("|cffee3333Vault:|r "..item.."|cffeeee33"..text.."|r")
end

function Vault.Purge()
        VaultDB = "-"

        Vault.Intercom("", "The vault has been emptied of all items.")
end

function Vault.Restore()
        VaultDB = VaultDB_Backup

        Vault.Intercom("", "Your vault has been restored from backup.")
end

function Vault.Overseer(link, check)
        local id = link:gmatch("item:(%d+):")()

        if check then
                Vault.Intercom(link, " "..(VaultDB:find("[-]"..id.."[-]") and "is" or "is not").." in your vault.")

        elseif VaultDB:find("[-]"..id.."[-]") then
                VaultDB = VaultDB:gsub("[-]"..id.."[-]", "-")

                Vault.Intercom(link, " has been removed from your vault.")

        else    VaultDB = VaultDB..id.."-"

                Vault.Intercom(link, " now rests safely within your vault.")
        end
end

function Vault.ADDON_LOADED(arg)
        if arg == "Vault" then
                VaultDB = VaultDB or "-"

                if VaultDB:sub(-string.len("-")) == "-" then else
                        VaultDB = VaultDB.."-"
                end

                VaultDB_Backup = VaultDB
        end
end

Vault:RegisterEvent"ADDON_LOADED"
Vault:SetScript("OnEvent", function(_, event, arg) Vault[event](arg) end)