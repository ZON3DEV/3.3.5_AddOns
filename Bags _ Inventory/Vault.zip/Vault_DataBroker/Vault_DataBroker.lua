Vault.LDB     = LibStub("LibDataBroker-1.1"):NewDataObject("Broker - Vault", {
        icon  = "Interface\\Icons\\INV_Box_04.png",
        type  = "launcher"
})

function Vault.RenderTooltip(hide)
        Vault.Tooltip:Clear()
        if hide then Vault.Tooltip:Hide() end

        Vault.Tooltip:AddLine("|cffffff00Vault: A DataBroker Plugin|r")
        Vault.Tooltip:AddLine(" ")

        if VaultDB == "" or VaultDB == nil or VaultDB == "-" then
                Vault.Tooltip:AddLine("|cff8888eeThere is nothing currently in your vault.|r")
                Vault.Tooltip:AddLine(" ")

        else    Vault.Tooltip:AddLine("|cff8888eeItems in your vault:|r")

                for item in VaultDB:gmatch("%d+") do
                        Vault.Tooltip:AddLine(select(2, GetItemInfo(item)))
                end

                Vault.Tooltip:AddLine(" ")
        end

        Vault.Tooltip:AddLine("|cff69b950Drag & Click:|r |cffeeeeeeAdd/Remove vault protection for an item.|r")
        Vault.Tooltip:AddLine("|cff69b950Alt + Click:|r |cffeeeeeeClear the vault (remove all items).|r")
        Vault.Tooltip:AddLine("|cff69b950Alt + Shift + Click:|r |cffeeeeeeRestore the last vault backup.|r")
end

function Vault.LDB.OnEnter(tip)
        Vault.Tooltip = LibStub"LibQTip-1.0":Acquire("VaultTip", 1, "LEFT")

        Vault.Tooltip:SetAutoHideDelay(.1, tip)

        Vault.RenderTooltip(true)

        Vault.Tooltip:EnableMouse()
        Vault.Tooltip:SmartAnchorTo(tip)
        Vault.Tooltip:UpdateScrolling()
        Vault.Tooltip:Show()
end

function Vault.LDB.OnLeave() return end

function Vault.LDB.OnClick()
        if IsAltKeyDown() and not IsShiftKeyDown() then Vault.Purge() Vault.RenderTooltip() return end
        if IsAltKeyDown() and IsShiftKeyDown() then Vault.Restore() Vault.RenderTooltip() return end

        local type, _, link = GetCursorInfo()

        if type == "item" and link then Vault.Overseer(link, IsAltKeyDown()) Vault.RenderTooltip()

        else Vault.Intercom("", "There is no item attached to your cursor.") end
end