Vault.StaticPopup_Show_Hook = StaticPopup_Show

function StaticPopup_Show(name, text, other)
	if name == "DELETE_ITEM" or name == "DELETE_GOOD_ITEM" then
	        local type, _, link = GetCursorInfo()

                if type == "item" and link and VaultDB:find("[-]"..link:gmatch("item:(%d+):")().."[-]") then
                        Vault.Intercom(link, " was not destroyed, as it is in your vault.") return
			ClearCursor()
                end
        end

        return Vault.StaticPopup_Show_Hook(name, text, other)
end