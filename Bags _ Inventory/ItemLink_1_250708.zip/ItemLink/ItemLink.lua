function ItemLink_RequestLink(itemid)
	local itemName, itemLink = GetItemInfo( itemid )
	if( itemLink ) then
		return itemLink, itemName
	else
		return 0
	end
end

function ItemLink_Search(query)
	i=0
	found = 0
	query = string.lower(query)
	DEFAULT_CHAT_FRAME:AddMessage("|cffcba300Searching for items containing search string '"..query.."'.|r ", .5, .5, 1.0) 
	while i<500000 do
		linky, name = ItemLink_RequestLink(i)
		if linky ~= 0 then
			if string.find(string.lower(name), query) then
				DEFAULT_CHAT_FRAME:AddMessage("|cC0C0C000Item: ".. linky .. "|r ", .5, .5, 1.0) 
				found = found + 1
			end
		end
		i = i + 1
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cffcba300Search completed, "..found.." items matched.|r ", .5, .5, 1.0) 
end

function ItemLink_Command(msg)
	if tonumber(msg) then
		link = ItemLink_RequestLink(tonumber(msg))
		if link == 0 then
			DEFAULT_CHAT_FRAME:AddMessage("|cffcba300Item ID not found in local cache.|r ", .5, .5, 1.0) 
		else
			DEFAULT_CHAT_FRAME:AddMessage("|cffcba300Item: "..link .. "|r ", .5, .5, 1.0) 
		end
	else
		ItemLink_Search(msg)
	end
end

function ItemLink_OnLoad()
	SLASH_ILINK1 = "/link"
	SLASH_ILINK2 = "/itemlink"
	SlashCmdList["ILINK"] = ItemLink_Command
	DEFAULT_CHAT_FRAME:AddMessage("|cffcba300ItemLink v1.0 Loaded!|r ", .5, .5, 1.0) 
end

