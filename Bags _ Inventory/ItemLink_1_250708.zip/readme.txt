ItemLink addon, v1.0
Created by Chiropteran of Alonsus, EU

Reason:
I wrote this addon up after fruitlessly searching for a small, light-weight tool that could do something 
extremely basic: searching and presenting a list of items based on a partial item name. Since then I have grown
quite dependent of it, and as it might be useful to others I have decided to release it to the public.

Installation:
Installation is as easy as it could be, drag the 'ItemLink' folder into your WoW\Interface\Addons directory. 
It does not require any additional addons to run.

Usage:
Ingame, type "/link " or "/itemlink ", followed by the search term (partial or full item name) into your chat line. 
After some serious database crunching it will return a list of all found matches, including the total amount of 
matched items.
While idle the addon uses virtually no memory or CPU power at all. When actually searching for items this can
spike quite a bit, even leading to the game freezing up for a few seconds on occasion. This is simply because it
forcefully reads the entire local item cache, searching for potential matches. This could probably have been done
better or more efficiently, at the cost of higher memory and cpu usage. This was not my intention - I tried to 
keep it as light-weight as possible while idling away in the background.

NOTE: ItemLink will only find items that are present in the local item cache. Items that are not there (ie. items 
that you have never seen yet) will therefore not be found.