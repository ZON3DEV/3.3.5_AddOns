-- --------------	--------------
--	SuperLoot
-- 	by Strucker of Kilrogg
-- ----------------------------
local SuperLoot = LibStub('AceAddon-3.0'):NewAddon('SuperLoot', 'AceTimer-3.0', 'AceEvent-3.0', 'AceConsole-3.0')
_G.SuperLoot = SuperLoot;
local p, r, x, y = "TOP", "BOTTOM", 0, -3;
local buttonHeight = LootButton1:GetHeight() + abs(y);
local baseHeight = LootFrame:GetHeight() - (buttonHeight * LOOTFRAME_NUMBUTTONS);
local lootingAll = false
local lootButtonFrame;
local lootScrollFrame;
local lootButtonCount = 1;
local scrollMax;
local defaults = {
	global = {
		shrink = true,
		maxVisibleButtonCount = 6,
		scale = .7,
		showmenu = true,
		p1 = "CENTER",
		p2 = "CENTER",
		x = 0,
		y = 0,
		borderColor = {r = 1,b = 0,g = 0,a = 1},
		backgroundColor = {r = 1,b = 0,g = 0,a = 1},
		supressAllBoPWarnings = false,
		supressAllDEWarnings = false,
		destroyGreyItems = false,
	}
}
local visibleButtonCount;
local menuFrame;
local db;

function LootSlotIsCurrency(slot)
	return false
end

function SuperLoot_DragStop(frame) 
	GetScrollFrame():StopMovingOrSizing(); 
	db.global.x = GetScrollFrame():GetLeft() * GetScrollFrame():GetEffectiveScale();
	db.global.y = GetScrollFrame():GetTop() * GetScrollFrame():GetEffectiveScale();
	db.global.p1 = "TOPLEFT";
	db.global.p2 = "BOTTOMLEFT";
	SuperLoot:ApplySettings()
end

function SuperLoot_DragStart(frame) 
	GetScrollFrame():StartMoving(); 
end

local function UpdateScrollFrameSize()
	lootScrollFrame:SetWidth(154)
	lootScrollFrame:SetHeight((SuperLootButton1:GetHeight()+abs(y))*visibleButtonCount)
	lootScrollFrame.slider:SetSize(12, lootScrollFrame:GetHeight()+4)
	lootScrollFrame.slider:SetValue(0)
end

function SuperLoot:OnInitialize()
	db = LibStub('AceDB-3.0'):New('SuperLootDB', defaults, 'Default')
	visibleButtonCount = db.global.maxVisibleButtonCount
	LootFrame:UnregisterEvent("LOOT_SLOT_CLEARED")
	LootFrame:UnregisterEvent("LOOT_OPENED")
	LootFrame:UnregisterEvent("LOOT_CLOSED")
	
	local clearedEventframe = CreateFrame("Frame")
	clearedEventframe:RegisterEvent("LOOT_SLOT_CLEARED")
	clearedEventframe:SetScript("OnEvent", SuperLootFrame_Update)

	local openedEventframe = CreateFrame("Frame")
	openedEventframe:RegisterEvent("LOOT_OPENED")
	openedEventframe:SetScript("OnEvent", SuperLootFrame_Show)
	
	local closedEventframe = CreateFrame("Frame")
	closedEventframe:RegisterEvent("LOOT_CLOSED")
	closedEventframe:SetScript("OnEvent", SuperLootFrame_Hide)

	local bindEventframe = CreateFrame("Frame")
	bindEventframe:RegisterEvent("LOOT_BIND_CONFIRM")
	bindEventframe:SetScript("OnEvent", SuperLootFrame_Bind)

	local rollEventframe = CreateFrame("Frame")
	rollEventframe:RegisterEvent("CONFIRM_LOOT_ROLL")
	rollEventframe:SetScript("OnEvent", SuperLootFrame_RollBind)
	
	local deRollEventframe = CreateFrame("Frame")
	deRollEventframe:RegisterEvent("CONFIRM_DISENCHANT_ROLL")
	deRollEventframe:SetScript("OnEvent", SuperLootFrame_RollDE)
	
	local lootReceivedEventframe = CreateFrame("Frame")
	lootReceivedEventframe:RegisterEvent("CHAT_MSG_LOOT")
	lootReceivedEventframe:SetScript("OnEvent", SuperLootFrame_LootReceived)
	
	local openingEventframe = CreateFrame("Frame")
	openingEventframe:RegisterEvent("CHAT_MSG_OPENING")
	openingEventframe:SetScript("OnEvent", function(a,b,c) end)
	
	
	
	
	self:RegisterChatCommand("sl", "SlashCommand")
	self:RegisterChatCommand("superloot", "SlashCommand")
	self:ApplySettings();
	
	self:RegisterOptions();
end 

function SuperLoot:ApplySettings()
	if db.global.showmenu then
		GetMenuFrame():Show();
	else
		GetMenuFrame():Hide();
	end
	GetScrollFrame():SetScale(db.global.scale);
	GetScrollFrame():ClearAllPoints();
	local tx = db.global.x / GetScrollFrame():GetEffectiveScale();                  
	local ty = db.global.y / GetScrollFrame():GetEffectiveScale();  
	GetScrollFrame():SetPoint(db.global.p1, nil, db.global.p2, tx, ty);
	visibleButtonCount = db.global.maxVisibleButtonCount;
	
	local color = db.global.borderColor;
	GetScrollFrame().borderFrame:SetBackdropBorderColor(color.r, color.g, color.b, color.a);
	GetMenuFrame():SetBackdropBorderColor(color.r, color.g, color.b, color.a);
	local color = db.global.backgroundColor;
	GetScrollFrame().texture:SetTexture(color.r, color.g, color.b, color.a);
	GetMenuFrame().texture:SetTexture(color.r, color.g, color.b, color.a);
	
	UpdateScrollFrameSize();
	if GetScrollFrame():IsVisible() then
		SuperLootFrame_Update();
	end
end

function GetMenuFrame()
	if (not menuFrame) then
		menuFrame = CreateFrame('Frame', "SuperLootMenuFrame", GetScrollFrame(), 'SuperLootMenuFrame')
		menuFrame:SetPoint("Top", GetScrollFrame(), "Bottom", 0,3)
	end
	return menuFrame
end

-- Almost identical to the default method by the same name, 
-- except that it collapses the items to prevent empty item slots preceding full ones.
function SuperLootFrame_Update()
	--ViragDevTool_AddData(GetTrueNumLootItems(), "SuperLootFrame_Update");
	if db.global.shrink then
		visibleButtonCount = min(db.global.maxVisibleButtonCount,GetTrueNumLootItems())	
		UpdateScrollFrameSize()
	end
	for index = 1, max(lootButtonCount,GetTrueNumLootItems()) do 
		SetButtonItem(index,SlotNumberToItemNumber(index));
	end
	GetButtonFrame():SetHeight((SuperLootButton1:GetHeight()+abs(y))*GetTrueNumLootItems())
	scrollMax = floor(GetButtonFrame():GetHeight() - GetScrollFrame():GetHeight())
	if scrollMax > 0 then
		GetScrollFrame().slider:SetValue(min(GetScrollFrame().slider:GetValue(),scrollMax))
		GetScrollFrame().slider:SetMinMaxValues(0, scrollMax)
		GetScrollFrame().slider:Show()
	else
		scrollMax = 0
		GetScrollFrame().slider:SetValue(0)
		GetScrollFrame().slider:SetMinMaxValues(0, 0)
		GetScrollFrame().slider:Hide()
	end

	if GetTrueNumLootItems() == 0 then
		SuperLootFrame_Hide()
	end
end  

function SuperLootFrame_Hide()
	GetScrollFrame():Hide()
end

function SuperLootFrame_Show()
	if ( GetCVar("lootUnderMouse") == "1" ) then                  
		-- position loot window under mouse cursor
		local x, y = GetCursorPosition();
		x = x / GetScrollFrame():GetEffectiveScale();
		y = y / GetScrollFrame():GetEffectiveScale();
		GetScrollFrame():ClearAllPoints();
		GetScrollFrame():SetPoint("TOPLEFT", nil, "BOTTOMLEFT", x, y);
		GetScrollFrame():GetCenter();
		GetScrollFrame():Raise();
	end            
	
	GetScrollFrame():Show()
	GetScrollFrame().slider:SetValue(0);
	SuperLootFrame_Update();
end

function SuperLootFrame_Bind(frame,event,slot)
	if db.global.supressAllBoPWarnings or (lootingAll and lootingAll > 0) then
		StaticPopup_Hide("LOOT_BIND")
		SuperLoot:ScheduleTimer(ConfirmLootSlot, .1,slot)
		if lootingAll and lootingAll ~= 0 then		
			SuperLoot:ScheduleTimer(SuperLoot_LootAll, .2)
		end
	end
end

local function ConfirmRoll(args)
	ConfirmLootRoll(args[1],args[2])
end

function SuperLootFrame_RollBind(frame,event,id,rollType)
	if db.global.supressAllBoPWarnings then
		StaticPopup_Hide("CONFIRM_LOOT_ROLL")
		SuperLoot:ScheduleTimer(ConfirmRoll, .1,{[1]=id,[2]=rollType})
	end
end

function SuperLootFrame_RollDE(frame,event,id,rollType)
	if db.global.supressAllDEWarnings then
		StaticPopup_Hide("CONFIRM_DISENCHANT_ROLL")
		SuperLoot:ScheduleTimer(ConfirmRoll, .1,{[1]=id,[2]=rollType})
	end
end

local function DeleteItem(itemID)
	for b = 0, 4 do
		for s = 1, GetContainerNumSlots(b) do
			if itemID == tostring(GetContainerItemID(b, s) or -1) then
				PickupContainerItem(b, s);
				DeleteCursorItem();
				return
			end
		end
	end
end

function SuperLootFrame_LootReceived(frame, event, msg)
	if db.global.destroyGreyItems and string.find(msg, "You receive loot") then
		local _,_,itemID = string.find(string.match(msg, "You receive loot: (.+)%."), ".*|Hitem:(%d+):.*");
		local _,_,quality = GetItemInfo(itemID)
		if quality == 0 then
			SuperLoot:ScheduleTimer(DeleteItem, .5,itemID)
		end
	end
end

function SuperLoot_LootAll()
	local count = GetNumLootItems()
	if  count > 0 and lootingAll ~=	count then
		lootingAll = count
		local lootmethod, masterlooterPartyID, masterlooterRaidID = GetLootMethod()
		if lootmethod == "master" then
			for ci = 1, 40 do
				if (GetMasterLootCandidate(ci) == UnitName("player")) then
					for li = 1, GetNumLootItems() do
						GiveMasterLoot(li, ci);
					end
				end
			end		
		else
			for i = count,1,-1 do
				LootSlot(i)	
			end
		end
	else
		lootingAll = 0
	end
end

function SetButtonItem(buttonIndex,itemIndex)
	local button = GetButton(buttonIndex);
	if ( itemIndex <= GetNumLootItems() ) then
		local texture, item, quantity, quality, locked = GetLootSlotInfo(itemIndex);
		button.quantity = quantity
		local color = ITEM_QUALITY_COLORS[quality];
		getglobal("SuperLootButton"..buttonIndex.."IconTexture"):SetTexture(texture);
		local text = getglobal("SuperLootButton"..buttonIndex.."Text");
		text:SetText(item);
		if( locked ) then
			SetItemButtonNameFrameVertexColor(button, 1.0, 0, 0);
			SetItemButtonTextureVertexColor(button, 0.9, 0, 0);
			SetItemButtonNormalTextureVertexColor(button, 0.9, 0, 0);
		else
			SetItemButtonNameFrameVertexColor(button, 0.5, 0.5, 0.5);
			SetItemButtonTextureVertexColor(button, 1.0, 1.0, 1.0);
			SetItemButtonNormalTextureVertexColor(button, 1.0, 1.0, 1.0);
		end
		if (color) then
			text:SetVertexColor(color.r, color.g, color.b);
		end
		local countString = getglobal("SuperLootButton"..buttonIndex.."Count");
		if quantity and quantity > 1 then
			countString:SetText(quantity);
			countString:Show();
		else
			countString:Hide();
		end
		button.slot = itemIndex;
		button.quality = quality;
		button:Show();
	else
		button:Hide();
	end
end

function GetScrollFrame()
	if not lootScrollFrame then
		lootScrollFrame = CreateFrame("ScrollFrame","SuperLootScrollFrame")
		lootScrollFrame:SetPoint(db.global.p1, nil, db.global.p2, db.global.x, db.global.y)
		lootScrollFrame:SetFrameStrata("DIALOG")
		lootScrollFrame:SetMovable(true)
		lootScrollFrame:EnableMouse(true)
		lootScrollFrame:RegisterForDrag("LeftButton")
		lootScrollFrame:SetClampedToScreen(true)
		lootScrollFrame.texture = lootScrollFrame:CreateTexture("bg", "BACKGROUND", "ActionBarButtonTemplate");
		lootScrollFrame.texture:SetPoint("TOPLEFT", lootScrollFrame ,"TOPLEFT", 0, -1);
		lootScrollFrame.texture:SetPoint("BOTTOMRIGHT", lootScrollFrame ,"BOTTOMRIGHT", 0, 1);
		lootScrollFrame:SetScript("OnDragStart", SuperLoot_DragStart)
		lootScrollFrame:SetScript("OnDragStop", SuperLoot_DragStop)
		lootScrollFrame:SetScale(db.global.scale)
		lootScrollFrame:SetScrollChild(GetButtonFrame())
		lootScrollFrame.borderFrame = CreateFrame("ScrollFrame","SuperLootScrollBorderFrame",lootScrollFrame)
		lootScrollFrame.borderFrame:SetFrameLevel(8)
		lootScrollFrame.borderFrame:SetPoint("TOPLEFT",lootScrollFrame,"TOPLEFT",-3,3)
		lootScrollFrame.borderFrame:SetPoint("BOTTOMRIGHT",lootScrollFrame,"BOTTOMRIGHT",3,-3)
		lootScrollFrame.borderFrame:SetBackdrop({bgFile = "", 
                                    edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                                    tile = true, tileSize = 16, edgeSize = 16, 
									insets = { left = 0, right = 0, top = 0, bottom = 0}});

		lootScrollFrame.slider = CreateFrame("Slider","SuperLootScrollSlider",lootScrollFrame)
		lootScrollFrame.slider.bg = lootScrollFrame.slider:CreateTexture(nil, "BACKGROUND")
		lootScrollFrame.slider.bg:SetAllPoints(true)
		lootScrollFrame.slider.bg:SetTexture(1,1,1, 0.1)
		lootScrollFrame.slider.thumb = lootScrollFrame.slider:CreateTexture(nil, "OVERLAY")
		lootScrollFrame.slider.thumb:SetTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
		lootScrollFrame.slider.thumb:SetSize(16, 16)
		lootScrollFrame.slider:SetThumbTexture(lootScrollFrame.slider.thumb)

		-- Set up the scrollbar to work properly
		scrollMax = 0
		lootScrollFrame.slider:SetOrientation("VERTICAL");
		lootScrollFrame.slider:SetSize(12, lootScrollFrame:GetHeight()+4)
		lootScrollFrame.slider:SetPoint("TOPRIGHT", lootScrollFrame, "TOPRIGHT", -1, 2)
		lootScrollFrame.slider:SetMinMaxValues(0, scrollMax)
		lootScrollFrame.slider:SetValue(0)
		lootScrollFrame.slider:SetScript("OnValueChanged", function(self)
			lootScrollFrame:SetVerticalScroll(self:GetValue())
		end)

		-- Enable mousewheel scrolling
		lootScrollFrame:EnableMouseWheel(true)
		lootScrollFrame:SetScript("OnMouseWheel", function(self, delta)
			local current = lootScrollFrame.slider:GetValue()
			if IsShiftKeyDown() and (delta > 0) then
				lootScrollFrame.slider:SetValue(0)
			elseif IsShiftKeyDown() and (delta < 0) then
				lootScrollFrame.slider:SetValue(scrollMax)
			elseif (delta < 0) and (current < scrollMax) then
				lootScrollFrame.slider:SetValue(current + 10)
			elseif (delta > 0) and (current > 1) then
				lootScrollFrame.slider:SetValue(current - 10)
			end
		end)
		
		UpdateScrollFrameSize()
		lootScrollFrame:Hide()
	end
	return lootScrollFrame
end

function GetButtonFrame()
	if not lootButtonFrame then
		lootButtonFrame = CreateFrame("Frame")
		local button = CreateFrame("Button", "SuperLootButton1", lootButtonFrame , "LootButtonTemplate")
		button:SetPoint("TOPLEFT", lootButtonFrame, "TOPLEFT", 2, -1)
		lootButtonFrame:SetSize(154,200)
		lootButtonFrame.bg = lootButtonFrame:CreateTexture(nil, "BACKGROUND")
		lootButtonFrame.bg:SetAllPoints(true)
		lootButtonFrame.bg:SetTexture(0,0,0, 1)
	end
	return lootButtonFrame
end

function GetButton(index)
	GetButtonFrame()
	local button = getglobal("SuperLootButton"..index);
	if not button then
		button = CreateFrame("Button", "SuperLootButton"..index, GetButtonFrame(), "LootButtonTemplate")
		button:ClearAllPoints()
		button:SetPoint(p, "SuperLootButton"..(index-1), r, 0, y)
		lootButtonCount = max(lootButtonCount,index)
	end
	return button
end

-- Replaces the default method to show the correct tooltip
function LootItem_OnEnter(self)
    if ( LootSlotIsItem(self.slot) ) then
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
		GameTooltip:SetLootItem(self.slot);
		CursorUpdate(self);
	end  
end 

-- Takes an uncollapsed slot number and returns the collapsed version.
function SlotNumberToItemNumber(slot)
	local x = 0
	for i = 1, GetNumLootItems() do
		if LootSlotIsItem(i) or LootSlotIsCoin(i) or LootSlotIsCurrency(i) then
			x = x + 1
			if(x == slot) then
				return i
			end
		end
	end
	return GetNumLootItems() + 1
end

-- Returns the number of Loots Items in the list that are not empty.
function GetTrueNumLootItems()
	local x = 0
	for i = 1, GetNumLootItems() do
		if LootSlotIsItem(i) or LootSlotIsCoin(i) or LootSlotIsCurrency(i) then
			x = x + 1
		end
	end
	return x
end

function SuperLoot:SlashCommand(info)
	if string.match(info,"height%s%d*") then
		local num = tonumber(string.match(info,"%d+"))
		if(num) then
			db.global.maxVisibleButtonCount = num;
			print("Super Loot: Height set to",num);
		end
	elseif string.match(info,"menu%shide") then
		db.global.showmenu = false;
		print("Super Loot: Menu hidden.");
	elseif string.match(info,"menu%sshow") then
		db.global.showmenu = true;
		print("Super Loot: Menu revealed.");
	elseif string.match(info,"shrink") then
		db.global.shrink = not db.global.shrink
		if (db.global.shrink) then
			print("Super Loot: Shrinking enabled.");
		else
			print("Super Loot: Shrinking disabled.");
		end
	elseif string.match(info,"reset") then
		db.global.shrink = true;
		db.global.showmenu = true;
		db.global.maxVisibleButtonCount = 4;
		db.global.scale = .7;
		db.global.p1 = "CENTER";
		db.global.p2 = "CENTER";
		db.global.x = 0;
		db.global.y = 0;
		print("Super Loot: Default settings restored.");
	elseif string.match(info,"scale%s%d*.*%d*") then
		local num = tonumber(string.match(info,"%s%d*.*%d*"))
		if num then
			db.global.scale = num
			print("Super Loot: Scale set to",num);
		end
	else
		print("Super Loot's Command List")
		print("     |cff3399FFscale #.#|r - Scales the size of the loot frame. (Default is 0.7)")
		print("     |cff3399FFmenu [show/hide]|r - Sets the visability of the menu frame at the bottom of the loot frame. (Shown by default)")
		print("     |cff3399FFshrink|r - Toggles whether or not the frame should shrink when there are less items to display then it can at once. (Enabled by default)")
		print("     |cff3399FFheight #|r - Sets the height of the loot frame to that which is required to display the given number of items. (Default is 4)")
		print("     |cff3399FFreset #|r - Restores all default settings.")
	end
	self:ApplySettings();
end

local function GetValue(info)
	return db.global[info.arg];
end

local function SetValue(info, value)
	db.global[info.arg] = value;
	SuperLoot:ApplySettings();
end

local function GetColorValue(info)
	local color = db.global[info.arg];
	return color.r, color.g, color.b, color.a;
end

local function SetColorValue(info, r, g, b, a)
	db.global[info.arg].r = r;
	db.global[info.arg].g = g;
	db.global[info.arg].b = b;
	db.global[info.arg].a = a;
	SuperLoot:ApplySettings();
end

local options = {
	name = 'Super Loot Frame',
	type = 'group',
	desc = 'Display an estimated kill time for your target, focus target and any mobs in the blizzard boss frames.',
	set = SetValue,
	get = GetValue,
	handler = SuperLoot,
	args = {
		["shrink"] = {
			name = "Hide Empty Slots",
			desc = "Shrink the loot window when there are not enough items to fill it.",
			type = 'toggle',
			width = 'full',
			order = 50,
			arg = 'shrink',
			disabled = false,
		},
		["suppressBoPConfirm"] = {
			name = "Suppress BoP Dialogs",
			desc = "Do not display 'Bind on Pickup' confirmation dialogs when looting or rolling on 'Bind on Pickup' items.",
			type = 'toggle',
			width = 'full',
			order = 75,
			arg = 'supressAllBoPWarnings',
			disabled = false,
		},
		["suppressDEConfirm"] = {
			name = "Suppress Disenchant Dialogs",
			desc = "Do not display disenchant confirmation dialogs when rolling to disenchant an item.",
			type = 'toggle',
			width = 'full',
			order = 85,
			arg = 'supressAllDEWarnings',
			disabled = false,
		},
		
		["destroyGreyLoot"] = {
			name = "Destroy Grey Items",
			desc = "Automatically destroy any grey quality items when they enter your bags.",
			type = 'toggle',
			width = 'full',
			order = 95,
			arg = 'destroyGreyItems',
			disabled = false,
		},
		["menuVisible"] = {
			name = "Show Menu Buttons",
			desc = "Display the 'Announce' and 'Loot All' buttons beneath your loot window.",
			type = 'toggle',
			width = 'full',
			order = 100,
			arg = 'showmenu',
			disabled = false,
		},
		["maxVisibleButtonCount"] = {
			name = "Max Visible Item Slots",
			desc = "The number of items to display at once in the loot window without scrolling.",
			type = 'range',
			min = 1, max = 10, step = 1, 
			order = 150,
			arg = 'maxVisibleButtonCount',
		},
		["BREAK1"] = {
			name = "",
			type = 'description',
			order = 200,
		},
		["scale"] = {
			name = "Scale",
			desc = "The size of the loot window and its contents.",
			type = 'range',
			min = .1, max = 2, step = .01 ,
			order = 250,
			arg = 'scale',
		}, 
		["borderColor"] = {
			name = "Border Color",
			desc = "The color of the loot window's border",
			type = 'color',
			hasAlpha = true,
			set = SetColorValue,
			get = GetColorValue,
			order = 550,
			width = 'full',
			arg = 'borderColor',
		},
		["backgroundColor"] = {
			name = "Background Color",
			desc = "The color of the loot window's background",
			type = 'color',
			hasAlpha = true,
			set = SetColorValue,
			get = GetColorValue,
			order = 750,
			width = 'full',
			arg = 'backgroundColor',
		},
	}
};

function SuperLoot:RegisterOptions()
	local global = LibStub('AceDBOptions-3.0'):GetOptionsTable(db);
	local registry = LibStub('AceConfigRegistry-3.0');
	local dialog = LibStub('AceConfigDialog-3.0');
	LibStub('AceConfig-3.0'):RegisterOptionsTable('Super Loot', options, {'Super Loot', 'Super Loot'});
	registry:RegisterOptionsTable('Super Loot Options', options);
	local main = dialog:AddToBlizOptions('Super Loot Options', 'Super Loot');
end