﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Inventory", "esMX" )

if not L then return end

L["Heroic"] = "Heroico"
L["Trash Mobs"] = "Enemigos basura"

