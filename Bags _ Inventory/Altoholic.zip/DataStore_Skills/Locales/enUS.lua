﻿local L = LibStub("AceLocale-3.0"):NewLocale("DataStore_Skills", "enUS", true, true)

if not L then return end

L["Professions"] = true
L["Secondary Skills"] = true
L["Riding"] = true
