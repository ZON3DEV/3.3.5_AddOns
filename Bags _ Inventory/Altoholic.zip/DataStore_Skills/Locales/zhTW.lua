﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Skills", "zhTW" )

if not L then return end

L["Professions"] = "專業技能"
L["Secondary Skills"] = "次要技能"
L["Riding"] = "騎術"