﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "zhTW" )

if not L then return end

L["Mail Expiry Warning"] = "郵件屆滿警告"
L["Scan mail body (marks it as read)"] = "掃描郵件內容 (標記為己讀取)"
L["Warn when mail expires in less days than this value"] = "當郵件屆滿少過此值的日數時發出警告"

