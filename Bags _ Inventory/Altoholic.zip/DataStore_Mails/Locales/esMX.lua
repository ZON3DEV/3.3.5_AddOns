﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "esMX" )

if not L then return end

L["Mail Expiry Warning"] = "Advertencia de expiración del correo"
L["Scan mail body (marks it as read)"] = "Analizar el contenido de los correos (marcarlos como leídos)"
L["Warn when mail expires in less days than this value"] = "Advertir cuando el correo expira en menos días que los indicados"

