﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore", "frFR" )

if not L then return end

L["Disabled"] = "Désactivée"
L["Enabled"] = "Activée"
L["Memory used for %d |4character:characters;:"] = "Mémoire utilisée pour %d |4personnage:personnages;:"

