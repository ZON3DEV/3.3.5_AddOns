﻿local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("DataStore", "enUS", true, debug)

L["Disabled"] = true
L["Enabled"] = true
L["Memory used for %d |4character:characters;:"] = true

