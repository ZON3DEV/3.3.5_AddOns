﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Crafts", "esES" )

if not L then return end

L["Broadcast my profession links to guild at logon"] = "Transmitir mis vínculos de profesión a la hermandad al iniciar sesión"
L["BROADCAST_PROFS_DISABLED"] = "Nada será enviado a todos. Al desactivar esta opción disminuye considerablemente el tráfico de red en el canal de hermandad."
L["BROADCAST_PROFS_ENABLED"] = "Los vínculos de profesión conocidos de tus alters serán enviados a la hermandad 5 segundos después de iniciar sesión."
L["BROADCAST_PROFS_TITLE"] = "Transmisión de Vínculos de Profesión"
L["Professions"] = "Profesiones"
L["Secondary Skills"] = "Habilidades secundarias"

