--[[
Copyright 2011 João Cardoso
Bagnon Scrap is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Bagnon Scrap.

Bagnon Scrap is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Bagnon Scrap is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Bagnon Scrap. If not, see <http://www.gnu.org/licenses/>.
--]]

local ItemSlot = Bagnon.ItemSlot
local SetQuality = ItemSlot.SetBorderQuality
local r, g, b = GetItemQualityColor(0)

function ItemSlot:SetBorderQuality(...)
	local link = select(7, self:GetItemSlotInfo())

	if link then
		local id = tonumber(strmatch(link, 'item:(%d+)'))
	
		if Scrap:IsJunk(id) then
			self.questBorder:Hide()
			self.border:SetVertexColor(r, g, b, self:GetHighlightAlpha())
			self.border:Show()
			return
		end
	end
	
	SetQuality(self, ...)
end

hooksecurefunc('Scrap_Hooks', function()
	for _,frame in pairs(Bagnon.frames) do
		frame.itemFrame:UpdateEverything()
	end
end)