--[[
Usefull info/tutorials found at the following URL's
http://www.wowwiki.com/Category:Interface_customization
http://www.wowwiki.com/Category:HOWTOs
http://www.wowwiki.com/World_of_Warcraft_API
http://www.wowwiki.com/Widget_API
http://www.wowwiki.com/Lua_functions
http://www.wowwiki.com/Events_%28API%29

Following might be usefull too:
http://www.wowwiki.com/Global_functions

My top Favorites (have been most useful) as this project has progressed
http://www.wowwiki.com/World_of_Warcraft_API
http://www.wowwiki.com/Widget_API
http://www.wowwiki.com/Lua_functions

Some Tutorials I have found that could be usefull
http://www.tentonhammer.com/node/26414
]]

-- Define variables That will get used in the WHOLE project
NeatFreakTitle = GetAddOnMetadata("neatfreak", "Title");
NeatFreakVersion = GetAddOnMetadata("neatfreak", "Version");
intMaxNumScrollLines = 14;
NeatFreakToolTipRColor = 0.9;
NeatFreakToolTipGColor = 0.4;
NeatFreakToolTipBColor = 0.0;

local NeatFreakBasicDescription = "Auto sorts/organizes bags, when you recieve/pick-up items.";
local NeatFreakDescription = "Description:" .. "\n" .. NeatFreakBasicDescription .. "  There are 2 main Sorting lists that determine how items should be organized.  The 1st is Account specific, nothing worse that having to setup ALL the same sorting settings for an alt.  The 2nd is Character specific, that takes priority over the Account specific settings.  Both lists start blank, and are completley configurable.";

-- Define/Setup the tables so can use them later
if (not NeatFreakOptions) or (NeatFreakOptions == nil) then NeatFreakOptions = {} end
if (not tableItemInfo) or (tableItemInfo == nil) then tableItemInfo = {} end
if (not tableCombinedSortItemList) or (tableCombinedSortItemList == nil) then tableCombinedSortItemList = {} end
if (not tableAccountSortItemList) or (tableAccountSortItemList == nil) then tableAccountSortItemList = {} end
if (not tableCharSortItemList) or (tableCharSortItemList == nil) then tableCharSortItemList = {} end

-- ============================================================================================================= --

local function NF_MB(pTypeMsg, pTheMsg)

--gColorDarkOrange = 0.9, 0.4, 0.0;  -- Color.new(255,140,0)  -- |cffFF6600 is real close too
--BrightYellow = 0.?, 0.?, 0.?;  -- Color.new(???,???,???)  -- |cFFFFFF00 or |c00FFFF00
--DarkGoldenrod = Color.new(184,134,11)  -- about 0.8, 0.5, 0.0
--OrangeRed = Color.new(255,69,0)
--Purple = Color.new(???,???,???)  -- 0.5, 0.5, 1.0
--3366FF -- a blue
--00FF33 -- a green

-- escape sequences (using the "|c" coloring)
-- The values following the |c are a color code in hexadecimal notation.
-- The first two digits are the alpha value. The following six are for red, green and blue.

	if (pTypeMsg == nil) then
		pTypeMsg = "chat";
	end
	pTypeMsg = strlower(pTypeMsg);

	if pTypeMsg == "popup" then
		message( pTheMsg );
	end

	if NeatFreakOptions.ShutUp == 1 and NeatFreakOptions.Debugging == 0 then
		return
	end

	if pTypeMsg == "chat" then
		DEFAULT_CHAT_FRAME:AddMessage( pTheMsg, NeatFreakToolTipRColor, NeatFreakToolTipGColor, NeatFreakToolTipBColor );
	end

end

-- ============================================================================================================= --

function NeatFreak_OnLoad()

	-- local intNumTabs   -- needs to be global for the tab onclick function

	-- Setup Hooks for ALT key
	NeatFreak_SetupHookFunctions();

	-- Following updates the Main Title Bar
	NeatFreakTitleText:SetText(NeatFreakTitle .. " " .. NeatFreakVersion);
	AccountRadio:SetChecked(1);
	StoreByNameRadioButton:SetChecked(1);

	-- Configure/Setup Bottom Tabs --
		-- Following updates the Tab Text
		-- NeatFreakTab1:SetText("Text")
		-- Following "Selects" the Tab
		-- NeatFreakTab1:Disable()
	intNumTabs = 3
	for i = 1, intNumTabs do
		local EachTab = getglobal("NeatFreakTab"..i)
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat","Show Tab#: " .. i)
		end
		-- Following "Un-Selects" the Tab
		EachTab:Enable()
		-- Then set tab to show
		EachTab:Show()
	end
	NeatFreakTab1:Disable()
	NeatFreakPageTitleText:SetText("Sort")

	-- Following code block is for/from the tabs based on the Char sheet
		---this.elapsed = 0;
		-- BuiltIn UI Tab Setup if using Char tabs template.  (MainFrame, #Tabs)
		---PanelTemplates_SetNumTabs(NeatFreak, 2);
		-- BuiltIn UI Tab Call
		---PanelTemplates_SetTab(NeatFreak, 1);

	-- Configure/Setup Right Tabs --
	NeatFreak_ShowHideRightTabs();

	-- Setup Slash Commands to watch for.  Not case sensitive --
	SLASH_NeatFreak1 = "/NeatFreak";
	SLASH_NeatFreak2 = "/NF";
	SlashCmdList["NeatFreak"] = HandleSlashCommands;

	--Check for Debugging addon loaded.
	bolCheck4Addon = false;
	strAllIKnowOf = ""
	tableDebuggingAddOns = {};
	-- tableDebuggingAddOns[ <directory name> ] = <AddOn Name>;
	tableDebuggingAddOns["!swatter"] = "Swatter";
	tableDebuggingAddOns["!improvederrorframe"] = "ImprovedErrorFrame";
	tableDebuggingAddOns["!buggrabber"] = "BugGrabber";
	for addon, name in pairs( tableDebuggingAddOns ) do
		strAllIKnowOf = strAllIKnowOf .. ", " .. name
		strCheck4Addon = IsAddOnLoaded( addon );  -- 1 for loaded nil for not
		if strCheck4Addon == nil then
			--NF_MB("chat", "Neat Freak detected that " .. name .. " is NOT loaded.  We recommend it to help catch errors, with ALL Addons you may have.");
		else
			--NF_MB("chat", "Neat Freak detected that " .. name .. " is loaded.");
			bolCheck4Addon = true;
		end
--[[
		local enabled = select(4, GetAddOnInfo(addon))
		if enabled then
			NF_MB("chat","|cffffaa11You are running "..name.."|r")
		end
]]
	end
	strAllIKnowOf = string.sub(strAllIKnowOf, 2)
	if bolCheck4Addon == false then
		NF_MB("chat", "Neat Freak detected that NO DEBUGGING Addon is loaded.  " .. strAllIKnowOf .. " are some I know of.");
	end

	-- UnRegister Events
	-- this:UnregisterEvent("ITEM_PUSH")

	-- Register the Events to Watch for.  Not Case Sensitive. --
	this:RegisterEvent("VARIABLES_LOADED");

	-- Start Sorting Events --
	this:RegisterEvent("ITEM_PUSH");
	--this:RegisterEvent("ITEM_LOCK_CHANGED");

	-- BAG_UPDATE may not be needed at all.
	this:RegisterEvent("BAG_UPDATE");
	-- End Sorting Events --

	-- Start Open/Close Bag Events --
	this:RegisterEvent("GUILDBANKFRAME_OPENED");
	this:RegisterEvent("BANKFRAME_OPENED");
	this:RegisterEvent("MAIL_SHOW");
	this:RegisterEvent("MERCHANT_SHOW");
	this:RegisterEvent("TRADE_SHOW");
	this:RegisterEvent("AUCTION_HOUSE_SHOW");

	this:RegisterEvent("GUILDBANKFRAME_CLOSED");
	this:RegisterEvent("BANKFRAME_CLOSED");
	this:RegisterEvent("MAIL_CLOSED");
	this:RegisterEvent("MERCHANT_CLOSED");
	this:RegisterEvent("TRADE_CLOSED");
	this:RegisterEvent("AUCTION_HOUSE_CLOSED");
	-- End Open/Close Bag Events --

end

-- ============================================================================================================= --

function NeatFreak_ShowHideRightTabs()

	NeatFreakRightTabs1Text:SetText("Sort All");
	NeatFreakRightTabs1.tooltip = NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORTALL;
	NeatFreakRightTabs2Text:SetText("Sort 0");
	NeatFreakRightTabs2.tooltip = NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT0;

	for i = 1, 4 do
		local strBagIsNamed = GetBagName( i );
		local EachRightTab = getglobal("NeatFreakRightTabs"..(i+2));
		local EachRightTabText = getglobal("NeatFreakRightTabs"..(i+2).."Text");

		EachRightTabText:SetText("Sort " .. i);

		if strBagIsNamed == nil or strBagIsNamed == "" then
			EachRightTab:Hide();
		else
			EachRightTab:Show();
			EachRightTab.tooltip = NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART1 .. i .. NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART2 .. "\n" .. strBagIsNamed;
		end
	end

end

-- ============================================================================================================= --

function NeatFreak_OnEvent(self, event, ...)
-- arg1 = the bag that has received the new item
-- arg2 = the path to the item's icon

	-- bolDidTrade, strBagPushedTo -> need to be global, as they track between Events
	local tempBagID

	-- Start Sorting Event Handlers --
	if not (bolDidTrade) or bolDidTrade == nil then
		bolDidTrade = false
	end
	if (string.upper(event) == "TRADE_SHOW") or (string.upper(event) == "TRADE_CLOSED") then
		bolDidTrade = true
	end
	if (string.upper(event) == "GUILDBANKFRAME_OPENED") or (string.upper(event) == "BANKFRAME_OPENED") or (string.upper(event) == "MAIL_SHOW") or (string.upper(event) == "MERCHANT_SHOW") or (string.upper(event) == "AUCTION_HOUSE_SHOW") or (string.upper(event) == "GUILDBANKFRAME_CLOSED") or (string.upper(event) == "BANKFRAME_CLOSED") or (string.upper(event) == "MAIL_CLOSED") or (string.upper(event) == "MERCHANT_CLOSED") or (string.upper(event) == "AUCTION_HOUSE_CLOSED") then
		bolDidTrade = false
	end

	if (string.upper(event) == "ITEM_PUSH") or (string.upper(event) == "BAG_UPDATE" and string.find(tostring(arg1), "-") ~= 1) then
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat","Neat Freak wants to sort, based on Event: " .. event);
			NF_MB("chat", "Bag " .. arg1 .. " got item" )
		end

		if bolDidTrade == true then
			arg1 = arg1 - 1
			bolDidTrade = false
		end

		-- Need to check bag # for double digits
		tempBagID = arg1
		if arg1 == 20 then
			tempBagID = 1
		end
		if arg1 == 21 then
			tempBagID = 2
		end
		if arg1 == 22 then
			tempBagID = 3
		end
		if arg1 == 23 then
			tempBagID = 4
		end
		if arg1 == 19 then
			tempBagID = 1
		end

		if (string.upper(event) == "ITEM_PUSH") then
			strBagPushedTo = tempBagID
		else
			if NeatFreakOptions.Debugging == 1 then
				if strBagPushedTo == nil then
					strBagPushedTo = "nothing"
				end
				NF_MB("chat", "Stored val is: " .. strBagPushedTo .. ",  modified val is: " .. tempBagID .. ", original val is: " .. arg1 .. ".");
			end
			if tempBagID == strBagPushedTo then
				CheckIfBagNeedsSorting( strBagPushedTo )
				strBagPushedTo = nil
			end
		end
	end
	-- End Sorting Event Handlers --

	-- Start Open/Close Bag Event Handlers --
	if NeatFreakOptions.EnableBags == 1 then
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak spotted event: " .. event);
		end

		if (string.upper(event) == "GUILDBANKFRAME_OPENED" and NeatFreakOptions.Guild == 1) or (string.upper(event) == "BANKFRAME_OPENED" and NeatFreakOptions.Bank == 1) or (string.upper(event) == "MAIL_SHOW" and NeatFreakOptions.Mail == 1) or (string.upper(event) == "MERCHANT_SHOW" and NeatFreakOptions.Merch == 1) or (string.upper(event) == "TRADE_SHOW" and NeatFreakOptions.Trade == 1) or (string.upper(event) == "AUCTION_HOUSE_SHOW" and NeatFreakOptions.Auct == 1) then
			OpenAllBags(true);
		end

		if (string.upper(event) == "GUILDBANKFRAME_CLOSED" and NeatFreakOptions.Guild == 1) or (string.upper(event) == "BANKFRAME_CLOSED" and NeatFreakOptions.Bank == 1) or (string.upper(event) == "MAIL_CLOSED" and NeatFreakOptions.Mail == 1) or (string.upper(event) == "MERCHANT_CLOSED" and NeatFreakOptions.Merch == 1) or (string.upper(event) == "TRADE_CLOSED" and NeatFreakOptions.Trade == 1) or (string.upper(event) == "AUCTION_HOUSE_CLOSED" and NeatFreakOptions.Auct == 1) then
			CloseAllBags();

			if IsBagOpen(0) then
				ToggleBackpack();
			end
		end
	end
	-- End Open/Close Bag Event Handlers --

	if string.upper(event) == "VARIABLES_LOADED" then
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak spotted event: " .. event);
		end

		-- ==== Per Account Options ==== --
		if (not NeatFreakOptions) or (NeatFreakOptions == nil) then NeatFreakOptions = {} end
		if (not NeatFreakOptions.EnableBags) then NeatFreakOptions["EnableBags"] = 1 end
		if (not NeatFreakOptions.Auct) then NeatFreakOptions["Auct"] = 1 end
		if (not NeatFreakOptions.Bank) then NeatFreakOptions["Bank"] = 1 end
		if (not NeatFreakOptions.Guild) then NeatFreakOptions["Guild"] = 1 end
		if (not NeatFreakOptions.Mail) then NeatFreakOptions["Mail"] = 1 end
		if (not NeatFreakOptions.Merch) then NeatFreakOptions["Merch"] = 1 end
		if (not NeatFreakOptions.Trade) then NeatFreakOptions["Trade"] = 1 end
		if (not NeatFreakOptions.Debugging) then NeatFreakOptions["Debugging"] = 0 end
		if (not NeatFreakOptions.Chat) then NeatFreakOptions["Chat"] = 0 end
		if (not NeatFreakOptions.HideGryphons) then NeatFreakOptions["HideGryphons"] = 1 end
		if (not NeatFreakOptions.HideMiniMapButton) then NeatFreakOptions["HideMiniMapButton"] = 0 end
		if (not NeatFreakOptions.MiniMapAngle) then NeatFreakOptions["MiniMapAngle"] = 133 end
		if (not NeatFreakOptions.MiniMapDistance) then NeatFreakOptions["MiniMapDistance"] = 9 end
		if (not NeatFreakOptions.NeatFreakBags) then NeatFreakOptions["NeatFreakBags"] = 0 end
		if (not NeatFreakOptions.SkipSoulbound) then NeatFreakOptions["SkipSoulbound"] = 0 end
		--if (not NeatFreakOptions.NumListItems) then NeatFreakOptions["NumListItems"] = intNeatFreakNumLineItemsShowing end
		if (not NeatFreakOptions.NumListItems) then NeatFreakOptions["NumListItems"] = 6 end
		if (not NeatFreakOptions.ShutUp) then NeatFreakOptions["ShutUp"] = 0 end

		-- ==== Per Account Sorting Table ==== --
		if (not tableAccountSortItemList) or (tableAccountSortItemList == nil) then tableAccountSortItemList = {} end

		-- ==== Per Character Sorting Table ==== --
		if (not tableCharSortItemList) or (tableCharSortItemList == nil) then tableCharSortItemList = {} end

		-- After Load of Saved Settings, update Interface
		table.foreach( NeatFreakOptions, function(k,v) if v == 1 or v == 0 then getglobal("NeatFreakOptionsPageCheckButton"..k):SetChecked(v) else getglobal("NeatFreakOptionsPageSlider" .. k):SetValue(v) end end )

		if NeatFreakOptions.HideGryphons == 1 then
			-- Hide Left and Right Griphions around Action Bar.
			MainMenuBarLeftEndCap:Hide()
			MainMenuBarRightEndCap:Hide()
		end

		PositionNeatFreakMiniMapIcon();

		SetScrollListForNumItemsToShow();

		-- Read the initial Sort lists and combine them
		CreateCombinedSortingList()

		local strVersion, strBuild, strDate, strTOCVersion = GetBuildInfo();
		DEFAULT_CHAT_FRAME:AddMessage( "Neat Freak Loaded, under WoW TOCver " .. strTOCVersion .. "." .. "\n" .. " Thank you for using Neat Freak.", NeatFreakToolTipRColor, NeatFreakToolTipGColor, NeatFreakToolTipBColor );
	end

end

-- ============================================================================================================= --

function CreateCombinedSortingList()

	-- clear current interface
	UpdateInterface("")

	-- Clean nil out of tables, from pre 0.7b versions
	for x = table.maxn(tableAccountSortItemList), 1, -1 do
		if tableAccountSortItemList[x] == nil then
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", x .. " is nil" );
			end
			table.remove(tableAccountSortItemList, x)
		end
	end
	for x = table.maxn(tableCharSortItemList), 1, -1 do
		if tableCharSortItemList[x] == nil then
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", x .. " is nil" );
			end
			table.remove(tableCharSortItemList, x)
		end
	end

	-- Read both tables (account, char) into one for scroll list
	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Acc table" );
	end
	table.foreach(tableAccountSortItemList, LoopThroughStoredSortingTables)

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Char table" );
	end
	table.foreach(tableCharSortItemList, LoopThroughStoredSortingTables)

	if (type(tableCombinedSortItemList)=="table") then
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Combined is table" );
		end
		-- Both tables are now loaded into one, so sort/group results
		tableCombinedSortItemList = SortTable( tableCombinedSortItemList );
	else
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Combined is not table" );
		end
	end

	--update/reload scroll list
	NeatFreakScrollBar_Update()

end

-- ============================================================================================================= --

function LoopThroughStoredSortingTables(k, v) 

	-- 1st call escentially passes in ("tableAccountSortItemList["ItemEntryNum"]" -> tableItemInfo)
	if (type(v) == "table") then
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Data to itterate is a table" )
		end
		tableItemInfo = {}
		table.foreach (v, LoopThroughStoredSortingTables)
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Add tableItemInfo to Combined table" )
		end
		-- tableCombinedSortItemList[tostring(k)] = v
		AddOrUpdateValuesToSortTable(tableCombinedSortItemList)
	else
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Itterate Data in to a table" )
			NF_MB("chat", k .. " -> " .. v )
		end

		-- 2nd call is the Item Info, so make table
		tableItemInfo[k] = v
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Done putting Data in to a table" )
		end
	end

end

-- ============================================================================================================= --

function AddOrUpdateValuesToSortTable(pTableToUpdate)
-- The values to add will be in tableItemInfo

	local WasFound, intEntryNum

	-- Check if new Entry is in the Table already
	WasFound = CheckIfItemIsInTable(pTableToUpdate)

	if WasFound == false then
		-- not found so get current size
		intEntryNum = table.getn(pTableToUpdate)
		intEntryNum = intEntryNum + 1
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "wasfound false " .. intEntryNum )
		end
	else
		intEntryNum = WasFound
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "wasfound true " .. intEntryNum )
		end
	end
	intEntryNum = tonumber(intEntryNum)

	-- add new Entry
	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", tableItemInfo["ItemName"] .. " found at " .. intEntryNum )
		NF_MB("chat", "add " .. tableItemInfo["ItemName"] .. " as entry # " .. intEntryNum )
	end
	pTableToUpdate[intEntryNum] = tableItemInfo

	-- clear tableItemInfo of the now old data
	tableItemInfo = {}

end

-- ============================================================================================================= --

function SortTable(pTable)

	local tableSorted = {}
	local strPreviousChar, str1stChar, bolDidInsert

	strPreviousChar = "";
	for k1, v1 in pairs(pTable) do
		str1stChar = strlower(string.sub(pTable[k1]["ItemName"], 1, 1));

		bolDidInsert = false;
		for k2, v2 in pairs(tableSorted) do
			if bolDidInsert == false then
				strPreviousChar = strlower(string.sub(tableSorted[k2]["ItemName"], 1, 1));
				if NeatFreakOptions.SortDesc == 1 then
					-- sorts Decending  (z to 0) ->   str1stChar > strPreviousChar
					if str1stChar > strPreviousChar then
						table.insert( tableSorted, k2, v1)
						bolDidInsert = true;
					end
				else
					-- sorts Ascending  (0 to z) ->   str1stChar < strPreviousChar
					if str1stChar < strPreviousChar then
						table.insert( tableSorted, k2, v1)
						bolDidInsert = true;
					end
				end
			end
		end

		if bolDidInsert == false then
			-- A catch all to add listing if not found match above
			table.insert( tableSorted, v1 )
		end
	end

	return tableSorted

end

-- ============================================================================================================= --

function CheckIfItemIsInTable(pTableToSearch)
-- Return False or The#OfTheEntry
-- The values to Search for/against will be in tableItemInfo (the item just picked up, or clicked in list)
-- Make Not CaseSensitive  --> strlower()

	local x, bolFound, intFound
	bolFound = false;

	-- loop through all until find result, or done all
	if (type(pTableToSearch) == "table") then
		for x in pairs(pTableToSearch) do
			if pTableToSearch[x]["ItemName"] ~= nil and pTableToSearch[x]["ItemName"] ~= "" then
				--Search by Quality / Rarity
				if tableItemInfo["ItemRarity"] ~= nil and tableItemInfo["ItemRarity"] ~= "" then
					if tonumber(pTableToSearch[x]["ItemName"]) == tonumber(tableItemInfo["ItemRarity"]) then
						if NeatFreakOptions.Debugging == 1 then
							NF_MB("chat", "Found Quality at " .. x );
						end
						bolFoundQuality = true;
						bolFound = true;
						intFound = x;
					end
				end

				--Search by Type - SubType
				if (tableItemInfo["ItemType"] ~= nil and tableItemInfo["ItemType"] ~= "") and (tableItemInfo["ItemSubType"] ~= nil and tableItemInfo["ItemSubType"] ~= "") then
					if strlower(pTableToSearch[x]["ItemName"]) == strlower(tableItemInfo["ItemType"] .. " - " .. tableItemInfo["ItemSubType"]) then
						if NeatFreakOptions.Debugging == 1 then
							NF_MB("chat", "Found Type - SubType at " .. x );
						end
						-- Below option is to ignore Soulbound items
						bolFoundQuality = true;
						bolFound = true;
						intFound = x;
					end
				end

				--Search by Name
				if tableItemInfo["ItemName"] ~= nil and tableItemInfo["ItemName"] ~= "" then
					-- true in search/find turns on plain searching
					if string.find(pTableToSearch[x]["ItemName"], "*", 1, true) ~= nil then
						if pTableToSearch[x]["ItemName"] == tableItemInfo["ItemName"] then
							-- Found item clicked on in list, that has *.
							if NeatFreakOptions.Debugging == 1 then
								NF_MB("chat", "Found Name at " .. x );
							end
							bolFoundQuality = false;
							bolFound = true;
							intFound = x;
							return intFound;
						else
							--Strip * and compare
							local strLookingFor = pTableToSearch[x]["ItemName"]
							strLookingFor = string.gsub(strLookingFor, "* ", "")
							strLookingFor = string.gsub(strLookingFor, " *", "")
							strLookingFor = string.gsub(strLookingFor, "*", "")

							if string.find(strlower(tableItemInfo["ItemName"]), strlower(strLookingFor), 1, true) ~= nil then  -- true turns on plain searching
								if NeatFreakOptions.Debugging == 1 then
									NF_MB("chat", "Found " .. strlower(strLookingFor) .. " in " .. strlower(tableItemInfo["ItemName"]) .. " using wildcards." );
								end
								bolFoundQuality = false;
								bolFound = true;
								intFound = x;
							end
						end
					else
						if strlower(pTableToSearch[x]["ItemName"]) == strlower(tableItemInfo["ItemName"]) then
							if NeatFreakOptions.Debugging == 1 then
								NF_MB("chat", "Found Name at " .. x );
							end
							bolFoundQuality = false;
							bolFound = true;
							intFound = x;
							return intFound;
						end
					end
				end
			else
				--blank entry in sort table.  should remove it.
				if NeatFreakOptions.Debugging == 1 then
					NF_MB("chat", "Found a blank entry in the sort table at " .. x );
				end
			end
		end
	end

	if bolFound == true then
		return intFound;
	else
		return bolFound;
	end

end

-- ============================================================================================================= --

function NeatFreakScrollBar_Update()

	local intNumEntries2Show, intPixelRowHeight, intNumTotalEntries
	local line, intFauxOffset, lineOffset

	--intNumEntries2Show = 6;
	intNumEntries2Show = NeatFreakOptions.NumListItems;
	--intPixelRowHeight = 6;
	intPixelRowHeight = NeatFreakOptions.NumListItems;
	intNumTotalEntries = 0;

	-- intNumTotalEntries = table.getn(tableCombinedSortItemList)  -- # entries in list
	for k,v in pairs(tableCombinedSortItemList) do
		intNumTotalEntries = intNumTotalEntries + 1
	end

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Showing: " .. intNumEntries2Show .. ".  # Total Entries: " .. intNumTotalEntries .. ".  RowHeight: " .. intPixelRowHeight );
	end

	-- FauxScrollFrame_Update( frame, numItems, numToDisplay, valueStep, button, smallWidth, bigWidth, highlightFrame, smallHighlightWidth, bigHighlightWidth );
	FauxScrollFrame_Update(NeatFreakSortPageScrollFrame, intNumTotalEntries, intNumEntries2Show, intPixelRowHeight);

	for line = 1, intNumEntries2Show do
		intFauxOffset = FauxScrollFrame_GetOffset(NeatFreakSortPageScrollFrame);
		if not tonumber(intFauxOffset) then
			intFauxOffset = 0;
		end
		lineOffset = line + intFauxOffset;

		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Offset: " .. lineOffset .. "  <=  intNumTotalEntries: " .. intNumTotalEntries );
		end

		if lineOffset <= intNumTotalEntries then
			-- Update Scroll Line w/ data from Table
			UpdateScrollListLine(line, lineOffset);
		else
			getglobal("NeatFreakSortPageListItem" .. line):SetText();
			getglobal("NeatFreakSortPageListItem" .. line .. "IconPic"):SetTexture();
			getglobal("NeatFreakSortPageListItem" .. line .. "ListDest"):SetText();
			getglobal("NeatFreakSortPageListItem" .. line .. "CharOnlyCheck"):Hide();
			getglobal("NeatFreakSortPageListItem" .. line):Hide();
		end
	end

end

-- ============================================================================================================= --

function UpdateScrollListLine(pScrollListLineNum, pItemTableEntryNum)

	local strLocationText, strItemNameText, intHowManyToTrunc;

--[[
	tableItemInfo["ItemName"] = TheName;
	tableItemInfo["ItemTexture"] = ItemTextureEditBox:GetText();
	tableItemInfo["ToBag"] = TheBagNum;
	tableItemInfo["ToSlot"] = TheSlotNum;
	tableItemInfo["PerChar"] = TheRadioButton;
]]

	-- Update Icon
	if tableCombinedSortItemList[pItemTableEntryNum]["ItemTexture"] ~= "" then
		strIconPicToUse = tableCombinedSortItemList[pItemTableEntryNum]["ItemTexture"];
		getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum .. "IconPic"):SetTexture( tableCombinedSortItemList[pItemTableEntryNum]["ItemTexture"] );
	else
		--NF_MB("chat", "Icon texture for " .. tableCombinedSortItemList[pItemTableEntryNum]["ItemName"] .. " is blank" );
		getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum .. "IconPic"):SetTexture( "" );
	end

	-- Update Text/Name
	if tonumber(tableCombinedSortItemList[pItemTableEntryNum]["ItemName"]) then
		local NF_red, NF_green, NF_blue, NF_hex, strEscColorEnd;
		NF_red, NF_green, NF_blue, NF_hex = GetItemQualityColor(tonumber(tableCombinedSortItemList[pItemTableEntryNum]["ItemName"]));
		if NF_hex ~= nil then
			--[[  Following changes ALL UI font color
			local font = getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):GetNormalFontObject(); 
			font:SetTextColor(NF_red, NF_green, NF_blue); 
			getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):SetNormalFontObject(font); 
			]]

			strEscColorEnd = "|r"
			getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):SetText( NF_hex .. tableCombinedSortItemList[pItemTableEntryNum]["ItemName"] .. " (".. getglobal("ITEM_QUALITY" .. tonumber(tableCombinedSortItemList[pItemTableEntryNum]["ItemName"]) .. "_DESC") .. ")" .. strEscColorEnd )
		else
			getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):SetText( tableCombinedSortItemList[pItemTableEntryNum]["ItemName"] .. " (".. getglobal("ITEM_QUALITY" .. tonumber(tableCombinedSortItemList[pItemTableEntryNum]["ItemName"]) .. "_DESC") .. ")" );
		end
	else
		getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):SetText( tableCombinedSortItemList[pItemTableEntryNum]["ItemName"] );
	end

	-- Update CheckMark
	if tableCombinedSortItemList[pItemTableEntryNum]["PerChar"] == 1 then
		getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum .. "CharOnlyCheck"):Show();
	else
		getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum .. "CharOnlyCheck"):Hide();
	end

	-- Update Location/Destination
	strLocationText = "Bag-" .. tableCombinedSortItemList[pItemTableEntryNum]["ToBag"];
	if tableCombinedSortItemList[pItemTableEntryNum]["ToSlot"] ~= "" and tableCombinedSortItemList[pItemTableEntryNum]["ToSlot"] ~= 0 then
		strLocationText = strLocationText .. "  Slot-" .. tableCombinedSortItemList[pItemTableEntryNum]["ToSlot"];
	else
		strLocationText = strLocationText .. " Any Slot";
	end
	getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum .. "ListDest"):SetText( strLocationText );
	
	-- show whole line
	getglobal("NeatFreakSortPageListItem" .. pScrollListLineNum):Show();

end

-- ============================================================================================================= --

function HandleSlashCommands(pstrCMD)

	local bolFoundCommand, intEachBag, strSortWhatBag

	bolFoundCommand = false;

	if pstrCMD == "" then
		NeatFreak:Show();
		bolFoundCommand = true;
	else
		if strlower(pstrCMD) == "reloadui" then
			NF_MB("chat","type '/console reloadui' in the chat window.");
			bolFoundCommand = true;
		end

		if strlower(pstrCMD) == "findwindow" then
			NF_MB("chat","Moving the Neat Freak Window to x=50 y=-50.");
			NeatFreak:ClearAllPoints();
			NeatFreak:SetPoint("TOPLEFT", "UIParent", "TOPLEFT", 50, -50);
			bolFoundCommand = true;
		end

		if strlower(string.sub(pstrCMD, 1, 4)) == "sort" and string.sub(pstrCMD, 5, 5) == " " then
			if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
				NF_MB("chat","Start Force Sorting.");
			end
			bolFoundCommand = true;
			if strlower(string.sub(pstrCMD, 6)) == "all" then
				for intEachBag = 0, 4 do
					if GetBagName(intEachBag) ~= nil then
						-- Check/Sort all bags
						--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(intEachBag) );
						CheckIfBagNeedsSorting(intEachBag);
					end
				end
			elseif string.sub(pstrCMD, 6) == "0" then
				-- bag 0 only
				if GetBagName(0) ~= nil then
					--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(0) );
					CheckIfBagNeedsSorting(0);
				else
					-- bag not exist
					NF_MB("chat", "Neat Freak - Bag 0 does not exist." );
				end
			elseif string.sub(pstrCMD, 6) == "1" then
				-- bag 1 only
				if GetBagName(1) ~= nil then
					--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(1) );
					CheckIfBagNeedsSorting(1);
				else
					-- bag not exist
					NF_MB("chat", "Neat Freak - Bag 1 does not exist." );
				end
			elseif string.sub(pstrCMD, 6) == "2" then
				-- bag 2 only
				if GetBagName(2) ~= nil then
					--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(2) );
					CheckIfBagNeedsSorting(2);
				else
					-- bag not exist
					NF_MB("chat", "Neat Freak - Bag 2 does not exist." );
				end
			elseif string.sub(pstrCMD, 6) == "3" then
				-- bag 3 only
				if GetBagName(3) ~= nil then
					--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(3) );
					CheckIfBagNeedsSorting(3);
				else
					-- bag not exist
					NF_MB("chat", "Neat Freak - Bag 3 does not exist." );
				end
			elseif string.sub(pstrCMD, 6) == "4" then
				-- bag 4 only
				if GetBagName(4) ~= nil then
					--NF_MB("chat", "Neat Freak is checking bag " .. GetBagName(4) );
					CheckIfBagNeedsSorting(4);
				else
					-- bag not exist
					NF_MB("chat", "Neat Freak - Bag 4 does not exist." );
				end
			else
				--NF_MB("chat", "Neat Freak - Sort " .. string.sub(pstrCMD, 6) .. " is not a valid command/option." );
				bolFoundCommand = false;
			end
			if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
				NF_MB("chat","Done Force Sorting.");
			end
		end
	end

	if bolFoundCommand == false then
		NF_MB("chat","The command '" .. pstrCMD .. "' is not understood by Neat Freak.");
	end

end

-- ============================================================================================================= --

function NeatFreakClickedTab()

	local intTabNum, theParent

	intTabNum = this:GetID()
	theParent = this:GetParent():GetName()

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat","Tab # to show: " .. intTabNum)
		NF_MB("chat", "Parent " .. theParent )
	end

	if theParent == "UIParent" then
		theParent = "NeatFreak"
		strDesiredPageName = "Sort"
	else
		strDesiredPageName = this:GetText()
	end

	if (theParent == "NeatFreak") then
		NeatFreakToggleTabs(strDesiredPageName, intTabNum)
	end

end

-- ============================================================================================================= --

function NeatFreakToggleTabs(pstrPageName, pintTabNum)
-- pstrPageName = "About" or "Options" etc.    end result -> NeatFreakAboutPage, NeatFreakOptionsPage, NeatFreakSortPage

	-- Following "Selects" the Tab, if based from SpellBook interface
	-- Tab1:Disable()
	-- Following "Un-Selects" the Tab, if based from SpellBook interface
	-- Tab2:Enable()

	local strCurrentTitle, i

	if tonumber(pintTabNum) == 0 then
		pintTabNum = 1
	end

	strCurrentTitle = NeatFreakPageTitleText:GetText()
	NeatFreakPageTitleText:SetText( pstrPageName )

	for i = 1, intNumTabs do
		-- Following "Un-Selects" the Tabs
		getglobal("NeatFreakTab" .. i):Enable()
	end

	-- Following "Selects" the Tab
	getglobal("NeatFreakTab" .. pintTabNum):Disable()
	getglobal("NeatFreak" .. strCurrentTitle .. "Page"):Hide()
	getglobal("NeatFreak" .. pstrPageName .. "Page"):Show()

end 

-- ============================================================================================================= --

function NeatFreakOption_OnClick()

	local intValue2Save, strWhatDo

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", this:GetName() );
	end

	if string.find(tostring(this:GetName()), "CheckButton") ~= nil then
		if string.find(tostring(this:GetName()), "CheckButton") > 0 then
			-- Is a Check Box
			-- NF_MB("chat", "found CheckButton more 0" )
			strWhatDo = "CheckBox"
		else
			-- Is NOT a Check Box.  -- Slider
			-- NF_MB("chat", "found CheckButton less 0" )
			strWhatDo = "Slider"
		end
	else
		-- Is NOT a Check Box.  -- Slider
		-- NF_MB("chat", "found CheckButton is nil" )
		strWhatDo = "Slider"
	end

	if strWhatDo == "CheckBox" then
		if tonumber(this:GetChecked()) == 1 then
			intValue2Save = 1
		else
			intValue2Save = 0
		end
	else
		intValue2Save = this:GetValue()
	end

	-- read setting out of checkbox (or slider) and save
	-- use this:GetName() to know which checkbox was clicked.  Could use this:GetID, if have ID's setup.
	if (this:GetName() == (this:GetParent():GetName() .. "CheckButtonEnableBags")) then
		NeatFreakOptions.EnableBags = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonAuct")) then
		NeatFreakOptions.Auct = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonBank")) then
		NeatFreakOptions.Bank = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonGuild")) then
		NeatFreakOptions.Guild = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonMail")) then
		NeatFreakOptions.Mail = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonMerch")) then
		NeatFreakOptions.Merch = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonTrade")) then
		NeatFreakOptions.Trade = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonDebugging")) then
		NeatFreakOptions.Debugging = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonChat")) then
		NeatFreakOptions.Chat = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonHideGryphons")) then
		NeatFreakOptions.HideGryphons = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonHideMiniMapButton")) then
		NeatFreakOptions.HideMiniMapButton = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "SliderMiniMapAngle")) then
		NeatFreakOptions.MiniMapAngle = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "SliderMiniMapDistance")) then
		NeatFreakOptions.MiniMapDistance = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonNeatFreakBags")) then
		NeatFreakOptions.NeatFreakBags = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonShutUp")) then
		NeatFreakOptions.ShutUp = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "CheckButtonSkipSoulbound")) then
		NeatFreakOptions.SkipSoulbound = intValue2Save
	elseif (this:GetName() == (this:GetParent():GetName() .. "SliderNumListItems")) then
		NeatFreakOptions.NumListItems = intValue2Save
	end

	PositionNeatFreakMiniMapIcon();

	if (this:GetName() == (this:GetParent():GetName() .. "SliderNumListItems")) then
		SetScrollListForNumItemsToShow();
	end

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", this:GetName() )
	end

end

-- ============================================================================================================= --

function UpdateInterface(tableItemInfo) 

	if tableItemInfo ~= "" and tableItemInfo ~= nil then
		ItemIcon:SetNormalTexture( tableItemInfo["ItemTexture"] )

		StoreByNameRadioButton:SetChecked(nil);
		StoreByTypeRadioButton:SetChecked(nil);
		StoreByRarityRadioButton:SetChecked(nil);
		ItemNameEditBox:Hide();
		ItemTypeInterfaceEditBox:Hide();
		ItemRarityInterfaceEditBox:Hide();
		if tonumber(tableItemInfo["ItemName"]) ~= nil then
			-- Rarity
			ItemRarityEditBox:SetText( tableItemInfo["ItemName"] );
			tableItemInfo["ItemRarity"] = ItemRarityEditBox:GetText();
			ItemRarityInterfaceEditBox:Show();
			StoreByRarityRadioButton:SetChecked(1);
		else
			if string.find(tableItemInfo["ItemName"], " - ", 1, true) ~= nil then
				-- Type
				--ItemTypeEditBox:SetText( string.sub(tableItemInfo["ItemName"], 1, string.find(tableItemInfo["ItemName"], " - ", 1, true)) );
				tableItemInfo["ItemType"] = string.sub(tableItemInfo["ItemName"], 1, (string.find(tableItemInfo["ItemName"], " - ", 1, true) - 1))
				tableItemInfo["ItemSubType"] = string.sub(tableItemInfo["ItemName"], (string.find(tableItemInfo["ItemName"], " - ", 1, true) + 3))
				--ItemSubTypeEditBox:SetText( string.sub(tableItemInfo["ItemName"], (string.find(tableItemInfo["ItemName"], " - ", 1, true) + 3)) );
				ItemTypeInterfaceEditBox:Show();
				StoreByTypeRadioButton:SetChecked(1);
			else
				-- Name
				ItemNameEditBox:SetText( tableItemInfo["ItemName"] );
				ItemNameEditBox:Show();
				StoreByNameRadioButton:SetChecked(1);
			end
		end

		ItemBagDropDownMenuButtonText:SetText( "Bag " .. tableItemInfo["ToBag"] );
		ItemSlotEditBox:SetText( tableItemInfo["ToSlot"] );
		if tableItemInfo["PerChar"] == 0 then
			CharacterRadio:SetChecked(nil);
			AccountRadio:SetChecked(1);
		else
			CharacterRadio:SetChecked(1);
			AccountRadio:SetChecked(nil);
		end

		-- Hidden Fields
		ItemName2EditBox:SetText( tableItemInfo["ItemName"] );
		ItemTextureEditBox:SetText( tableItemInfo["ItemTexture"] );
		ItemBagEditBox:SetText( tableItemInfo["ToBag"] );

		if tableItemInfo["ItemType"] ~= "" and tableItemInfo["ItemType"] ~= nil then
			ItemTypeEditBox:SetText( tableItemInfo["ItemType"] );
		else
			ItemTypeEditBox:SetText( "" );
		end
		if tableItemInfo["ItemSubType"] ~= "" and tableItemInfo["ItemSubType"] ~= nil then
			ItemSubTypeEditBox:SetText( tableItemInfo["ItemSubType"] );
		else
			ItemSubTypeEditBox:SetText( "" );
		end
		ItemTypeInterfaceEditBox:SetText( ItemTypeEditBox:GetText() .. " - " .. ItemSubTypeEditBox:GetText() );

		if tableItemInfo["ItemRarity"] ~= "" and tableItemInfo["ItemRarity"] ~= nil then
			ItemRarityEditBox:SetText( tableItemInfo["ItemRarity"] );
		end
		ItemRarityInterfaceEditBox:SetText( ItemRarityEditBox:GetText() );
	else
		ItemIcon:SetNormalTexture( "" );
		ItemNameEditBox:SetText( "" );
		ItemBagDropDownMenuButtonText:SetText( "" );
		ItemSlotEditBox:SetText( "" );
		-- No longer default to Account Level
		--CharacterRadio:SetChecked(nil);
		--AccountRadio:SetChecked(1);
		ItemTypeInterfaceEditBox:SetText( "" );
		ItemRarityInterfaceEditBox:SetText( "" );

		-- Hidden Fields
		ItemTextureEditBox:SetText( "" );
		ItemBagEditBox:SetText( "" );
		ItemName2EditBox:SetText( "" );
		ItemTypeEditBox:SetText( "" );
		ItemSubTypeEditBox:SetText( "" );
		ItemRarityEditBox:SetText( "" );
	end 

end

-- ============================================================================================================= --

function RadioButton_OnClick(pIndex)

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "GetName: " .. this:GetName() .. "    GetID: " .. this:GetID() .. "    Index: " .. pIndex )
	end

	if this:GetName() == "CharacterRadio" or this:GetName() == "AccountRadio" then
		if (pIndex == 1) then
			CharacterRadio:SetChecked(1);
			AccountRadio:SetChecked(nil);
		else
			CharacterRadio:SetChecked(nil);
			AccountRadio:SetChecked(1);
		end
	end

	intIsStoreBy = string.find(tostring(this:GetName()), "StoreBy");
	if intIsStoreBy ~= nil then
		StoreByNameRadioButton:SetChecked(nil);
		StoreByTypeRadioButton:SetChecked(nil);
		StoreByRarityRadioButton:SetChecked(nil);
		ItemNameEditBox:Hide();
		ItemTypeInterfaceEditBox:Hide();
		ItemRarityInterfaceEditBox:Hide();

		getglobal(this:GetName()):SetChecked(1);
		if pIndex == 1 then
			ItemNameEditBox:Show();
		end
		if pIndex == 2 then
			ItemTypeInterfaceEditBox:Show();
		end
		if pIndex == 3 then
			ItemRarityInterfaceEditBox:Show();
		end
	end

	PlaySound("igMainMenuOptionCheckBoxOn");

end

-- ============================================================================================================= --

function ItemIconButton_OnClick(self, button)

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Icon clicked: " .. button )
	end

	if button == "LeftButton" then
		if GetCursorInfo() == nil then
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "Nothing suppplied to check, it was nil" )
			end
			return
		end

		UpdateInterface("")

		local infoType, info1, info2, TheRadioButton
		local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture
		-- local itemName, itemTexture, iPrice, iQuantity, iNumAvailable, sIsUsable, iExtendedCost
		local iPrice, iQuantity, iNumAvailable, sIsUsable, iExtendedCost

		infoType, info1, info2 = GetCursorInfo()
	
		-- infoType can be: item, spell, macro, money, merchant
		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Type item: " .. infoType )
			NF_MB("chat", "Item Info1: " ..  info1 )
			NF_MB("chat", "Item Info2: " .. info2 )  -- nill if not returned.   merchant, money, macro
		end

		if infoType == "item" then
			itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(info1);
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", itemName )
			end
		end

		if infoType == "merchant" then
			itemName, itemTexture, iPrice, iQuantity, iNumAvailable, sIsUsable, iExtendedCost = GetMerchantItemInfo( info1 );
		end

		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", itemTexture )
		end

		-- Set the tableItemInfo fields and call UpdateInterface(tableItemInfo)
		tableItemInfo = {}
		tableItemInfo["ItemName"] = itemName
		tableItemInfo["ItemTexture"] = itemTexture
		tableItemInfo["ToBag"] = ""
		tableItemInfo["ToSlot"] = ""
		-- No longer default to Account Level
		TheRadioButton = CharacterRadio:GetChecked()  -- Flag -> 1 if the radio/check button is checked, or nil otherwise
		if TheRadioButton == nil then
--			NF_MB("chat", "CharacterRadio not selected" )
			tableItemInfo["PerChar"] = 0
		else
--			NF_MB("chat", "CharacterRadio is selected" )
			tableItemInfo["PerChar"] = 1
		end

		tableItemInfo["ItemType"] = itemType
		tableItemInfo["ItemSubType"] = itemSubType
		tableItemInfo["ItemRarity"] = itemRarity

		UpdateInterface(tableItemInfo)
		ClearCursor()
	else
		UpdateInterface("")
	end

end

-- ============================================================================================================= --

function AddUpdateButton()

	local TheName, TheBagNum, TheSlotNum, TheRadioButton, strWhatStoring

	--make sure have Name (or Type, or Rarity), bag, radio, slot is optional
	-- Flag -> 1 if the radio/check button is checked, or nil otherwise
	if StoreByNameRadioButton:GetChecked() == nil then
		if StoreByTypeRadioButton:GetChecked() == nil then
			if StoreByRarityRadioButton:GetChecked() == nil then
				-- Error
				message( "There was an error determining what Name, Type, Rarity is to be Added/Updated." )
				return
			else
				--Set What to Store (Rarity)
				strWhatStoring = "Rarity"
				TheName = ItemRarityInterfaceEditBox:GetText()
			end
		else
			--Set What to Store (Type)
			strWhatStoring = "Type"
			TheName = ItemTypeInterfaceEditBox:GetText()
			if TheName == " - " then
				TheName = ""
			end
		end
	else
		--Set What to Store (Name)
		strWhatStoring = "Name"
		TheName = ItemNameEditBox:GetText()
	end

	if string.find(TheName, "*", 1, true) ~= nil then  -- true turns on plain searching
		if strWhatStoring == "Name" then
			if (string.sub(TheName, 1, 1) == "*" or string.sub(TheName, string.len(TheName)) == "*") then
				-- Strip the 1st and last chars and check again for a *.
				if string.find(string.sub(TheName, 2, (string.len(TheName)-1)), "*", 1, true) ~= nil then
					message( "WildCards (*) are only allowed at the begining or end of entries." )
					return
				end
			else
				message( "WildCards (*) are only allowed at the begining or end of entries." )
				return
			end
		else
			message( "WildCards (*) are only allowed for Item Names, not Item " .. strWhatStoring .. "." )
			return
		end
	end

	if TheName == "" then
		message( "You need to supply an 'Item " .. strWhatStoring .. "' to be Added/Updated." )
		return
	end

	TheBagNum = ItemBagEditBox:GetText();
	if TheBagNum == "" then
		message( "You need to supply a 'Bag #' to be Added/Updated." )
		return
	end

	TheSlotNum = ItemSlotEditBox:GetText();
	TheRadioButton = CharacterRadio:GetChecked()  -- Flag -> 1 if the radio/check button is checked, or nil otherwise
	if TheRadioButton == nil then
		TheRadioButton = 0   -- AccountRadio:GetChecked()
	end

	-- If Rarity or Type do not set texture
	if strWhatStoring == "Type" or strWhatStoring == "Rarity" then
		ItemTextureEditBox:SetText( "" )
	else
		if ItemTextureEditBox:GetText() == "" or ItemTextureEditBox:GetText() == nil then
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "No texture, so try to get one." )
			end
			local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(ItemNameEditBox:GetText());
			if itemTexture ~= nil then
				ItemTextureEditBox:SetText( itemTexture );
			end
		end
	end

	--build tableItemInfo  ->
	tableItemInfo = {}
	tableItemInfo["ItemName"] = TheName
	tableItemInfo["ItemTexture"] = ItemTextureEditBox:GetText()
	tableItemInfo["ToBag"] = TheBagNum
	tableItemInfo["ToSlot"] = TheSlotNum
	tableItemInfo["PerChar"] = TheRadioButton

	--check what radio button, and add to table (overwrites existing - if any, otherwise writes new)
	if TheRadioButton == 1 then
		if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak - Add " .. TheName .. " to the Char sort list." )
		end
		AddOrUpdateValuesToSortTable(tableCharSortItemList)
	else
		if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak - Add " .. TheName .. " to the Account sort list." )
		end
		AddOrUpdateValuesToSortTable(tableAccountSortItemList)
	end

	CreateCombinedSortingList()

end

-- ============================================================================================================= --

function ScrollListItemClick() 

	local ItemName, intEntryNum
	UpdateInterface("")

	-- get item name from scroll list 
	ItemName = this:GetText()
	-- check if 1st char is tubes '|'.  if yes then strip the next 11 chars.
	if string.sub(ItemName,1,1) == "|" then
		ItemName = string.sub(ItemName,11)
	end
	--NF_MB("chat", ItemName .. " is text, if 1st is # drop rest" );
	if tonumber(string.sub(ItemName,1,1)) and string.sub(ItemName,2,2) == " " then
		ItemName = string.sub(ItemName,1,1)
	end

	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", ItemName .. " is the name clicked." );
	end

	tableItemInfo = {}
	tableItemInfo["ItemName"] = ItemName

	-- Find Item in table based on name
	intEntryNum = CheckIfItemIsInTable(tableCombinedSortItemList)
--NF_MB("chat", intEntryNum .. " is the number." );

	-- get item info from table, based on the Entry Number 
	tableItemInfo = tableCombinedSortItemList[intEntryNum]

	UpdateInterface(tableItemInfo)

end

-- ============================================================================================================= --

function RemoveButton() 

	local ItemName, TheRadioButton, intEntryNum, strWhatRemoving

	-- Flag -> 1 if the radio/check button is checked, or nil otherwise
	-- or check if field isVisible()
	if StoreByNameRadioButton:GetChecked() == nil then
		if StoreByTypeRadioButton:GetChecked() == nil then
			if StoreByRarityRadioButton:GetChecked() == nil then
				-- Error
				message( "There was an error determining what Name, Type, Rarity is to be Added/Updated." )
				return
			else
				--Set What to Store (Rarity)
				strWhatRemoving = "Rarity"
				ItemName = ItemRarityInterfaceEditBox:GetText()
			end
		else
			--Set What to Store (Type)
			strWhatRemoving = "Type"
			ItemName = ItemTypeInterfaceEditBox:GetText()
			if ItemName == " - " then
				ItemName = ""
			end
		end
	else
		--Set What to Store (Name)
		strWhatRemoving = "Name"
		ItemName = ItemNameEditBox:GetText()
	end

	--ItemName = ItemNameEditBox:GetText()
	if ItemName == "" then
		message( "You need to supply an 'Item " .. strWhatRemoving .. "' to be removed." )
		return
	end

	-- check what radio button
	TheRadioButton = CharacterRadio:GetChecked()  -- Flag -> 1 if the radio/check button is checked, or nil otherwise
	if TheRadioButton == nil then
		TheRadioButton = 0   -- AccountRadio:GetChecked()
	end

	tableItemInfo = {}
	tableItemInfo["ItemName"] = ItemName

	-- check if in table (based on radio button selected), and get what Entry# it is
	if TheRadioButton == 1 then
		if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak - Remove " .. ItemName .. " from the Char sort list." )
		end

		intEntryNum = CheckIfItemIsInTable(tableCharSortItemList)
		-- Make sure intEntryNum is a number

		-- remove entry from table
		table.remove(tableCharSortItemList, intEntryNum)
	else
		if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", "Neat Freak - Remove " .. ItemName .. " from the Account sort list." )
		end

		intEntryNum = CheckIfItemIsInTable(tableAccountSortItemList)
		-- Make sure intEntryNum is a number

		-- remove entry from table
		table.remove(tableAccountSortItemList, intEntryNum)
	end

	-- Clear the current combined Sorting List
	tableCombinedSortItemList = {}

	-- Recreate the combined Sorting List w/ the updated tables
	CreateCombinedSortingList()

end

-- ============================================================================================================= --

function CheckIfBagNeedsSorting(pTheBagID)

	local BagSlot, intEntryNum, strIsBagValid, TheItem, strDestSlot, tooltipLine2, tooltipLine3, bolItemIsSoulbound
	local lockedTexture, lockedCount, lockedLocked, lockedQuality, lockedReadable
	local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture
	bolFoundQuality = false

	if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Neat Freak is checking Bag " .. GetBagName(pTheBagID) );
	end

	for BagSlot = 1, GetContainerNumSlots( pTheBagID ) do
		if NeatFreakOptions.Debugging == 1 then
			--NF_MB("chat", "Neat Freak - Slot " .. BagSlot .. " checked of " .. GetContainerNumSlots( pTheBagID ));
		end

		lockedTexture, lockedCount, lockedLocked, lockedQuality, lockedReadable = GetContainerItemInfo(pTheBagID, BagSlot);
		-- lockedLocked returns a # (not nil) if it IS locked
		if lockedLocked ~= nil then
			-- locked so move on to next slot
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "Neat Freak - Slot " .. BagSlot .. ", is locked." );
			end
		else 
			-- Not Locked is basically being returned ALL the time.
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "Neat Freak  - Slot " .. BagSlot .. ", is NOT locked." );
			end

			--get item info
			TheItem = GetContainerItemLink(pTheBagID, BagSlot)
			if TheItem == nil then
				itemName = "nothing";
			else
				--itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo( GetContainerItemLink(pTheBagID, BagSlot) );
				itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo( TheItem );
			end

			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "Neat Freak pulled item info for " .. itemName );
			end

			if TheItem == nil or itemName == "nothing" then
				itemName = "Nothing";
			else
				-- Get Destination/Sort info from Table
				tableItemInfo = {};
				tableItemInfo["ItemName"] = itemName;
				tableItemInfo["ItemType"] = itemType;
				tableItemInfo["ItemSubType"] = itemSubType;
				tableItemInfo["ItemRarity"] = itemRarity;
				intEntryNum = CheckIfItemIsInTable(tableCombinedSortItemList);

				if intEntryNum ~= false then
					tableItemInfo = tableCombinedSortItemList[tonumber(intEntryNum)];
					-- make sure Dest bag # is valid
					strIsBagValid = GetBagName( tableItemInfo["ToBag"] );
					if NeatFreakOptions.Debugging == 1 then
						NF_MB("chat", "Neat Freak - Dest Bag Name is " .. strIsBagValid );
					end

					-- option to ignore Soulbound items
					if bolFoundQuality == true then
						bolItemIsSoulbound = false;
						if NeatFreakOptions.SkipSoulbound == 1 then
							owner = getglobal("NeatFreak");
							GameTooltip:SetOwner(owner, "ANCHOR_NONE");
							GameTooltip:SetBagItem(pTheBagID,BagSlot);
							tooltipLine2 = getglobal("GameTooltipTextLeft2"):GetText();
							--tooltipLine3 = getglobal("GameTooltipTextLeft3"):GetText();
							--GameTooltip = nil;
							GameTooltip:Hide();
							--NF_MB("chat", tooltipLine2 .. " -> " .. tooltipLine3 );
							if ( tooltipLine2 == NEATFREAK_LOCALE_TEXT_SOULBOUND ) then
								-- is soulbound
								strIsBagValid = nil;
								bolItemIsSoulbound = true;
							end
						end
					end

					if strIsBagValid == nil or strIsBagValid == "" then
						if bolItemIsSoulbound ~= true then
							NF_MB("chat", "The Bag# specified '" .. tableItemInfo["ToBag"] .. "' does not exist, so Neat Freak can not sort " .. itemName .. "." )
						end
					else
						-- NF_MB("chat", "Neat Freak - Dest bag is: " .. strIsBagValid )
						strDestSlot = tableItemInfo["ToSlot"]

						-- Check Dest slot #
						intLookForDash = string.find(strDestSlot, "-")
						if intLookForDash == nil then
							intLookForDash = 0;
						end
						if tonumber(intLookForDash) > 0 then
							intDashAt = string.find(strDestSlot, "-")
							strDestStartSlot = string.sub(strDestSlot, 1, (intDashAt - 1))
							strDestEndSlot = string.sub(strDestSlot, (intDashAt + 1))
						else
							if strDestSlot == "" or strDestSlot == nil then
								strDestSlot = 0
							end
							strDestStartSlot = strDestSlot
							strDestEndSlot = strDestSlot
						end

						bolHaveItemsToMove = true
						for strDestSlot = strDestStartSlot, strDestEndSlot do
							if bolHaveItemsToMove == true then
								if tonumber(strDestSlot) > tonumber(GetContainerNumSlots( tableItemInfo["ToBag"] )) then
									if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
										NF_MB("chat", "Slot " .. strDestSlot .. " does not exist for bag " .. tableItemInfo["ToBag"] .. ", so Neat Freak will dump " .. itemName .. " to bag " .. tableItemInfo["ToBag"] )
									end
									-- Check if there R free slots
									if GetContainerNumFreeSlots( tonumber(tableItemInfo["ToBag"]) ) == 0 then
										NF_MB("chat", "Neat Freak - No free slots in bag " .. tableItemInfo["ToBag"] )
									else
										MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], "", "")
									end
									bolHaveItemsToMove = false
								else
									if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
										NF_MB("chat", "Neat Freak - Dest slot is: " .. strDestSlot )
									end
									-- Only move if dest bag and source bag R diff
									if tonumber(pTheBagID) ~= tonumber(tableItemInfo["ToBag"]) then
										-- if Dest Slot is 0 or "" then need check whole bag to see if item exists.
										if tonumber(strDestSlot) == 0 or strDestSlot == "" then
											for EachDestSlot = 1, GetContainerNumSlots( tableItemInfo["ToBag"] ) do
												strTempItem = GetContainerItemLink(tableItemInfo["ToBag"], EachDestSlot)
												if strTempItem ~= nil then
													if GetItemInfo( strTempItem ) == itemName then
														strDestSlot = EachDestSlot
														-- Could be improved to check # of items in this slot and if stackable use this # instead of moving on.
														-- And if full stack keep looking, else exit this for loop
													end
												end
											end
										end

										-- Check if Dest Slot item is same as item to move
										strDestItem = GetContainerItemLink(tableItemInfo["ToBag"], strDestSlot);
										if strDestItem == nil then
											--Empty Slot
											if GetContainerNumFreeSlots( tableItemInfo["ToBag"] ) > 0 then
												MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], strDestSlot, "")
												bolHaveItemsToMove = false
											else
												NF_MB("chat", "Neat Freak - No free slots in bag " .. tableItemInfo["ToBag"] )
											end
										else
											--strDestItem, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo( strDestItem );
											strDestItem = GetItemInfo( strDestItem );
											if strDestItem == itemName then
												--lockedTexture, lockedCount, lockedLocked, lockedQuality, lockedReadable = GetContainerItemInfo(pTheBagID, strDestSlot);
												DestlockedTexture, DestlockedCount = GetContainerItemInfo(tableItemInfo["ToBag"], strDestSlot);
												if tonumber(itemStackCount) > tonumber(DestlockedCount) then
													-- Room to stack
													intNumToFullStack = tonumber(itemStackCount) - tonumber(DestlockedCount)
													if tonumber(lockedCount) > tonumber(intNumToFullStack) then
														-- Need to split
														MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], strDestSlot, intNumToFullStack)
													else
														--current will fit on stack
														MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], strDestSlot, "")
														bolHaveItemsToMove = false
													end
												else
													-- Full stack at Dest, wait for next slot #?.
													if tonumber(strDestSlot) >= tonumber(strDestEndSlot) then
														-- Check if there R free slots
														if GetContainerNumFreeSlots( tonumber(tableItemInfo["ToBag"]) ) == 0 then
															NF_MB("chat", "Neat Freak - No free slots in bag " .. tableItemInfo["ToBag"] )
														else
															MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], "", "")
														end
														bolHaveItemsToMove = false
													end
												end
											else
												if tonumber(strDestSlot) == tonumber(strDestEndSlot) then
													-- Check if there R free slots
													if GetContainerNumFreeSlots( tonumber(tableItemInfo["ToBag"]) ) == 0 then
														NF_MB("chat", "Neat Freak - No free slots in bag " .. tableItemInfo["ToBag"] )
													else
														MoveItem(pTheBagID, BagSlot, tableItemInfo["ToBag"], "", "")
													end
													bolHaveItemsToMove = false
												end
											end
										end
									else
										if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
											NF_MB("chat", "Neat Freak - " .. itemName .. " is already in the Bag you want it." )
										end
									end
								end
							end
						end
					end
				end
			end
			if NeatFreakOptions.Debugging == 1 then
				NF_MB("chat", "Neat Freak - " .. itemName .. " found in slot " .. BagSlot )
			end
		end
	end

end

-- ============================================================================================================= --

function MoveItem(pSourceBagNum, pSourceSlotNum, pDestBagNum, pDestSlotNum, pQuantToMove)

	local lockedTexture, lockedCount, lockedLocked, lockedQuality, lockedReadable, strDestLocked

	if NeatFreakOptions.Chat == 1 or NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Neat Freak - Move from: " .. pSourceBagNum .. "/" .. pSourceSlotNum .. "  to: " .. pDestBagNum .. "/" .. pDestSlotNum )
	end

	if (pDestSlotNum ~= "" and pDestSlotNum ~= 0) then
		lockedTexture, lockedCount, lockedLocked, lockedQuality, lockedReadable = GetContainerItemInfo(pDestBagNum, pDestSlotNum)
		strDestLocked = lockedCount  --  Get any value from above that is present if an item in slot, or nil if empty
		-- lockedCount is nil if NOT locked.  Returns a val if locked
	end

	ClearCursor()
	if pQuantToMove == "" then  -- blank ("") Means move all.
		PickupContainerItem(pSourceBagNum, pSourceSlotNum);
	else
		SplitContainerItem(pSourceBagNum, pSourceSlotNum, pQuantToMove);
	end

	if strDestLocked ~= nil or pDestSlotNum == "" or pDestSlotNum == 0 then  -- desired dest bag/slot is locked (or dest slot not supplied), so just dump to bag
		if tonumber(pDestBagNum) == 0 then -- (backpack)
			PutItemInBackpack()  -- item currently on the cursor
		else
			pDestBagNum = (tonumber(pDestBagNum) - 1) + 20
			PutItemInBag( pDestBagNum )  -- item on the cursor
		end
	else
		PickupContainerItem(pDestBagNum, pDestSlotNum)  -- If the cursor currently contains an item , calling this will place the item currently on the cursor into the specified bag slot. If there is already an item in that bag slot, the two items will be exchanged.
	end

end

-- ============================================================================================================= --

function NeatFreakDropDownMenu_OnLoad()
-- http://www.wowwiki.com/UI_Object_UIDropDownMenu

	for x = 0, 4 do
		info = {};
		if GetBagName(x) ~= nil then
			info.text = "Bag " .. x .. " (" .. GetBagName(x) .. ")";
		else
			info.text = "Bag " .. x .. " (nothing equipped)";
		end
		info.value = x;
		info.func = function() NeatFreakWhatDropDownListOption() end;

		-- Add the above information to the options menu as a button.
		UIDropDownMenu_AddButton(info);
	end

end

-- ============================================================================================================= --

function NeatFreakWhatDropDownListOption()

	--NF_MB("chat", "option " .. this.value .. " was selected." );
	ItemBagDropDownMenuButtonText:SetText( "Bag " .. this.value );
	ItemBagEditBox:SetText( this.value );

end

-- ============================================================================================================= --

function NeatFreakDropDownMenu_OnClick()

	ToggleDropDownMenu(1, nil, NeatFreakDropDownMenu, ItemBagDropDownMenuButton, 0, 0);

end

-- ============================================================================================================= --

function PositionNeatFreakMiniMapIcon()

	local intMiniMapAngle, intMiniMapDistance, intWidth, intHeight, iconX, iconY;

	-- Show or Hide MiniMap Icon based on options
	if NeatFreakOptions.HideMiniMapButton == 1 then
		NeatFreakMinimapButton:Hide();
		NeatFreakOptionsPageSliderMiniMapAngle:Hide();
		NeatFreakOptionsPageSliderMiniMapDistance:Hide();
	else
		NeatFreakMinimapButton:Show();
		NeatFreakOptionsPageSliderMiniMapAngle:Show();
		NeatFreakOptionsPageSliderMiniMapDistance:Show();
	end

	if (not NeatFreakOptions.MiniMapAngle) then 
		intMiniMapAngle = 133;
	else
		intMiniMapAngle = NeatFreakOptions.MiniMapAngle;
	end

	if (not NeatFreakOptions.MiniMapDistance) then
		intMiniMapDistance = 9;
	else
		intMiniMapDistance = NeatFreakOptions.MiniMapDistance;
	end

	intWidth, intHeight = Minimap:GetWidth()/2, Minimap:GetHeight()/2;
	intWidth = intWidth + intMiniMapDistance;
	intHeight = intHeight + intMiniMapDistance;

	iconX = intWidth * sin(intMiniMapAngle);
	iconY = intHeight * cos(intMiniMapAngle);

	NeatFreakMinimapButton:ClearAllPoints();
	NeatFreakMinimapButton:SetPoint("CENTER", Minimap, "CENTER", iconX, iconY);

end

-- ============================================================================================================= --

function SetScrollListForNumItemsToShow()

	local intPadding, intEachLineHeight, intNumLineItemsShown, NeatFreakBarDist, line

	intPadding = 75;  -- Constant.  Top part of frame that we do NOT want any controls/data in.
	intEachLineHeight = 12.5;  -- Constant.  The row height of an entry. 
	if tonumber(NeatFreakOptions.NumListItems) < 7 then
		intEachLineHeight = 12.75;
	end
	if tonumber(NeatFreakOptions.NumListItems) > 10 then
		intEachLineHeight = 12.3;
	end
	intNumLineItemsShown = NeatFreakOptions.NumListItems;
	NeatFreakBarDist =  (intPadding + (intEachLineHeight * intNumLineItemsShown)) * -1;

	-- loop through each Line Entry and set it visible or hidden.
	for line = 1, intMaxNumScrollLines do
		if line <= NeatFreakOptions.NumListItems then
			getglobal("NeatFreakSortPageListItem" .. line):Show();
		else
			getglobal("NeatFreakSortPageListItem" .. line):Hide();
		end
	end

	NeatFreakOptionsPageSliderNumListItemsText:SetText(NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_NUMSHOWING .. ": " .. NeatFreakOptions.NumListItems);
	NeatFreakSortPageTheHorizontalBar:ClearAllPoints();
	NeatFreakSortPageTheHorizontalBar:SetPoint("TOPLEFT", NeatFreakSortPage, "TOPLEFT", 16, NeatFreakBarDist);

end

-- ============================================================================================================= --

function NeatFreak_SetupHookFunctions()

	NeatFreak_orig_ContainerFrameItemButton_OnModifiedClick = ContainerFrameItemButton_OnModifiedClick;
	ContainerFrameItemButton_OnModifiedClick = NeatFreak_ContainerFrameItemButton_OnModifiedClick;

end

-- ============================================================================================================= --

function NeatFreak_ContainerFrameItemButton_OnModifiedClick(button)

	-- Check if Neat Freak is showing and for ALT key
	if ( not NeatFreak:IsShown() or not IsAltKeyDown()) then
		return NeatFreak_orig_ContainerFrameItemButton_OnModifiedClick (button);
	end;

	if NeatFreakPageTitleText:GetText() ~= "Sort" then
		NeatFreakToggleTabs("Sort", 1)
	end

	local bagID  = this:GetParent():GetID();
	local slotID = this:GetID();
	PickupContainerItem(bagID, slotID);

	local infoType, info1, info2 = GetCursorInfo();
	-- infoType can be: item, spell, macro, money, merchant
	if NeatFreakOptions.Debugging == 1 then
		NF_MB("chat", "Type item: " .. infoType )
		NF_MB("chat", "Item Info1: " ..  info1 )
		NF_MB("chat", "Item Info2: " .. info2 )  -- nill if not returned.   merchant, money, macro
	end
	ClearCursor();

	if (infoType == "item" or infoType == "merchant") then
		local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, iPrice, iQuantity, iNumAvailable, sIsUsable, iExtendedCost, TheRadioButton
		if (infoType == "item") then
			itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(info1);
		end

		if infoType == "merchant" then
			itemName, itemTexture, iPrice, iQuantity, iNumAvailable, sIsUsable, iExtendedCost = GetMerchantItemInfo( info1 );
		end

		if NeatFreakOptions.Debugging == 1 then
			NF_MB("chat", itemName );
			NF_MB("chat", itemTexture );
		end

		-- Set the tableItemInfo fields and call UpdateInterface(tableItemInfo)
		tableItemInfo = {}
		tableItemInfo["ItemName"] = itemName
		tableItemInfo["ItemTexture"] = itemTexture
		tableItemInfo["ToBag"] = bagID
		tableItemInfo["ToSlot"] = slotID
		-- No longer default to Account Level
		--tableItemInfo["PerChar"] = 0
		TheRadioButton = CharacterRadio:GetChecked()  -- Flag -> 1 if the radio/check button is checked, or nil otherwise
		if TheRadioButton == nil then
--			NF_MB("chat", "CharacterRadio not selected" )
			tableItemInfo["PerChar"] = 0
		else
--			NF_MB("chat", "CharacterRadio is selected" )
			tableItemInfo["PerChar"] = 1
		end
		tableItemInfo["ItemType"] = itemType
		tableItemInfo["ItemSubType"] = itemSubType
		tableItemInfo["ItemRarity"] = itemRarity

		UpdateInterface(tableItemInfo);
	end

end

-- ============================================================================================================= --

function ErrorWithStack(msg) 

	msg = msg .. "\n" .. debugstack();
	_ERRORMESSAGE(msg);

end 

-- ============================================================================================================= --
