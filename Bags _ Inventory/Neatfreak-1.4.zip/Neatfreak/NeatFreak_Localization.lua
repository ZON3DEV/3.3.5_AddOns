﻿
	local bolDidLoc, NeatFreakAbout, NeatFreakSlashes, strTextToShow
	bolDidLoc = false;

	-- Default Localization --
	NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND = "English";
	-- for Neat Freak to work right only the next line MUST be done.
	NEATFREAK_LOCALE_TEXT_SOULBOUND = "Soulbound";

	-- Right Side Bar
	NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORTALL = "Sort All Bags";
	NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT0 = "Sort BackPack only";
	NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART1 = "Sort Bag ";
	NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART2 = " only";

	-- Main Interface
	NEATFREAK_LOCALE_INTERFACE_IMAGE_TOOLTIP_ITEM = "Drag an Item here to populate the Name, or ALT click on an item." .. "\n" .. "Right click to clear current entry info.";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_NAME = "By Name";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_NAME = "Select this radio button if the sorting entry should be by Item Name.";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TYPE = "By Type";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_TYPE = "Select this radio button if the sorting entry should be by Item Type.";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_RARITY = "By Rarity";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_RARITY = "Select this radio button if the sorting entry should be by Item Rarity.";
	NEATFREAK_LOCALE_INTERFACE_FIELD_NAME = "Item Name";
	NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_NAME = "Enter the Item Name." .. "\n" .. "(WildCard is *)";
	NEATFREAK_LOCALE_INTERFACE_FIELD_TYPE = "Item Type";
	NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_TYPE = "Enter the Item Type and Subtype, separated by ' - '.";
	NEATFREAK_LOCALE_INTERFACE_FIELD_RARITY = "Item Rarity";
	NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_RARITY = "Enter the Item Rarity." .. "\n" .. "(A Number, Gray = 0)";
	NEATFREAK_LOCALE_INTERFACE_DROPDOWN_BAG = "To Bag:";
	NEATFREAK_LOCALE_INTERFACE_DROPDOWN_TOOLTIPBAG = "Select the Destination Bag.";
	NEATFREAK_LOCALE_INTERFACE_FIELD_SLOT = "To Slot:";
	NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_SLOT = "Enter the Destination Slot #." .. "\n" .. "(optional)";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_CHARACTER = "Character Level";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_CHARACTER = "Select this radio button if the sorting should ONLY be for this Character.";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_ACCOUNT = "Account Level";
	NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_ACCOUNT = "Select this radio button if the sorting should be for all Characters (on this account).";
	NEATFREAK_LOCALE_INTERFACE_BUTTON_DONE = "Done";
	NEATFREAK_LOCALE_INTERFACE_BUTTON_ADDUPDATE = "Add / Update";
	NEATFREAK_LOCALE_INTERFACE_BUTTON_REMOVE = "Remove";

	-- Options Interface
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_ENABLEBAGS = "Enable Bags";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_ENABLEBAGS = "Turn opening/closing of bags on/off.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_AUCTION = "Auction";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_AUCTION = "Open/Close your bags at the Auction House.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_BANK = "Bank";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_BANK = "Open/Close your bags at the Bank.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_GUILD = "Guild";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_GUILD = "Open/Close your bags at the Guildbank.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MAILBOX = "MailBox";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MAILBOX = "Open/Close your bags at the Mailbox.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MERCHANTS = "Merchants";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MERCHANTS = "Open/Close your bags at Merchants.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TRADE = "Trade";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_TRADE = "Open/Close your bags when Trading.";
	--NEATFREAK_LOCALE_OPTIONS_CHECKBOX_NEATFREAK = "Neat Freak";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NEATFREAK = "Open/Close bags when Open/Closing Neat Freak.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEGRYPHONS = "Hide Gryphons";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEGRYPHONS = "Hide the Gryphons around the Action Bar." .. "\n" .. "Changing this requires a UI Reload to see it.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_DEBUGGING = "Debugging";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_DEBUGGING = "Turn Debugging Messages on/off.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_CHATTING = "Chatting";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_CHATTING = "Turn Neat Freak Chatting Messages on/off.";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SHUTUP = "Shut Up";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SHUTUP = "Make Neat Freak NEVER chat." .. "\n" .. "Will still do popups, and the welcome chat message." ;
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SOULBOUND = "Skip Soulbound Items";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SOULBOUND = "Do NOT sort Soulbound items if checked." .. "\n" .. "For when sorting by Rarity/Quality.";
	NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_NUMSHOWING = "Number Items Showing";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NUMSHOWING = "Set number of Scroll List items to show.";

	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEMINIMAP = "Hide MiniMap Button";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEMINIMAP = "Hide the MiniMap Button.";
	NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPANGLE = "MiniMap Angle";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPANGLE = "Set what Angle, around the MiniMap, to put the button." .. "\n" .. "(0/360 is the top)";
	NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPDISTANCE = "MiniMap Distance";
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPDISTANCE = "Set what Distance, from the Center of the MiniMap, to put the button.";

	-- About Interface
	NeatFreakAbout = "About:" .. "\n" .. "I started this AddOn because I wanted a way to keep my bags organized when questing/grinding." .. "\n\n";
	NeatFreakAbout = NeatFreakAbout .. "Wildcard character --> *" .. "\n\n" .. "Add Entry to List (By Name):" .. "\n" .. "With the interface open select the 'By Name' radio button. Type in the name of the Item to be sorted, or drag and drop the Item onto the Icon place holder, or ALT click the item. Select the Bag # and Slot # (optional)(starts at 1 in the upper left most slot). Click the 'Add / Update' button." .. "\n\n"
	NeatFreakAbout = NeatFreakAbout .. "Add Entry to List (By Type):" .. "\n" .. "With the interface open select the 'By Type' radio button. Type in the Type and Subtype of the Items to be sorted separated by a [space] [dash] [space] (ie 'Trade Goods - Cloth', or 'Quest - Quest'), or drag and drop an item of the Type to be sorted onto the icon place holder, or ALT click an item. Select the Bag # and Slot # (optional. Kind of useless for Type, so I leave it blank). Click the 'Add / Update' button." .. "\n"
	NeatFreakSlashes = "Slash Commands:" .. "\n" .. "/neatfreak  -> Opens the Neat Freak interface." .. "\n" .. "/neatfreak sort (bag#)  -> valid bag #'s: all, 0, 1, 2, 3, 4" .. "\n" .. "/neatfreak findwindow  -> Relocates the Interface window if it is off screen somehow.";
	NEATFREAK_LOCALE_ABOUT_TEXTAREA_ABOUT = "|cff00FF33" .. NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND .. " localization used." .. "\n" .. NeatFreakAbout .. "\n\n" .. NeatFreakSlashes .. "|r"

	-- MiniMap Buttoon
	NEATFREAK_LOCALE_MINIMAP_BUTTON_TOOLTIP = "Open / Close Neat Freak.";

	-- English Localization --
	if (GetLocale() == "enUS") then
		bolDidLoc = true;
	end

	-- German Localization --
	if (GetLocale() == "deDE") then
		NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND = "Deutsch";
	-- for Neat Freak to work right only the next line MUST be done.
		NEATFREAK_LOCALE_TEXT_SOULBOUND = "Seelengebunden";
	
		-- Right Side Bar
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORTALL = "Sortieren Sie Alle Säcke";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT0 = "Sortieren Sie Rucksack nur";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART1 = "Sortieren Sie Sack ";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART2 = " nur";
	
		-- Main Interface
		NEATFREAK_LOCALE_INTERFACE_IMAGE_TOOLTIP_ITEM = "Schleppen Sie ein Ding hier, den Namen zu bevölkern, oder ALT klicken Sie ein Ding an." .. "\n" .. "Richtiges Klicken, jetzige Zuganginfo zu reinigen.";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_NAME = "Mit Namen";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_NAME = "Wählen Sie diesen Radioknopf aus, wenn der sortierende Zugang durch Dingnamen sein sollte. ";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TYPE = "Durch Typ";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_TYPE = "Wählen Sie diesen Radioknopf aus, wenn der sortierende Zugang durch Ding sein sollte. ";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_RARITY = "Durch Seltenheit";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_RARITY = "Wählen Sie diesen Radioknopf aus, wenn der sortierende Zugang durch Dingseltenheit sein sollte. ";
		NEATFREAK_LOCALE_INTERFACE_FIELD_NAME = "Dingname";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_NAME = "Tragen Sie den Dingnamen ein. " .. "\n" .. "(WildCard ist *)";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TYPE = "Ding";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_TYPE = "Tragen Sie das Ding und den SubType ein, die von getrennt werden ' - '.";
		NEATFREAK_LOCALE_INTERFACE_FIELD_RARITY = "Dingseltenheit";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_RARITY = "Tragen Sie die Dingseltenheit ein." .. "\n" .. "(Eine Zahl, Grauen Sie an = 0)";
		NEATFREAK_LOCALE_INTERFACE_DROPDOWN_BAG = "Um Einzusacken:";
		NEATFREAK_LOCALE_INTERFACE_DROPDOWN_TOOLTIPBAG = "Wählen Sie den Reisezielsack aus.";
		NEATFREAK_LOCALE_INTERFACE_FIELD_SLOT = "Zu Steckplatz:";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_SLOT = "Tragen Sie den Reisezielsteckplatz ein #." .. "\n" .. "(wahlfrei)";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_CHARACTER = "Charakterhöhe";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_CHARACTER = "Wählen Sie diesen Radioknopf aus, wenn der Sortieren NUR für diesen Charakter sein sollte.";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_ACCOUNT = "Begründen Sie Höhe";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_ACCOUNT = "Wählen Sie diesen Radioknopf aus, wenn der Sortieren für alle Charaktere sein sollte (Auf diesem Konto).";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_DONE = "Gemacht";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_ADDUPDATE = "Stellen Sie / Änderung";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_REMOVE = "Löschen Sie";
	
		-- Options Interface
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_ENABLEBAGS = "Ermöglichen Säcke";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_ENABLEBAGS = "Drehen Sie offen/nah von Säcken auf/ab.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_AUCTION = "Auktion";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_AUCTION = "Offen/nah Ihre Säcke am Auktionshaus.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_BANK = "Bank";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_BANK = "Offen/nah Ihre Säcke an der Bank.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_GUILD = "Zunft";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_GUILD = "Offen/nah Ihre Säcke am ZunftBank.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MAILBOX = "Briefkasten";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MAILBOX = "Offen/nah Ihre Säcke am Briefkasten.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MERCHANTS = "Kaufleute";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MERCHANTS = "Offen/nah Ihre Säcke an Kaufleuten.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TRADE = "Handel";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_TRADE = "Offen/nah Ihre Säcke wenn Handel.";
		--NEATFREAK_LOCALE_OPTIONS_CHECKBOX_NEATFREAK = "Neat Freak";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NEATFREAK = "Offen/nahe Säcke wenn Offen/Nah Neat Freak.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEGRYPHONS = "Verstecken Gryphons";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEGRYPHONS = "Verstecken Sie der Gryphons um den Handlungsstab." .. "\n" .. "Änderung dies erfordert, dass ein UI Wiederlädt, es zu sehen.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_DEBUGGING = "Testhilfe";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_DEBUGGING = "Schalten Sie Testhilfee Nachrichten ein/ab.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_CHATTING = "Plaudern";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_CHATTING = "Drehen Sie Ordentlichen Exzentriker, der Nachrichten auf Plaudert/ab.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SHUTUP = "Schließen Sie ab";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SHUTUP = "Ausführung Neat Freak Plaudern Sie NIE." .. "\n" .. "Noch wird popups, und die willkommene Plaudereiennachricht machen." ;
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SOULBOUND = "Übergehen Seelengebunden";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SOULBOUND = "Sortieren Sie Seelengebunden Dinge NICHT wenn geprüft." .. "\n" .. "Für beim Sortieren durch Seltenheit/Qualität.";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_NUMSHOWING = "Zahlendinge Zeigend";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NUMSHOWING = "Feste Zahl von Rollenlistendingen, zu zeigen.";
	
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEMINIMAP = "Verstecken MiniMap Knopf";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEMINIMAP = "Verstecken Sie den MiniMap Knopf. ";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPANGLE = "MiniMap Winkel";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPANGLE = "Setzen Sie, was Umbiegt, um den MiniMap, den Knopf zu stellen." .. "\n" .. "(0/360 Ist das Oberteil)";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPDISTANCE = "MiniMap Entfernung";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPDISTANCE = "Setzen Sie, was Distanziert, von der Mitte dem MiniMap, den Knopf zu stellen.";
	
		-- About Interface
		NeatFreakAbout = "Um:" .. "\n" .. "Ich habe dieser AddOn angefangen, weil ich einen Weg gewollt habe, meine Säcke zu behalten, haben organisiert, beim questing/mahlend. " .. "\n\n";
		NeatFreakAbout = NeatFreakAbout .. "WildCard Charakter --> *" .. "\n\n" .. "Fügen Sie Zugang hinzu um (mit Namen) Aufzuführen:" .. "\n" .. "Mit der Schnittstelle wählt offen das ‚mit Namen‘ Radioknopf aus.  Tippen Sie den Namen vom Ding ein, sortiert zu werden, oder schleppen Sie und lassen Sie fallen das Ding auf den Abbild Stellenhalter, oder ALT klickt das Ding. Wählen Sie den Sack aus # und Steckplatz # (wahlfrei)(anfänge an 1 im links oben der meiste Steckplatz).  Klicken Sie das ‚Fügt / Aktualisierung Hinzu‘ Knopf." .. "\n\n"
		NeatFreakAbout = NeatFreakAbout .. "Fügen Sie Zugang Aufzuführen hinzu (Durch Typ):" .. "\n" .. "Mit der Schnittstelle wählt offen das ‚Durch Typ‘ Radioknopf aus.  Tippen Sie die Typen und die SubType von den Dingen ein, getrennt durch ein sortiert zu werden [platz] [sprung] [platz] (ie 'Handeln Sie Güter - Tuch', oder 'Suche - Suche'), oder Widerstand und lässt fallen ein Ding vom Typ, auf den Abbildstellenhalter sortiert zu werden, oder ALT klicken ein Ding. Wählen Sie den Sack aus # und Steckplatz # (wahlfrei). Klicken Sie das ‚Fügt / Aktualisierung Hinzu‘ Knopf." .. "\n"
		NeatFreakSlashes = "Streich Befiehlt:" .. "\n" .. "/neatfreak  -> Öffnet das Neat Freak schnittstelle." .. "\n" .. "/neatfreak sort (bag#)  -> Gültiger Sack zählt: all, 0, 1, 2, 3, 4" .. "\n" .. "/neatfreak findwindow  -> Repositioniert das Schnittstelle Fenster, wenn es ab Schirm irgendwie ist.";
		NEATFREAK_LOCALE_ABOUT_TEXTAREA_ABOUT = "|cff00FF33" .. NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND .. " lokalisation hat benutzt." .. "\n" .. NeatFreakAbout .. "\n\n" .. NeatFreakSlashes .. "|r"
	
		-- MiniMap Buttoon
		NEATFREAK_LOCALE_MINIMAP_BUTTON_TOOLTIP = "Offen / Nah Neat Freak.";

		bolDidLoc = true;
	end

	-- Traditional Chinese (zhTW) Localization -- 
	if (GetLocale() == "zhTW") then 
		NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND = "繁體中文"; 
	-- for Neat Freak to work right only the next line MUST be done.
		NEATFREAK_LOCALE_TEXT_SOULBOUND = "靈魂綁定";

		-- Right Side Bar
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORTALL = "種類都捕獲";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT0 = "種類只限背包";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART1 = "種類的袋 ";
		NEATFREAK_LOCALE_RSIDEBAR_BUTTON_TOOLTIP_SORT_PART2 = " 只是";

		-- Main Interface
		NEATFREAK_LOCALE_INTERFACE_IMAGE_TOOLTIP_ITEM = "拖曳一個項目在這裡要居住於在一個項目上的名字，或 ALT 按一下。" .. "\n" .. "按一下滑鼠右鍵清除目前的進入資訊。";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_NAME = "憑名字";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_NAME = "選擇這個選項按鈕，如果交往進入應該按項目名字。";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TYPE = "按品級";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_TYPE = "選擇這個選項按鈕，如果交往進入應該透過項目類型。";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_RARITY = "到了稀罕";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_RARITY = "選擇這個選項按鈕，如果交往進入應該按項目稀罕。";
		NEATFREAK_LOCALE_INTERFACE_FIELD_NAME = "項目名字";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_NAME = "輸入項目名字。" .. "\n" .. "(萬用字元 是 *)";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TYPE = "項目類型";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_TYPE = "進入項目類型和 子型，分開所作 ' - '.";
		NEATFREAK_LOCALE_INTERFACE_FIELD_RARITY = "項目稀罕";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_RARITY = "輸入項目稀罕。" .. "\n" .. "(一個數字，格雷 = 0)";
		NEATFREAK_LOCALE_INTERFACE_DROPDOWN_BAG = "到袋:";
		NEATFREAK_LOCALE_INTERFACE_DROPDOWN_TOOLTIPBAG = "選擇目的地袋。";
		NEATFREAK_LOCALE_INTERFACE_FIELD_SLOT = "到縫:";
		NEATFREAK_LOCALE_INTERFACE_FIELD_TOOLTIP_SLOT = "輸入目的地縫數字。" .. "\n" .. "(可選)";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_CHARACTER = "特性水平";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_CHARACTER = "選擇這個選項按鈕，如果排序應該只是為這個文字的。";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_ACCOUNT = "帳戶水平";
		NEATFREAK_LOCALE_INTERFACE_RADIOBUTTON_TOOLTIP_ACCOUNT = "選擇這個選項按鈕，如果排序應該對所有文字 (在這個帳戶上).";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_DONE = "結束";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_ADDUPDATE = "添加 / 更新";
		NEATFREAK_LOCALE_INTERFACE_BUTTON_REMOVE = "移開";

		-- Options Interface
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_ENABLEBAGS = "容許袋";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_ENABLEBAGS = "袋的旋轉開始/關閉開／關。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_AUCTION = "拍賣";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_AUCTION = "公開/接近你的在拍賣所的袋。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_BANK = "Bank";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_BANK = "公開/接近你的在銀行的袋。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_GUILD = "同業工會";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_GUILD = "公開/接近你的 同業工會庫 的袋。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MAILBOX = "信箱";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MAILBOX = "公開/接近你的信箱的袋。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_MERCHANTS = "商人";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MERCHANTS = "公開/接近你的商人的袋。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TRADE = "貿易";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_TRADE = "公開/接近進行貿易時的你的袋。";
		--NEATFREAK_LOCALE_OPTIONS_CHECKBOX_NEATFREAK = "Neat Freak";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NEATFREAK = "公開/接近的袋當公開/結束 Neat Freak.";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEGRYPHONS = "隱藏半獅半鷺的怪獸";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEGRYPHONS = "隱藏在行動酒吧附近的半獅半鷺的怪獸。" .. "\n" .. "更換這要求一 UI 重新裝入要看它。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_DEBUGGING = "偵錯";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_DEBUGGING = "旋轉除錯消息開／關。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_CHATTING = "聊天";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_CHATTING = "旋轉整潔奇異聊天消息開／關。";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SHUTUP = "住口";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SHUTUP = "決不製作整潔的怪東西閒聊。" .. "\n" .. "還將做彈出式，受歡迎的閒聊消息。" ;
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_SOULBOUND = "跳靈魂向的項目";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_SOULBOUND = "不排序靈魂向的項目如果檢查。" .. "\n" .. "對依稀罕/質量排序時。";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_NUMSHOWING = "數字項目放映";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_NUMSHOWING = "將紙卷清單項目的數字，設定為顯示。";

		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_HIDEMINIMAP = "隱藏 MiniMap 按鈕";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_HIDEMINIMAP = "隱藏 Minimap 按鈕。";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPANGLE = "Minimap 角";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPANGLE = "設定釣魚的，環繞 MiniMap，要提出按鈕。" .. "\n" .. "(0/360 是頂部)";
		NEATFREAK_LOCALE_OPTIONS_SLIDEBAR_MINIMAPDISTANCE = "MiniMap 距離";
		NEATFREAK_LOCALE_OPTIONS_CHECKBOX_TOOLTIP_MINIMAPDISTANCE = "設定超過的，從 MiniMap 的中心，要提出按鈕。";

		-- About Interface
		NeatFreakAbout = "大約:" .. "\n" .. "我開始這 外接附件 因為我想要保有被組織的我的袋的一種方式當探索/折磨。" .. "\n\n";
		NeatFreakAbout = NeatFreakAbout .. "萬用字元 --> *" .. "\n\n" .. "把進入加到清單上 (憑名字):" .. "\n" .. "拿著介面打開選擇 ' 到了名字 ' 選項按鈕。 鍵入以有待排序的項目的名義，或往圖示地方持有人上拖和扔下品種, 或 ALT 按一下項目。 選擇袋數字和開槽數字 (可選)(在上面的左邊裡始於 一個 大多數縫). 按一下 ' 添加/更新 ' 按鈕。" .. "\n\n"
		NeatFreakAbout = NeatFreakAbout .. "把進入加到清單上 (按品級):" .. "\n" .. "拿著介面打開選擇 ' 到了類型 ' 選項按鈕。 鍵入在類型中和子型有待排序的項目中分開所作 [空間] [破折號] [空間] (ie ' 貿易貨物 - 布 '，或 ' 探索 - 探索 '), 或拖曳和扔下往圖示地方持有人上有待整理的類型的一個項目, 或 ALT 按一下一個項目。 選擇袋數字和開槽數字 (可選. 有點無用對類型，這樣我留下它空白). 按一下 ' 添加/更新 ' 按鈕。" .. "\n"
		NeatFreakSlashes = "Slash Commands:" .. "\n" .. "/neatfreak  -> 打開整潔奇異的介面。" .. "\n" .. "/neatfreak sort (袋數字)  -> 有效的袋計數: all, 0, 1, 2, 3, 4" .. "\n" .. "/neatfreak findwindow  -> 重新確定介面窗口的位置，如果它以某種方法離開螢幕。";
		NEATFREAK_LOCALE_ABOUT_TEXTAREA_ABOUT = "|cff00FF33" .. NEATFREAK_LOCALE_TEXT_LANGUAGE_FOUND .. " 本地化使用。" .. "\n" .. NeatFreakAbout .. "\n\n" .. NeatFreakSlashes .. "|r"

		-- MiniMap Buttoon
		NEATFREAK_LOCALE_MINIMAP_BUTTON_TOOLTIP = "打開 /關閉 Neat Freak.";

		bolDidLoc = true;
	end

	-- Following should probably NEVER be Transulated
	NEATFREAK_LOCALE_OPTIONS_CHECKBOX_NEATFREAK = "Neat Freak";

	if bolDidLoc == false then
		--strTextToShow = "Neat Freak is not Localized for " .. GetLocale() .. ".  Defaulting to enUS.";
		strTextToShow = "Neat Freak is not Localized for " .. GetLocale() .. ".  Defaulting to enUS." .. "\n" .. "If you post the following (at curse.com), with the blanks filled in, then I can add basic localization." .. "\n" .. "'Soulbound' in " .. GetLocale() .. " is _____";
		message( strTextToShow );
	end
