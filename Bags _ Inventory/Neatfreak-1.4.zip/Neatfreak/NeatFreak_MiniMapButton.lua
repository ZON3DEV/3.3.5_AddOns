-- http://www.wowinterface.com/forums/showthread.php?t=16339

local NeatFreakMinimapButton = CreateFrame('Button', "NeatFreakMinimapButton", Minimap)

function NeatFreakMinimapButton:Load()

    self:SetFrameStrata('HIGH')  -- I did not use in xml
    self:SetWidth(31)  -- 21 in xml
    self:SetHeight(31)  -- 21 in xml
    self:SetFrameLevel(8)  -- 7 in xml, in the OnLoad
    --self:RegisterForClicks('anyUp')
    self:SetHighlightTexture('Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight')

    local overlay = self:CreateTexture(nil, 'OVERLAY')
    overlay:SetWidth(53)
    overlay:SetHeight(53)
    overlay:SetTexture('Interface\\Minimap\\MiniMap-TrackingBorder')
    overlay:SetPoint('TOPLEFT')

    local icon = self:CreateTexture(nil, 'BACKGROUND')  -- ARTWORK in xml
    icon:SetWidth(18)  -- 22 in xml
    icon:SetHeight(18)  -- 22 in xml
    icon:SetTexture('Interface\\MerchantFrame\\UI-BuyBack-Icon')
    icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)  -- not in xml
    icon:SetPoint('TOPLEFT', 6, -6)  -- 1, -1 in xml
    self.icon = icon

    self:SetScript('OnClick', self.OnClick)
    self:SetScript('OnEnter', self.OnEnter)
    self:SetScript('OnLeave', self.OnLeave)

--    self:SetScript('OnDragStart', self.OnDragStart)
--    self:SetScript('OnDragStop', self.OnDragStop)
--    self:SetScript('OnMouseDown', self.OnMouseDown)
--    self:SetScript('OnMouseUp', self.OnMouseUp)

    --self:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", -2, 2)  -- positions button.  Neat Freak has function 4 this.

end

------------------

function NeatFreakMinimapButton:OnClick(button)

--[[
    -- modified slightly from orig sample, and left for referance.
	if button == 'LeftButton' then
        message("left click")
    elseif button == 'RightButton' then
        message("right click")
    end
]]

	if(NeatFreak:IsVisible()) then
		NeatFreak:Hide();
	else
		NeatFreak:Show();
	end

end

------------------

function NeatFreakMinimapButton:OnEnter()

	getglobal(this:GetName()).tooltip = NEATFREAK_LOCALE_MINIMAP_BUTTON_TOOLTIP;
	if (self.tooltip) then
		GameTooltip:SetOwner(self, "ANCHOR_LEFT");
		GameTooltip:SetText(self.tooltip, 0.9, 0.4, 0.0, nil, 1);
	end

end

------------------

function NeatFreakMinimapButton:OnLeave()

	GameTooltip:Hide();

end

------------------

NeatFreakMinimapButton:Load();
