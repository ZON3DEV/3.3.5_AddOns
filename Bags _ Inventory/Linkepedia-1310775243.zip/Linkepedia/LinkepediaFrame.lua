﻿------------------------------------------------------
-- LinkepediaFrame.lua
-- The frame code for Linkepedia
------------------------------------------------------

-- PROGRESS FRAME --

LNKPDFrame_FrameState = "CANCELED";
local LNKPDFrame_OrigBarWidth = 0;

function LNKPDFrame_BuildCache_OnLoad()
    LNKPDFrame_OrigBarWidth = LNKPDFrame_BuildCache_ProgressBar:GetWidth();
end

function LNKPDFrame_BuildCache_Cancel_OnClick()
    if(LNKPDFrame_FrameState == "BUILDING") then
        LNKPD_CancelBuild();
        LNKPDFrame_BuildCache_Cancel:SetText("Rebuild");
        LNKPDFrame_FrameState = "CANCELED";
        LNKPDFrame_SetStatusText(" > Idle Scanning", "", "")
        LNKPDFrame_SetActiveStatus(1);

    elseif(LNKPDFrame_FrameState == "CANCELED") then
        LNKPD_RebuildCache();
        LNKPDFrame_BuildCache_Cancel:SetText("Cancel");
        LNKPDFrame_FrameState = "BUILDING";
    end
end

function LNKPDFrame_BuildCache_HideWindow_OnClick()
    LNKPDFrame_BuildCache:Hide();
end

function LNKPDFrame_ShowBuild()
    if(LNKPDFrame_FrameState == "CANCELED") then
        LNKPDFrame_BuildCache_Cancel:SetText("Rebuild");
        LNKPDFrame_SetStatusText(" > Idle Scanning", "", "")
        LNKPDFrame_SetActiveStatus(1);
    elseif(LNKPDFrame_FrameState == "BUILDING") then
        LNKPDFrame_BuildCache_Cancel:SetText("Cancel");
        LNKPDFrame_SetActiveStatus(1);
    end

    LNKPDFrame_BuildCache:Show();
end

function LNKPDFrame_SetStatusText(one, two, three)
    LNKPDFrame_BuildCache_Status1:SetText(one);
    LNKPDFrame_BuildCache_Status2:SetText(two);
    LNKPDFrame_BuildCache_Status3:SetText(three);
end

function LNKPDFrame_SetActiveStatus(val)
    LNKPDFrame_BuildCache_Status1:SetTextColor(0.5, 0.5, 0.5);
    LNKPDFrame_BuildCache_Status2:SetTextColor(0.5, 0.5, 0.5);
    LNKPDFrame_BuildCache_Status3:SetTextColor(0.5, 0.5, 0.5);

    _G["LNKPDFrame_BuildCache_Status" .. val]:SetTextColor(0.0, 1.0, 0.0);
end

function LNKPDFrame_SetPercentage(val)
    LNKPDFrame_BuildCache_Percent:SetText(string.format("%.2f", val * 100) .. "%");
    local newWidth = LNKPDFrame_OrigBarWidth * val;
    LNKPDFrame_BuildCache_ProgressBar:SetWidth(newWidth);
end

function LNKPDFrame_SetLinksFound(val)
    LNKPDFrame_BuildCache_LinksFound:SetText("Items Found: " .. LNKPDUtils.CommaValue(val));
end

-- WELCOME FRAME --
function LNKPDFrame_ShowWelcome()
    LNKPDFrame_Welcome_Frame:Show();
end

function LNKPDFrame_Welcome_Build_OnClick()
    LNKPDFrame_Welcome_Frame:Hide();
    LNKPD_RebuildCache();
end

function LNKPDFrame_Welcome_Close_OnClick()
    LNKPDFrame_Welcome_Frame:Hide();
end