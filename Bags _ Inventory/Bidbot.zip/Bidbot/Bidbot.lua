function Bidbot_OnLoad()
	Bidbot:RegisterEvent("CHAT_MSG_RAID");
	Bidbot:RegisterEvent("CHAT_MSG_RAID_LEADER");
	Bidbot:RegisterEvent("CHAT_MSG_SYSTEM");
	Bidbot:RegisterEvent("LOOT_OPENED");
	Bidbot:RegisterEvent("LOOT_CLOSED");

	SLASH_BIDBOT1 = "/bb";
	SLASH_BIDBOT2 = "/bidbot";
	SlashCmdList["BIDBOT"] = Bidbot_Command;

	Bidbot_Variables();

	bb_loot_list={};
	bb_loot_id=1;
	bb_loot_more=false;
end

function Bidbot_OnEvent(self, event, msg, author, ...)
	if(not BB["standby"] and bb_bidding and (event=="CHAT_MSG_RAID" or event=="CHAT_MSG_RAID_LEADER")) then
		local type,amount=Bidbot_CheckMSG(msg,author);
		if(type~=nil and amount~=nil) then
			Bidbot_DoBid(author,type,amount);
		end
	elseif(bb_bidding and event=="CHAT_MSG_SYSTEM") then
		local txt_start,txt_end=string.find(msg,bb_txt_roll);
		local dig_start,dig_end=string.find(msg,bb_txt_roll_dig);
		if(txt_start~=nil and dig_start~=nil) then
			local author,type,amount=strsub(msg,1,txt_start-2),"roll ("..strsub(msg,txt_end+2,strlen(msg)-8)..")",0;
			Bidbot_DoBid(author,type,amount);
		end
	elseif(event=="LOOT_OPENED" and GetLootMethod()=="master") then
		local player_is_ml=false;
		if(select(1,UnitName("player"),...)==select(1,GetRaidRosterInfo(select(3,GetLootMethod())),...)) then
			player_is_ml=true;
		end
		if(not bb_bidding and player_is_ml) then
			local crap,bb_id=true,1;
			for i=1,GetNumLootItems() do
				local lootIcon, lootName, lootQuantity, rarity, locked = GetLootSlotInfo(i);
				if(rarity>=BB['autoloot']['threshold']) then
					crap=false;
					if(GetLootSlotLink(i)~=nil) then
						bb_loot_list[bb_id]=GetLootSlotLink(i);
					else
						bb_loot_list[bb_id]="";
					end
					bb_id=bb_id+1;
				end
			end
			if(BB['autoloot']['link'] and not crap) then
				local mess,mess2="","";
				for i=1,#bb_loot_list do
					if(i==1) then
						mess=bb_loot_list[i];
					elseif(i==#bb_loot_list) then
						if((strlen(mess)+strlen(bb_loot_list[i]))<=255) then
							mess=mess..bb_txt_and..bb_loot_list[i];
						else
							if(mess2=="") then
								mess2=bb_txt_and..bb_loot_list[i];
							else
								mess2=mess2..bb_txt_and..bb_loot_list[i];
							end
						end
					else
						if((strlen(mess)+strlen(", ")+strlen(bb_loot_list[i]))<=255) then
							mess=mess..", "..bb_loot_list[i];
						else
							if(mess2=="") then
								mess=mess..", ";
								mess2=bb_loot_list[i];
							else
								mess2=mess2..", "..bb_loot_list[i];
							end
						end
					end
				end
				if(mess2~="") then
					SendChatMessage(bb_txt_name..bb_txt_loot_link..mess..".",BB['announce'],nil);
					SendChatMessage(mess2..".",BB['announce'],nil);
				else
					SendChatMessage(bb_txt_name..bb_txt_loot_link..mess..".",BB['announce'],nil);
				end
			end
			if(BB['autoloot']['all']) then
				Bidbot_Loot();
			end	
		end
		bb_loot_interrupted=false;
		bb_loot_countdown_finished=false;
	elseif(bb_bidding and event=="LOOT_CLOSED" and GetLootMethod()=="master" and not bb_loot_countdown_finished) then
		bb_loot_interrupted=true;
	end
end

function Bidbot_OnUpdate(self, elapsed)
	if(bb_bidding) then
		bb_timer_last=bb_timer_last+elapsed;
		if(bb_timer_last>bb_timer_interval) then
			if(not bb_bid_announced) then
				SendChatMessage(bb_txt_name..bb_txt_bid_start_pre..bb_bid_ilink..bb_txt_bid_start_mid..bb_timer_bidtime.."+"..bb_timer_countdown..bb_txt_bid_start_post,BB['announce'],nil);
				bb_bid_announced=true;
			end
			if(bb_timer_bidtime>0) then
				bb_timer_bidtime=bb_timer_bidtime-1;
			elseif(bb_timer_countdown>0) then
				if(bb_timer_countdown==BB['countdown']) then
					SendChatMessage(bb_txt_name..bb_txt_bid_countdown..bb_timer_countdown.."...", BB['announce'], nil);
				else
					SendChatMessage(bb_timer_countdown.."...", BB['announce'], nil);
				end
				bb_timer_countdown=bb_timer_countdown-1;
			elseif(bb_timer_countdown==0 and bb_timer_bidtime==0) then
				if(not bb_loot_announced) then
					if(#bb_high_bidder==0) then
						SendChatMessage(bb_txt_name..bb_txt_bid_no_winner_pre..bb_bid_ilink..bb_txt_bid_no_winner_post, BB['announce'], nil);
						local crap;
						bb_high_bidder[1],crap=UnitName("player");
					elseif(#bb_high_bidder==1) then
						SendChatMessage(bb_txt_name..bb_high_bidder[1]..bb_txt_bid_end_pre..bb_bid_ilink..bb_txt_bid_end_post..bb_high_bid.." "..bb_txt_dkp.." ("..bb_high_type..")!", BB['announce'], nil);
					else
						local bidders,taken,winner="","","";
						for i=1,#bb_high_bidder do
							local newnum;
							do
								newnum=math.random(#bb_high_bidder);
								if(string.find(taken,newnum)~=nil) then
									break;
								end
							end
							taken=taken..newnum;
							if(i==1) then
								bidders=bb_high_bidder[newnum];
								winner=bb_high_bidder[newnum];
							else
								bidders=bidders..", "..bb_high_bidder[newnum];
							end
						end
						SendChatMessage(bb_txt_bid_roll_pre..bb_bid_ilink..bb_txt_bid_roll_mid..bb_high_bid.." "..bb_txt_dkp.." ("..bb_high_type..")"..bb_txt_bid_roll_post..bidders..".", BB['announce'], nil);
						bb_high_bidder[1]=winner;
					end
					bb_loot_announced=true;
				end
				bb_loot_countdown_finished=true;
				if(not bb_loot_interrupted) then
					if(bb_bidding and BB['autoloot']['all']) then
						local given=false;
						for i=1,GetNumRaidMembers() do
							if(bb_high_bidder[1]==GetMasterLootCandidate(i)) then
								local give_id=1;
								for i=1,GetNumLootItems() do
									if(GetLootSlotLink(i)==bb_loot_list[bb_loot_id]) then
										give_id=i;
										break;
									end
								end
								GiveMasterLoot(give_id,i);
								given=true;
								break;
							end
						end
						if(not given) then
							SendChatMessage(bb_txt_name..bb_txt_bid_error_loot_eligble..bb_bid_ilink..".", BB['announce'], nil);
							
							bb_loot_more=false;
						end
					end

					if(bb_loot_more) then
						bb_loot_id=bb_loot_id+1;
						Bidbot_Loot();
					else
						Bidbot_StopBid();
						CloseLoot();
					end
				end
			end
			bb_timer_last=0;
		end
	end
end

function Bidbot_Variables()
	if(BB==nil) then
		BB={};
		BB['standby']=false;
		BB['bidwords']={};
		BB['bidwords'][1]="bid";
		BB['default_bid']=10;
		BB['bidtime']=20;
		BB['countdown']=5;
		BB['announce']="RAID_WARNING";
		
		BB['autoloot']={link=false,all=false,threshold=4};

		for i=1,100 do
			BB['bidwords'][1000-i]="roll ("..i..")";
		end
	end

	if(BB['bidwords'][999]==nil) then
		for i=1,100 do
			BB['bidwords'][1000-i]="roll ("..i..")";
		end
	end
	
	if(BB['autoloot']==nil) then
		BB['autoloot']={};
		BB['autoloot']['link']=false;
		BB['autoloot']['all']=false;
		BB['autoloot']['threshold']=4;
	end
	
	if(BB['announce']==nil) then
		BB['announce']="RAID_WARNING";
	end
	
	if(BB['autoloot']['threshold']==nil) then
		BB['autoloot']['threshold']=4;
	end

	bb_timer_last=0.0;
	bb_timer_interval=1.0;
	
	bb_loot_interrupted=false;
	bb_loot_countdown_finished=false;
	bb_loot_announced=false;
	
	bb_bidding=false;
	bb_bid_announced=false;
	bb_bid_ilink="";
	bb_high_bid=0;
	bb_high_type="";
	bb_high_bidder={};
	bb_bidlist={};

-- ****************************************************************************************************************
	bb_txt_cname="|cFFccccccBidbot|r - ";
	bb_txt_name="Bidbot - ";
	bb_txt_stop="Stopped manually.";

	bb_txt_rarity={rare=3,epic=4,legendary=5};
	bb_txt_crarity={'','','|cff0070ddrare|r','|cffa335eeepic|r','|cffff8000legendary|r'};

	bb_txt_dkp="DKP";
	bb_txt_roll="rolls";
	bb_txt_roll_dig="(1-100)";
	
	bb_txt_loot_link="Loots are: ";
	
	bb_txt_and=" and ";

	bb_txt_bid_start_pre="Start bidding for ";
	bb_txt_bid_start_mid="... you have ";
	bb_txt_bid_start_post=" seconds.";
	bb_txt_bid_countdown="Bidding ending in ";
	bb_txt_bid_end_pre=" wins ";
	bb_txt_bid_end_post=" with a bid of ";
	bb_txt_bid_no_winner_pre="There was noone bidding for ";
	bb_txt_bid_no_winner_post=". Goes to disenchant!";
	bb_txt_bid_roll_pre="Randomizing have been finished, the winner of ";
	bb_txt_bid_roll_mid=" for a price of ";
	bb_txt_bid_roll_post=" is (in descending order): ";
	bb_txt_bid_error_loot_eligble="Error looting... The player that won was not eligble as looter on ";

	bb_txt_bidwords_help="Useage: '/bb <add/remove/promote/demote/list> <word>'";
	bb_txt_bidwords_help_add="Useage: '/bb add <word>'";
	bb_txt_bidwords_help_remove="Useage: '/bb remove <word>'";
	bb_txt_bidwords_help_promote="Useage: '/bb promote <word>'";
	bb_txt_bidwords_help_demote="Useage: '/bb demote <word>'";
	bb_txt_bidwords_list="Bidwords (Descending):";
	
	bb_txt_already_running="Already running with a bid. Can not start a new one until the first one is done. ('/bb stop' to force stop)";
	bb_txt_bidword="The bidword ";
	bb_txt_the_bidword=" the bidword ";
	bb_txt_does_not_exist=" does not exist.";
	bb_txt_already_exists=" already exists.";

	bb_txt_base_help="Useage: '/bb <*itemlink*/stop/bidwords/defaultbid/bidtime/countdown/autostart/autolink/threshold/getstarted/help>";

	bb_txt_help="Help (more help at Curse.com (http://wow.curse.com/downloads/wow-addons/details/bidbot.aspx)):\n "..
			"'*itemlink*' to start Bidbot with specified item.\n "..
			"'stop' to force Bidbot to a stop.\n "..
			"'bidwords' to change what words are useable and what priority they have when bidding.\n "..
			"'defaultbid' to change the default bid.\n "..
			"'bidtime' to modify the time people have to bid on.\n "..
			"'countdown' to change at what time Bidbot should start counting down.\n "..
			"'autostart' to toggle wether or not Bidbot automatically starts when you loot a corpse.\n "..
			"'autolink' to toggle if Bidbot should link the whole contents of the loot or not upon looting.\n "..
			"'threshold' to change the threshold for autostarting of Bidbot when looting.\n "..
			"'getstarted' shows you how to get started with Bidbot.\n "..
			"'help' show this message.";

	bb_txt_getstarted_1="Thanks for using Bidbot! Here is how you use it in 3 simple steps:\n 1. Set up your ranks (bidwords (=words used to bid)) with '/bb bidwords', in descending order (highest priority at top, lowest at bottom).";
	bb_txt_getstarted_2="2. Setup the countdowntime (how long Bidbot should countdown) and the bidtime (time to bid until countdown starts) with '/bb countdown' and '/bb bidtime' respectively.";
	bb_txt_getstarted_3="3. Enter the default bid (the one that is used if no value specified (this is also the minimum price)) with '/bb defaultbid'. Now start bidding with '/bb [itemlink]'. Good luck!";

	bb_txt_cno_standby="no longer in |cff00ff00standby|rmode";
	bb_txt_cstandby="now in |cffff0000standby|rmode";

	bb_txt_cautolink="Autolinking of loot turned |cff00ff00on|r.";
	bb_txt_cno_autolink="Autolinking of loot turned |cffff0000off|r.";

	bb_txt_cautoloot="Autostarting of Bidbot turned |cff00ff00on|r.";
	bb_txt_cno_autoloot="Autostarting of Bidbot turned |cffff0000off|r.";

	bb_txt_stop="Bidbot |cFFff0000stopped|r.";
	bb_txt_ncstop="Bidbot stopped.";
	bb_txt_no_stop="Not running. Can not stop.";

	bb_txt_add="Successfully added the bidword ";

	bb_txt_remove="Successfully removed the bidword ";
	bb_txt_remove_cant="Can not remove the bidwords since you only have one... Bidbot will not function without bidwords!";

	bb_txt_do_promote="Successfully promoted the bidword ";
	bb_txt_no_promote_pre="Can not promote the bidword ";
	bb_txt_no_promote_post=" since it is already at the top.";

	bb_txt_do_demote="Successfully demoted the bidword ";
	bb_txt_no_demote_pre="Can not demote the bidword ";
	bb_txt_no_demote_post=" since it is already at the bottom.";

	bb_txt_defaultbid="Useage '/bb defaultbid <*number*>'";
	bb_txt_change_defaultbid="Defaultbid successfully set to ";

	bb_txt_countdown="Useage '/bb countdown <*number*>'";
	bb_txt_change_countdown="Countdowntime successfully set to ";
	
	bb_txt_bidtime="Useage '/bb bidtime <*number*>'";
	bb_txt_change_bidtime="Bidtime successfully set to ";

	bb_txt_threshold_is="Threshold for autostart of Bid bot is currently ";
	bb_txt_threshold_set="Threshold for autostarting of Bidbot successfully set to ";
	bb_txt_threshold="Useage '/bb threshold <show/rare/epic/legendary>'";

	bb_txt_dbg_off="Debugging turned off!";
	bb_txt_dbg_on="Debugging turned on!";
-- ****************************************************************************************************************
end

function Bidbot_GetCmd(msg)
	if(msg) then
		local a,b,c = strfind(msg, "(%S+)");
		if(a) then
			return c, strsub(msg, b+2);
		else	
			return "";
		end
	end
end

function Bidbot_CheckMSG(msg,author)
	local type,tpe,amount;
	if(tonumber(msg)~=nil) then
		if(bb_bidlist[author]~=nil) then
			type=bb_bidlist[author];
		else
			type=BB['bidwords'][#BB['bidwords']];
		end
	else
		for i=1,#BB['bidwords'] do
			tpe=BB['bidwords'][i];
			if(select(1,string.find(msg,tpe))==1) then
				type=tpe;
				break;
			end
		end
	end
	if(string.find(msg,"%d")~=nil) then
		amount=tonumber(strsub(msg,string.find(msg,"%d"),strlen(msg)));
		if(amount==0) then
			amount=nil;
		end
	else
		amount=BB['default_bid'];
	end
	return type,amount;
end

function Bidbot_DoBid(author,type,amount)
	if(amount%5~=0) then
		return;
	end

	local nt,ot=-1000,1000;
	for i=1,#BB['bidwords']+100 do
		if(BB['bidwords'][i]==type) then
			nt=i;
			break;
		elseif(BB['bidwords'][1000-i]==type) then
			nt=1000-i;
			break;
		end
	end
	for i=1,#BB['bidwords']+100 do
		if(BB['bidwords'][i]==bb_high_type) then
			ot=i;
			break;
		elseif(BB['bidwords'][1000-i]==bb_high_type) then
			ot=1000-i;
			break;
		end
	end
	if(nt>ot) then
		return;
	end

	if(amount>bb_high_bid or nt<ot) then
		bb_high_bid=amount;
		bb_high_bidder={author};
		bb_high_type=type;

		if(bb_dbg) then
			print("New highbid! "..author.." ("..type..") with "..amount);
		end

		bb_timer_countdown=BB['countdown'];
		bb_timer_bidtime=BB['bidtime'];
		bb_bidlist[author]=type;
	elseif(amount==bb_high_bid and nt==ot) then
		for i=1,#bb_high_bidder do
			if(bb_high_bidder[i]==author) then
				return;
			end
		end

		bb_high_bidder[#bb_high_bidder+1]=author;
		local bidders="";
		for i=1,#bb_high_bidder do
			if(i==1) then
				bidders=bb_high_bidder[i];
			else
				bidders=bidders..", "..bb_high_bidder[i];
			end
		end

		if(bb_dbg) then
			print("High bidders ("..type..") are now: "..bidders.." with "..amount);
		end

		bb_timer_countdown=BB['countdown'];
		bb_timer_bidtime=BB['bidtime'];
		bb_bidlist[author]=type;
	end
	return;
end

function Bidbot_StartBid()
	Bidbot_Variables();

	bb_timer_countdown=BB['countdown'];
	bb_timer_bidtime=BB['bidtime'];

	bb_bidding=true;
end

function Bidbot_StopBid()
	bb_bidding=false;

	bb_timer_last=0;

	bb_loot_list={};
	bb_loot_id=1;
	bb_loot_more=false;
end

function Bidbot_Loot()
	local money=true;
	bb_loot_more=false;
	while money do
		money=false;
		if(bb_loot_list[bb_loot_id]~=nil) then
			if(bb_loot_list[bb_loot_id]~="") then
				Bidbot_StartBid();
				bb_bid_ilink=bb_loot_list[bb_loot_id];
			elseif(BB['autoloot']['all']) then
				LootSlot(bb_loot_id);
				money=true;
			end
	
			if(bb_loot_list[bb_loot_id+1]~=nil) then
				bb_loot_more=true;
			end
		end
	end
end

function Bidbot_Command(msg)
	local cmd, subCmd = Bidbot_GetCmd(msg);
	if(cmd=='standby') then
		if(BB['standby']) then
			BB['standby']=false;
			print(bb_txt_cname..bb_txt_cno_standby);
		else
			BB['standby']=true;
			print(bb_txt_cname..bb_txt_cstandby);
		end
	elseif(cmd=='stop') then
		if(bb_bidding) then
			Bidbot_StopBid();
			SendChatMessage(bb_txt_name..bb_txt_ncstop,BB['announce'],nil);
			print(bb_txt_cname..bb_txt_stop);
		else
			print(bb_txt_cname..bb_txt_no_stop);
		end
	elseif(cmd=='bidwords') then
		local cmd, subCmd = Bidbot_GetCmd(subCmd);
		if(cmd=='add') then
			if(subCmd~="") then
				local exist=false;
				for i=1,#BB['bidwords'] do
					if(BB['bidwords'][i]==subCmd) then
						exist=true;
						break;
					end
				end
				if(not exist) then
					BB['bidwords'][#BB['bidwords']+1]=subCmd;
					print(bb_txt_cname..bb_txt_add.."'"..subCmd.."'.");
				else
					print(bb_txt_cname..bb_txt_bidword.."'"..subCmd.."'"..bb_txt_already_exists);
				end
			else
				print(bb_txt_cname..bb_txt_bidwords_help_add);
			end
		elseif(cmd=='remove') then
			if(subCmd~="") then
				if(#BB['bidwords']~=1) then
					local exist,pos=false,0;
					for i=1,#BB['bidwords'] do
						if(BB['bidwords'][i]==subCmd) then
							exist=true;
							pos=i;
							break;
						end
					end
					if(exist) then
						local i=pos;
						while(BB['bidwords'][i]~=nil) do
							BB['bidwords'][i]=BB['bidwords'][i+1];
							i=i+1;
						end
						print(bb_txt_cname..bb_txt_remove.."'"..subCmd.."'.");
					else
						print(bb_txt_cname..bb_txt_bidword.."'"..subCmd.."'"..bb_txt_does_not_exist);
					end
				else
					print(bb_txt_cname..bb_txt_remove_cant);
				end
			else
				print(bb_txt_cname..bb_txt_bidwords_help_remove);
			end
		elseif(cmd=='promote') then
			if(subCmd~="") then
				local exist,pos=false,0;
				for i=1,#BB['bidwords'] do
					if(BB['bidwords'][i]==subCmd) then
						exist=true;
						pos=i;
						break;
					end
				end
				if(exist) then
					if(pos~=1) then
						local temp=BB['bidwords'][pos-1];
						BB['bidwords'][pos-1]=BB['bidwords'][pos];
						BB['bidwords'][pos]=temp;
						print(bb_txt_cname..bb_txt_do_promote.."'"..subCmd.."'.");
					else
						print(bb_txt_cname..bb_txt_no_promote_pre.."'"..subCmd.."'"..bb_txt_no_promote_post);
					end
				else
					print(bb_txt_cname..bb_txt_bidword.."'"..subCmd.."'"..bb_txt_does_not_exist);
				end
			else
				print(bb_txt_cname..bb_txt_bidwords_help_promote);
			end
		elseif(cmd=='demote') then
			if(subCmd~="") then
				local exist,pos=false,0;
				for i=1,#BB['bidwords'] do
					if(BB['bidwords'][i]==subCmd) then
						exist=true;
						pos=i;
						break;
					end
				end
				if(exist) then
					if(pos~=#BB['bidwords']) then
						local temp=BB['bidwords'][pos+1];
						BB['bidwords'][pos+1]=BB['bidwords'][pos];
						BB['bidwords'][pos]=temp;
						print(bb_txt_cname..bb_txt_do_demote.."'"..subCmd.."'.");
					else
						print(bb_txt_cname..bb_txt_no_demote_pre.."'"..subCmd.."'"..bb_txt_no_demote_post);
					end
				else
					print(bb_txt_cname..bb_txt_bidword.."'"..subCmd.."'"..bb_txt_does_not_exist);
				end
			else
				print(bb_txt_cname..bb_txt_bidwords_help_demote);
			end
		elseif(cmd=='list') then
			local words="";
			for i=1,#BB['bidwords'] do
				words=words.."\n "..i..". "..BB['bidwords'][i];
			end
			print(bb_txt_cname..bb_txt_bidwords_list..words);
		else
			print(bb_txt_cname..bb_txt_bidwords_help);
		end
	elseif(cmd=='defaultbid') then
		if(tonumber(subCmd)~=nil) then
			BB['defaultbid']=tonumber(subCmd);
			print(bb_txt_cname..bb_txt_change_defaultbid.."'"..subCmd.."'.");
		else
			print(bb_txt_cname..bb_txt_defaultbid);
		end
	elseif(cmd=='countdown') then
		if(tonumber(subCmd)~=nil) then
			BB['countdown']=tonumber(subCmd);
			print(bb_txt_cname..bb_txt_change_countdown.."'"..subCmd.."'.");
		else
			print(bb_txt_cname..bb_txt_countdown);
		end
	elseif(cmd=='bidtime') then
		if(tonumber(subCmd)~=nil) then
			BB['bidtime']=tonumber(subCmd);
			print(bb_txt_cname..bb_txt_change_bidtime.."'"..subCmd.."'.");
		else
			print(bb_txt_cname..bb_txt_bidtime);
		end
	elseif(cmd=='debug') then
		if(bb_dbg) then
			bb_dbg=false;
			print(bb_txt_cname..bb_txt_dbg_off);
		else
			bb_dbg=true;
			print(bb_txt_cname..bb_txt_dbg_on);
		end
	elseif(cmd=='getstarted') then
		print(bb_txt_cname..bb_txt_getstarted_1);
		print(bb_txt_cname..bb_txt_getstarted_2);
		print(bb_txt_cname..bb_txt_getstarted_3);
	elseif(cmd=='help') then
		print(bb_txt_cname..bb_txt_help);
	elseif(cmd=='autostart') then
		if(BB['autoloot']['all']) then
			BB['autoloot']['all']=false;
			print(bb_txt_cname..bb_txt_cno_autoloot);
		else
			BB['autoloot']['all']=true;
			print(bb_txt_cname..bb_txt_cautoloot);
		end
	elseif(cmd=='autolink') then
		if(BB['autoloot']['link']) then
			BB['autoloot']['link']=false;
			print(bb_txt_cname..bb_txt_cno_autolink);
		else
			BB['autoloot']['link']=true;
			print(bb_txt_cname..bb_txt_cautolink);
		end
	elseif(cmd=='threshold') then
		local cmd, subCmd = Bidbot_GetCmd(subCmd);
		if(cmd=='rare' or cmd=='epic' or cmd=='legendary') then
			BB['autoloot']['threshold']=bb_txt_rarity[cmd];
			print(bb_txt_cname..bb_txt_threshold_set..bb_txt_crarity[bb_txt_rarity[cmd]]..".");
		elseif(cmd=='show') then
			print(bb_txt_cname..bb_txt_threshold_is..bb_txt_crarity[BB['autoloot']['threshold']]..".");
		else
			print(bb_txt_cname..bb_txt_threshold);
		end
	else
		if(not bb_bidding) then
			local i,j=string.find(msg,"|c");
			if(i~=nil or j~=nil) then
				Bidbot_StartBid();
				bb_bid_ilink=string.sub(msg,0,i-2);
			else
				print(bb_txt_cname..bb_txt_base_help);
			end
		else
			print(bb_txt_cname..bb_txt_already_running);
		end
	end
end