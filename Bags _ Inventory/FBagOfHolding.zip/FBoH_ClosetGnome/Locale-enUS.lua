local L = LibStub("AceLocale-3.0"):NewLocale("FBoH_ClosetGnome", "enUS", true)

L["ClosetGnome"] = true;

L["Any Set"] = true;
