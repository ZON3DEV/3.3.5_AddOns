local L = LibStub("AceLocale-3.0"):NewLocale("FBoH_EquipmentManager", "enUS", true)

L["Equipment Manager"] = true;

L["Any Set"] = true;
