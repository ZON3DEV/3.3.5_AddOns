local L = LibStub("AceLocale-3.0"):NewLocale("FBoH_PeriodicTable", "enUS", true)

L["Periodic Table"] = true;

L["- All %s -"] = true;
L["No Values"] = true;