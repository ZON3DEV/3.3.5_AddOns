local L = LibStub("AceLocale-3.0"):NewLocale("FBoH_ItemRack", "enUS", true)

L["ItemRack"] = true;

L["Any Set"] = true;
