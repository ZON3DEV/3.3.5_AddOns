local AceOO = AceLibrary("AceOO-2.0")

local PaintChips = AceLibrary("PaintChips-2.0")
PaintChips:RegisterColor("trivial",192,192,192)
PaintChips:RegisterColor("easy",0,255,0)
PaintChips:RegisterColor("medium",255,255,0)
PaintChips:RegisterColor("optimal",255,128,0)
PaintChips:RegisterColor("difficult",255,0,0)

local Abacus = AceLibrary("Abacus-2.0")

IRecipe = AceOO.Interface{
	DependsOn = "function",				-- DependsOn(recipe,recipeDB)
	Craft = "function",						-- Craft(curskill,number)
	NumberCraftable = "function",	-- NumberCraftable(invDB,bankDB,recipeDB)
	UpdateIndex = "function",			-- UpdateIndex(index)
	GetIcon = "function",					-- GetIcon()
	GetLink = "function",					-- GetLink()
	GetName = "function",					-- GetName()
	GetID = "function",						-- GetID()
	AverageMade = "function",
	AddMenuLine = "function",			-- AddMenuLine(dewdrop,goal)
	Ingredients = "function"			-- returns a closure to be used in for k,v in xxx() do statements.
}

local function ItemInfoFromItemLink(link,idprefix)
	if not link then return nil, nil, nil end
	idprefix = idprefix or "item"
	local name
	local id
	local color
	_,_,name = strfind(link,"%[([^%]]+)")
	_,_,id = strfind(link,idprefix..":(%d+)")
	_,_,color = strfind(link,"|c([^|]+)")
	--local _,_,color,id,name = strfind(link,"(|c%x%x%x%x%x%x%x%x)|Hitem:(%d+):$d+:$d+:$d+|h%[([^%]]+)%]|h|r")
	return name, tonumber(id), "|c"..color
end

local function striptolink(link)
	_,_,link = strfind(link,"|H([^|]+)")
	return link
end

local TSRecipe = AceOO.Class(IRecipe)

function TSRecipe.prototype:init(tradeskill,index)
	self.class.super.prototype.init(self)
	if type(tradeskill) ~= "table" then
		self.tskill = tradeskill
		if tradeskill == "Mining" then self.tskill = "Smelting" end
		self.index = index
		self.icon = GetTradeSkillIcon(index)
		self.link = GetTradeSkillItemLink(index)
		self.name,self.itemid = ItemInfoFromItemLink(self.link)
		local _, diff = GetTradeSkillInfo(index)
		self.color = PaintChips:GetRGBPercent("trivial")
		if diff ~= "header" then self.color = PaintChips:GetRGBPercent(diff) end
		self.minmade, self.maxmade = GetTradeSkillNumMade(index)
		self.avgmade = (self.minmade + self.maxmade) * 0.5
		local countmod = 1 / self.avgmade
		local numIngredients = GetTradeSkillNumReagents(index)
		for i = 1, numIngredients do
			self[i] = {}
			self[i].link = GetTradeSkillReagentItemLink(index,i)
			self[i].name, self[i].itemid, self[i].color = ItemInfoFromItemLink(self[i].link)
			_,_,self[i].count = GetTradeSkillReagentInfo(index,i)
			self[i].count = self[i].count * countmod
		end
	else
		for k,v in pairs(tradeskill) do
			self[k] = v
		end
	end
end

function TSRecipe.prototype:update(tradeskill,index)
	self.tskill = tradeskill
	if tradeskill == "Mining" then self.tskill = "Smelting" end
	self.index = index
	self.icon = GetTradeSkillIcon(index)
	self.link = GetTradeSkillItemLink(index)
	self.name,self.itemid = ItemInfoFromItemLink(self.link)
	local _, diff = GetTradeSkillInfo(index)
	self.color = PaintChips:GetRGBPercent("trivial")
	if diff ~= "header" then self.color = PaintChips:GetRGBPercent(diff) end
	self.minmade, self.maxmade = GetTradeSkillNumMade(index)
	self.avgmade = (self.minmade + self.maxmade) * 0.5
	local countmod = 1 / self.avgmade
	local numIngredients = GetTradeSkillNumReagents(index)
	for i = 1, numIngredients do
		self[i] = {}
		self[i].link = GetTradeSkillReagentItemLink(index,i)
		self[i].name, self[i].itemid, self[i].color = ItemInfoFromItemLink(self[i].link)
		_,_,self[i].count = GetTradeSkillReagentInfo(index,i)
		self[i].count = self[i].count * countmod
	end
end

function TSRecipe.prototype:valid(index)
	if not self.tskill then return false end
	if not self.icon then return false end
	if not self.link then return false end
	if not self.name then return false end
	if not self.itemid then return false end
	if not self.color then return false end
	if not self.avgmade then return false end
	return true
end

function TSRecipe.prototype:SortBefore(recipeB,recipeDB)
	if self:DependsOn(recipeB:GetID(),recipeDB) then return false end
	if recipeB:DependsOn(self.itemid,recipeDB) then return true end
	return self.tskill < recipeB:GetTradeSkill()
end

function TSRecipe.prototype:DependsOn(itemid,recipeDB)
	for i,ing in ipairs(self) do
		if ing.itemid == itemid then return true end
		if recipeDB[ing.itemid] and recipeDB[ing.itemid]:DependsOn(itemid,recipeDB) then return true end
	end
	return false
end

function TSRecipe.prototype:Craft(curskill,number)
	if curskill ~= self.tskill then
		CastSpellByName(self.tskill)
		return
	end
	if number == 'max' then
		_, _, number = GetTradeSkillInfo(self.index)
	end
	DoTradeSkill(self.index,number)
end

function TSRecipe.prototype:NumberCraftable(invDB,bankDB,recipeDB)
	local craftable = 100000000
	local bankCraftable = 100000000
	for i,ing in ipairs(self) do
		local ingAvail = invDB[ing.itemid] or 0
		local bankAvail = ingAvail + (bankDB[ing.itemid] or 0)
		local recipe = recipeDB[ing.itemid]
		if recipe then
			local ingC, ingB = recipe:NumberCraftable(invDB,bankDB,recipeDB)
			ingAvail = ingAvail + ingC
			bankAvail = bankAvail + ingC + ingB
		end
		local ingCraftable = ingAvail / ing.count
		if ingCraftable < craftable then craftable = ingCraftable end
		ingCraftable = bankAvail / ing.count
		if ingCraftable < bankCraftable then bankCraftable = ingCraftable end
	end
	return craftable,bankCraftable
end

function TSRecipe.prototype:UpdateIndex(index)
	self.index = index
end

function TSRecipe.prototype:GetIcon()
	return self.icon
end

function TSRecipe.prototype:GetLink()
	return self.link
end

function TSRecipe.prototype:GetName()
	return self.name
end

function TSRecipe.prototype:GetCooldown(cdDB)
	if cdDB[self.itemid] then
		local cooldown = cdDB[self.itemid] - time()
		if cooldown > 0 then
			return " ("..Abacus:FormatDurationShort(cooldown)..")"
		else
			cdDB[self.itemid] = nil
			return " (Ready)"
		end
	else
		return ""
	end
end

function TSRecipe.prototype:UpdateCooldown(cdDB)
	local cooldown = GetTradeSkillCooldown(self.index)
	if cooldown then
		cdDB[self.itemid] = time() + cooldown
	end
end

function TSRecipe.prototype:GetID()
	return self.itemid
end

function TSRecipe.prototype:GetTradeSkill()
	return self.tskill
end

function TSRecipe.prototype:AverageMade()
	return self.avgmade
end

function TSRecipe.prototype:GetHyperlink()
	return striptolink(self.link)
end

function TSRecipe.prototype:AddMenuLine(dewdrop,goal,diffDB)
	local diffcolor = PaintChips:GetRGBPercent(diffDB[self.itemid] or "trivial")
	dewdrop:AddLine("text",self.name,'value',{self,'ingredients'},'hasArrow',true,'arg1',goal,'func',function(goal)
			goal.JSID = self:GetID()
			goal.name = self.name
		end, 'checked', goal.JSID == self.itemid,'textR',diffcolor[1],'textG',diffcolor[2],'textB',diffcolor[3],
		'tooltipFunc',GameTooltip.SetHyperlink,'tooltipArg1',GameTooltip,'tooltipArg2',striptolink(self.link))
end

function TSRecipe.prototype:MenuIngredients(dewdrop)
	local s = tostring(self.avgmade)
	if self.minmade ~= self.maxmade then s = self.minmade.." - "..self.maxmade end
	dewdrop:AddLine("text",self.name.." x "..s.." Requires:",'notClickable',true)
	dewdrop:AddLine()
	for i,ing in ipairs(self) do
		local count = ing.count * self.avgmade
    if type(ing.name) == "nil" then dewdrop:AddLine("text","Ingredient unavailable, do not queue this.")
    dewdrop:AddLine("text","Use regular crafting menu.")
    else
  	dewdrop:AddLine("text",ing.name.." x "..count, 'notClickable', true,
		'tooltipFunc',GameTooltip.SetHyperlink,'tooltipArg1',GameTooltip,'tooltipArg2',striptolink(ing.link))
    end
	end
end

function TSRecipe.prototype:Ingredients()
	return ipairs(self)
end

function TSRecipe:Deserialize(t)
	return self:new(t)
end

function TSRecipe.prototype:Serialize()
	local serialized = {}
	serialized.tskill = self.tskill
	serialized.index = self.index
	serialized.icon = self.icon
	serialized.link = self.link
	serialized.name = self.name
	serialized.itemid = self.itemid
	serialized.color = self.color
	serialized.minmade = self.minmade
	serialized.maxmade = self.maxmade
	serialized.avgmade = self.avgmade
	for i,ing in ipairs(self) do serialized[i] = ing end
	return serialized
end

local CRecipe = AceOO.Class(IRecipe)

function CRecipe.prototype:init(tradeskill,index)
	self.class.super.prototype.init(self)
	if type(tradeskill) ~= "table" then
		self.tskill = tradeskill
		self.index = index
		self.icon = GetTradeSkillIcon(index)
		self.link = GetTradeSkillItemLink(index)
		self.name,self.itemid = ItemInfoFromItemLink(self.link,"enchant")
		local _, _, diff = GetTradeSkillInfo(index)
		self.color = PaintChips:GetRGBPercent("trivial")
		if diff ~= "header" then self.color = PaintChips:GetRGBPercent(diff) end
		local numIngredients = GetTradeSkillNumReagents(index)
		for i = 1, numIngredients do
			self[i] = {}
			self[i].link = GetTradeSkillReagentItemLink(index,i)
			self[i].name, self[i].itemid, self[i].color = ItemInfoFromItemLink(self[i].link)
			_,_,self[i].count = GetTradeSkillReagentInfo(index,i)
			self[i].count = self[i].count
		end
	else
		for k,v in pairs(tradeskill) do
			self[k] = v
		end
	end
end

function CRecipe.prototype:update(tradeskill,index)
	self.tskill = tradeskill
	self.index = index
	self.icon = GetTradeSkillIcon(index)
	self.link = GetTradeSkillItemLink(index)
	self.name,self.itemid = ItemInfoFromItemLink(self.link,"enchant")
	local _, _, diff = GetTradeSkillInfo(index)
	self.color = PaintChips:GetRGBPercent("trivial")
	if diff ~= "header" then self.color = PaintChips:GetRGBPercent(diff) end
	local numIngredients = GetTradeSkillNumReagents(index)
	for i = 1, numIngredients do
		self[i] = {}
		self[i].link = GetTradeSkillReagentItemLink(index,i)
		self[i].name, self[i].itemid, self[i].color = ItemInfoFromItemLink(self[i].link)
		_,_,self[i].count = GetTradeSkillReagentInfo(index,i)
		self[i].count = self[i].count
	end
end

function CRecipe.prototype:valid(index)
	if not self.tskill then return false end
	if not self.icon then return false end
	if not self.link then return false end
	if not self.name then return false end
	if not self.itemid then return false end
	if not self.color then return false end
	return true
end

function CRecipe.prototype:SortBefore(recipeB,recipeDB)
	if self:DependsOn(recipeB:GetID(),recipeDB) then return false end
	if recipeB:DependsOn(self.itemid,recipeDB) then return true end
	return self.tradeskill < recipeB:GetTradeSkill()
end

function CRecipe.prototype:DependsOn(recipe,recipeDB)
	for i,ing in ipairs(self) do
		if ing.itemid == recipe then return true end
		if recipeDB[ing.itemid] and recipeDB[ing.itemid]:DependsOn(recipe,recipeDB) then return true end
	end
	return false
end

function CRecipe.prototype:Craft(curskill,number)
	if curskill ~= self.tskill then
		CastSpellByName(self.tskill)
		return
	end
	DoTradeSkill(self.index)
end

function CRecipe.prototype:NumberCraftable(invDB,bankDB,recipeDB)
	local craftable = 100000000
	local bankCraftable = 100000000
	for i,ing in ipairs(self) do
		local ingAvail = invDB[ing.itemid] or 0
		local bankAvail = ingAvail + (bankDB[ing.itemid] or 0)
		local recipe = recipeDB[ing.itemid]
		if recipe then
			local ingC, ingB = recipe:NumberCraftable(invDB,bankDB,recipeDB)
			ingAvail = ingAvail + ingC
			bankAvail = bankAvail + ingC + ingB
		end
		local ingCraftable = ingAvail / ing.count
		if ingCraftable < craftable then craftable = ingCraftable end
		ingCraftable = bankAvail / ing.count
		if ingCraftable < bankCraftable then bankCraftable = ingCraftable end
	end
	return craftable,bankCraftable
end

function CRecipe.prototype:UpdateIndex(index)
	self.index = index
end

function CRecipe.prototype:GetIcon()
	return self.icon
end

function CRecipe.prototype:GetLink()
	return self.link
end

function CRecipe.prototype:GetName()
	return self.name
end

function CRecipe.prototype:GetCooldown(cdDB)
	return ""
end

function CRecipe.prototype:UpdateCooldown(cdDB)
end

function CRecipe.prototype:GetID()
	return self.itemid
end

function CRecipe.prototype:GetTradeSkill()
	return self.tskill
end

function CRecipe.prototype:AverageMade()
	return 1
end

function CRecipe.prototype:GetHyperlink()
	return striptolink(self.link)
end

function CRecipe.prototype:AddMenuLine(dewdrop,goal,diffDB)
	local diffcolor = PaintChips:GetRGBPercent(diffDB[self.name])
	if diffcolor then
		dewdrop:AddLine("text",self.name,'arg1',goal,'func',function(goal)
			goal.JSID = self.name
			goal.name = self.name
		end, 'checked', goal.JSID == self.name,'textR',diffcolor[1],'textG',diffcolor[2],'textB',diffcolor[3],
		'tooltipFunc',GameTooltip.SetHyperlink,'tooltipArg1',GameTooltip,'tooltipArg2',striptolink(self.link))
	else
		dewdrop:AddLine("text",self.name,'arg1',goal,'func',function(goal)
			goal.JSID = self.name
			goal.name = self.name
		end, 'checked', goal.JSID == self.name,'textR',0,'textG',0,'textB',255,
		'tooltipFunc',GameTooltip.SetHyperlink,'tooltipArg1',GameTooltip,'tooltipArg2',striptolink(self.link))
	end
end

function CRecipe.prototype:Ingredients()
	return ipairs(self)
end

function CRecipe:Deserialize(t)
	return self:new(t)
end

function CRecipe.prototype:Serialize()
	local serialized = {}
	serialized.tskill = self.tskill
	serialized.index = self.index
	serialized.icon = self.icon
	serialized.link = self.link
	serialized.name = self.name
	serialized.itemid = self.itemid
	serialized.color = self.color
	for i,ing in ipairs(self) do serialized[i] = ing end
	return serialized
end

local function activate(self, oldLib, oldDeactivate)
    if oldDeactivate then
        oldDeactivate(oldLib)
    end
end

AceLibrary:Register(TSRecipe,"JigsawTSRecipe-1.0",1,activate)
AceLibrary:Register(CRecipe,"JigsawCRecipe-1.0",1,activate)
TSRecipe = nil
CRecipe = nil
