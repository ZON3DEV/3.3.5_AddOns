
local function print(text)
    DEFAULT_CHAT_FRAME:AddMessage(tostring(text))
end

Jigsaw = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceDB-2.0", "FuBarPlugin-2.0")
local dewdrop = AceLibrary("Dewdrop-2.0")
local tablet = AceLibrary("Tablet-2.0")
local TSRecipe = AceLibrary("JigsawTSRecipe-1.0")
local CRecipe = AceLibrary("JigsawCRecipe-1.0")
local Queue = AceLibrary("JigsawQueue-1.0")
local AceOO = AceLibrary("AceOO-2.0")

--local jigsawOptions = {
--	type = 'group',
--	args = {
--	}
--}

--Jigsaw:RegisterChatCommand({"/jigsaw"}, jigsawOptions)

Jigsaw:RegisterDB("JigsawDB", "JigsawDBPC")
Jigsaw.hasNoText = true
Jigsaw.hasIcon = true
Jigsaw.overrideMenu = true
Jigsaw.defaultPosition = "RIGHT"
Jigsaw.defaultMinimapPosition = 90
Jigsaw.clickableTooltip = true
--Jigsaw:RegisterDefaults("profile", { } )

local function IDFromItemLink(itemlink)
	if not itemlink then return end
	local found, _, itemId, enchantId, suffixId, uniqueId = strfind(itemlink, "item:(%d+):(%d+):(%d+):(%d+)")
	if not itemId then return end
	return tonumber(itemId)
end

function Jigsaw:OnEnable()
	self.db.char.bag = self.db.char.bag or {}
	self.db.char.inv = self.db.char.inv or {}
	self.db.char.bank = self.db.char.bank or {}
	self.db.char.queue = self.db.char.queue or {Queue:new()}
	if AceOO.inherits(self.db.char.queue, Queue) then self.db.char.queue = {self.db.char.queue} end
	-- Check for weird object serialization issues
	for i,queue in ipairs(self.db.char.queue) do
		if queue.uid then
			queue.uid = nil
			self.db.char.queue[i] = Queue:new(queue)
		end
	end
	-- update recipe indexes for this character.
	if self.db.char.recipeIndex then
		for ID,Index in pairs(self.db.char.recipeIndex) do
			if self.db.account.recipe[ID] then
				if self.db.account.recipe[ID].uid then
					self.db.account.recipe[ID].uid = nil
					if self.db.account.recipe[ID].tskill == "Enchanting" then
						self.db.account.recipe[ID] = CRecipe:new(self.db.account.recipe[ID])
					else
						self.db.account.recipe[ID] = TSRecipe:new(self.db.account.recipe[ID])
					end
				end
				self.db.account.recipe[ID]:UpdateIndex(Index)
			end
		end
	end
	-- Events for discovering Tradeskill Recipes
	self:RegisterEvent("TRADE_SKILL_UPDATE","UpdateRecipes")
	self:RegisterEvent("CRAFT_UPDATE","UpdateEnchants")
	self:RegisterEvent("SKILL_LINES_CHANGED","SkillUpdate")
	-- Events for tracking inventory.
	self:RegisterEvent("BAG_UPDATE","ReconcileInv")
	self:RegisterEvent("PLAYERBANKSLOTS_CHANGED","ReconcileInv")
	-- AutoPurchase Trigger
	self:RegisterEvent("MERCHANT_SHOW","AutoPurchase")
	-- AutoWithdraw Trigger
	self:RegisterEvent("BANKFRAME_OPENED","AutoWithdraw")
	-- External Event Triggers
	self:RegisterEvent("Jigsaw_AddExternalGoal","AddExternalGoal")
	self:RegisterEvent("Jigsaw_SuppressCraftingMenu","SuppressCraftingMenu")
	self:RegisterEvent("Jigsaw_SuppressCrafting","SuppressCrafting")
	self:RegisterEvent("Jigsaw_RunQueue","RunQueue")
	-- Queue Update Event, primarily for internal use only.
	self:RegisterEvent("Jigsaw_UpdateQueue","UpdateQueue",1)
end

local tradeskills = {
	["Alchemy"] = true,
	["Blacksmithing"] = true,
	["Cooking"] = true,
	["Enchanting"] = true,
	["Engineering"] = true,
	["First Aid"] = true,
	["Leatherworking"] = true,
	["Mining"] = true,
	["Poisons"] = true,
	["Tailoring"] = true,
	["Jewelcrafting"] = true,
}

function Jigsaw:SkillUpdate(msg)
	if not self.db.char.tskill then return end
	local preSkills = {}
	for k in pairs(self.db.char.tskill) do preSkills[k] = true end
	local numSkills = GetNumSkillLines()
	local function CheckLines(start, finish, depth)
		depth = depth or 0
		if depth > 2 then return end
		for i = start, finish do
			local skillName, isHeader, isExpanded, skillRank, _, _, skillMaxRank = GetSkillLineInfo(i)
			if isHeader then
				if not isExpanded then
					ExpandSkillHeader(i)
					CheckLines(n+1, i + GetNumSkillLines() - finish, depth + 1)
					CollapseSkillHeader(i)
				end
			elseif tradeskills[skillName] then
				preSkills[skillName] = nil
				self.db.char.tskill[skillName] = self.db.char.tskill[skillName] or {}
				self.db.char.tskill[skillName].curLevel = skillRank
				self.db.char.tskill[skillName].maxLevel = skillMaxRank
			end
		end
	end
	CheckLines(1,numSkills)
	for k in pairs(preSkills) do
		self.db.char.tskill[k] = nil
	end
end

function Jigsaw:SuppressCraftingMenu()
	self.suppressJigsawMenu = true
end

function Jigsaw:SuppressCrafting()
	self.suppressJigsawCrafting = true
end

--function Jigsaw:ReconcileBankSlot(a,b,c,d,e,f,g,h,i,j,k)
	--print("ReconcileBankSlot("..tostring(a)..", "..tostring(b)..", "..tostring(c)..", "..tostring(d)..", "..tostring(e)..", "..tostring(f)..", "..tostring(g)..", "..tostring(h)..", "..tostring(i)..", "..tostring(j)..", "..tostring(k)..")")
	--self:ReconcileInv(a)
--end

function Jigsaw:ReconcileInv(bag)
	bag = bag or -1 -- If we are reconciling the bank window, change bag (nil) to -1
	--print(tostring(bag))
	local slots
	if bag == -2 then
		return
	elseif bag == -1 or type(bag) ~= "number" then
		bag = -1
		slots = 28
	elseif bag == 0 then
		slots = 16
	else
		slots = GetContainerNumSlots(bag)
	end
	local availableslots = slots
	self.db.char.bag[bag] = self.db.char.bag[bag] or {}
	self.db.char.bag[bag].list = {}
	for slot=1,slots do
		--print(tostring(bag).." "..tostring(slot))
		local itemlink = GetContainerItemLink(bag, slot)
		local _, stack = GetContainerItemInfo(bag, slot)
		if itemlink then availableslots = availableslots - 1 end

		self.db.char.bag[bag] = self.db.char.bag[bag] or {}
		self.db.char.bag[bag][slot] = self.db.char.bag[bag][slot] or {}
		local oldlink = self.db.char.bag[bag][slot][1]
		local oldstack = self.db.char.bag[bag][slot][2]
		if oldlink ~= itemlink or oldstack ~= stack then
			self.db.char.bag[bag][slot][1], self.db.char.bag[bag][slot][2] = itemlink, stack
		end
		
		local itemid = IDFromItemLink(itemlink)
		local oldid = IDFromItemLink(oldlink)
		if itemid then
			self.db.char.bag[bag].list[itemid] = (self.db.char.bag[bag].list[itemid] or 0) + (stack or 0)
		end
		local storeIn = self.db.char.inv
		if bag < 0 or bag > 4 then storeIn = self.db.char.bank end
		if itemlink then
			storeIn[itemid] = (storeIn[itemid] or 0) + (stack or 0)
			if storeIn[itemid] == 0 then storeIn[itemid] = nil end
			--print("Update: "..itemlink..", "..(stack or 0))
		end
		if oldlink then
			storeIn[oldid] = (storeIn[oldid] or 0) - (oldstack or 0)
			if storeIn[oldid] == 0 then storeIn[oldid] = nil end
			--print("Update: "..oldlink..", -"..(oldstack or 0))
		end
	end
	self.db.char.bag[bag].avail = availableslots
	self:ScheduleEvent("Jigsaw_UpdateQueue",0.1)
	if self.postreconcile then
		self.postreconcile()
		self.postreconcile = nil
	end
end

function Jigsaw:UpdateQueue()
	for i,queue in ipairs(self.db.char.queue) do
		queue:UpdateAvail(self.db.char.inv,self.db.char.bank,self.db.char.recipe,self.db.account.recipe)
	end
	self:UpdateTooltip()
end

function Jigsaw:UpdateRecipes()
	local tradeskill,curlvl,maxlvl = GetTradeSkillLine()
	if tradeskill == "UNKNOWN" then return end
	self.db.char.tskill = self.db.char.tskill or {}
	self.db.char.tskill[tradeskill] = {}
	self.db.char.tskill[tradeskill].curLevel = curlvl
	self.db.char.tskill[tradeskill].maxLevel = maxlvl
	self.db.char.recipeIndex = self.db.char.recipeIndex or{}
	self.db.char.cooldowns = self.db.char.cooldowns or {}
	self.db.char.diff = self.db.char.diff or {}
	local curheader = ""
	local curheaderi = 0
	self.db.account.recipe = self.db.account.recipe or {}
	for skillId = 1, GetNumTradeSkills() do
		local recipeName, recipeType = GetTradeSkillInfo(skillId)
		if recipeType == "header" then
			curheader = recipeName
			table.insert(self.db.char.tskill[tradeskill],{name = curheader,list = {}})
			curheaderi = table.getn(self.db.char.tskill[tradeskill])
		else
			local JSID = IDFromItemLink(GetTradeSkillItemLink(skillId)) or recipeName
			local recipe
			if self.db.account.recipe[JSID] then
				recipe = self.db.account.recipe[JSID]
				if not recipe:valid(skillId) then
					recipe:update(tradeskill,skillId)
				end
			else
				recipe = TSRecipe:new(tradeskill,skillId)
			end
			self.db.char.recipeIndex[JSID] = skillId
			recipe:UpdateIndex(skillId)
			recipe:UpdateCooldown(self.db.char.cooldowns)
			self.db.account.recipe[JSID] = recipe
			self.db.char.recipe = self.db.char.recipe or {}
			self.db.char.recipe[JSID] = true
			local _, diff = GetTradeSkillInfo(skillId)
			self.db.char.diff[JSID] = diff
			self.db.char.tskill[tradeskill][curheaderi] = self.db.char.tskill[tradeskill][curheaderi] or {name=tradeskill, list={}}
			table.insert(self.db.char.tskill[tradeskill][curheaderi].list,JSID)
		end
	end
end

function Jigsaw:UpdateEnchants()
	local tradeskill,curlvl,maxlvl = GetCraftDisplaySkillLine()
	if not tradeskill then return end
	self.db.char.tskill = self.db.char.tskill or {}
	self.db.char.tskill[tradeskill] = {}
	self.db.char.tskill[tradeskill].curLevel = curlvl
	self.db.char.tskill[tradeskill].maxLevel = maxlvl
	self.db.char.recipeIndex = self.db.char.recipeIndex or{}
	self.db.char.cooldowns = self.db.char.cooldowns or {}
	self.db.char.diff = self.db.char.diff or {}
	local curheader = ""
	local curheaderi = 1
	self.db.account.recipe = self.db.account.recipe or {}
	for skillId = 1, GetNumCrafts() do
		local recipeName,_, recipeType = GetCraftInfo(skillId)
		if recipeType == "header" then
			curheader = recipeName
			table.insert(self.db.char.tskill[tradeskill],{name = curheader,list = {}})
			curheaderi = table.getn(self.db.char.tskill[tradeskill])
		else
			local JSID = IDFromItemLink(GetCraftItemLink(skillId)) or recipeName
			local recipe
			if self.db.account.recipe[JSID] then
				recipe = self.db.account.recipe[JSID]
				if not recipe:valid(skillId) then
					recipe:update(tradeskill,skillId)
				end
			else
				recipe = CRecipe:new(tradeskill,skillId)
			end
			self.db.char.recipeIndex[JSID] = skillId
			recipe:UpdateIndex(skillId)
			recipe:UpdateCooldown(self.db.char.cooldowns)
			self.db.account.recipe[JSID] = recipe
			self.db.char.recipe = self.db.char.recipe or {}
			self.db.char.recipe[JSID] = true
			local _, _, diff = GetCraftInfo(skillId)
			self.db.char.diff[JSID] = diff
			self.db.char.tskill[tradeskill][curheaderi] = self.db.char.tskill[tradeskill][curheaderi] or {name=tradeskill, list={}}
			table.insert(self.db.char.tskill[tradeskill][curheaderi].list,JSID)
		end
	end
end

function Jigsaw:OnMenuRequest(level, v1, intip, v2, v3, v4)
	if self.suppressJigsawMenu then
		self:AddImpliedMenuOptions()
		return
	end
	local function ttupdate()
		self:UpdateTooltip()
	end
	local function delqueue(i)
		table.remove(self.db.char.queue,i)
		self:UpdateTooltip()
	end
	if level == 1 then
		for i,queue in ipairs(self.db.char.queue) do
			queue:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, self.db.char.inv, self.db.char.bank, self.db.account.recipe, ttupdate, i, delqueue)
		end
		dewdrop:AddLine()
		dewdrop:AddLine("text", "New Goal", "value", "newgoal", "hasArrow", true)
		dewdrop:AddLine("text","AutoWithdraw Materials from the Bank",'func',function()
			self.db.char.AutoWithdraw = not self.db.char.AutoWithdraw
		end, 'checked',self.db.char.AutoWithdraw)
		dewdrop:AddLine("text","AutoBuy Raw Materials from Vendors",'func',function()
			self.db.char.AutoBuy = not self.db.char.AutoBuy
			self.db.char.AutoBuyLimit = self.db.char.AutoBuyLimit or 1000
			self.db.char.PerVendorLimit = self.db.char.PerVendorLimit or 5000
		end, 'checked',self.db.char.AutoBuy)
		dewdrop:AddLine("text","AutoBuy Limit in Silver","hasArrow",true,"hasSlider",true,"sliderMin",10,"sliderMax",500,"sliderValue",(self.db.char.AutoBuyLimit or 1000)/100,'sliderStep',10,
			'sliderFunc',function(val) self.db.char.AutoBuyLimit = val*100 end,'disabled',not self.db.char.AutoBuy)
		dewdrop:AddLine("text","Per Vendor Limit in Silver","hasArrow",true,"hasSlider",true,"sliderMin",50,"sliderMax",2500,"sliderValue",(self.db.char.PerVendorLimit or 5000)/100,'sliderStep',50,
			'sliderFunc',function(val) self.db.char.PerVendorLimit = val*100 end,'disabled',not self.db.char.AutoBuy)
		dewdrop:AddLine()
		self:AddImpliedMenuOptions()
	elseif level == 2 then
		if v1 == "newgoal" then
			self.newgoal = self.newgoal or {qindex=1}
			self:InsertGoalDetail(self.newgoal,true)
		elseif type(v1) == "table" then
			v1[2]:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, self.db.char.inv, self.db.char.bank, self.db.account.recipe, ttupdate, v1[3], delqueue)
		else
			self:AddImpliedMenuOptions()
		end
	elseif v1 == "tradeskill" or v2 == "tradeskill" or v3 == "tradeskill" or v1 == "queue" then
		self.newgoal = self.newgoal or {qindex=1}
		self:OnGoalMenuRequest(level-2,v1,intip,v2,v3,v4,self.newgoal)
	else
		local q
--		if type(v1) == "table" then q = v1[2]
		if type(v2) == "table" then q = v2[2]
		elseif type(v3) == "table" then q = v3[2]
		elseif type(v4) == "table" then q = v4[2]
		end
    if type(q) == "nil" then print "Cannot add to or remove from the queue individual goals using the detached menu.  Right-click on the Jigsaw Fubar Icon."
    else
		q:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, self.db.char.inv, self.db.char.bank, self.db.account.recipe, ttupdate, i, delqueue)
	  end
  end
end

function Jigsaw:InsertGoalDetail(goal,isnew,itemid)
	if self.db.char.tskill and self.db.account.recipe and self.db.char.recipe then
		dewdrop:AddLine("text","Goal","value","tradeskill","hasArrow",true)
	else
		dewdrop:AddLine("text","Recheck Tradeskills","isTitle",true)
	end
	local recipestep = 1
  if not self.db.account.recipe[goal.JSID] then print "Some goals from the Enchanting profession cannot be queued at this time.  Hopefully there will be an update to fix that."
  else
	if goal.JSID then recipestep = self.db.account.recipe[goal.JSID]:AverageMade() end
	dewdrop:AddLine("text","Number","hasArrow",true,"hasSlider",true,"sliderMin",recipestep,"sliderMax",50*recipestep,"sliderValue",goal.count or recipestep,'sliderStep',recipestep,
		'sliderFunc',function(goal,val) goal.count = val end, 'sliderArg1',goal)
	dewdrop:AddLine("text","Clear when Completed",'arg1',goal,'func',function(goal) goal.clear = not goal.clear end, 'checked',goal.clear)
	dewdrop:AddLine("text","Queue","value","queue","hasArrow",true)
	dewdrop:AddLine('text',"Add Goal", 'arg1', self, 'arg2', goal, 'func', 'AddGoal', 'closeWhenClicked', true)
  end
end

function Jigsaw:OnGoalMenuRequest(level,v1,intip,v2,v3,v4,goal)
	if v1 == "tradeskill" then
		for k,v in pairs(self.db.char.tskill) do
			--dewdrop:AddLine("text",k.."     "..v.curLevel.."/"..v.maxLevel,"value",k,"hasArrow",true)
			dewdrop:AddLine("text",k.."     "..v.curLevel.."/"..v.maxLevel,"isTitle",true)
			for i,header in ipairs(self.db.char.tskill[k]) do
				dewdrop:AddLine("text",header.name,"value",{k,i},"hasArrow",true)
			end
			dewdrop:AddLine()
		end
	elseif v2 == "tradeskill" then
		for i,JSID in pairs(self.db.char.tskill[v1[1]][v1[2]].list) do
			--local recipeJSID = JSID
			self.db.account.recipe[JSID]:AddMenuLine(dewdrop,goal,self.db.char.diff)
		end
	elseif v3 == "tradeskill" then
		v1[1]:MenuIngredients(dewdrop)
	elseif v1 == "queue" then
		for i,queue in ipairs(self.db.char.queue) do
			local _i = i
			dewdrop:AddLine("text",queue:GetName(),'arg1',goal,'func',function(goal) goal.qindex = _i end, 'checked', goal.qindex == _i)
		end
		dewdrop:AddLine()
		dewdrop:AddLine("text","New Queue",'hasArrow',true,'hasEditBox',true,'editBoxFunc',function(text)
			table.insert(self.db.char.queue,Queue:new(text))
		end)
	end
end

function Jigsaw:AddGoal(goal)
	goal.count = goal.count or self.db.account.recipe[goal.JSID]:AverageMade()
	local link = self.db.account.recipe[goal.JSID]:GetLink()
	local qindex = goal.qindex or 1
	self.db.char.queue[qindex]:AddGoal(link, goal.name, goal.JSID, goal.count, false, goal.clear, self.db.char.inv, self.db.char.bank, self.db.char.recipe,
		self.db.account.recipe)
	if goal == self.newgoal then self.newgoal = nil end
	self:UpdateTooltip()
end

function Jigsaw:AddExternalGoal(ItemLink,ItemCount,ClearOnComplete)
	local goal = {}
	goal.JSID = IDFromItemLink(ItemLink)
	goal.name = self.db.account.recipe[goal.JSID]:GetName()
	goal.clear = ClearOnComplete
	goal.count = ItemCount
	self:AddGoal(goal)
end

function Jigsaw:ClearGoal(itemid,queue)
	queue:ClearGoal(itemid)
	self:UpdateTooltip()
end

function Jigsaw:OnTooltipUpdate()
	--local cat = tablet:AddCategory('columns',2)
	self.db.char.cooldowns = self.db.char.cooldowns or {}
	for i,queue in ipairs(self.db.char.queue) do
		queue:OnTooltipUpdate(tablet, self.db.char.inv, self.db.char.bank, self.db.account.recipe, self.db.char.cooldowns)
	end
end

function Jigsaw:OnClick(button)
	if button ~= "LeftButton" or self.suppressJigsawCrafting then return end
	self:RunQueue()
end

function Jigsaw:RunQueue()
	local curskill = GetTradeSkillLine()
	if not curskill then curskill = GetTradeSkillLine() end

	local noneexecuted = true
	for i,queue in ipairs(self.db.char.queue) do
		if queue:RunQueue(curskill,self.db.account.recipe, self.db.char.inv) then
			noneexecuted = false
			break
		end
	end
	if noneexecuted and canDisenchant then CastSpellByName("Disenchant") return true end
end

function Jigsaw:AutoPurchase()
	if not self.db.char.AutoBuy then return end
	for i,queue in ipairs(self.db.char.queue) do
		queue:AutoBuy(self.db.account.recipe, self.db.char.AutoBuyLimit, self.db.char.PerVendorLimit)
	end
end

function Jigsaw:AutoWithdraw(i)
	i = i or 1
	if not self.db.char.AutoWithdraw then return end
	queue = self.db.char.queue[i]
	if queue then
		queue:AutoWithdraw(self.db.account.recipe,self.db.char.bag,
			function(...)
				local arg = {...}
				local prepostrecon = self.postreconcile
				if prepostrecon then
					self.postreconcile = function() prepostrecon() self:ScheduleEvent(unpack(arg)) end
				else
					self.postreconcile = function() self:ScheduleEvent(unpack(arg)) end
				end
			end,
			function()
				local prepostrecon = self.postreconcile
				if prepostrecon then
					self.postreconcile = function() prepostrecon() self:ScheduleEvent(self.AutoWithdraw,0.2,self,i+1) end
				else
					self.postreconcile = function() self:ScheduleEvent(self.AutoWithdraw,0.2,self,i+1) end
				end
				self:ScheduleEvent(self.UpdateQueue,0.2,self)
			end)
	end
end
