local AceOO = AceLibrary("AceOO-2.0")

local Queue = AceOO.Class()
local QueueItem = AceOO.Class()

local function IDFromItemLink(itemlink)
	if not itemlink then return end
	local found, _, itemId, enchantId, suffixId, uniqueId = strfind(itemlink, "item:(%d+):(%d+):(%d+):(%d+)")
	if not itemId then return end
	return tonumber(itemId)
end

local function ItemInfoFromItemLink(link)
	local name
	local id
	local color
	_,_,name = strfind(link,"%[([^%]]+)")
	_,_,id = strfind(link,"item:(%d+):")
	_,_,color = strfind(link,"|c([^|]+)")
	--local _,_,color,id,name = strfind(link,"(|c%x%x%x%x%x%x%x%x)|Hitem:(%d+):$d+:$d+:$d+|h%[([^%]]+)%]|h|r")
	return name, tonumber(id), "|c"..color
end

local function striptolink(link)
	_,_,link = strfind(link,"|H([^|]+)")
	return link
end

function QueueItem.prototype:init(link, name, itemid, count, implied, clear, invDB, bankDB, craftableDB)
	self.class.super.prototype.init(self)
	if type(link) ~= "table" then
		self.link = link
		self.req = count
		self.implied = 0
		if implied then self.implied = count end
		self.reserve = 0
		self.cleared = 0
		if not clear then self.reserve = count end
		self.name = name
		self.itemid = itemid
		self.invAvail = invDB[self.itemid] or 0
		self.totalAvail = self.invAvail + (bankDB[self.itemid] or 0)
		self.craftable = craftableDB[itemid]
	else
		for k,v in pairs(link) do self[k] = v end
	end
end

function QueueItem.prototype:GetUnimplied()
	return self.req - self.implied
end

function QueueItem.prototype:AddToCount(count, implied, clear)
	self.req = self.req + count
	if implied then
		self.implied = self.implied + count
	end
	if not clear then
		self.reserve = self.reserve + count
	end
end

function QueueItem.prototype:RemoveCount(count,implied, queue,recipeDB,dontRecurse)
	self.req = self.req - count
	if implied then self.implied = self.implied - count end
	if self.implied < 0 then self.implied = 0 end
	if self.implied > self.req then self.implied = self.req end
	local recipe = recipeDB[self.itemid]
	if recipe and not dontRecurse then
		for i,ing in recipe:Ingredients() do
			queue:RemoveGoalCount(ing.itemid,count * ing.count, true, recipeDB)
		end
	end
	return not (self.req > 0)
end

function QueueItem.prototype:GetCountRequired()
	return self.req
end

function QueueItem.prototype:GetCountNeeded()
	local n = self.req - self.invAvail
	if n > 0 then return n else return 0 end
end

function QueueItem.prototype:GetCountNeededIncludingBank()
	local n = self.req - self.totalAvail
	if n > 0 then return n else return 0 end
end

function QueueItem.prototype:UpdateAvail(invDB, bankDB, recipeDB)
	local preAvail = self.totalAvail
	self.invAvail = invDB[self.itemid] or 0
	self.totalAvail = self.invAvail + (bankDB[self.itemid] or 0)
	local cleared = self.totalAvail - preAvail
	if self.totalAvail > self.req and cleared < 0 then cleared = 0 end
	if preAvail < self.req and cleared > 0 then
		local count, r, g = self:GetCountAndColor(invDB,bankDB,recipeDB)
		UIErrorsFrame:AddMessage(self.name.." "..count, r, g, 0, 1)
	end
	if self.req > self.reserve then
		self.cleared = math.min(self.req - self.reserve,self.cleared + cleared)
		if self.cleared + self.reserve >= self.req then
			return cleared, self.cleared
		end
	end
	return cleared
end

local curhlink = nil

function QueueItem.prototype:AddTooltipLine(cat, invDB, bankDB, recipeDB, cdDB, hidesteps, hidegoals)
	local function _InternalAddTooltipLine(cat, invDB, bankDB, recipeDB, cdDB)
		local count, r, g = self:GetCountAndColor(invDB, bankDB, recipeDB)
		local name
		local recipe = recipeDB[self.itemid]
		name = recipe and recipe:GetName() or self.name or "<nil>"
		local cd = recipe and recipe:GetCooldown(cdDB) or ""
		if recipe then
			cat:AddLine('text',name..cd,'justify2',"RIGHT",'text2',count,'textR',r,'textG',g,'textB',0,'text2R',r,'text2G',g,'text2B',0,'func',function()
				local curskill = GetTradeSkillLine()
				if not curskill then curskill = GetTradeSkillLine() end
				if curskill == "Mining" then curskill = "Smelting" end
				recipe:Craft(curskill,'max')
			end,'onEnterFunc',function()
				GameTooltip:SetOwner(this, "ANCHOR_NONE")
				GameTooltip:SetPoint("TOPLEFT", this, "TOPRIGHT", 5, 0)
				curhlink = self
				GameTooltip:SetHyperlink(recipe:GetHyperlink())
				GameTooltip:Show()
			end,'onLeaveFunc',function()
				if curhlink == self then
					GameTooltip:Hide()
					curhlink = nil
				end
			end)
		else
			cat:AddLine('text',name..cd,'justify2',"RIGHT",'text2',count,'textR',r,'textG',g,'textB',0,'text2R',r,'text2G',g,'text2B',0,'func',
				function() end,
				'onEnterFunc',function()
					GameTooltip:SetOwner(this, "ANCHOR_NONE")
					GameTooltip:SetPoint("TOPLEFT", this, "TOPRIGHT", 5, 0)
					curhlink = self
					GameTooltip:SetHyperlink(striptolink(self.link))
					GameTooltip:Show()
				end,'onLeaveFunc',function()
					if curhlink == self then
						GameTooltip:Hide()
						curhlink = nil
					end
				end)
		end
	end
	if self.invAvail < self.req then
		_InternalAddTooltipLine(cat, invDB, bankDB, recipeDB, cdDB)
		return
	end
	if not hidesteps and self.req == self.implied then
		_InternalAddTooltipLine(cat, invDB, bankDB, recipeDB, cdDB)
		return
	end
	if not hidegoals and self.implied ~= self.req then
		_InternalAddTooltipLine(cat, invDB, bankDB, recipeDB, cdDB)
		return
	end
end

function QueueItem.prototype:OnMenuRequest(dewdrop, level, v1, intip, v2, v3, v4, invDB, bankDB, recipeDB, queue, ttupdate)
	if level == 2 then
		if self.req > self.implied then
			count, r, g = self:GetCountAndColor(invDB, bankDB, recipeDB)
			dewdrop:AddLine("text",self.name.." "..count,"textR",r,"textG",g,"textB",0,"value",self.itemid,"hasArrow",true)
		end
	else
		dewdrop:AddLine("text","Clear Goal","func",function() queue:ClearGoal(self.itemid,recipeDB) ttupdate() end,"closeWhenClicked",true)
	end
end

function QueueItem.prototype:GetCountAndColor(invDB, bankDB, recipeDB)
	local count, r, g
	local craftable, bankCraftable = 0, 0
	if self.craftable then
		craftable, bankCraftable = recipeDB[self.itemid]:NumberCraftable(invDB, bankDB, recipeDB)
	end
	local req = math.ceil(self.req)
	local bankCount = ""
	if self.totalAvail > self.invAvail or bankCraftable > craftable then
		local craftSub = ""
		local totalCraftable = math.floor(bankCraftable + craftable)
		if totalCraftable > 0 and self.totalAvail < req then craftSub = "["..math.min(req,totalCraftable + self.totalAvail).."]" end
		bankCount = math.min(req,self.totalAvail)..craftSub.."/"..req
	end
	local craftSub = ""
	craftable = math.floor(craftable)
	if craftable > 0 and self.invAvail < req then craftSub = "["..math.min(req,craftable + self.invAvail).."]" end
	count = math.min(req,self.invAvail)..craftSub.."/"..req
	if bankCount ~= count and bankCount ~= "" then count = count.." ("..bankCount..")" end
	g = self.invAvail / req
	r = 1 - g
	g = math.min(1,g*2)
	r = math.min(1,r*2)
	return count, r, g
end

function QueueItem.prototype:SubWithdraw(recipeDB,bags,bnum)
	bnum = bnum or -1
	local bag = bags[bnum]
	if not bag then return end
	local BP = bags[0]
	for i = 1,#bag do
		local slot = bag[i]
		if type(slot) == "table" and slot[1] then
			local itemid = IDFromItemLink(slot[1])
			if itemid == self.itemid then
				local amountNeeded = self:GetCountNeeded()
				local numAvailable = slot[2]
				local amountToGrab = math.min(numAvailable,amountNeeded)
				if amountToGrab > 0 then
					if BP.avail > 0 or (BP.list[itemid] or 0) > 0 then
						SplitContainerItem(bnum,i,amountToGrab)
						PutItemInBackpack()
						--Jigsaw:ReconcileInv(0)
						return true
					else
						local b2 = 20
						while b2 < 24 do
							if bags[b2 - 19].avail > 0 or (bags[b2 - 19].list[itemid] or 0) > 0 then
								SplitContainerItem(bnum,i,amountToGrab)
								PutItemInBag(b2)
								--Jigsaw:ReconcileInv(b2 - 19)
								return true
							end
							b2 = b2 + 1
						end
					end
				end
			end
		end
	end
	if bnum == -1 then
		return self:SubWithdraw(recipeDB,bags,5)
	else
		return self:SubWithdraw(recipeDB,bags,bnum + 1)
	end
end

function QueueItem:Deserialize(t)
	return self:new(t)
end

function QueueItem.prototype:Serialize()
	local serialized = {}
	serialized.link = self.link
	serialized.req = self.req
	serialized.implied = self.implied
	serialized.name = self.name
	serialized.itemid = self.itemid
	serialized.invAvail = self.invAvail
	serialized.totalAvail = self.totalAvail
	serialized.craftable = self.craftable
	serialized.cleared = self.cleared
	serialized.reserve = self.reserve
	return serialized
end

function Queue.prototype:init(t)
	self.class.super.prototype.init(self)
	if type(t) ~= "table" then
		self.name = t or "Default Queue"
		self.hidesteps = true
		self.items = {}
		self.order = {}
	else
		for k,v in pairs(t) do self[k] = v end
		-- check for weird serialization errors here.
		for i,item in ipairs(self.items) do
			if item.uid then
				item.uid = nil
				self.items[i] = QueueItem:new(item)
			end
		end
	end
end

function Queue.prototype:AddGoal(link, name, itemid, count, implied, clear, invDB, bankDB, craftableDB, recipeDB, dontSort)
	if self.items[itemid] then
		self.items[itemid]:AddToCount(count,implied, clear)
	else
		self.items[itemid] = QueueItem:new(link, name, itemid, count, implied, clear, invDB, bankDB, craftableDB)
		table.insert(self.order,itemid)
	end
	-- need to add goals for ingredients, count = ing per produced * number needed
	local recipe = recipeDB[itemid]
	if recipe then
		local needed = math.min(self.items[itemid]:GetCountNeededIncludingBank(),count)
		--local needed = count
		if needed > 0 then
			for i,ing in recipe:Ingredients() do
				self:AddGoal(ing.link, ing.name, ing.itemid, needed * ing.count, true, false, invDB, bankDB, craftableDB, recipeDB, true)
			end
		end
	end
	if not dontSort then
		self:SortItems(recipeDB)
	end
end

function Queue.prototype:ClearGoal(itemid,recipeDB)
	local goal = self.items[itemid]
	local unimplied = goal:GetUnimplied()
	self:RemoveGoalCount(itemid, unimplied, false, recipeDB,false, false)
end

function Queue.prototype:ClearAllGoals(ttupdate)
	self.items = {}
	self.order = {}
	ttupdate()
end

function Queue.prototype:RemoveGoalCount(itemid, count, implied, recipeDB, dontRemoveItems, dontRecurse)
	local goal = self.items[itemid]
	if not goal then return end
	local delete = goal:RemoveCount(count,implied,self,recipeDB,dontRecurse)
	if delete then
		self.items[itemid] = nil
		if not dontRemoveItems then
			self:RemoveItems()
		end
		return true
	end
end

function Queue.prototype:UpdateAvail(invDB, bankDB, craftableDB, recipeDB)
	local clearItems = {}
	local sort = false
	for k,item in pairs(self.items) do
		local clearIng,clearItem = item:UpdateAvail(invDB,bankDB, recipeDB)
		if clearIng or clearItem then
			clearItems[k] = {clearIng or 0,clearItem or 0}
		end
	end
	for k,clear in pairs(clearItems) do
		local recipe = recipeDB[k]
		if recipe then
			if clear[1] > 0 then
				for i,ing in recipe:Ingredients() do
					if self:RemoveGoalCount(ing.itemid,ing.count * clear[1], true, recipeDB, true) then sort = true end
				end
			elseif clear[1] < 0 then
				for i,ing in recipe:Ingredients() do
					self:AddGoal(ing.link, ing.name, ing.itemid, -(clear[1] * ing.count), true, false, invDB, bankDB, craftableDB, recipeDB, true)
				end
			end
			if clear[2] then
				if self:RemoveGoalCount(k,clear[2],false,recipeDB,true,true) then sort = true end
			end
		end
	end
	if sort then
		self:RemoveItems()
		self:SortItems(recipeDB)
	end
end

function Queue.prototype:RemoveItems()
	local i, itemid = 1, self.order[1]
	while itemid do
		if not self.items[itemid] then
			table.remove(self.order,i)
		else
			i = i + 1
		end
		itemid = self.order[i]
	end
end

function Queue.prototype:SortItems(recipeDB)
	table.sort(self.order,function(itemidA, itemidB)
		local recipeA = recipeDB[itemidA]
		local recipeB = recipeDB[itemidB]
		if not recipeA and not recipeB then
			if type(itemidA) ~= type(itemidB) then
				return type(itemidA) < type(itemidB)
			else
				return itemidA < itemidB
			end
		end
		if not recipeA then return true end
		if not recipeB then return false end
		return recipeA:SortBefore(recipeB,recipeDB)
	end)
end

function Queue.prototype:GetName()
	return self.name or "Default Queue"
end

function Queue.prototype:OnMenuRequest(dewdrop, level, v1, intip, v2, v3, v4, invDB, bankDB, recipeDB, ttupdate, qi, delqueue)
	if level == 1 then
		--if table.getn(self.order) > 0 then
			dewdrop:AddLine("text", self.name or "Default Queue", "value", {"curgoal",self,qi}, "hasArrow", true)
		--end
	elseif level == 2 then
		local hasitems = false
		for i,itemid in ipairs(self.order) do
			hasitems = true
			if self.items[itemid] then
				self.items[itemid]:OnMenuRequest(dewdrop, level, v1, intip, v2, v3, v4, invDB, bankDB, recipeDB, self, ttupdate)
			end
		end
		if hasitems then
			dewdrop:AddLine()
		end
		dewdrop:AddLine("text","Rename Queue",'hasArrow',true,'hasEditBox',true,'editBoxText',self.name or "",'editBoxArg1',self,'editBoxFunc',function(self,newname) self.name = newname end)
		if hasitems then
			dewdrop:AddLine("text","Clear Queue",'arg1',self,'arg2',ttupdate,'func',"ClearAllGoals",'closeWhenClicked',true)
		end
		dewdrop:AddLine("text","Hide Completed Steps",'arg1',self,'func',function(self) self.hidesteps = not self.hidesteps ttupdate() end,'checked',self.hidesteps)
		dewdrop:AddLine("text","Hide Completed Goals",'arg1',self,'func',function(self) self.hidegoals = not self.hidegoals ttupdate() end,'checked',self.hidegoals)
		dewdrop:AddLine("text","Hide Queue from Tooltip",'arg1',self,'func',function(self) self.hide = not self.hide ttupdate() end,'checked',self.hide)
		if qi > 1 then
			dewdrop:AddLine()
			dewdrop:AddLine("text","Delete Queue",'hasArrow',true,'value',"delqueue")
		end
	elseif v1 == "delqueue" then
		dewdrop:AddLine("text","Confirm",'func',function() delqueue(qi) end,'closeWhenClicked',true)
	elseif type(v2) == "table" then
		self.items[v1]:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, invDB, bankDB, recipeDB, self, ttupdate)
	elseif type(v3) == "table" then
		self.items[v2]:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, invDB, bankDB, recipeDB, self, ttupdate)
	elseif type(v4) == "table" then
		self.items[v3]:OnMenuRequest(dewdrop, level,v1,intip,v2,v3,v4, invDB, bankDB, recipeDB, self, ttupdate)
	end
end

function Queue.prototype:OnTooltipUpdate(tablet, invDB, bankDB, recipeDB, cdDB)
	if table.getn(self.order) > 0 and not self.hide then
		local qcat = tablet:AddCategory('columns',2,'id',self.uid,'text',self.name or "Default Queue")
		for i,itemid in ipairs(self.order) do
			local item = self.items[itemid]
			if item then
				if item.uid then
					item.uid = nil
					self.items[itemid] = QueueItem:new(item)
					item = self.items[itemid]
				end
				item:AddTooltipLine(qcat, invDB, bankDB, recipeDB, cdDB, self.hidesteps, self.hidegoals)
			end
		end
	--else
		--cat:AddLine("text","No Jigsaw Goals")
	end
end

function Queue.prototype:RunQueue(curskill,recipeDB, invDB)
	for i, itemid in ipairs(self.order) do
		local recipe = recipeDB[itemid]
		if recipe then
			local craftable = recipe:NumberCraftable(invDB,{},recipeDB)
			local itemcount = math.min(self.items[itemid]:GetCountNeeded() / recipe:AverageMade(),craftable)
			if itemcount > 0 then
				if curskill == "Mining" then curskill = "Smelting" end
				recipe:Craft(curskill,itemcount)
				return true
			end
		end
	end
end

function Queue.prototype:AutoBuy(recipeDB,peritemLimit,pervendorLimit)
	local numItems = GetMerchantNumItems()
	for i = 1,numItems do
		local itemid = IDFromItemLink(GetMerchantItemLink(i))
		local item = self.items[itemid]
		if item then
			local amountNeeded = item:GetCountNeededIncludingBank()
			local name, _, price, stackSize, numAvailable = GetMerchantItemInfo(i)
			if numAvailable >= 0 and (numAvailable * stackSize) < amountNeeded then amountNeeded = numAvailable * stackSize end
			local amountToBuy = math.ceil(amountNeeded / stackSize)
			if amountToBuy > 0 then
				if stackSize > 1 then
					while amountToBuy > 0 do
						BuyMerchantItem(i,1)
						amountToBuy = amountToBuy - 1
					end
				else
					while amountToBuy > 0 do
						local amountBuyingNow = math.min(amountToBuy, GetMerchantItemMaxStack(i))
						BuyMerchantItem(i, amountBuyingNow)
						amountToBuy = amountToBuy - amountBuyingNow
					end
				end
			end
		end
	end
end

function Queue.prototype:AutoWithdraw(recipeDB,bags,sched,callback)
	-- Try to withdraw the latest stuff from the bank first.
	for i = #self.order,1,-1 do local item = self.items[self.order[i]]
		if item:SubWithdraw(recipeDB,bags) then
			-- schedule next
			return sched(self.AutoWithdraw,0.2,self,recipeDB,bags,sched,callback)
		end
	end
	-- run callback if we've gotten through everything.
	return callback()
end

function Queue:Deserialize(t)
	return self:new(t)
end

function Queue.prototype:Serialize()
	local serialized = {}
	serialized.items = self.items
	serialized.order = self.order
	serialized.name = self.name
	serialized.hidesteps = self.hidesteps
	serialized.hidegoals = self.hidegoals
	serialized.hide = self.hide
	return serialized
end

local function activate(self, oldLib, oldDeactivate)
    if oldDeactivate then
        oldDeactivate(oldLib)
    end
end

AceLibrary:Register(Queue,"JigsawQueue-1.0",1,activate)
Queue = AceLibrary("JigsawQueue-1.0")
AceLibrary:Register(QueueItem,"JigsawQueueItem-1.0",1,activate)
QueueItem = AceLibrary("JigsawQueueItem-1.0")
