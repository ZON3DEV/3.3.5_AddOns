--== Traduction fran�aise par Atropyne (EU-Garona) ==--
if ( GetLocale() == "frFR" ) then

--[[ Status messages ]]--
-- Displays on load
RECIPEBOOK_LOADED = string.format(RECIPEBOOK_VERSION_TEXT.." charg\195\169! Entrez "..RB_HEXCOLOR["yellow"].."/recipebook help"..RB_HEXCOLOR["end"].." ou "..RB_HEXCOLOR["yellow"].."/rbk help"..RB_HEXCOLOR["end"].." pour les options; "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." pourla configuration graphique.");
-- Help file
RECIPEBOOK_HELP = {
	RB_HEXCOLOR["green"].."Utilisation:"..RB_HEXCOLOR["end"].." tapez "..RB_HEXCOLOR["yellow"].."/recipebook config"..RB_HEXCOLOR["end"].." ou "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." pour afficher le menu graphique.  Quelques commandes slashs sont disponibles: ",
	"   "..RB_HEXCOLOR["yellow"].."help"..RB_HEXCOLOR["end"].." : Affiche le message d'aide.",
	"   "..RB_HEXCOLOR["yellow"].."on|off"..RB_HEXCOLOR["end"].." : Change l'\195\169tat d'affichage des donn\195\169es de RecipeBook, Marche et arr\195\170t.",
	"   "..RB_HEXCOLOR["yellow"].."config"..RB_HEXCOLOR["end"].." : Ouvre la fen\195\170tre de configuration.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."send [<un de vos personnage>] to <personne>"..RB_HEXCOLOR["end"].." : Envoye vos donn\195\169es de RecipeBook d'un de vos personnages \195\160 la personne nomm\195\169e.  Utilisez 'guild' pour faire une mise \195\160 jour compl\195\168te \195\160 votre guilde.  Vous pouvez utiliser 'me' pour envoyer seulement les donn\195\169es de votre personnage courant.",
	"   "..RB_HEXCOLOR["yellow"].."update from <person>"..RB_HEXCOLOR["end"].." : Requests a RecipeBook update from another character.  Only works if you have RecipeBook data already stored for that character.",
	"   "..RB_HEXCOLOR["yellow"].."share"..RB_HEXCOLOR["end"].." : Ouvrir la panneau de configuration des partages et mise \195\160 jour",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."skill"..RB_HEXCOLOR["end"].." : Affiche les recettes connues actuellement par un personnage.",
	"   "..RB_HEXCOLOR["yellow"].."search <Cha\195\174ne de recherche>"..RB_HEXCOLOR["end"].." : Recherche d'un objet dans la base de donn\195\169e de RecipeBook qui correspond \195\160 la chaine de recherche.",
	"   "..RB_HEXCOLOR["yellow"].."searchmats <Cha\195\174ne de recherche>"..RB_HEXCOLOR["end"].." : Comme /rbk search, Recherche uniquement les donn\195\169es concernant les composants.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."bank"..RB_HEXCOLOR["end"].." : Affiche l'onglet Banque de RecipeBook.",
	"   ",
	};
RECIPEBOOK_ERR_BADARG = "D\195\169sol\195\169, je ne sais pas quoi faire de '%s'. Voici un peu d'aide.";
RECIPEBOOK_TXT_SUPPLIES = "Composants n\195\169cessaires pour ";
RECIPEBOOK_ADDED_SPECIALS = "Trouv\195\169 et ajout\195\169, la sp\195\169cialisation suivante:";

--[[ Data strings for parsing recipes ]]--
-- Whatever "ItemType" is for recipes in your locale
RECIPEBOOK_RECIPEWORD = "Recette";
RECIPEBOOK_WORD_TRANSMUTE = "Transmutation";
RECIPEBOOK_TRADESKILLS = {
	["Alchemy"] 		= "Alchimie", --1
	["Blacksmithing"] 	= "Forge", --2
	["Enchanting"] 		= "Enchantement", --3
	["Engineering"] 	= "Ing\195\169nierie", --4
	["Inscription"]		= "Calligraphie", --5
	["Jewelcrafting"] 	= "Joaillerie", --6
	["Leatherworking"] 	= "Travail du cuir", --7
	["Mining"] 			= "Minage", --8
	["Skinning"] 		= "D\195\169pe\195\167age", --9
	["Tailoring"] 		= "Couture", --10
	["Cooking"]			= "Cuisine", --11
	["First Aid"] 		= "Secourisme", --12
	["Fishing"] 		= "P\195\170che", --13
	["Herbalism"]       = "Herboristerie", --14
}

--Specializations
RECIPEBOOK_SPECIALS = {
	["Forge"] 	= {"Fabricant d'armures", "Fabricant d'armes"},
	["Ing\195\169nierie"] 	= {"Ing\195\169nieur gobelin", "Ing\195\169nieur gnome"},
	["Travail du cuir"] 	= {"Travail du cuir tribal", "Travail du cuir \195\169l\195\169mentaire", "Travail du cuir d'\195\169cailles de dragon"},
	["Couture"]       = {"Couture de tisse-ombre", "Couture du feu-sorcier", "Couture d'\195\169toffe lunaire"},
	["Alchimie"]         = {"Ma\195\174tre des potions", "Ma\195\174tre des \195\169lixirs", "Ma\195\174tre des transmutations"},
};
-- Subspecializations
RECIPEBOOK_SUBSPECIALS = {
	["Blacksmithing"] = {"Ma\195\174tre fabricant d'\195\169p\195\169es", "Ma\195\174tre fabricant de haches", "Ma\195\174tre fabricant de marteaux" },
};

--[[ Regex parsed items; these may need adjustment for your language. ]]--
RECIPEBOOK_CHAT_SKILLUP = gsub(gsub(ERR_SKILL_UP_SI, "%%1%$s", "(%%w)*"), "%%2%$d", "(%%d+)%%");
RECIPEBOOK_REGEX_SKILL = string.gsub(string.gsub(string.gsub(ITEM_MIN_SKILL, "%%%d%$", "%%"), "%%s", "%(%[^%%s%]+%)"), "%(%%d%)", "%%%(%(%%d+%)%%%)");
RECIPEBOOK_REGEX_SPECIALTY = string.gsub(string.gsub(ITEM_REQ_SKILL, "%%%d%$", "%%"), "%%s", "%(%[^%%s%]+%)" );
RECIPEBOOK_REGEX_REPUTATION = string.gsub(string.gsub(ITEM_REQ_REPUTATION, "%-", "%%%-"), "%%s", "%(%[%%w %]+%)" );
RECIPEBOOK_REGEX_NOTONLINE = string.gsub(ERR_CHAT_PLAYER_NOT_FOUND_S, "%%s", "%(%%w+%)");
RECIPEBOOK_REGEX_UNLEARNSKILL = string.gsub(ERR_SPELL_UNLEARNED_S, "%%s", "(%%w+)");
RECIPEBOOK_REGEX_LEARNRECIPE = string.gsub(ERR_LEARN_RECIPE_S, "%%s", "%(%[%%w%%s%]+%)");
RECIPEBOOK_REGEX_LEARNSPELL = string.gsub(ERR_LEARN_SPELL_S, "%%s", "%(%[%%w%%s%]+%)");
RECIPEBOOK_REGEX_ONLINE = string.gsub(string.gsub(string.gsub(ERR_FRIEND_ONLINE_SS, "%]", "%%%]"), "%[", "%%%["), "%%s", "%(%[%%w%]+%)");
	local a = string.find(LOOT_ITEM_PUSHED_SELF, "%s", 1, true);
RECIPEBOOK_REGEX_GETITEM = string.sub(LOOT_ITEM_PUSHED_SELF, 1, a-1);


--[[ Output prefixes ]]--
--== Chatframe Output ==--
RECIPEBOOK_CHATFRAME_KNOWNBY = " est d\195\169j\195\160 connu de: ";
RECIPEBOOK_CHATFRAME_NONEKNOWN = " n'est connu d'aucun Alt";
RECIPEBOOK_CHATFRAME_CANLEARN = " peut \195\170tre appris par: ";
RECIPEBOOK_CHATFRAME_NONELEARN = " ne peut \195\170tre appris par aucun Alt";
RECIPEBOOK_CHATFRAME_WILLLEARN = " pourra \195\170tre eventuellement appris par (comp\195\169tence actuelle): ";
RECIPEBOOK_CHATFRAME_NONEWILLLEARN = " ne peut pas \195\170tre appris par aucun de vos Alt, m\195\170me avec une augmentation de comp\195\169tences.";
RECIPEBOOK_CHATFRAME_BANKED = " est stock\195\169 par: ";
RECIPEBOOK_CHATFRAME_NOTBANKED = " n'est pas stock\195\169.";
RECIPEBOOK_CHATFRAME_CANMAKE = " peut etre fabriqu\195\169 par: ";

--== Tooltip Output ==--
-- RECIPEBOOK_TOOLTIPPREFIX = "\194\183";
RECIPEBOOK_KNOWNBY = "D\195\169j\195\160 connu de: ";
RECIPEBOOK_CANLEARN = "Peut \195\170tre appris par: ";
RECIPEBOOK_WILLLEARN = "Pourra \195\170tre appris par: ";
RECIPEBOOK_CANMAKE = "Peut \195\170tre fabriqu\195\169 par: ";
RECIPEBOOK_ISBANKED = "Stock\195\169 par: ";
-- RECIPEBOOK_NODATA = RECIPEBOOK_TOOLTIPPREFIX.."Aucun personnage ne connait ou ne peut utiliser cette recette." -- For future use
RECIPEBOOK_ERR_DATANOTLOADED = "Les donn\195\169es de RecipeBook ne sont pas encore charg\195\169es.\nAttendez quelques secondes et r\195\169essayez.";
RECIPEBOOK_ERR_ITEMDBEMPTY = "RecipeBook has no stored tradeskill data."

--[[ Options display text; name is RBOPTIONS_(option)_(suboption) ]]--
RBOPTIONS_STATUS = "Sortie des donn\195\169es de RecipeBook: %s (la collecte des donn\195\169es est toujours en marche).  Utilisez /rbk (or /rbk) config pour configurer RecipeBook.";
-- Chatframe options display has been outmoded; using GUI instead.  Options default to RBOptions_NotFound
RBOPTIONS_NOTFOUND = "D'autres options peuvent \195\170tre vues dans le panneau de configuration(/rbk config)";
-- Cn/off colored text
RBOPTIONS_ON = RB_HEXCOLOR["green"].."On"..RB_HEXCOLOR["end"];
RBOPTIONS_OFF = RB_HEXCOLOR["red"].."Off"..RB_HEXCOLOR["end"];

--== RBOutput_Print() ==--
RECIPEBOOK_ERROR_PREFIX = "|cffffff00<|cffff0000RecipeBook Erreur|cffffff00>|r ";
RECIPEBOOK_PREFIX = "|cffffff00<RecipeBook>|r ";


--========================[[ Configuration Screens ]]============================--
---------------------------------- Main Frame and Subframe Tabs  -------------------------------------------
RECIPEBOOK_SFTAB_SEARCH = "Recherche";
RECIPEBOOK_SFTAB_BROWSE = "Parcourir";
RECIPEBOOK_SFTAB_OPTIONS = "Options";
RECIPEBOOK_SFTAB_SHARING = "Partage";
RECIPEBOOK_SFTAB_BANKING = "Stockage";
RECIPEBOOK_SFTAB_COLORS = "Couleurs";
RECIPEBOOK_SFSUBTAB_AA = "Accept. Auto";
RECIPEBOOK_SFSUBTAB_AD = "Refus Auto";
RECIPEBOOK_SFSUBTAB_AU = "MAJ Auto";

---------------------------------- Main Frame and Subframe Buttons -------------------------------------------
RECIPEBOOK_CFG_B_MAKEDEFAULT = "Etablir D\195\169faut";

--------------------------------- Search Panel  (tab 1) -------------------------------------------
RECIPEBOOK_SFTITLE_SEARCH = "Recherche de Recettes/Composants";
-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_KNOWNS = "  Connu de: 1 alt";
RECIPEBOOK_TEMPLATE_KNOWNM = "  Connu de: %d alts";
-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_HAVES = " (1 autre a %s)";
RECIPEBOOK_TEMPLATE_HAVEM = " (%d autres ont %s)";
RECIPEBOOK_TXT_KNOWNBY = "Connu de (difficult\195\169): ";
RECIPEBOOK_TXT_HASKILL = "%s connu[e] (niveau): "; -- modif ?
RECIPEBOOK_TXT_NOKNOWNBY = "Connu d'aucun alts";
RECIPEBOOK_TEMPLATE_KNOWNMATS = " Compo(s): ";
RECIPEBOOK_CBX_SEARCHITEMS = "Recherche dans les recettes connues";
RECIPEBOOK_CBX_TT_SEARCHITEMS = "Cochez pour rechercher les objets cr\195\169\195\169s qui correspondent au texte entr\195\169.";
RECIPEBOOK_CBX_SEARCHMATS = "Rechercher dans les composants";
RECIPEBOOK_CBX_TT_SEARCHMATS = "Cochez pour rechercher les objets qui utilisent comme composant le texte entr\195\169.";
RECIPEBOOK_CBX_SEARCHEXACT = "Recherche la phrase exacte";
RECIPEBOOK_CBX_TT_SEARCHEXACT = "Si vous d\195\169cochez cette case, tous les mots seront compris dans votre recherche (ex:\"Masque Blanc\" donnera comme r\195\169sultat \"Masque de Bandit Blanc\"). Si elle est coch\195\169e, il sera trouv\195\169 exactement ce que vous aurez tap\195\169.";
RECIPEBOOK_CBX_SEARCHBOOSTS = "Uniquement les objets qui am\195\169liorent un Alt";
RECIPEBOOK_CBX_TT_SEARCHBOOSTS = "Afficher uniquement les objets qui aurait le potentiel d'am\195\169liorer un de vos personnages (vert, jaune ou orange)";
RECIPEBOOK_ERR_NOSEARCHRESULT = RB_HEXCOLOR["red"].."Rien ne correspond \195\160 votre recherche"..RB_HEXCOLOR["end"];

--------------------------------- Skill Browse Panel (tab 2) -------------------------------------------
RECIPEBOOK_SFTITLE_SKILL = "Parcourir les m\195\169tiers connus";
RECIPEBOOK_BROWSE_FS_NOSPEC = "Aucune sp\195\169cialisation";
RECIPEBOOK_BROWSE_FS_NODATA = "Aucune donn\195\169e";
RECIPEBOOK_BROWSE_FS_NOTRACKED = "Non suivi";
RECIPEBOOK_BROWSE_FS_NODATE = "Aucune date";

RECIPEBOOK_BROWSE_FS_CLICK = "[Clic pour changer]";
RECIPEBOOK_BROWSE_BUT_SHOW = "Voir";
RECIPEBOOK_BROWSE_FS_SHARED = "partag\195\169";
RECIPEBOOK_BROWSE_FS_PERSONAL = "Personel";
RECIPEBOOK_BROWSE_FS_NOTRADESKILL = "Aucun m\195\169tier trouv\195\169";

RECIPEBOOK_BROWSE_FS_SEARCH = "Entrez votre recherche";

RECIPEBOOK_BROWSE_FS_ITEM = "Obj.";
RECIPEBOOK_BROWSE_FS_RECIPE = "Recettes";
RECIPEBOOK_BROWSE_FS_INFOITEMLEVEL = "Niveau objet";
RECIPEBOOK_BROWSE_FS_INFOMINLEVEL = "Niveau requis";

RECIPEBOOK_BROWSE_DD_SORTALPHA = "Alphab\195\169tique";
RECIPEBOOK_BROWSE_DD_SORTDIFF = "Difficult\195\169";
RECIPEBOOK_BROWSE_DD_SORTILVL = "Niveau objet";
RECIPEBOOK_BROWSE_DD_SORTMLVL = "Niveau min requis";
RECIPEBOOK_BROWSE_DD_SORTITYPE = "Type/Emplacement";

RECIPEBOOK_CFG_CBX_SU = "Montrer tous les objets de la BDD";
RECIPEBOOK_CFG_MOUSEOVER_SU = "Montrer tous les objets se trouvant dans la base de donn\195\169e de RecipeBook pour les m\195\169tiers s\195\169lectionn\195\169s, mais que ce personnage ne connait pas.";
--------------------------------- Skill Tracking Subframe -------------------------------------------
RECIPEBOOK_BROWSE_TT_APPLY = "Appliquer les changements, efface les donn\195\169es des m\195\169tiers non suivis.";
RECIPEBOOK_BROWSE_TT_RESET = "Abandonner les changements.";
RECIPEBOOK_BROWSE_TT_SHOW = "D\195\169cochez pour supprimer les donn\195\169es obsol\195\168tes (anticipe que certaines recettes de ce m\195\169tier soient vues comme 'peut \195\170tre appris' ou 'pourra \195\170tre appris')" -- modif ?
RECIPEBOOK_BROWSE_TT_DEFAULTS = "Reinitialiser toutes les options de suivi \195\160 leur valeur par d\195\169faut, ensuite applique ces changements.";
RECIPEBOOK_BROWSE_FS_TRACKED = "M\195\169tiers suivis";
RECIPEBOOK_BROWSE_TT_TRACKED = "R\195\169gler les options de suivi de comp\195\169tences pour ce personnage."
RECIPEBOOK_BROWSE_TT_REFRESH = "Recharger la fen\195\170tre de ce m\195\169tier.";
RECIPEBOOK_BROWSE_TT_DELETE = "Effacer toutes les donn\195\169es des m\195\169tiers pour ce personnage.";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDHEADER = "Objet non pr\195\169sent dans le cache:";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDITEM = {
	"Une requ\195\170te pour cet objet a \195\169chou\195\169.",
	"En cons\195\169quence, cet objet est risqu\195\169. Pour voir cet objet sans \195\170tre d\195\169connect\195\169, vous devez l'avoir d\195\169j\195\160 vu une fois dans le jeux. C'est une restriction introduite avec le patch 1.10.",
	"Vous pouvez cliquer pour interroger le serveur. Il se peut que vous soyez d\195\169connect\195\169."
};
--------------------------------- Sharing Panel (tab 3) -------------------------------------------
RECIPEBOOK_SFTITLE_SHARING = "Donn\195\169es partag\195\169es";
RECIPEBOOK_CFG_HEADER_SHARING = "Donn\195\169es partag\195\169es (Amis)";
RECIPEBOOK_CFG_FS_SHARECATEGORIES = "Montrer les recettes qui sont: ";
RECIPEBOOK_CFG_CBX_SL = "Store Linked Recipes";
RECIPEBOOK_CFG_MOUSEOVER_SL = "Store tradeskill data from gold [Tradeskill] links when opened.";
RECIPEBOOK_CFG_CBX_SK = "Connues";
RECIPEBOOK_CFG_CBX_SC = "Apprenable";
RECIPEBOOK_CFG_CBX_SW = "de nos m\195\169tiers";
RECIPEBOOK_CFG_FS_SHAREFACTION = "Montrer les donn\195\169es des recettes partag\195\169es de:";
RECIPEBOOK_CFG_CBX_SSF = "M\195\170me faction";
RECIPEBOOK_CFG_CBX_SOF = "Faction oppos\195\169e";

RECIPEBOOK_CFG_RADIO_CAPTION = "Demande de partage de:"
RECIPEBOOK_CFG_RADIO_HEADER = "Accepter    Refuser    Demander"
RECIPEBOOK_CFG_RADIO_FRIENDS = "Amis";
RECIPEBOOK_CFG_RADIO_GUILD = "Guildies";
RECIPEBOOK_CFG_RADIO_DEFAULT = "R\195\169ponse par d\195\169faut";

RECIPEBOOK_CFG_HEADER_AUTOUPDATE = "Configuration des mises \195\160 jour auto";
RECIPEBOOK_CFG_FS_AUFREQ = "Envoyer les mises \195\160 jour auto pour les donn\195\169es datant de:";
RECIPEBOOK_CFG_RADIO_DAY = "1 jour";
RECIPEBOOK_CFG_RADIO_WEEK = "1 semaine";
RECIPEBOOK_CFG_RADIO_NEVER = "Jamais";
RECIPEBOOK_CFG_FS_AUSOURCE = "Accepter automatiquement la mise \195\160 jour provenant de:"
RECIPEBOOK_CFG_CBX_G = "Guildies";
RECIPEBOOK_CFG_MOUSEOVER_G = "Accepter les mises \195\160 jour provenant des membres de la guilde qui utilises la commande '/rbk send me to guild'"
RECIPEBOOK_CFG_CBX_A = "liste des accept. auto";
RECIPEBOOK_CFG_MOUSEOVER_A = "Accepter les mises \195\160 jour entrantes automatiquement, SI l'exp\195\169diteur est dans votre liste des mises \195\160 jour auto."
RECIPEBOOK_CFG_CBX_GU = "Envoyer les MAJ \195\160 la guilde \lors de la connection"; -- For future use

RECIPEBOOK_CFG_DDHEADER_UPDATEFROM = "Mise \195\160 jour auto de:";

--== see below for parser information ==--
--------------------------------- Banking Panel (tab 4) -------------------------------------------
RECIPEBOOK_SFTITLE_BANKING = "Stockage : configuration";
RECIPEBOOK_CFG_HEADER_BANKLIST = "Stock\195\169 sur ce serveur/faction:";
RECIPEBOOK_CFG_HEADER_BANKOPTIONS = "Options de stockage:";
RECIPEBOOK_CFG_CBX_B = "Afficher le statut : Stock\195\169";
RECIPEBOOK_CFG_CBX_BT = "Notification du stockage ou non des recettes";
RECIPEBOOK_CFG_FS_AUTOBANK = "Suivi auto des recettes stock\195\169es de:";
RECIPEBOOK_CFG_CBX_BK = "Votre banque";
RECIPEBOOK_CFG_CBX_BG = "Vos sacs";
RECIPEBOOK_CFG_TT_UNBANK = "Efface les objets de la liste de stockage de ce personnage";

--== Chatframe Banking Messages ==--
RECIPEBOOK_AUTOHELD = "Ajou\195\169 \195\160 la liste de stockage: ";
RECIPEBOOK_AUTOUNHELDSUCCEED = "Enlev\195\169 de la liste de stockage de %s: %s";
RECIPEBOOK_AUTOUNHELDFAIL = "D\195\169sol\195\169, %s n'a pas %s de stock\195\169.";
RECIPEBOOK_INFO_CANLEARNONSKILLUP = "Vous avez maintenant la possibilit\195\169 d'apprendre %s, stock\195\169 par %s.";

--------------------------------- Options Panel (tab 5) -------------------------------------------
RECIPEBOOK_SFTITLE_OPTIONS = "Options de RecipeBook";
RECIPEBOOK_CFG_FS_SELECTFACTION = "Suivre les factions (global)";
RECIPEBOOK_CFG_CBX_S = "Afficher les messages de RecipeBook";
RECIPEBOOK_CFG_CBX_MM = "Afficher le bouton de la minimap";
RECIPEBOOK_CFG_CBX_DM = "Afficher le perrsonnage actuel";
RECIPEBOOK_CFG_CBX_I = "Afficher messages d'info (pas les erreurs)";
RECIPEBOOK_CFG_MOUSEOVER_I = "D\195\169cochez cette case pour enlever les messages tels que les \195\169tapes de scan de vos m\195\169tiers ou les infos /rbk send.";
RECIPEBOOK_CFG_CBX_C = "Effacer les recettes qu'aucun personnage ne connait";
RECIPEBOOK_CFG_MOUSEOVER_C = "D\195\169cochez si vous voulez que RecipeBook conserve les recettes dans la base de donn\195\169e, m\195\170me si aucun de vos personnages ne la connait. Cochez, si vous d\195\169sirez garder une base de donn\195\169e plus l\195\169g\195\168re (et s\195\187rement plus rapide), en contrepartie de ne pouvoir consulter que les recettes que  vos personnages/personnages partag\195\169s peuvent faire.";
RECIPEBOOK_CFG_FS_OUTPUT = "Sortie des infos de recettes vers:";
RECIPEBOOK_CFG_CBX_OT = "La bulle d'info";
RECIPEBOOK_CFG_CBX_OC = "L'onglet RecipeBook du chat";
RECIPEBOOK_CFG_FS_CATEGORIES = "Afficher les recettes qui:";
RECIPEBOOK_CFG_CBX_AK = "Sont d\195\169j\195\160 connues";
RECIPEBOOK_CFG_CBX_AC = "Peuvent \195\170tre apprises";
RECIPEBOOK_CFG_CBX_AW = "Pourront \195\170tre apprises";
RECIPEBOOK_CFG_FS_CANMAKE = "Afficher les objets qui peuvent \195\170tre cr\195\169\195\169 par:";
RECIPEBOOK_CFG_CBX_AM = "Vos personnages";
RECIPEBOOK_CFG_CBX_SM = "Les personnages partag\195\169s";
RECIPEBOOK_CFG_FS_FACTION = "Afficher les donn\195\169es de recettes/objets de:";
RECIPEBOOK_CFG_CBX_ASF = "La m\195\170me faction";
RECIPEBOOK_CFG_CBX_AOF = "La faction oppos\195\169e";
RECIPEBOOK_CFG_CBX_TM = "Collecter les donn\195\169e RecipeBook pour ce personnage";

RECIPEBOOK_CFG_FS_AUCTION = "Options de l'h\195\180tel des ventes et des marchands";
RECIPEBOOK_CFG_CBX_ACS = "Code-couleurs pour l'HV/marchands";
RECIPEBOOK_CFG_CBX_ABS = "Noircir les recettes stock\195\169es";
RECIPEBOOK_CFG_CBX_ASC = "Color-code shared data";
RECIPEBOOK_CFG_MOUSEOVER_SC = "Check this if you want RecipeBook to consider shared data as well as personal data when color-coding at the Auction House and merchants.";

--------------------------------- Colors Panel (tab 6) -------------------------------------------
RECIPEBOOK_SFTITLE_COLORS = "Color-coding Options";

-- Auction Frame: --
RECIPEBOOK_CFG_FS_AUCTIONCOLOR = "Auction House Color Coding (click on the icon to change)";
RECIPEBOOK_CFG_SW_AAC = "Colorise les recettes qui peuvent \195\170tre apprises par vos personnages (ce personnage non inclu).";
RECIPEBOOK_CFG_SW_AAW = "Colorise les recettes qui pourront \195\170tre apprises un de vos personnages (incluant ce personnage).";
RECIPEBOOK_CFG_SW_AMW = "Colorise les recettes qui pourront eventuellement \195\170tre apprises par ce personnage uniquement.";
RECIPEBOOK_CFG_SW_AOC = "Colorise les recettes qu'aucun de vos personnages ne pourra apprendre.";
RECIPEBOOK_CFG_SW_AAK = "Colorise les recettes qui sont connues par tous les personnages suivis.";
-- Tooltip Options: --
RECIPEBOOK_CFG_FS_TOOLTIPCOLOR = "Tooltip Text Color Coding (click the color square to change)";
-- Tooltip: Alt Names -- 
RECIPEBOOK_CFG_FS_ALTS = "Names of alts";
RECIPEBOOK_CFG_SW_TASF = "Same faction"; --Alts/same faction
RECIPEBOOK_CFG_SW_TAOF = "Opposing faction"; --Alts/other faction
RECIPEBOOK_CFG_FS_SHARED = "Names of shared characters";
RECIPEBOOK_CFG_SW_TSSF = "This faction"; --Shared/same faction
RECIPEBOOK_CFG_SW_TSOF = "Opposing faction"; --Shared/other faction
-- Tooltip: Recipe colors --
RECIPEBOOK_CFG_FS_RECIPES = "Recipe Information";
RECIPEBOOK_CFG_SW_TK = '"Known by:" text' ; -- Known
RECIPEBOOK_CFG_SW_TC = '"Can be learned by:" text'; -- Can learn
RECIPEBOOK_CFG_SW_TW = '"Will be learnable by:" text'; -- Will learn
RECIPEBOOK_CFG_SW_TB = '"Banked by:" text'; -- Banked
RECIPEBOOK_CFG_SW_TM = '"Can be made by:" text'; -- Can Make

-----------------------------------------------------------------------------------------------------------------------------

RECIPEBOOK_SHARE_USAGE = RB_HEXCOLOR["red"].."Note: cel\195\160 a chang\195\169! "..RB_HEXCOLOR["end"].."Utilisation: "..RB_HEXCOLOR["yellow"].."/rbk send [<un de vos personnaget>] to <personne>"..RB_HEXCOLOR["end"]..".  Vous pouvez utiliser 'me' pour envoyer seulement les donn\195\169es de votre personnage courant..";
RECIPEBOOK_UPDATE_USAGE = "Usage: "..RB_HEXCOLOR["yellow"].."/rbk update from <person>"..RB_HEXCOLOR["end"]..".  You must already have data from that person to request an update.";
--== RB Share User Notifications ==--
RECIPEBOOK_SHARERROR_NOCOMPLETE = "Ne peut pas terminer le partage RecipeBook (Initi\195\169 par %s, M\195\169tier %s pour le joueur %s): ";
RECIPEBOOK_SHARERROR_NOTRACKED = "%s non suivi pour %s.";
RECIPEBOOK_SHARERROR_CANCEL = "Le partage a \195\169t\195\169 annul\195\169."
RECIPEBOOK_SHARERROR_VERSION = "Version de RecipeBook incompatible. Requi\195\168re au moins la version ".. table.concat(RECIPEBOOK_COMPATIBLE, ".") .. " pour le partage.";
RECIPEBOOK_SHARERROR_TIMEOUT = "Echec pour recevoir une r\195\169ponse appropri\195\169 de %s avant que le temps n'expire.";
RECIPEBOOK_SHARERROR_AUTODECLINE = "%s is automatically declining all tradeskill shares for %s";
RECIPEBOOK_SHARERROR_NOTRACKING = "%s is not tracking tradeskill %s for %s.";
RECIPEBOOK_SHARERROR_MANUALDECLINE = "%s has declined to accept %s's data from %s";
RECIPEBOOK_UPDATERROR_MANUALDECLINE = "%s has declined to send updated data to %s";
RECIPEBOOK_SHARERROR_TIMEOUTDECLINE = "%s has let the accept window expire for %s's data from %s";
RECIPEBOOK_SHARERROR_SENDSELF = "Vous ne pouvez pas envoyer des donn\195\169es RecipeBook \195\160 vous m\195\170me. Vous l'avez d\195\169j\195\160.";
RECIPEBOOK_SHARERROR_NOTINGUILD = "Vous n'\195\170tes pas dans une guilde.";
RECIPEBOOK_SHARERROR_NOGUILDONLINE = "Aucun membre de la guilde n'est en ligne; RecipeBook ne va pas envoyer de donn\195\169es.";
RECIPEBOOK_ERROR_NOREQUEST = "Vous n'avez aucune donn\195\169e concernant %s dans votre RecipeBook.  Aucune requ\195\170te de mise \195\160 jour ne peut \195\170tre faite.";
RECIPEBOOK_ERROR_AUTODECLINE = " ne d\195\169sire actuellement pas, accepter les donn\195\169es RecipeBook de "; -- modif ?
RECIPEBOOK_ERROR_DECLINEDSESSION = "Refus auto du partage RecipeBook venant de ";
RECIPEBOOK_ERROR_ACCEPTEDSESSION = "Acceptation auto du partage RecipeBook provenant de %s pour %s.";
--== Info messages ==--
RECIPEBOOK_SHAREMSG_INITIATE = "Tentative d'envoyer les donn\195\169es de %s pour %s \195\160 %s.";
RECIPEBOOK_SHAREMSG_TERMINATE = "Envoye des donn\195\169es de %s termin\195\169 pour %s \195\160 %s.";
RECIPEBOOK_SHAREMSG_RECEIVEDALL = "Donn\195\169es de %s pour %s, Re\195\167ues avec succ\195\169s provenant de %s.";
--== Popups ==--
RECIPEBOOK_POPUP_BLOCKPLAYER = "Vous avez D\195\169clin\195\169 les donn\195\169es RecipeBook du joueur %s.  Toujours refuser les partages de ce joueur?";
RECIPEBOOK_POPUP_ACCEPTPLAYER = "Vous avez accept\195\169 les donn\195\169es RecipeBook du joueur %s.  Toujours accepter les partages de ce joueur?";
RECIPEBOOK_POPUP_REQUESTING_SEND = "%s d\195\169sire vous envoyer des donn\195\169es RecipeBook pour le personnage %s.  Ce transfert va \195\170tre annul\195\169 automatiquement dans %d %s.";
RECIPEBOOK_POPUP_REQUESTING_UPDATE = "%s d\195\169sire que vous envoyiez des mises \195\160 jour de vos donn\195\169es.  Choisissez 'Accepter' pour envoyer la mise \195\160 jour.  Cette requ\195\170te va \195\170tre annul\195\169e automatiquement dans %d %s.";
RECIPEBOOK_POPUP_ADD_CHARACTER = "Entrez le nom du personnage \195\160 ajouter:";
RECIPEBOOK_POPUP_SHARE_TO 		= "Enter the name of the character to exchange RecipeBook data with.";

------------------------------------------------------[[ Minimap Menu, User Menu,  and Key Bindings ]]------------------------------------
--== User Menu ==--
RECIPEBOOK_MENU_MAIN = "RecipeBook";
RECIPEBOOK_MENU_SHARE = "Envoyer des donn\195\169es";
RECIPEBOOK_MENU_REQUEST = "Demander une mise \195\160 jour";
RECIPEBOOK_MENU_SHARESELF = "Envoyer les donn\195\169es de ce personnage";
RECIPEBOOK_MENU_SHAREALL = "Envoyer les donn\195\169es pour tous vos personnages";
--== Key Bindings ==--
BINDING_HEADER_RECIPEBOOK = "RecipeBook";
BINDING_NAME_RECIPEBOOK_SKILL = "Panneau de parcours des m\195\169tiers";
BINDING_NAME_RECIPEBOOK_CONFIG = "Panneau de configuration";
BINDING_NAME_RECIPEBOOK_SEARCH = "Panneau de recherche";
--== Minimap Button ==--
RECIPEBOOK_MMTXT = "|cffffff00Recipe Book|r:\n|cff00ff00Clic gauche|r pour afficher la fen\195\170tre de parcours des m\195\169tiers\n|cff00ff00Clic droit|r pour choisir une autre fen\195\170tre";
RECIPEBOOK_MM_MENUTITLE = "Choisissez un onglet:";
RECIPEBOOK_MM_SHARETITLE = "Shared Data";
RECIPEBOOK_MM_SHARESUBTITLE = "For Target Player:";
RECIPEBOOK_MM_HIDE = "Cacher le bouton de la minimap";


-----------------------[[ Informational Messages ]]-----------------
RECIPEBOOK_ERR_NOTRADESKILLOPEN = "No tradeskill is currently open.  Try opening a tradeskill window before attempting to force scan.";
RECIPEBOOK_INFO_SCANNINGTRADESKILL = "Refreshing tradeskill and reagent data.  Please wait a few seconds...";
RECIPEBOOK_INFO_RESCANNINGTRADESKILL = "...still scanning.  This usually means there is a lot of new data.  Please be patient...";
RECIPEBOOK_ERR_TRADESKILLNOTSCANNED = "Certains objets n'ont pas \195\169t\195\169 scann\195\169s.\nPeut RecipeBook tenter de forcer la charge?";
RECIPEBOOK_INFO_SCANCOMPLETED = "Tous les objets et les composants ont \195\169t\195\169 sauv\195\169 pour le m\195\169tier %s.  OK pour fermer la fen\195\170tre des m\195\169tiers.";
RECIPEBOOK_TEXT_ITEMDISCONNECTED = "RecipeBook a trouv\195\169 un mauvais ID d'objet dans cette base de donn\195\169e, causant une d\195\169connection. Nous n'allons pas essayer de faire une nouvelle requ\195\170te pour l'ID de cet objet tant qu'il n'aura pas \195\169t\195\169 vu par un de vos personnage. Choisissez OKAY s'il vous plait pour continuer. Si cel\195\160 arrive sans cesse, effacer votre fichier savedvariables et red\195\169marrez le jeu.";


-----------------------[[ RecipeBook DB Error Messages ]]-----------------
RECIPEBOOK_DBERROR_NOSKILLID = "Aucun m\195\169tier trouv\195\169";
RECIPEBOOK_DBERROR_NODIFFID = "Mauvaise ID de difficult\195\169";
RECIPEBOOK_DBERROR_NOSPECID = "Pas de sp\195\169cialisation";

RECIPEBOOK_NEWVERSION = "Cette version de RecipeBook ne supporte pas les donn\195\169es des versions pr\195\169c\195\169dentes. Vous devez reconstruire votre base de donn\195\169e de vos personnages et de ceux partag\195\169s."

end;
