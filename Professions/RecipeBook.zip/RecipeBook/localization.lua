


--[[ Status messages ]]--
-- Displays on load
RECIPEBOOK_LOADED = string.format(RECIPEBOOK_VERSION_TEXT.." загружен! Введите "..RB_HEXCOLOR["yellow"].."/recipebook help"..RB_HEXCOLOR["end"].." или "..RB_HEXCOLOR["yellow"].."/rbk help"..RB_HEXCOLOR["end"].." для настроек; "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." для графических настроек.");
-- Help file
RECIPEBOOK_HELP = {
	RB_HEXCOLOR["green"].."Использование:"..RB_HEXCOLOR["end"].." Использовать "..RB_HEXCOLOR["yellow"].."/recipebook config"..RB_HEXCOLOR["end"].." или "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." для графических настроек.  Доступны некоторые слэш команды: ",
	"   "..RB_HEXCOLOR["yellow"].."help"..RB_HEXCOLOR["end"].." : Показывает это сообщение помощи.",
	"   "..RB_HEXCOLOR["yellow"].."on|off"..RB_HEXCOLOR["end"].." : Включает/выключает аддон.",
	"   "..RB_HEXCOLOR["yellow"].."config"..RB_HEXCOLOR["end"].." : Открывает графическое окно настроек.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."send [<alt>] to <person>"..RB_HEXCOLOR["end"].." : Отсылает ваши данные аддона с определенного альта к игроку указанном в скобках.  Используйте 'guild' что бы провести обновление в гильдии.  Вы также можете использовать 'me' что бы отправить данные только этого персонажа.",
	"   "..RB_HEXCOLOR["yellow"].."update from <person>"..RB_HEXCOLOR["end"].." : Запрашивает обновление базы данных с других персонажей.  Работает только если вы уже храните данные.",
	"   "..RB_HEXCOLOR["yellow"].."share"..RB_HEXCOLOR["end"].." : Открывает обмен и обновляет понель настроек.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."skill"..RB_HEXCOLOR["end"].." : Показывает текущие известные рецепты для персонажа.",
	"   "..RB_HEXCOLOR["yellow"].."search <search string>"..RB_HEXCOLOR["end"].." : Поиск базы данных для вещей которые совпадают со строкой поиска",
	"   "..RB_HEXCOLOR["yellow"].."searchmats <search string>"..RB_HEXCOLOR["end"].." : Также как /rbk search, ищет только данные по материалам.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."bank"..RB_HEXCOLOR["end"].." : Отображает панель Банкинга аддона.",
	"   ",
	};
RECIPEBOOK_ERR_BADARG = "Простите, я незнаю что делать с'%s'.  Нужна помощь.";
RECIPEBOOK_TXT_SUPPLIES = "Припасы нужны для ";
RECIPEBOOK_ADDED_SPECIALS = "Нашел и добавил следущие торговые специализации: ";

--[[ Data strings for parsing recipes ]]--
-- Whatever "ItemType" is for recipes in your locale
RECIPEBOOK_RECIPEWORD = "Рецепт";
RECIPEBOOK_WORD_TRANSMUTE = "Трансмутация";
RECIPEBOOK_TRADESKILLS = {
	["Alchemy"] 		= "Алхимия", --1
	["Blacksmithing"] 	= "Кузнечное дело", --2
	["Enchanting"] 		= "Наложение чар", --3
	["Engineering"] 	= "Инженерное дело", --4
	["Inscription"]		= "Начертание", --5
	["Jewelcrafting"] 	= "Ювелирное дело", --6
	["Leatherworking"] 	= "Кожевничество", --7
	["Mining"] 			= "Горное дело", --8

	["Skinning"] 		= "Снятие шкур", --9
	["Tailoring"] 		= "Портняжное дело", --10

	["Cooking"]			= "Кулинария", --11
	["First Aid"] 		= "Первая помощь", --12
	["Fishing"] 		= "Рыбная ловля", --13
	["Herbalism"]       = "Травничество", --14
}

--Specializations
RECIPEBOOK_SPECIALS = {
	["Blacksmithing"] 	= {"Бронник", "Оружейник"},
	["Engineering"] 	= {"Гоблинский механик", "Гномский механик"},
	["Leatherworking"] 	= {"Кожевничество: традиции предков", "Кожевничество: сила стихий", "Кожевничество: чешуя дракона"},
	["Tailoring"]       = {"Шитье из тенеткани", "Шитье из чароткани", "Шитье из луноткани"},
	["Alchemy"]         = {"Мастер эликсиров", "Мастер эликсиров", "Мастер трансмутации"},
};
-- Subspecializations
RECIPEBOOK_SUBSPECIALS = {
	["Blacksmithing"] = {"Мастер ковки клинков", "Мастер школы топора", "Мастер школы Молота" },
};

--[[ Regex parsed items; these may need adjustment for your language. ]]--
RECIPEBOOK_CHAT_SKILLUP = gsub(gsub(ERR_SKILL_UP_SI, "%%s", "(%%w*)"), "%%d.", "(%%d+)%%.");
RECIPEBOOK_REGEX_SKILL = string.gsub(string.gsub(ITEM_MIN_SKILL, "%%s", "%(%[%%w%%s%]+%)" ), "%(%%d%)", "%%%(%(%%d+%)%%%)");
RECIPEBOOK_REGEX_SPECIALTY = string.gsub(ITEM_REQ_SKILL, "%%s", "%(%[%%w%%s%]+%)" );
RECIPEBOOK_REGEX_REPUTATION = string.gsub(string.gsub(ITEM_REQ_REPUTATION, "%-", "%%%-"), "%%s", "%(%[%%w %]+%)" );
RECIPEBOOK_REGEX_NOTONLINE = string.gsub(ERR_CHAT_PLAYER_NOT_FOUND_S, "%%s", "%(%%w+%)");
RECIPEBOOK_REGEX_UNLEARNSKILL = string.gsub(ERR_SPELL_UNLEARNED_S, "%%s", "(%%w+)");
RECIPEBOOK_REGEX_LEARNRECIPE = string.gsub(ERR_LEARN_RECIPE_S, "%%s", "%(%[%%w%%s%]+%)");
RECIPEBOOK_REGEX_LEARNSPELL = string.gsub(ERR_LEARN_SPELL_S, "%%s", "%(%[%%w%%s%]+%)");
RECIPEBOOK_REGEX_ONLINE = string.gsub(string.gsub(string.gsub(ERR_FRIEND_ONLINE_SS, "%]", "%%%]"), "%[", "%%%["), "%%s", "%(%[%%w%]+%)");
	local a = string.find(LOOT_ITEM_PUSHED_SELF, "%s", 1, true);
RECIPEBOOK_REGEX_GETITEM = string.sub(LOOT_ITEM_PUSHED_SELF, 1, a-1);--[[ Output prefixes ]]--
--== Chatframe Output ==--
RECIPEBOOK_CHATFRAME_KNOWNBY = " уже известен: ";
RECIPEBOOK_CHATFRAME_NONEKNOWN = " неизвестен альтам";
RECIPEBOOK_CHATFRAME_CANLEARN = " может изучить: ";
RECIPEBOOK_CHATFRAME_NONELEARN = " не может быть узученным ни одним альтом";
RECIPEBOOK_CHATFRAME_WILLLEARN = " будет доступен для изучения (текущий уровень навыка): ";


RECIPEBOOK_CHATFRAME_NONEWILLLEARN = " нет альтов которым нужно только поднятие скила для его изучения.";
RECIPEBOOK_CHATFRAME_BANKED = " в банке у: ";
RECIPEBOOK_CHATFRAME_NOTBANKED = " не в банке.";
RECIPEBOOK_CHATFRAME_CANMAKE = " может сделать: ";

--== Tooltip Output ==--
-- RECIPEBOOK_TOOLTIPPREFIX = "\194\183";
RECIPEBOOK_KNOWNBY = "Уже известен: ";
RECIPEBOOK_CANLEARN = "Может изучить: ";
RECIPEBOOK_WILLLEARN = "Будет доступен для изучения: ";

RECIPEBOOK_CANMAKE = "Может сделать: ";
RECIPEBOOK_ISBANKED = "В банке у: ";
-- RECIPEBOOK_NODATA = RECIPEBOOK_TOOLTIPPREFIX.."No alts know or can use this recipe." -- For future use
RECIPEBOOK_ERR_DATANOTLOADED = "Данные RecipeBook еще не загружены.\nПодождите несколько секунд и повторите попытку.";



--[[ Options display text; name is RBOPTIONS_(option)_(suboption) ]]--
RBOPTIONS_STATUS = "RecipeBook выход данных: %s (коллекция данных всегда включена).  Используйте /rb (или /rbk) что бы настроить RecipeBook.";
-- Chatframe options display has been outmoded; using GUI instead.  Options default to RBOptions_NotFound
RBOPTIONS_NOTFOUND = "Другие настроки могут быть отображены в панели конфигурации (/rb config)";
-- Cn/off colored text
RBOPTIONS_ON = RB_HEXCOLOR["green"].."Вкл"..RB_HEXCOLOR["end"];
RBOPTIONS_OFF = RB_HEXCOLOR["red"].."Выкл"..RB_HEXCOLOR["end"];

--== RBOutput_Print() ==--
RECIPEBOOK_ERROR_PREFIX = "|cffffff00<|cffff0000RecipeBook Ошибка|cffffff00>|r ";
RECIPEBOOK_PREFIX = "|cffffff00<RecipeBook>|r ";


--========================[[ Configuration Screens ]]============================--
---------------------------------- Main Frame and Subframe Tabs  -------------------------------------------
RECIPEBOOK_SFTAB_SEARCH = "Поиск";
RECIPEBOOK_SFTAB_BROWSE = "Обзор";
RECIPEBOOK_SFTAB_OPTIONS = "Опции";
RECIPEBOOK_SFTAB_SHARING = "Общее";
RECIPEBOOK_SFTAB_BANKING = "Банк";
RECIPEBOOK_SFSUBTAB_AA = "Авто-Принять";


RECIPEBOOK_SFSUBTAB_AD = "Авто-Отклонить";
RECIPEBOOK_SFSUBTAB_AU = "Авто-Обновить";

---------------------------------- Main Frame and Subframe Buttons -------------------------------------------
RECIPEBOOK_CFG_B_MAKEDEFAULT = "Стандарт";

--------------------------------- Search Panel  (tab 1) -------------------------------------------
RECIPEBOOK_SFTITLE_SEARCH = "Поиск рецептов/матерьялов";

-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_KNOWNS = "  Известен: 1 альту";
RECIPEBOOK_TEMPLATE_KNOWNM = "  Известен: %d алтам(и)";
-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_HAVES = " (1 дополнительный имеет %s)";
RECIPEBOOK_TEMPLATE_HAVEM = " (%d дополнительный есть у %s)";
RECIPEBOOK_TXT_KNOWNBY = "Доступен (сложность): ";
RECIPEBOOK_TXT_HASKILL = "Имеет %s (уровень): ";
RECIPEBOOK_TXT_NOKNOWNBY = "Выучен альтами";
RECIPEBOOK_TEMPLATE_KNOWNMATS = "  Используется: ";
RECIPEBOOK_CBX_SEARCHITEMS = "Поиск в известных рецептах";

RECIPEBOOK_CBX_TT_SEARCHITEMS = "Проверяет поиск для созданной вещи которая совпадает с текстом поиска.";
RECIPEBOOK_CBX_SEARCHMATS = "Поиск в матерьялах";
RECIPEBOOK_CBX_TT_SEARCHMATS = "Проверка вещей которые используют реагент который совпадает с текстом поиска.";
RECIPEBOOK_CBX_SEARCHEXACT = "Поиск только точной фразы";
RECIPEBOOK_CBX_TT_SEARCHEXACT = "Если это выключить, проверка всех слов в строке поиска (т.е. \"white mask\" выведет White Bandit Mask).  Если отмечено, находит ТОЛЬКО точно то что вы отметили.";
RECIPEBOOK_CBX_SEARCHBOOSTS = "Только предметы, которые могут помочь альтам";

RECIPEBOOK_CBX_TT_SEARCHBOOSTS = "Возвращать вещи только те которые подходят для буста альта(зеленые, желтые, или оранжевые)";
RECIPEBOOK_ERR_NOSEARCHRESULT = RB_HEXCOLOR["red"].."Нет совпадения в данном поиске"..RB_HEXCOLOR["end"];

--------------------------------- Skill Browse Panel (tab 2) -------------------------------------------
RECIPEBOOK_SFTITLE_SKILL = "Обзор известных навыков";
RECIPEBOOK_BROWSE_FS_NOSPEC = "Нет специализации";
RECIPEBOOK_BROWSE_FS_NODATA = "Нет данных";
RECIPEBOOK_BROWSE_FS_NOTRACKED = "Не отслеживаемый";
RECIPEBOOK_BROWSE_FS_NODATE = "Нет даты";

RECIPEBOOK_BROWSE_FS_CLICK = "[кликните чтоб изменить]";
RECIPEBOOK_BROWSE_BUT_SHOW = "Показ";
RECIPEBOOK_BROWSE_FS_SHARED = "Общий";
RECIPEBOOK_BROWSE_FS_PERSONAL = "Личный";
RECIPEBOOK_BROWSE_FS_NOTRADESKILL = "Навык не найден";

RECIPEBOOK_BROWSE_FS_SEARCH = "Ведите текст поиска";

RECIPEBOOK_BROWSE_FS_ITEM = "Предмет";
RECIPEBOOK_BROWSE_FS_RECIPE = "Делает";
RECIPEBOOK_BROWSE_FS_INFOITEMLEVEL = "Уровень предмета";
RECIPEBOOK_BROWSE_FS_INFOMINLEVEL = "Треб. уровень";

RECIPEBOOK_BROWSE_DD_SORTALPHA = "По алфавиту";
RECIPEBOOK_BROWSE_DD_SORTDIFF = "По сложности";
RECIPEBOOK_BROWSE_DD_SORTILVL = "По уровеню предмета";
RECIPEBOOK_BROWSE_DD_SORTMLVL = "По мин треб уровню";
RECIPEBOOK_BROWSE_DD_SORTITYPE = "По типу/расположению";

RECIPEBOOK_CFG_CBX_SU = "Показ всех предметов в базе данных";
RECIPEBOOK_CFG_MOUSEOVER_SU = "Показывать вещи которые есть в базе данных аддона для указанного навыка, но которые данный персонаж не знает.";
--------------------------------- Skill Tracking Subframe -------------------------------------------
RECIPEBOOK_BROWSE_TT_APPLY = "Подтверждает изменения, удаляя данные професий для не отслеживаемых навыков.";
RECIPEBOOK_BROWSE_TT_RESET = "Отменить изменения.";
RECIPEBOOK_BROWSE_TT_SHOW = "Убрать данные определений (убирает надписи с этим навыком 'можно выучить' или 'сможете выучить')"
RECIPEBOOK_BROWSE_TT_DEFAULTS = "Сбрасывает все настройки отслеживания на стандартные, и подтверждает изменения.";
RECIPEBOOK_BROWSE_FS_TRACKED = "Слежение навыков";
RECIPEBOOK_BROWSE_TT_TRACKED = "Установить опции слежения навыков для данного персонажа."
RECIPEBOOK_BROWSE_TT_REFRESH = "Перезагрузить данное окно навыков.";
RECIPEBOOK_BROWSE_TT_DELETE = "Удалить все данные навыков для данного альта.";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDHEADER = "Предмет вне кеша:";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDITEM = {
	"Данный запрос может вас выбить из игры(безопасные, небезопасные вещи).",
};
--------------------------------- Sharing Panel (tab 3) -------------------------------------------
RECIPEBOOK_SFTITLE_SHARING = "Общие данные";
RECIPEBOOK_CFG_HEADER_SHARING = "Общие (друзей) данные";
RECIPEBOOK_CFG_FS_SHARECATEGORIES = "Отображать рецепты которые: ";
RECIPEBOOK_CFG_CBX_SL = "Хранить Линкованые Рецепты";
RECIPEBOOK_CFG_MOUSEOVER_SL = "Хранить данные професии из золтых [Професий] линков, когда открыто.";
RECIPEBOOK_CFG_CBX_SK = "Известные";
RECIPEBOOK_CFG_CBX_SC = "Доступный";
RECIPEBOOK_CFG_CBX_SW = "С навыком";
RECIPEBOOK_CFG_FS_SHAREFACTION = "Данный общих рецептов для:";
RECIPEBOOK_CFG_CBX_SSF = "Тойже фракции";
RECIPEBOOK_CFG_CBX_SOF = "Противоположной";

RECIPEBOOK_CFG_RADIO_CAPTION = "Общий запрос для:"
RECIPEBOOK_CFG_RADIO_HEADER = "Принять  Отменить  Напомнить"
RECIPEBOOK_CFG_RADIO_FRIENDS = "Друзей";
RECIPEBOOK_CFG_RADIO_GUILD = "Согульдчан";
RECIPEBOOK_CFG_RADIO_DEFAULT = "Стандартное действие";

RECIPEBOOK_CFG_HEADER_AUTOUPDATE = "Настройка Авто-Обновления";
RECIPEBOOK_CFG_FS_AUFREQ = "Запуск Авто-Обновления данных старше чем:";
RECIPEBOOK_CFG_RADIO_DAY = "1 день";
RECIPEBOOK_CFG_RADIO_WEEK = "1 неделя";
RECIPEBOOK_CFG_RADIO_NEVER = "Никогда";
RECIPEBOOK_CFG_FS_AUSOURCE = "Принять входящее Авто-Обновление от:"
RECIPEBOOK_CFG_CBX_G = "Гильдии";
RECIPEBOOK_CFG_MOUSEOVER_G = "Принимать обновления от согульчан, которые также использую эту функцию";
RECIPEBOOK_CFG_CBX_A = "Списка Авто-Приёма";
RECIPEBOOK_CFG_MOUSEOVER_A = "Принять входящее Авто-Обновление ЕСЛИ отсылатель внесён в ваш список Авто-Приёма."
RECIPEBOOK_CFG_CBX_GU = "Высылать обновление в гильдию при входе"; -- For future use

RECIPEBOOK_CFG_DDHEADER_UPDATEFROM = "Также Авто-Обновлять от:";
--== see below for parser information ==--
--------------------------------- Banking Panel (tab 4) -------------------------------------------
RECIPEBOOK_SFTITLE_BANKING = "Настройки банка";
RECIPEBOOK_CFG_HEADER_BANKLIST = "Банк данного сервера/фракции:";
RECIPEBOOK_CFG_HEADER_BANKOPTIONS = "Опции банка:";
RECIPEBOOK_CFG_CBX_B = "Статус банка";
RECIPEBOOK_CFG_CBX_BT = "Отображать оповещения банка";
RECIPEBOOK_CFG_FS_AUTOBANK = "Автоматически отслеживать рецепты в:";
RECIPEBOOK_CFG_CBX_BK = "В ваших ячейках";
RECIPEBOOK_CFG_CBX_BG = "В ваших сумках";
RECIPEBOOK_CFG_TT_UNBANK = "Удалить предмет из списка вложений в банк персонажа";

--== Chatframe Banking Messages ==--
RECIPEBOOK_AUTOHELD = "Добавлен в список вложений в банк: ";
RECIPEBOOK_AUTOUNHELDSUCCEED = "Удален из %s'а списка вложений в банк: %s";
RECIPEBOOK_AUTOUNHELDFAIL = "Извените, %s не имеет %s вложений в банке.";
RECIPEBOOK_INFO_CANLEARNONSKILLUP = "Сейчас вы можете выучить %s, в банке у %s.";

--------------------------------- Options Panel (tab 5) -------------------------------------------
RECIPEBOOK_SFTITLE_OPTIONS = "Настройки RecipeBook";
RECIPEBOOK_CFG_FS_SELECTFACTION = "Отслеживаемые Фракции (глобально)";
RECIPEBOOK_CFG_CBX_S = "Показать вывод Recipe Book";
RECIPEBOOK_CFG_CBX_MM = "Показать кнопку миникарты";
RECIPEBOOK_CFG_CBX_DM = "Отобразить текущего персонажа";
RECIPEBOOK_CFG_CBX_I = "Показать информационные (не ошибки) сообщения";
RECIPEBOOK_CFG_MOUSEOVER_I = "Снемите галочку что бы убрать инфо сообщения такие как сканирование профессий и /rbk send инфо.";
RECIPEBOOK_CFG_CBX_C = "Удалять рецепты которые не известны ни одному персонажу";
RECIPEBOOK_CFG_MOUSEOVER_C = "Снимите галочку если вы хотите что бы RecipeBook проверял вещи в базе данных даже если никто не знает рецепта. Отметьте что бы держать базу данных в меньшем виде(также она будет работать быстрее).";
RECIPEBOOK_CFG_FS_OUTPUT = "Вывод инфо о рецепте в:";
RECIPEBOOK_CFG_CBX_OT = "Подсказка";
RECIPEBOOK_CFG_CBX_OC = "RecipeBook чат";
RECIPEBOOK_CFG_FS_CATEGORIES = "Показать рецепты которые:";
RECIPEBOOK_CFG_CBX_AK = "Уже известны";
RECIPEBOOK_CFG_CBX_AC = "Могут быть выучены";
RECIPEBOOK_CFG_CBX_AW = "Точно Выучите";
RECIPEBOOK_CFG_FS_CANMAKE = "Показать вещи которые могут быть зделаны:";
RECIPEBOOK_CFG_CBX_AM = "Вашими альтами";
RECIPEBOOK_CFG_CBX_SM = "Обменивающимся персонажами";
RECIPEBOOK_CFG_FS_FACTION = "Показать данные по рецепту и вещи для:";
RECIPEBOOK_CFG_CBX_ASF = "Той же фракции";
RECIPEBOOK_CFG_CBX_AOF = "Вражеской фракции";
RECIPEBOOK_CFG_CBX_TM = "Собрать RecipeBook данныедля этого персонажа";

RECIPEBOOK_CFG_FS_AUCTION = "Настройки Аукциона и продавцов";
RECIPEBOOK_CFG_CBX_ACS = "Цвет кода аукционов и продавцов";
RECIPEBOOK_CFG_CBX_ABS = "Затемнять рецепты в банке";
RECIPEBOOK_CFG_CBX_ASC = "Цвет обменяных данных";
RECIPEBOOK_CFG_MOUSEOVER_SC = "Отметьте это если вы хотите что бы RecipeBook подтверждал обменяные данные как персональные с Аукционами и продавцами.";

--------------------------------- Colors Panel (tab 6) -------------------------------------------
RECIPEBOOK_SFTITLE_COLORS = "Настройки Цвета";

-- Auction Frame: --
RECIPEBOOK_CFG_FS_AUCTIONCOLOR = "Цвет аукцина (нажмите на иконку что бы сменить)";
RECIPEBOOK_CFG_SW_AAC = "Рецепты которые могут быть выучены альтами (не включая этого персонажа).";
RECIPEBOOK_CFG_SW_AAW = "Рецепты которые вконце могут быть выучены альтами (может включать этого персонажа).";
RECIPEBOOK_CFG_SW_AMW = "Рецепты которые в конце могут быть выучены только этим персонажем.";
RECIPEBOOK_CFG_SW_AOC = "Рецепты которые не смогут быть выучеными альтами.";
RECIPEBOOK_CFG_SW_AAK = "Рецепты которые уже известны всем альтам.";
-- Tooltip Options: --
RECIPEBOOK_CFG_FS_TOOLTIPCOLOR = "Цвет текста подсказки (кликните на цветной квадрат для смены)";
-- Tooltip: Alt Names -- 
RECIPEBOOK_CFG_FS_ALTS = "Имена альтов";
RECIPEBOOK_CFG_SW_TASF = "Таже фракция"; --Alts/same faction
RECIPEBOOK_CFG_SW_TAOF = "Вражеская фракция"; --Alts/other faction
RECIPEBOOK_CFG_FS_SHARED = "Имена обменивающихся персонажей";
RECIPEBOOK_CFG_SW_TSSF = "Эта фракция"; --Shared/same faction
RECIPEBOOK_CFG_SW_TSOF = "Вражеская фракция"; --Shared/other faction
-- Tooltip: Recipe colors --
RECIPEBOOK_CFG_FS_RECIPES = "Информация о рецепте";
RECIPEBOOK_CFG_SW_TK = '"Известа:" текст' ; -- Known
RECIPEBOOK_CFG_SW_TC = '"Может быть выучено:" текст'; -- Can learn
RECIPEBOOK_CFG_SW_TW = '"Смогут выучить:" текст'; -- Will learn
RECIPEBOOK_CFG_SW_TB = '"В банке у:" текст'; -- Banked
RECIPEBOOK_CFG_SW_TM = '"Может зделать:" текст'; -- Can Make

-----------------------------------------------------------------------------------------------------------------------------

RECIPEBOOK_SHARE_USAGE = RB_HEXCOLOR["red"].."Заметка: Это было изменено! "..RB_HEXCOLOR["end"].."Использование: "..RB_HEXCOLOR["yellow"].."/rbk send [<альт>] к <игроку>"..RB_HEXCOLOR["end"]..".  Вы можете использовать 'me' что бы отослать данные только этого персонажа.";
RECIPEBOOK_UPDATE_USAGE = "Использование: "..RB_HEXCOLOR["yellow"].."/rbk update from <person>"..RB_HEXCOLOR["end"]..".  Вы уже должны были принять данные от этого игрока что запросить обновление.";
--== RB Share User Notifications ==--
RECIPEBOOK_SHARERROR_NOCOMPLETE = "Немогу закончить обмен (Инициировано %s, профессия %s для игрока %s): ";
RECIPEBOOK_SHARERROR_NOTRACKED = "Нет отслеживания %s для %s.";
RECIPEBOOK_SHARERROR_CANCEL = "Обмен был отменен."
RECIPEBOOK_SHARERROR_VERSION = "Неподходящая версия RecipeBook.  Требуется как минимум версия ".. table.concat(RECIPEBOOK_COMPATIBLE, ".") .. " для обмена.";
RECIPEBOOK_SHARERROR_TIMEOUT = "Провал получить соотвецтвующий ответ от %s перед истечением времени.";
RECIPEBOOK_SHARERROR_AUTODECLINE = "%s автоматически отменяет все обмены информацией для %s";
RECIPEBOOK_SHARERROR_NOTRACKING = "%s не отслеживает профессию %s для %s.";
RECIPEBOOK_SHARERROR_MANUALDECLINE = "%s отменил подтверждение %s данных %s";
RECIPEBOOK_UPDATERROR_MANUALDECLINE = "%s отменил отправку обновленных данных к %s";
RECIPEBOOK_SHARERROR_TIMEOUTDECLINE = "%s дал окну подтверждения закрытся для %s данных от %s";
RECIPEBOOK_SHARERROR_SENDSELF = "Вы не можете отправлять данные себе. У вас они уже есть.";
RECIPEBOOK_SHARERROR_NOTINGUILD = "Вы не в гильдии.";
RECIPEBOOK_SHARERROR_NOGUILDONLINE = "Нет согильдийцев в сети; RecipeBook не отрпавит данные.";
RECIPEBOOK_ERROR_NOREQUEST = "У вас нет данных. Обновление не может быть осуществлено.";
RECIPEBOOK_ERROR_AUTODECLINE = " не хочет принимать данные для ";
RECIPEBOOK_ERROR_DECLINEDSESSION = "Авто-отмена обмена от ";
RECIPEBOOK_ERROR_ACCEPTEDSESSION = "Авто-подтверждение обмена от %s для %s.";
--== Info messages ==--
RECIPEBOOK_SHAREMSG_INITIATE = "Проба отослать %s данные для %s к %s.";
RECIPEBOOK_SHAREMSG_TERMINATE = "Завершена пересылка %s данных для %s к %s.";
RECIPEBOOK_SHAREMSG_RECEIVEDALL = "Данные для %s %s успешно получены от %s.";
--== Popups ==--
RECIPEBOOK_POPUP_BLOCKPLAYER = "Вы отменили данные для игрока %s.  Всегда отменять обмен от этого игрока?";
RECIPEBOOK_POPUP_ACCEPTPLAYER = "Вы подтвердили данные для игрока %s.  Авто-подтверждение обмена для этого игрока?";
RECIPEBOOK_POPUP_REQUESTING_SEND = "%s хочет отправить вам данные для персонажа %s.  Эта пересылка будет отменена через %d %s.";
RECIPEBOOK_POPUP_REQUESTING_UPDATE = "%s хотите ли вы запросить  обновленные данные.  Нажмите 'Поддтвердить' Что бы отправить обновление. Этот запрос автоматом закроется через %d %s.";
RECIPEBOOK_POPUP_ADD_CHARACTER = "Введите имя персонажа что бы добавить:";
RECIPEBOOK_POPUP_SHARE_TO = "Введите имя персонажа что бы обменятся данными с ним.";

------------------------------------------------------[[ Minimap Menu, User Menu,  and Key Bindings ]]------------------------------------
--== User Menu ==--
RECIPEBOOK_MENU_MAIN = "RecipeBook";
RECIPEBOOK_MENU_SHARE = "Отправить данные";
RECIPEBOOK_MENU_REQUEST = "Запросить обновление";
RECIPEBOOK_MENU_SHARESELF = "Отправить данные этого персонажа";
RECIPEBOOK_MENU_SHAREALL = "Отправить данные всем альтам";
--== Key Bindings ==--
BINDING_HEADER_RECIPEBOOK = "RecipeBook Ключи";
BINDING_NAME_RECIPEBOOK_SKILL = "Панель обзора Навыка";
BINDING_NAME_RECIPEBOOK_CONFIG = "Панель Настроек";
BINDING_NAME_RECIPEBOOK_SEARCH = "Окно поиска";
--== Minimap Button ==--
RECIPEBOOK_MMTXT = "|cffffff00Recipe Book|r:\n|cff00ff00Левый клик|r что бы включить/выключить окно выбора Навыка\n|cff00ff00Правый клик|r что бы выбрать другое окошко";
RECIPEBOOK_MM_MENUTITLE = "Выбрать окно:";
RECIPEBOOK_MM_SHARETITLE = "Обмениваемые данные";
RECIPEBOOK_MM_SHARESUBTITLE = "Для цели:";
RECIPEBOOK_MM_HIDE = "Спрятать кнопку на Миникарте";


-----------------------[[ Informational Messages ]]-----------------
RECIPEBOOK_ERR_NOTRADESKILLOPEN = "Сейчас окно профессии не открыто. Попробуйте сначала открыть окно профессии перед тем как начинать сканирование";
RECIPEBOOK_INFO_SCANNINGTRADESKILL = "Обновление данных реагентов и профессий.  Пожалуйста подождите несколько секунд...";
RECIPEBOOK_INFO_RESCANNINGTRADESKILL = "...еще сканируем. Это обычна значит что новых данных слишко много. Пожалуйста будьте терпеливыми...";
RECIPEBOOK_ERR_TRADESKILLNOTSCANNED = "Некоторые данные профессий еще не доступны.\nМожет ли RecipeBook попробовать перезагрузить их?\n(* ваш Интерфейс может лагать*)";
RECIPEBOOK_INFO_SCANCOMPLETED = "Все вещи и реагенты были сохранены для %s профессии %s.  Можете закрывать окно профессии.";
RECIPEBOOK_TEXT_ITEMDISCONNECTED = "RecipeBook нашел вещь с неверным ИД в базе данных, который вызвал отключение. Аддон больше не будет пробовать посылать запросы на сервер за этой вещью пока вы не найдете этой вещи в игре. Пожалуйста выбирите  'ПОДТВЕРДИТЬ' что бы продолжить с созданием. Если повторяется часто, удалите файл SavedVariables в папке ВТФ и перезайдите в игру.";


-----------------------[[ RecipeBook DB Error Messages ]]-----------------
RECIPEBOOK_DBERROR_NOSKILLID = "Не найдено професии";
RECIPEBOOK_DBERROR_NODIFFID = "Не правильный ИД";
RECIPEBOOK_DBERROR_NOSPECID = "Нет специализации";

RECIPEBOOK_NEWVERSION = "Данная версия RecipeBook не поддерживает предыдущие версии. Вам нужно обновить все."
