--[[ RECIPE BOOK AUCTIONS : 
Contains most of the functions used for dealing with the auction house and merchants

]]--
--============================== VARIABLES ==============================--
RBAuction = {};
--============================== FUNCTIONS ==============================--
--[[ HookAuctionFunctions() --> AH functions are not hooked until the AH is in use; this seems to avoid some compatibility problems. ]]--
function RBAuction:HookAuctionFunctions()
	if RecipeBook.Parms.AddOnsLoaded["Auction House"] then return end; -- No duplicating.

	hooksecurefunc("AuctionFrameItem_OnEnter", RecipeBook_DefaultHook)
	hooksecurefunc("AuctionFrameBrowse_Update", RBAuction.AuctionFrameBrowse_Update);

	if IsAddOnLoaded("AuctionFilterPlus") and not RecipeBook.Parms.AddOnsLoaded["AuctionFilterPlus"] then
		-- This may need to be reworked depending on how I'm doing hooks.
		if afp_AuctionFrameBrowse_Update ~= nil then
			RBAuction_OldAFPAuctionFrameBrowse_Update = afp_AuctionFrameBrowse_Update;
			afp_AuctionFrameBrowse_Update = RBAuction.AuctionFrameBrowse_Update;
			RecipeBook.Parms.AddOnsLoaded["AuctionFilterPlus"] = true;
		end
	end

	RecipeBook.Parms.AddOnsLoaded["Auction House"] = true;
	-- this:UnregisterEvent("AUCTION_HOUSE_SHOW");  -- Only runs once.
end

--[[ MerchantFrame_UpdateMerchantInfo() --> When a merchant frame is opened, colors items ]]--
function RBAuction:MerchantFrame_UpdateMerchantInfo()
	if not RBOptions:GetOption("AucC", "Show") then return end;
    local total = GetMerchantNumItems() +1;
	local valid, skill, aknow, alearn, ahave, banked, rank, spec, fac, reput, makes, use, link;
	for i=1, MERCHANT_ITEMS_PER_PAGE, 1 do
	    local j = (((MerchantFrame.page - 1) * MERCHANT_ITEMS_PER_PAGE) + i);
	    if j < total then
	        link = GetMerchantItemLink(j);
	        valid, skill, id = RecipeBook:ParseItemLink(link);
			if valid then -- this is a recipe.
				RecipeBookTooltip:SetMerchantItem(j);
	            rank, spec, rep, honor, makes = RecipeBook:GetSkillInfo(RecipeBookTooltip, skill);
				makes, rid = RBDB:Item_TextToDB(makes);
				if rank then
					banked = RBDB:GetItemIsBanked(RBDB:Link_TextToDB(link));
					if banked and RBOptions:GetOption("Bank", "Show") then -- Blackout banked recipes.
					    r,g,b = RBAuction:BankedColor(banked);
					else
						local known = RBDB:GetKnownInfo(makes, skill, rid);
						aknow, alearn, ahave = RecipeBook:MatchRecipeData(makes, skill, rank, spec, rep, honor, known);
						r,g,b = RBAuction:IconColor(aknow, alearn, ahave, RecipeBook.Globals.Player)
					end
					local but = getglobal("MerchantItem"..i.."ItemButton");
					SetItemButtonTextureVertexColor(but, r,g,b);
					SetItemButtonNormalTextureVertexColor(but, r,g,b);
				end
			end
	    end
	end
end

--[ AuctionFrameBrowse_Update : Colors Auction items. ]--
function RBAuction:AuctionFrameBrowse_Update()
	-- Exit if not coloring auctions.
 	if not RBOptions:GetOption("AucC", "Show") then return end;
	-- If Auctioneer is scanning then don't color code.
	if IsAddOnLoaded("Auctioneer") and Auctioneer.ScanManager.IsScanning() then return end;
	if RecipeBook.Parms.AddOnsLoaded["Auc-Advanced"]then
		if AucAdvanced.Settings.GetSetting("util.compactui.activated") then
			RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] = true;
		else
			RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] = false;
		end
		if AucAdvanced.Scan.IsScanning() then return end;
	end

	-- AuctionFilter Plus is not compatible with AucAdvanced; don't try to run them together.
	if (RecipeBook.Parms.AddOnsLoaded["AuctionFilterPlus"]) and not RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] then
		RBAuction_OldAFPAuctionFrameBrowse_Update();
	end

	local offset = FauxScrollFrame_GetOffset(BrowseScrollFrame);
	local valid, skill;
	local aknow, alearn, ahave, banked, who;
	local rank, spec, rep, honor, makes, link, item;
	local trueID = 0;

	for i=1, NUM_BROWSE_TO_DISPLAY, 1 do
		local button = getglobal("BrowseButton"..i);
		if not button then RecipeBook_Debug("Button does not exist for index :"..i) end;

		-- AuctionFilter Plus compatibility
		if (RecipeBook.Parms.AddOnsLoaded["AuctionFilterPlus"]) and next(afp_BrowseList) ~= nil and (afp_BrowseList[i] ~= nil) then
   			offset = afp_BrowseList[i];
		end
		-- Auctioneer Compatibility
		if RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] and button:IsVisible() then
			RecipeBook:Debug("CompactUI loaded, getting ID");
		    trueID = button.id;
		else
			trueID = button:GetID() + offset;
			RecipeBook:Debug("Getting ID for button: "..trueID);
		end
		if not trueID then RecipeBook:Debug("No ID for index: "..i) end;
		link = GetAuctionItemLink("list", trueID);
		valid, skill, item = RecipeBook:ParseItemLink(link);
		if valid then -- this is a recipe.
			RecipeBookTooltip:SetAuctionItem("list", trueID);
			rank, spec, rep, honor, makes = RecipeBook:GetSkillInfo(RecipeBookTooltip, skill);
			makes, rid = RBDB:Item_TextToDB(makes, skill);
			if rank then
			    if RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] then
					tex = button.Icon;
			    else
					tex = getglobal("BrowseButton"..i.."ItemIconTexture");
				end
			    if tex then
					banked = RBDB:GetItemIsBanked(RBDB:Link_TextToDB(link));
					if banked and RBOptions:GetOption("Bank", "Show") then -- Blackout banked recipes.
						tex:SetVertexColor(unpack(RBOptions:GetOption("AucC", "B")));
					else
						local known = RBDB:GetKnownInfo(makes, skill, rid);
						aknow, alearn, ahave = RecipeBook:MatchRecipeData(makes, skill, rank, spec, rep, honor, known);
						tex:SetVertexColor(RBAuction:IconColor(aknow, alearn, ahave, RecipeBook.Globals.Player));
					end
				end
			end
		elseif RecipeBook.Parms.AddOnsLoaded["Auctioneer CompactUI"] and button:IsVisible() then
		    button.Icon:SetVertexColor(1,1,1);
		end
	end
end

--[[ IconColor(aknow, alearn, ahave, use) --> sets up the color of an icon based on known info
	Returns: r, g, b ]]--
function RBAuction:IconColor(aknow, alearn, ahave, who)
	RecipeBook:Debug("Running IconColor for: "..who);
	
	local i,v;
	local r,g,b;
	local shared = RBOptions:GetOption("AucC", "Shared");
	
	if alearn and next(alearn) then -- A listed alt can currently learn this recipe
		RecipeBook:Debug("Running Can Learn");
		for i, v in ipairs(alearn) do -- {who, color}
			if v[1] == who then -- This player can learn this recipe.  Return color coding.
				RecipeBook:Debug("You Can Learn.");
	        	return 1,1,1;
			else -- Someone else can learn the recipe.
				local fac;
				if v[3] then fac = v[3] else fac = RBDB:GetPlayerFaction(v[1]) end;
				RecipeBook:Debug("Fac: "..fac);
				if fac and (math.fmod(fac, 10) > 0) and shared then -- Shared info, coloring for shared info.  Return color coding.
					r,g,b = unpack(RBOptions:GetOption("AucC", "AC"));
					return r,g,b;
				elseif fac and math.fmod(fac, 10) == 0 then -- Personal info.  Return color coding.
					r,g,b = unpack(RBOptions:GetOption("AucC", "AC"));
					return r,g,b;
				end
			end
		end
		return RBAuction:IconColor(aknow, {}, ahave, who); -- No valid color coding.  Blank aLearn and rerun.
	elseif ahave and next(ahave) then -- A listed alt will be able to learn this recipe.
		RecipeBook:Debug("Running Will Learn");
		for i, v in ipairs(ahave) do -- {who, color}
			if v[1] == who then -- This player will be able to learn this recipe.  Return color coding.
				RecipeBook:Debug("You Will Learn.");
	        	r,g,b = unpack(RBOptions:GetOption("AucC", "MW"));
	        	return r,g,b;
			else -- Someone else will be able to learn the recipe.
				local fac;
				if v[3] then fac = v[3] else fac = RBDB:GetPlayerFaction(v[1]) end;
				if fac and (math.fmod(fac, 10) > 0) and shared then -- Shared info, coloring for shared info.  Return color coding.
					r,g,b = unpack(RBOptions:GetOption("AucC", "AW"));
					return r,g,b;
				elseif fac and math.fmod(fac, 10) == 0 then -- Personal info.  Return color coding.
					r,g,b = unpack(RBOptions:GetOption("AucC", "AW"));
					return r,g,b;
				end
			end
		end
		return RBAuction:IconColor(aknow, alearn, {}, who); -- No valid color coding.  Blank aHave and rerun.
	elseif know and next(aknow) then -- A listed alt will be able to learn this recipe.
		RecipeBook:Debug("Everyone knows this recipe.");
		for i, v in ipairs(aknow) do -- {who, color}
			local fac;
			if v[3] then fac = v[3] else fac = RBDB:GetPlayerFaction(v[1]) end;
			if fac and (math.fmod(fac, 10) > 0) and shared then -- Shared info, coloring for shared info.  Return color coding.
				r,g,b = unpack(RBOptions:GetOption("AucC", "AK"));
				return r,g,b;
			elseif fac and math.fmod(fac, 10) == 0 then -- Personal info.  Return color coding.
				r,g,b = unpack(RBOptions:GetOption("AucC", "AK"));
				return r,g,b;
			end
		end 
		-- This is the end of the line.  No data if all we have is shared data.
		r,g,b = unpack(RBOptions:GetOption("AucC", "OC"));
		return r,g,b;
	else -- No alts know or can learn this recipe.
		RecipeBook:Debug("Nobody has data");
		r,g,b = unpack(RBOptions:GetOption("AucC", "OC"));
		return r,g,b;
	end
end

--[[ BankedColor(banked) --> banked recipes override any other preference.
	Returns: r,g,b or false ]]--
function RBAuction:BankedColor(banked)
	if banked and RBOptions:GetOption("Bank", "Show") then -- Blackout banked recipes.
		r,g,b = unpack(RBOptions:GetOption("AucC", "B"))
	    return r,g,b;
	else
		return false;
 	end
end
