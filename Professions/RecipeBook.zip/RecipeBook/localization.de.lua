--== AUF DEUTSCH! ==--
if ( GetLocale() == "deDE" ) then

--[[ Status messages ]]--
-- Displays on load
RECIPEBOOK_LOADED = string.format(RECIPEBOOK_VERSION_TEXT.." geladen! Geben Sie "..RB_HEXCOLOR["yellow"].."/recipebook help"..RB_HEXCOLOR["end"].." oder "..RB_HEXCOLOR["yellow"].."/rbk help"..RB_HEXCOLOR["end"].." f\195\188r eine Erkl\195\164rung der Text-Optionen, oder "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." f\195\188r ein grafisches Konfigurationsfenster ein.");
-- Help file
RECIPEBOOK_HELP = {
	RB_HEXCOLOR["green"].."Benutzung:"..RB_HEXCOLOR["end"].." "..RB_HEXCOLOR["yellow"].."/recipebook config"..RB_HEXCOLOR["end"].." oder "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." eingeben um ein grafisches Konfigurationsfenster zu \195\182ffnen. Die folgenen Text-Optionen sind dar\195\188ber hinaus noch verf\195\188gbar: ",
	"   "..RB_HEXCOLOR["yellow"].."help"..RB_HEXCOLOR["end"].." : Zeigt diese Hilfe.",
	"   "..RB_HEXCOLOR["yellow"].."on|off"..RB_HEXCOLOR["end"].." : Anzeige von RecipeBook Daten ein- (on) oder ausschalten (off).",
	"   "..RB_HEXCOLOR["yellow"].."config"..RB_HEXCOLOR["end"].." : \195\182ffnet das grafische Konfigurationsfenster.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."send [<alt>] to <person>"..RB_HEXCOLOR["end"].." : Sendet deine RecipeBook Daten [f\195\188r einen speziellen Charakter] an die angegebene Person. Benutzen Sie 'guild' um ein gildenweites Update zu veranlassen. Bei Benutzung von 'me' werden nur die Daten des aktuellen Charakter \195\188bertragen.",
	"   "..RB_HEXCOLOR["yellow"].."update from <person>"..RB_HEXCOLOR["end"].." : Requests a RecipeBook update from another character.  Only works if you have RecipeBook data already stored for that character.",
	"   "..RB_HEXCOLOR["yellow"].."share"..RB_HEXCOLOR["end"].." : Zeigt die Datenaustausch- und Aktualisierungskonfiguration.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."skill"..RB_HEXCOLOR["end"].." : Zeigt die momentan bekannten Rezepte und Berufe eines Charakters.",
	"   "..RB_HEXCOLOR["yellow"].."search <Suchbegriff>"..RB_HEXCOLOR["end"].." : Sucht in der RecipeBook Datenbank nach Gegenst\195\164nden die den Suchbegriff enthalten.",
	"   "..RB_HEXCOLOR["yellow"].."searchmats <Suchbegriff>"..RB_HEXCOLOR["end"].." : Funktioniert wie /rbk search, sucht aber nach Materialien.",
	"   ",
	"   "..RB_HEXCOLOR["yellow"].."bank"..RB_HEXCOLOR["end"].." : Zeigt das RecipeBook Bank Fenster.",
	"   ",
	};
RECIPEBOOK_ERR_BADARG		= "Leider ist der Befehl '%s' unbekannt. Vielleicht hilft das hier weiter:";
RECIPEBOOK_TXT_SUPPLIES		= "Materialien notwendig f\195\188r ";
RECIPEBOOK_ADDED_SPECIALS	= "Die folgenden Spezialisierungen wurden gefunden und hinzugef\195\188gt: ";

--[[ Data strings for parsing recipes ]]--
-- Whatever "ItemType" is for recipes in your locale
RECIPEBOOK_RECIPEWORD = "Rezept";
RECIPEBOOK_WORD_TRANSMUTE = "Transmutieren";
RECIPEBOOK_TRADESKILLS = {
	["Alchemy"]			= "Alchemie", --1
	["Blacksmithing"]	= "Schmiedekunst", --2
	["Enchanting"]		= "Verzauberkunst", --3
	["Engineering"]		= "Ingenieurskunst", --4
	["Inscription"]		= "Inschriftenkunde", --5
	["Jewelcrafting"]	= "Juwelenschleifen", --6
	["Leatherworking"]	= "Lederverarbeitung", --7
	["Mining"]			= "Bergbau", --8
	["Skinning"]		= "K\195\188rschnerei", --9
	["Tailoring"]		= "Schneiderei", --10
	["Cooking"]			= "Kochkunst", --11
	["First Aid"]		= "Erste Hilfe", --12
	["Fishing"]			= "Angeln", --13
	["Herbalism"]		= "Kr\195\164uterkunde", --14
}

--Specializations
RECIPEBOOK_SPECIALS = {
	["Schmiedekunst"]		= {"R\195\188stungsschmied", "Schwertschmiedemeister","Axtschmiedemeister","Hammerschmiedemeister"},
	["Ingenieurskunst"]		= {"Gobliningenieur","Gnomeningenieur"},
	["Lederverarbeitung"]	= {"Stammeslederverarbeitung","Elementarlederverarbeitung","Drachenlederverarbeitung"},
	["Schneiderei"]			= {"Urmondstoffschneiderei","Zauberstoffschneiderei","Schattenstoffschneiderei"},
	["Alchemie"]			= {"Meister der Transmutation","Meister der Elixiere","Meister der Tr\195\164nke"},
};
-- Subspecializations
RECIPEBOOK_SUBSPECIALS = {
	["Blacksmithing"]	= {"Schwertschmiedemeister", "Axtschmiedemeister", "Hammerschmiedemeister"},
};

--[[ Regex parsed items; these may need adjustment for your language. ]]--
RECIPEBOOK_CHAT_SKILLUP = gsub(gsub(ERR_SKILL_UP_SI, "%%1%$s", "(%%w)*"), "%%2%$d", "(%%d+)%%");
RECIPEBOOK_REGEX_SKILL = string.gsub(string.gsub(string.gsub(ITEM_MIN_SKILL, "%%%d%$", "%%"), "%%s", "%(%[^%%s%]+%)"), "%(%%d%)", "%%%(%(%%d+%)%%%)");
RECIPEBOOK_REGEX_SPECIALTY = string.gsub(string.gsub(ITEM_REQ_SKILL, "%%%d%$", "%%"), "%%s", "%(%[^%%s%]+%)" );
RECIPEBOOK_REGEX_REPUTATION = string.gsub(string.gsub(ITEM_REQ_REPUTATION, "%-", "%%%-"), "%%s", "%(%[%%w %]+%)" );
RECIPEBOOK_REGEX_NOTONLINE = string.gsub(ERR_CHAT_PLAYER_NOT_FOUND_S, "%%s", "%(%%w+%)");
RECIPEBOOK_REGEX_UNLEARNSKILL = string.gsub(ERR_SPELL_UNLEARNED_S, "%%s", "(%%w+)");
-- RECIPEBOOK_REGEX_LEARNRECIPE = string.gsub(ERR_LEARN_RECIPE_S, "%%s", "%(%[%%w%%s%]+%)");
-- RECIPEBOOK_REGEX_LEARNSPELL = string.gsub(ERR_LEARN_SPELL_S, "%%s", "%(%[%%w%%s%]+%)");
-- RECIPEBOOK_REGEX_ONLINE = string.gsub(string.gsub(string.gsub(ERR_FRIEND_ONLINE_SS, "%]", "%%%]"), "%[", "%%%["), "%%s", "%(%[%%w%]+%)");
	-- local a = string.find(LOOT_ITEM_PUSHED_SELF, "%s", 1, true);
-- RECIPEBOOK_REGEX_GETITEM = string.sub(LOOT_ITEM_PUSHED_SELF, 1, a-1);


--[[ Output prefixes ]]--
--== Chatframe Output ==--
RECIPEBOOK_CHATFRAME_KNOWNBY		= " wird bereits beherrscht von: ";
RECIPEBOOK_CHATFRAME_NONEKNOWN		= " ist noch keinem eurer Charakter bekannt.";
RECIPEBOOK_CHATFRAME_CANLEARN		= " kann gelernt werden von: ";
RECIPEBOOK_CHATFRAME_NONELEARN		= " kann von keinem eurer Charakter gelernt werden.";
RECIPEBOOK_CHATFRAME_WILLLEARN		= " kann sp\195\164ter gelernt werden von (momentane Fertigkeitsstufe): ";
RECIPEBOOK_CHATFRAME_NONEWILLLEARN	= " kann von keinem eurer Charakter gelernt werden, selbst wenn diese ein h\195\182heres Fertigkeitsstufe erreichen";
RECIPEBOOK_CHATFRAME_BANKED			= " ist in der Bank von: ";
RECIPEBOOK_CHATFRAME_NOTBANKED		= " ist nicht 'auf der Bank'.";
RECIPEBOOK_CHATFRAME_CANMAKE		= " kann hergestellt werden von: ";

--== Tooltip Output ==--
-- RECIPEBOOK_TOOLTIPPREFIX = "\194\183";
RECIPEBOOK_KNOWNBY		= "Wird bereits beherrscht von: ";
RECIPEBOOK_CANLEARN		= "Kann gelernt werden von: ";
RECIPEBOOK_WILLLEARN	= "Kann sp\195\164ter gelernt werden von: ";
RECIPEBOOK_CANMAKE		= "Kann hergestellt werden von: ";
RECIPEBOOK_ISBANKED		= "In der Bank von: ";
-- RECIPEBOOK_NODATA = RECIPEBOOK_TOOLTIPPREFIX.."Keinem eurer Charakter kennt dieses Rezept oder kann es nutzen." -- For future use
RECIPEBOOK_ERR_DATANOTLOADED = "RecipeBook Daten noch nicht geladen.\nWarten sie ein paar Sekunden und versuchen Sie es erneut.";
RECIPEBOOK_ERR_ITEMDBEMPTY = "RecipeBook has no stored tradeskill data."

--[[ Options display text; name is RBOPTIONS_(option)_(suboption) ]]--
RBOPTIONS_STATUS = "Anzeige von RecipeBook Daten: %s (Datensammlung ist immer an). Geben Sie "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"].." (oder "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"]..") ein um RecipeBook zu konfigurieren.";
-- Chatframe options display has been outmoded; using GUI instead.  Options default to RBOptions_NotFound
RBOPTIONS_NOTFOUND = "Weitere Einstellungen k\195\182nnen in einem grafischen Konfigurationsfenster manipuliert werden "..RB_HEXCOLOR["yellow"].."/rbk config"..RB_HEXCOLOR["end"];
-- Cn/off colored text
RBOPTIONS_ON	= RB_HEXCOLOR["green"].."An"..RB_HEXCOLOR["end"];
RBOPTIONS_OFF	= RB_HEXCOLOR["red"].."Aus"..RB_HEXCOLOR["end"];

--== RBOutput_Print() ==--
RECIPEBOOK_ERROR_PREFIX	= "|cffffff00<|cffff0000RecipeBook Fehler|cffffff00>|r ";
RECIPEBOOK_PREFIX		= "|cffffff00<RecipeBook>|r ";


--========================[[ Configuration Screens ]]============================--
---------------------------------- Main Frame and Subframe Tabs  -------------------------------------------
RECIPEBOOK_SFTAB_SEARCH		= "Suchen";
RECIPEBOOK_SFTAB_BROWSE		= "Durchbl\195\164tern";
RECIPEBOOK_SFTAB_OPTIONS	= "Einstellungen";
RECIPEBOOK_SFTAB_SHARING	= "Datenaustausch";
RECIPEBOOK_SFTAB_BANKING	= "In der Bank";
RECIPEBOOK_SFTAB_COLORS		= "Farben";
RECIPEBOOK_SFSUBTAB_AA		= "immer annehmen";
RECIPEBOOK_SFSUBTAB_AD		= "immer ablehnen";
RECIPEBOOK_SFSUBTAB_AU		= "Auto-Update";

---------------------------------- Main Frame and Subframe Buttons -------------------------------------------
RECIPEBOOK_CFG_B_MAKEDEFAULT = "Als Standard";

--------------------------------- Search Panel  (tab 1) -------------------------------------------
RECIPEBOOK_SFTITLE_SEARCH = "Suche nach Rezepten/Materialien";
-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_KNOWNS	= "  Einem Charakter bekannt";
RECIPEBOOK_TEMPLATE_KNOWNM	= "  %d Charaktern bekannt";
-- Single/plural versions of this template
RECIPEBOOK_TEMPLATE_HAVES		= " (ein weiterer hat %s)";
RECIPEBOOK_TEMPLATE_HAVEM		= " (%d weitere haben %s)";
RECIPEBOOK_TXT_KNOWNBY			= "Beherrscht von (Fertigkeitsstufe): ";
RECIPEBOOK_TXT_HASKILL			= "Hat %s (Fertigkeitsstufe): ";
RECIPEBOOK_TXT_NOKNOWNBY		= "Keinem Charakter bekannt";
RECIPEBOOK_TEMPLATE_KNOWNMATS	= "  Ben\195\182tigt: ";
RECIPEBOOK_CBX_SEARCHITEMS		= "Suche nach bekannten Rezepten";
RECIPEBOOK_CBX_TT_SEARCHITEMS	= "Ausw\195\164hlen um nach Gegenst\195\164nden zu suchen die den Suchbegriff enthalten.";
RECIPEBOOK_CBX_SEARCHMATS		= "Suche nach Materialien";
RECIPEBOOK_CBX_TT_SEARCHMATS	= "Ausw\195\164hlen um nach Gegenst\195\164nden welche Materialien ben\195\182tigen, die den Suchbegriff enthalten.";
RECIPEBOOK_CBX_SEARCHEXACT		= "Suche nur nach dem exakten Ausdruck";
RECIPEBOOK_CBX_TT_SEARCHEXACT	= "Wenn dies nicht ausw\195\164hlt ist, werden alle W\195\182rter gefunden die den Suchbegriff enthalten (z.B. \"Wei\195\159e Maske\" w\195\188rde Wei\195\159e Banditen Maske finden).  Wenn dies ausw\195\164hlt ist, wird nur nach einer exakten \195\156bereinstimmung gesucht.";
RECIPEBOOK_CBX_SEARCHBOOSTS		= "Nur Gegenst\195\164nde, die einen Charakter verbessern";
RECIPEBOOK_CBX_TT_SEARCHBOOSTS	= "Zeigt nur Gegenst\195\164nde die das Potential bieten einen Charakter verbessern (gr\195\188n, gelb, oder orange)";
RECIPEBOOK_ERR_NOSEARCHRESULT	= RB_HEXCOLOR["red"].."Keine Ergebnisse f\195\188r ihre Suche"..RB_HEXCOLOR["end"];

--------------------------------- Skill Browse Panel (tab 2) -------------------------------------------
RECIPEBOOK_SFTITLE_SKILL		= "Alle bekannten Berufe durchbl\195\164tern";
RECIPEBOOK_BROWSE_FS_NOSPEC		= "keine Spezialisierung";
RECIPEBOOK_BROWSE_FS_NODATA		= "keine Daten";
RECIPEBOOK_BROWSE_FS_NOTRACKED	= "nicht verfolgt";
RECIPEBOOK_BROWSE_FS_NODATE		= "Kein Datum";

RECIPEBOOK_BROWSE_FS_CLICK			= "[hier klicken zum \195\164ndern]";
RECIPEBOOK_BROWSE_BUT_SHOW			= "zeigen";
RECIPEBOOK_BROWSE_FS_SHARED			= "Datenaustausch";
RECIPEBOOK_BROWSE_FS_PERSONAL		= "pers\195\182nlich";
RECIPEBOOK_BROWSE_FS_NOTRADESKILL	= "keinen Beruf gefunden";

RECIPEBOOK_BROWSE_FS_SEARCH = "Suchbegriff eingeben";

RECIPEBOOK_BROWSE_FS_ITEM				= "Gegenstand";
RECIPEBOOK_BROWSE_FS_RECIPE				= "Rezept erzeugt";
RECIPEBOOK_BROWSE_FS_INFOITEMLEVEL		= "Stufe";
RECIPEBOOK_BROWSE_FS_INFOMINIMUMLEVEL	= "Stufe";

RECIPEBOOK_BROWSE_DD_SORTALPHA	= "Alphabetisch";
RECIPEBOOK_BROWSE_DD_SORTDIFF	= "Fertigkeitsstufe";
RECIPEBOOK_BROWSE_DD_SORTILVL	= "Gegenstandsstufe";
RECIPEBOOK_BROWSE_DD_SORTMLVL	= "min ben\195\182tigte Stufe";
RECIPEBOOK_BROWSE_DD_SORTITYPE	= "Typ/Ort";

RECIPEBOOK_CFG_CBX_SU		= "zeige alle Gegenst\195\164nde";
RECIPEBOOK_CFG_MOUSEOVER_SU	= "Show items that are in the RecipeBook database for the selected skill, but which the current character does not know.";
--------------------------------- Skill Tracking Subframe -------------------------------------------
RECIPEBOOK_BROWSE_TT_APPLY				= "Wendet alle Ver\195\164nderungen an, l\195\182scht Daten f\195\188r nicht verfolgte Berufe.";
RECIPEBOOK_BROWSE_TT_RESET				= "Verwirft alle \195\132nderungen.";
RECIPEBOOK_BROWSE_TT_SHOW				= "Abw\195\164hlen um Daten zu verwerfen (verhindert das Rezepte aus diesem Beruf als 'lernbar' or 'sp\195\164ter lernbar' angezeigt werden)"
RECIPEBOOK_BROWSE_TT_DEFAULTS			= "Setzt alle Berufseinstellungen zur\195\188ck und wendet diese Ver\195\164nderungen sofort an.";
RECIPEBOOK_BROWSE_FS_TRACKED			= "Verfolgte Berufe";
RECIPEBOOK_BROWSE_TT_TRACKED			= "Modifiziert Berufseinstellungen f\195\188r diesen Character."
RECIPEBOOK_BROWSE_TT_REFRESH			= "Dieses Fenster neu laden.";
RECIPEBOOK_BROWSE_TT_DELETE				= "L\195\182scht alle Daten f\195\188r diesen Charakter.";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDHEADER	= "nicht zwischengespeicherter Gegenstand:";
RECIPEBOOK_BROWSE_TT_UNCONFIRMEDITEM	= {
	"Dieser Gegenstand konnte nicht sicher abgefragt werden.",
	"Dadurch ist dieser Gegenstand nicht sicher. Um ihn zu betrachten ohne m\195\182glicherweise vom Server getrennt zu werden, m\195\188ssen Sie ihn erst in der Spielwelt sehen. Diese Beschr\195\164nkung wird von Blizzard seit Patch 1.10 durchgesetzt.",
	"Klicken Sie den Gegenstand um ihn vom Server abzufragen. Sie werden vielleicht vom Server getrennt."
};
--------------------------------- Sharing Panel (tab 3) -------------------------------------------
RECIPEBOOK_SFTITLE_SHARING			= "Datenaustausch";
RECIPEBOOK_CFG_HEADER_SHARING		= "Daten anderer Spieler";
RECIPEBOOK_CFG_FS_SHARECATEGORIES	= "zeige Rezepte: ";
RECIPEBOOK_CFG_CBX_SL = "Store Linked Recipes";
RECIPEBOOK_CFG_MOUSEOVER_SL = "Store tradeskill data from gold [Tradeskill] links when opened.";
RECIPEBOOK_CFG_CBX_SK				= "bekannt";
RECIPEBOOK_CFG_CBX_SC				= "lernbar";
RECIPEBOOK_CFG_CBX_SW				= "aus bekanntem Beruf";
RECIPEBOOK_CFG_FS_SHAREFACTION		= "zeige getauschte Daten f\195\188r:";
RECIPEBOOK_CFG_CBX_SSF				= "eigene Fraktion";
RECIPEBOOK_CFG_CBX_SOF				= "gegnerische Fraktion";

RECIPEBOOK_CFG_RADIO_CAPTION	= "Bei Austauschsanfragen:"
RECIPEBOOK_CFG_RADIO_HEADER		= "annehmen  ablehnen  fragen"
RECIPEBOOK_CFG_RADIO_FRIENDS	= "Freunde";
RECIPEBOOK_CFG_RADIO_GUILD		= "Gildenmitglieder";
RECIPEBOOK_CFG_RADIO_DEFAULT	= "Standard";

RECIPEBOOK_CFG_HEADER_AUTOUPDATE	= "Auto-Update Konfiguration";
RECIPEBOOK_CFG_FS_AUFREQ			= "sende Auto-Update f\195\188r Daten \195\164lter als:";
RECIPEBOOK_CFG_RADIO_DAY			= "1 Tag";
RECIPEBOOK_CFG_RADIO_WEEK			= "1 Woche";
RECIPEBOOK_CFG_RADIO_NEVER			= "Niemals";
RECIPEBOOK_CFG_FS_AUSOURCE			= "eingehendes Auto-Update akzeptieren von:"
RECIPEBOOK_CFG_CBX_G				= "gildenweiten Update";
RECIPEBOOK_CFG_MOUSEOVER_G			= "eingehendes Auto-Update von Gildenmitgliedern akzeptieren die '/rbk send me to guild' benutzen";
RECIPEBOOK_CFG_CBX_A				= "'immer annehmen'-Liste";
RECIPEBOOK_CFG_MOUSEOVER_A			= "eingehendes Auto-Update akzeptieren wenn der Sender auf ihrer 'immer annehmen'-Liste ist."
RECIPEBOOK_CFG_CBX_GU				= "nach dem Anmelden Auto-Update an die Gilde senden"; -- For future use

RECIPEBOOK_CFG_DDHEADER_UPDATEFROM	= "Auto-update annehmen von:";

--== see below for parser information ==--
--------------------------------- Banking Panel (tab 4) -------------------------------------------
RECIPEBOOK_SFTITLE_BANKING			= "Bank Konfiguration";
RECIPEBOOK_CFG_HEADER_BANKLIST		= "In der Bank auf diesem Server/Fraktion:";
RECIPEBOOK_CFG_HEADER_BANKOPTIONS	= "Bank Einstellungen:";
RECIPEBOOK_CFG_CBX_B				= "zeige Bankstatus";
RECIPEBOOK_CFG_CBX_BT				= "zeige Bankbewegungs-Anzeigen im Chat";
RECIPEBOOK_CFG_FS_AUTOBANK			= "Rezepte 'in der Bank' automatisch verfolgen f\195\188r:";
RECIPEBOOK_CFG_CBX_BK				= "ihre Bank";
RECIPEBOOK_CFG_CBX_BG				= "ihre Taschen";
RECIPEBOOK_CFG_TT_UNBANK			= "L\195\182scht diesen Gegenstand aus der 'in der Bank'-Liste dieses Charakters";

--== Chatframe Banking Messages ==--
RECIPEBOOK_AUTOHELD					= "'in der Bank'-Liste hinzugef\195\188gt: ";
RECIPEBOOK_AUTOUNHELDSUCCEED		= "aus 'in der Bank'-Liste entfernt: %s";
RECIPEBOOK_AUTOUNHELDFAIL			= "%s hat %s nicht in der Bank.";
RECIPEBOOK_INFO_CANLEARNONSKILLUP	= "Es ist ihnen nun m\195\182glich %s, aus der Bank von %s zu lernen.";

--------------------------------- Options Panel (tab 5) -------------------------------------------
RECIPEBOOK_SFTITLE_OPTIONS		= "RecipeBook Einstellungen";
RECIPEBOOK_CFG_FS_SELECTFACTION	= "Verfolgte Fraktionen (global)"; -- Header for player selection menu
RECIPEBOOK_CFG_CBX_S			= "zeige RecipeBook Ausgaben";
RECIPEBOOK_CFG_CBX_MM			= "zeige Minimap Button";
RECIPEBOOK_CFG_CBX_DM			= "zeige aktuellen Character";
RECIPEBOOK_CFG_CBX_I			= "zeige informative (nicht-Fehler) Nachrichten";
RECIPEBOOK_CFG_MOUSEOVER_I 		= "Abw\195\164hlen um informative Nachrichten \195\188ber den Verarbeitungsstatus oder '/rbk send' zu unterdr\195\188cken.";
RECIPEBOOK_CFG_CBX_C 			= "L\195\182scht alle Rezepte die keinem Charakter bekannt sind.";
RECIPEBOOK_CFG_MOUSEOVER_C 		= "Wenn dies nicht ausgew\195\164hlt ist verbleiben auch Rezepte in der Datenbank, die keinem Charakter bekannt sind. W\195\164hlen Sie dies aus, wenn Sie diese Rezepte l\195\182schen wollen, was die Datenbank kleiner und damit schneller h\195\164lt aber dann k\195\182nnen Sie nur nach Gegenst\195\164nden suchen die ein bekannter Charakter herstellen kann.";
RECIPEBOOK_CFG_FS_OUTPUT		= "gebe Informationen aus im:";
RECIPEBOOK_CFG_CBX_OT			= "ToolTip";
RECIPEBOOK_CFG_CBX_OC			= "RecipeBook Chatfenster";
RECIPEBOOK_CFG_FS_CATEGORIES	= "zeige Rezepte:";
RECIPEBOOK_CFG_CBX_AK			= "bereits bekannt";
RECIPEBOOK_CFG_CBX_AC			= "lernbar";
RECIPEBOOK_CFG_CBX_AW			= "sp\195\164ter lernbar";
RECIPEBOOK_CFG_FS_CANMAKE		= "zeige Gegenst\195\164nde die gemacht werden von:";
RECIPEBOOK_CFG_CBX_AM			= "eigenen Charakteren";
RECIPEBOOK_CFG_CBX_SM			= "Characteren anderer Spieler";
RECIPEBOOK_CFG_FS_FACTION		= "zeige Daten f\195\188r:";
RECIPEBOOK_CFG_CBX_ASF			= "eigene Fraktion";
RECIPEBOOK_CFG_CBX_AOF			= "gegnerische Fraktion";
RECIPEBOOK_CFG_CBX_TM			= "sammle RecipeBook Daten f\195\188r diesen Character";

RECIPEBOOK_CFG_FS_AUCTION	= "bei Auktionen und H\195\164ndlern";
RECIPEBOOK_CFG_CBX_ACS		= "farbliche Hinterlegungen";
RECIPEBOOK_CFG_CBX_ABS		= "Rezepte die in der Bank sind schw\195\164rzen";
RECIPEBOOK_CFG_CBX_ASC = "Color-code shared data";
RECIPEBOOK_CFG_MOUSEOVER_SC = "Check this if you want RecipeBook to consider shared data as well as personal data when color-coding at the Auction House and merchants.";

--------------------------------- Colors Panel (tab 6) -------------------------------------------
RECIPEBOOK_SFTITLE_COLORS = "Color-coding Options";

-- Auction Frame: --
RECIPEBOOK_CFG_FS_AUCTIONCOLOR = "Auction House Color Coding (click on the icon to change)";
RECIPEBOOK_CFG_SW_AAC = "Farbe f\195\188r Rezepte die von einem bekannten Charakter gelernt werden k\195\182nnen (exklusive dieses Charakters).";
RECIPEBOOK_CFG_SW_AAW = "Farbe f\195\188r Rezepte die sp\195\164ter von einem bekannten Charakter gelernt werden k\195\182nnen (inklusive dieses Charakters).";
RECIPEBOOK_CFG_SW_AMW = "Farbe f\195\188r Rezepte die sp\195\164ter von diesem Charakter gelernt werden k\195\182nnen.";
RECIPEBOOK_CFG_SW_AOC = "Farbe f\195\188r Rezepte die keine bekannten Charaktere lernen werden k\195\182nnen.";
RECIPEBOOK_CFG_SW_AAK = "Farbe f\195\188r Rezepte die allen bekannten Charakteren mit diesem Beruf bekannt sind.";
-- Tooltip Options: --
RECIPEBOOK_CFG_FS_TOOLTIPCOLOR = "Tooltip Text Color Coding (click the color square to change)";
-- Tooltip: Alt Names -- 
RECIPEBOOK_CFG_FS_ALTS = "Names of alts";
RECIPEBOOK_CFG_SW_TASF = "Same faction"; --Alts/same faction
RECIPEBOOK_CFG_SW_TAOF = "Opposing faction"; --Alts/other faction
RECIPEBOOK_CFG_FS_SHARED = "Names of shared characters";
RECIPEBOOK_CFG_SW_TSSF = "This faction"; --Shared/same faction
RECIPEBOOK_CFG_SW_TSOF = "Opposing faction"; --Shared/other faction
-- Tooltip: Recipe colors --
RECIPEBOOK_CFG_FS_RECIPES = "Recipe Information";
RECIPEBOOK_CFG_SW_TK = '"Known by:" text' ; -- Known
RECIPEBOOK_CFG_SW_TC = '"Can be learned by:" text'; -- Can learn
RECIPEBOOK_CFG_SW_TW = '"Will be learnable by:" text'; -- Will learn
RECIPEBOOK_CFG_SW_TB = '"Banked by:" text'; -- Banked
RECIPEBOOK_CFG_SW_TM = '"Can be made by:" text'; -- Can Make

-----------------------------------------------------------------------------------------------------------------------------

RECIPEBOOK_SHARE_USAGE = RB_HEXCOLOR["red"].."Achtung: Dies hat sich ver\195\164ndert! "..RB_HEXCOLOR["end"].."Benutzung: "..RB_HEXCOLOR["yellow"].."/rbk send [<alt>] to <person>"..RB_HEXCOLOR["end"].." : Sendet deine RecipeBook Daten [f\195\188r einen speziellen Charakter] an die angegebene Person. Benutzen Sie 'guild' um ein gildenweites Update zu veranlassen. Bei Benutzung von 'me' werden nur die Daten des aktuellen Charakter \195\188bertragen.";
RECIPEBOOK_UPDATE_USAGE = "Usage: "..RB_HEXCOLOR["yellow"].."/rbk update from <person>"..RB_HEXCOLOR["end"]..".  You must already have data from that person to request an update.";
--== RB Share User Notifications ==--
RECIPEBOOK_SHARERROR_NOCOMPLETE		= "Kann RecipeBook Datenaustausch nicht abschlie\195\159en (begonnen von %s, Beruf %s des Charakters %s): ";
RECIPEBOOK_SHARERROR_NOTRACKED		= "%s f\195\188r %s wird nicht verfolgt.";
RECIPEBOOK_SHARERROR_CANCEL			= "Datenaustausch abgebrochen."
RECIPEBOOK_SHARERROR_VERSION		= "Inkompatible RecipeBook Version. Es wird mindestens Version ".. table.concat(RECIPEBOOK_COMPATIBLE, ".") .. " f\195\188r den Datenaustausch ben\195\182tigt.";
RECIPEBOOK_SHARERROR_TIMEOUT		= "Keine verarbeitbaren Daten von %s erhalten bevor das Zeitfenster abgelaufen ist.";
RECIPEBOOK_SHARERROR_AUTODECLINE	= "%s lehnt jeden Datenaustausch von %s ab.";
RECIPEBOOK_SHARERROR_NOTRACKING		= "%s verfolgt den Beruf %s von %s nicht.";
RECIPEBOOK_SHARERROR_MANUALDECLINE	= "%s hat %s's Daten von %s abgelehnt.";
RECIPEBOOK_UPDATERROR_MANUALDECLINE	= "%s hat es abgelehnt neue Daten an %s zu senden.";
RECIPEBOOK_SHARERROR_TIMEOUTDECLINE	= "%s hat das Annahmezeitfenster f\195\188r %s's Daten der %s verstreichen lassen.";
RECIPEBOOK_SHARERROR_SENDSELF		= "Sie k\195\182nnen sich RecipeBook Data nicht selbst senden. Sie haben diese bereits.";
RECIPEBOOK_SHARERROR_NOTINGUILD		= "Sie sind in keiner Gilde.";
RECIPEBOOK_SHARERROR_NOGUILDONLINE	= "Es sind momentan keine Gildenmitglieder online; RecipeBook wird keine Daten senden.";
RECIPEBOOK_ERROR_NOREQUEST			= "Sie haben keine Daten f\195\188r %s in ihrem RecipeBook. Eine Update Anforderung kann nicht get\195\164tigt werden.";
RECIPEBOOK_ERROR_AUTODECLINE		= " m\195\182chte keine RecipeBook Daten akzeptieren f\195\188r ";
RECIPEBOOK_ERROR_DECLINEDSESSION	= "RecipeBook Datenaustausch automatisch abgeleht von ";
RECIPEBOOK_ERROR_ACCEPTEDSESSION	= "RecipeBook Datenaustausch automatisch angenommen von %s f\195\188r %s.";
--== Info messages ==--
RECIPEBOOK_SHAREMSG_INITIATE	= "Versuche %s's Daten der %s an %s zu senden.";
RECIPEBOOK_SHAREMSG_TERMINATE	= "Senden von %s's Daten der %s an %s abgeschlossen.";
RECIPEBOOK_SHAREMSG_RECEIVEDALL	= "Daten f\195\188r %s's %s erfolgreich von %s empfangen.";
--== Popups ==--
RECIPEBOOK_POPUP_BLOCKPLAYER		= "Sie haben RecipeBook Daten von %s abgelehnt. Daten von diesem Charakter immer ablehnen?";
RECIPEBOOK_POPUP_ACCEPTPLAYER		= "Sie haben RecipeBook Daten von %s akzeptiert. Daten von diesem Charakter immer annehmen?";
RECIPEBOOK_POPUP_REQUESTING_SEND	= "%s m\195\182chte ihnen RecipeBook Daten des Character %s senden. Dieser Transfer wird in %d %s automatisch abgebrochen.";
RECIPEBOOK_POPUP_REQUESTING_UPDATE	= "%s hat ein Update ihrer RecipeBook Daten angefordert. W\195\164hlen Sie 'Accept' um das Update zu senden. Diese Anforderung wird in %d %s automatisch abgelehnt.";
RECIPEBOOK_POPUP_ADD_CHARACTER		= "Geben Sie den Namen des Charakters ein, die Sie hinzuf\195\188gen wollen:";
RECIPEBOOK_POPUP_SHARE_TO 			= "Enter the name of the character to exchange RecipeBook data with.";

------------------------------------------------------[[ Minimap Menu, User Menu,  and Key Bindings ]]------------------------------------
--== User Menu ==--
RECIPEBOOK_MENU_MAIN		= "RecipeBook";
RECIPEBOOK_MENU_SHARE		= "Daten senden";
RECIPEBOOK_MENU_REQUEST		= "Update anfordern";
RECIPEBOOK_MENU_SHARESELF	= "sende Daten dieses Charakters";
RECIPEBOOK_MENU_SHAREALL	= "Send Daten f\195\188r alle Charaktere";
--== Key Bindings ==--
BINDING_HEADER_RECIPEBOOK		= "RecipeBook Tasten";
BINDING_NAME_RECIPEBOOK_SKILL	= "Durchbl\195\164tern-Fenster";
BINDING_NAME_RECIPEBOOK_CONFIG	= "Einstellungsfenster";
BINDING_NAME_RECIPEBOOK_SEARCH	= "Suchfenster";
--== Minimap Button ==--
RECIPEBOOK_MMTXT		= "|cffffff00Recipe Book|r:\n|cff00ff00Links-Klick|r um das Durchbl\195\164tern-Fenster anzuzeigen\n|cff00ff00Rechts-Klick|r um ein anderes Fenster zu w\195\164hlen";
RECIPEBOOK_MM_MENUTITLE	= "Fenster ausw\195\164hlen:";
RECIPEBOOK_MM_SHARETITLE = "Shared Data";
RECIPEBOOK_MM_SHARESUBTITLE = "For Target Player:";
RECIPEBOOK_MM_HIDE		= "Minimap Button ausblenden";


-----------------------[[ Informational Messages ]]-----------------
RECIPEBOOK_ERR_NOTRADESKILLOPEN = "No tradeskill is currently open.  Try opening a tradeskill window before attempting to force scan.";
RECIPEBOOK_INFO_SCANNINGTRADESKILL = "Refreshing tradeskill and reagent data.  Please wait a few seconds...";
RECIPEBOOK_INFO_RESCANNINGTRADESKILL = "...still scanning.  This usually means there is a lot of new data.  Please be patient...";
RECIPEBOOK_ERR_TRADESKILLNOTSCANNED	= "Einige Gegenst\195\164nde konnten nicht verarbeitet werden. RecipeBook fehlen vielleicht einige Daten. Neuer Versuch beim n\195\164chsten Update...";
RECIPEBOOK_INFO_SCANCOMPLETED		= "Alle Gegenst\195\164nde und Materialien der %s wurden gespeichert. Es ist OK das Fenster zu schlie\195\159en.";
RECIPEBOOK_TEXT_ITEMDISCONNECTED	= "RecipeBook hat eine falsche Gegenst\195\164nds-ID in der Datenbank, die eine Trennung vom Server verursachte. Es wird nicht weiter auf diese Gegenst\195\164nds-ID zugegriffen, bis Sie von einen angemeldeten Character gesehen wurde. Bitten w\195\164hlen Sie 'OKAY' um fortzufahren. Sollte dies \195\182ffter passieren l\195\182schen Sie ihre 'SavedVariables'-Datei und starten Sie das Spiel neu.";


-----------------------[[ RecipeBook DB Error Messages ]]-----------------
RECIPEBOOK_DBERROR_NOSKILLID	= "Kein Beruf gefunden";
RECIPEBOOK_DBERROR_NODIFFID		= "Falsche Fertigkeitsstufe";
RECIPEBOOK_DBERROR_NOSPECID		= "Keine Spezialisierung";

RECIPEBOOK_NEWVERSION = "Diese RecipeBook Version unterst\195\188tzt die gepeicherten Daten \195\164lterer Versionen nicht mehr. Bitte aktualisieren Sie all ihre pers\195\182nlichen und ihre gespeicherten Berufe von anderen Spielern."

end;
