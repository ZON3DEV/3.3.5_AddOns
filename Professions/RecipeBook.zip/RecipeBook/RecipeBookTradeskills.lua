--[[ RECIPE BOOK TRADESKILLS :
Contains most of the functions used for dealing with collecting and storing personal tradeskill data
See RecipeBookDBFunctions for:
	SetPlayerTradeskillInfo(who, skill, key, value)
	AddDBItem(id, skill)
	AddMaterialsData(id, {materials list})
	AddKnownData(id, player, difficulty, faction code)

]]--

--============================== VARIABLES ==============================--
RBTradeskill = {};
RBTradeskill.FrameOpen = false;
RBTradeskill.DeepScanning = false;
RBTradeskill.DeepScannerUpdate = 0;
local RB_PlayerTradeskills = {};

-- Default values for tradeskill data
RECIPEBOOK_TRADESKILL_DEFAULTS = {rank = {1, "number", 0}, maxrank = {2, "number", 0}, spec = {3, "number", 0}, subspec = {4, "number", 0}, lastupd = {5, "string", "Not yet updated"}, show = {6, "boolean", true}, numskills = {7, "number", 0},};

--============================== FUNCTIONS ==============================--
--[[ ForceSkillUpdate(who, skill) --> Sets RB_PlayerTradeskills[who][skill] to nil, forcing an update on next open. ]]--
function RBTradeskill:ForceSkillUpdate(who, skill)
	if RB_PlayerTradeskills[who] and RB_PlayerTradeskills[who][skill] then 
		RB_PlayerTradeskills[who][skill] = nil 
		return true;
	else return false;
	end;
end

--[[ SkillWindowOpen([updated]) --> Scans through the tradeskill window, collecting and storing all the data. ]]--
function RBTradeskill:SkillWindowOpen(update, rescan)
	local linked, who = IsTradeSkillLinked();
	local fac;
	if linked then 
		if who == RecipeBook.Globals.Player then return; -- Don't save yourself as a linked skill.
		elseif RBOptions:GetOption("Updates", "Linked") then
			RecipeBook:Debug("Tracking Linked Skills");
			-- If this is an alt's linked data, don't save as shared.  This is not bullet-proof (if you are linked an alt's data without having logged in that alt on this data set, it will show as shared) but should be close enough.
			fac = RBDB:GetPlayerFaction(who);
			if not fac then 
				fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 11 or 21); -- Set shared player faction
			end
		    RBDB:AddNewPlayer(who, fac, true);
		else
			RecipeBook:Debug("Not tracking Linked skills.");
			-- Not tracking linked skills.
			return; 
		end
	else
		who = RecipeBook.Globals.Player;
		fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 10 or 20); -- Set player faction
	end
	--set up functions for crafts/noncrafts
	local total = 0;
	local known = 0;

	if RecipeBook.Parms.AddOnsLoaded["Blizzard_TradeSkillUI"] then -- All tradeskills
	    RecipeBook:Debug("Beginning tradeskill scan.");
		RBTradeskill.FrameOpen = true;
	else
	    return;
	end

	total = GetNumTradeSkills();
	local skill, rank, maxrank = GetTradeSkillLine();
	skill = RBDB:Skill_TextToDB(skill);

	-- Is this tradeskill being tracked?
	if skill == 0 then
		RecipeBook:Debug("Not a known tradeskill.");
		return false;
	elseif (not linked and not RBDB:GetSkillIsTracked(who, fac, skill)) then
		RecipeBook:Debug("Not a tracked tradeskill.");
		return false;	
	-- Dynamically updating tradeskill list; account for this.
	else
		known = RBDB:GetPlayerTradeskillInfo(who, fac, skill, "numskills");
		RecipeBook.Parms.LastTSUpdate = time();
		-- This tradeskill has already been completely scanned, including reagents, and nothing new has been added.  Update difficulty tables.
		if type(known) == "number" and known >= total then
			-- We want to only do this if you've skilled up...
			if (rank > RBDB:GetPlayerTradeskillInfo(who, fac, skill, "rank")) then
				RecipeBook:Debug("Updating Rank info");
				for i = 1, total do
					rname, diff = GetTradeSkillInfo(i);
					if diff ~= "header" then
						local what, id, recipe, rid;
						what = GetTradeSkillItemLink(i);
						id = RBDB:Link_TextToDB(what);
						recipe = GetTradeSkillRecipeLink(i);
						rid = RBDB:Link_TextToDB(recipe);
						RBDB:AddKnownData(id, rid, who, diff, fac); -- Update known data for this player.
					end
				end
				RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "rank", rank);
			end
			RBDB:SetPlayerTradeskillInfo(who, fac, skill, "lastupd", string.gsub(date(), " %d+:%d+:%d+", "")); -- Update the "last update" field.
		    RecipeBook:Debug("Already scanned all these items. Tradeskill info updated.  Exiting.");
		    return true;
		-- This tradeskill has fewer scanned items than the tradeskill window suggests it should, or has not been scanned.
		else
			update = true;
			if RB_PlayerTradeskills[who] ==  nil then RB_PlayerTradeskills[who] = {} end;
			if RB_PlayerTradeskills[who][skill] ~= nil then
			    if RB_PlayerTradeskills[who][skill].Reagents == nil then RB_PlayerTradeskills[who][skill].Reagents = {} end;
			    if RB_PlayerTradeskills[who][skill].Items == nil then RB_PlayerTradeskills[who][skill].Items = {} end;
			else
				RB_PlayerTradeskills[who][skill] = {Reagents = {}, Items = {}};
			end
		end
	end

   	RBDB:SetPlayerTradeskillInfo(who, fac, skill, "rank", tonumber(rank));
	RBDB:SetPlayerTradeskillInfo(who, fac, skill, "maxrank", tonumber(maxrank));
	if RBDB:GetPlayerTradeskillInfo(who, fac, skill, "show") ~= false then
		RBDB:SetPlayerTradeskillInfo(who, fac, skill, "show", true);
	end

	local diff, id, link;

	-- Create table of reagents for an index item
	local name, diff, id, rid;
	local count = 0;
	local incomplete = 0;
	local reagenTable = function(index)
	    local reagT = {};
	    for j = 1, GetTradeSkillNumReagents(index) do
			local link = GetTradeSkillReagentItemLink(index,j);
			if link then
				local _,_,num = GetTradeSkillReagentInfo(index,j);
				reagT[RBDB:Link_TextToDB(link)] = num;
				RB_PlayerTradeskills[who][skill].Reagents[GetTradeSkillItemLink(index)] = nil;
			else --This link doesn't exist; reagents aren't loaded.
                RB_PlayerTradeskills[who][skill].Reagents[GetTradeSkillItemLink(index)] = true;
                return {};
			end;
	    end
	    -- All reagents loaded, return reagent table.
		return reagT;
	end

	for i = 1, total do
	    -- Difficulty or 'header'
		rname, diff = GetTradeSkillInfo(i);
		if diff == "header" then count = count + 1; -- Increment count for header fields
		-- Not a header
		else
		    what = GetTradeSkillItemLink(i);
			recipe = GetTradeSkillRecipeLink(i);
		    -- Item is already in the tradeskill item table, therefore has been completely scanned.
		    if RB_PlayerTradeskills[who][skill].Items[recipe] then
				count = count + 1; -- Increment count.
 		    else
		    -- Item is not already in the tradeskill item table
		        id = RBDB:Link_TextToDB(what);
				rid = RBDB:Link_TextToDB(recipe);
		        if id then
					local iname;
					if id == rid then iname = GetSpellInfo(id);
					else iname = GetItemInfo(what);
					end
					RBDB:AddDBItem(id, rid, iname, rname, skill); -- Potentially new item to the DB
					RBDB:AddKnownData(id, rid, who, diff, fac); -- Add known data for this player.
					
				    local reagenT = reagenTable(i);
				    -- This item has materials available
	            	count = count + 1; -- Increment count only if item is added.
					if next(reagenT) then
			            RB_PlayerTradeskills[who][skill].Items[recipe] = true;
		            	RBDB:AddMaterialsData(id, rid, reagenT);
					else
					    incomplete = incomplete + 1;
	            	end
				end
		    end
		end
	end
	
	if (count < total or count < 1 ) or (incomplete > 0) then 
		if rescan then RecipeBook:ScheduleEvent(RBTradeskill.ReScanTradeskill, 1);
		else RBOutput:Popup(RECIPEBOOK_ERR_TRADESKILLNOTSCANNED, RBTradeskill.DeepScanTradeskill, nil);
		end
	elseif count >= total and incomplete == 0 and not RB_PlayerTradeskills[who][skill].Completed then
		RBOutput:Print(string.format(RECIPEBOOK_INFO_SCANCOMPLETED, who, RBDB:Skill_DBToText(skill)), "info");
		RB_PlayerTradeskills[who][skill].Completed = true;
		RBTradeskill.DeepScanning = false;
	end

	-- RecipeBook:Debug("[RBTradeskill:SkillWindowOpen] Scanned: "..count.." - Archived: "..count-incomplete);
	RBDB:SetPlayerTradeskillInfo(who, fac, skill, "lastupd", string.gsub(date(), " %d+:%d+:%d+", ""));
	RBDB:SetPlayerTradeskillInfo(who, fac, skill, "numskills", count-incomplete);
 end

--[[ SkillWindowUpdate() --> Updates semi-intelligently to save memory and cycles ]]--
function RBTradeskill:SkillWindowUpdate()
	if not RBOptions:GetOption("TrackMe") then return end;
	if time() - RecipeBook.Parms.LastTSUpdate < 5 then return end;
	if RBTradeskill.DeepScanning then return end; -- Don't rescan while we're deep scanning.
	RBTradeskill:SkillWindowOpen(true)
end

--[[ SkillWindowClose() --> Resets data when a window closes. ]]--
function RBTradeskill:SkillWindowClose()
	RBTradeskill.FrameOpen = false;
	RBTradeskill.DeepScanning = false;
	RBDB:UpdateNameList();
end

--[[ DeepScanTradeskill() --> Scans the current tradeskill, attempting a force-load on all items. ]]--
function RBTradeskill:DeepScanTradeskill(update)
	if not RBTradeskill.FrameOpen then return RBOutput:Print(RECIPEBOOK_ERR_NOTRADESKILLOPEN, "error");
	elseif update then 
		if time() - RBTradeskill.DeepScannerUpdate > 15 then 
			RBOutput:Print(RECIPEBOOK_INFO_RESCANNINGTRADESKILL, "info");
			RBTradeskill.DeepScannerUpdate = time();
		end
	else RBOutput:Print(RECIPEBOOK_INFO_SCANNINGTRADESKILL, "info");
	end
	RBTradeskill.DeepScanning = true;
	-- Iterate trade skills
	for id=1, GetNumTradeSkills(), 1 do
		local skillName, skillType, _, _, _= GetTradeSkillInfo(id);
		if ( skillName and skillType == "header" ) then -- Expand everything
			if ( not isExpanded ) then ExpandTradeSkillSubClass(id) end;
		else
			TradeSkillFrame_SetSelection(id);
		end
	end
	TradeSkillFrame_Update();
	RecipeBook:ScheduleEvent(RBTradeskill.SkillWindowRescan, 3);
end

-- Rescan the skill window, passing correct parameters.
function RBTradeskill:SkillWindowRescan()
	RBTradeskill:SkillWindowOpen(true, true)
end
-- Repeat the tradeskill deep scan.
function RBTradeskill:ReScanTradeskill()
	RBTradeskill:DeepScanTradeskill(true);
end


--[[ SpecialtyScan() --> Scans through the player's known skills for specializations.
	Returns : new specialties added/changed or false ]]--
function RBTradeskill:SpecialtyScan()
	local specT = {};
	local _, _, _, numSpells = GetSpellTabInfo(1);
	for i = 1, numSpells, 1 do
		local name = GetSpellName(i, BOOKTYPE_SPELL);
		local found = false;
		if name then
			local fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 10 or 20); -- Set player faction
			for skill,v in pairs(RECIPEBOOK_SPECIALS) do
				local s = RBDB:Skill_TextToDB(skill);
			    for i, ts in ipairs(v) do
			        if ts == name then
						spec = RBDB:GetPlayerSpecializations(RecipeBook.Globals.Player, fac, s);
			            if spec ~= i then
			                RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, s, "spec", i);
							table.insert(specT, name);
						end
			            found = true;
			            break;
			        end
			    end
			    -- if found then break end;
			end
			if not found then
				for skill,v in pairs(RECIPEBOOK_SUBSPECIALS) do
					local s = RBDB:Skill_TextToDB(skill);
				    for j, ts in ipairs(v) do
				        if ts == name then
							_, spec = RBDB:GetPlayerSpecializations(RecipeBook.Globals.Player, fac, s);
			            	if spec ~= j then
			            	    RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, s, "subspec", j);
								table.insert(specT, name);
							end
				            found = true;
				            break;
				        end
				    end
				end
				-- if found then break end;
			end
		end
	end

	return #specT > 0 and RECIPEBOOK_ADDED_SPECIALS.. table.concat(specT, ", ") or false;
end

--[[ ProfessionScan() --> Scans through known professions for this character and populates the database with them, if tracking is enabled.
	Returns: Nothing ]]--
function RBTradeskill:ProfessionScan()
    local pind = 0;
	for i=1,10 do
	    local skill, _, expo = GetSkillLineInfo(i);
		if ( skill == TRADE_SKILLS ) then
		    if not expo then ExpandSkillHeader(i) end;
			pind = i;
			break;
		end
	end
	local skillT = {};
	local now = string.gsub(date(), " %d+:%d+:%d+", "");
	local fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 10 or 20); -- Set player faction
	for i = 1,7 do
		local skill, header, expo , rank, _, _, maxrank = GetSkillLineInfo(i+pind);
		if header and not expo then ExpandSkillHeader(i+pind) end; -- expand lines!
		skill = RBDB:Skill_TextToDB(skill);
		if not header and skill > 0 then
			-- RecipeBook:Debug("Populating Database with skill:"..skill)
			skillT[skill] = {Rank = rank, MaxR = maxrank}; -- All skills known
			if RBDB:GetSkillIsTracked(RecipeBook.Globals.Player, fac, skill) then
			    RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "rank", rank);
			    RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "maxrank", maxrank);
				RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "lastupd", now);
			end
		end
	end
	if next(skillT) ~= nil then
		for what, _ in pairs(RBDB:GetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, "all")) do
		    if not skillT[what] then RBDB:DeleteTradeskill(RecipeBook.Globals.Player, fac, what) end; -- Tradeskill no longer known.
		end
	end

end

function RBTradeskill:ReputationScan()
	local name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild;
	for i = 1, GetNumFactions() do
  		name, description, standingID, barMin, barMax, barValue, atWarWith, canToggleAtWar, isHeader, isCollapsed, hasRep, isWatched, isChild  = GetFactionInfo(i);
		local fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 10 or 20); -- Set player faction
  		if not isHeader then
  		    RBDB:SetPlayerReputation(RecipeBook.Globals.Player, fac, name, standingID);
		end
	end
end

--[[ ParseSkillupMessage(msg) --> Updates skill rank on a chat window skillup message. ]]--
function RBTradeskill:ParseSkillupMessage(msg)
	local skill, rank;
	if not msg then return end;
    string.gsub(msg, RECIPEBOOK_CHAT_SKILLUP, function(a,b) skill = a; rank = tonumber(b); end); -- skill and rank from message
    skill = RBDB:Skill_TextToDB(skill);
	local fac = ((RecipeBook.Globals.Faction == FACTION_ALLIANCE) and 10 or 20); -- Set player faction
    if not RBDB:GetSkillIsTracked(RecipeBook.Globals.Player, fac, skill) then return end; -- Not a tracked tradeskill.
    
	if RBTradeskill.FrameOpen then
		local tskill = RBDB:Skill_TextToDB(GetTradeSkillLine());
		if tskill ~= skill then RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "rank", rank) end;
		-- Don't set rank on tradeskills that are currently open; data is needed for tradeskill updates.
	else
		RBDB:SetPlayerTradeskillInfo(RecipeBook.Globals.Player, fac, skill, "rank", rank);
	end
	
	local banked = RBDB:GetBankedForSkill(skill, rank)
	if banked then
	    for id, who in pairs(banked) do
			if ( who and next(who)) then
		        local name, link = GetItemInfo(id);
				if not name then link = "Unsafe item [id: "..id.."]" end;
		    	RBOutput:Print(format(RECIPEBOOK_INFO_CANLEARNONSKILLUP, link, RBOutput:MakeLine(who), "output"));
			end
		end
	end
end
