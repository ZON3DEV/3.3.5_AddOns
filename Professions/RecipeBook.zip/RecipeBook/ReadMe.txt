ReadMe file
Version 3.3.2 Beta 2
Last updated 11 March 2010 by Ayradyss (recipebook@comcast.net)
Installation: Unzip into the World of Warcraft/Interface/AddOns directory.

RecipeBook is a mod that allows you to browse tradeskill recipes with one alt and see whether your other alts know it.   

For example:
I have character BetsyRoss, who is a tailor by nature.  She knows Pattern: American Flag, but for some reason, I can never remember this when UncleScrooge goes to the auction house to buy patterns.  
	* Previously, I would have to keep a written or mental list of BetsyRoss's known patterns so that UncleScrooge didn't buy her a second copy of Pattern: American Flag on accident.  
	* Now, with RecipeBook, UncleScrooge can mouse over Pattern: American Flag and see "Already known by: BetsyRoss" right there on the tooltip - or, if he chooses, in a special chat tab just for RecipeBook information.
	
It's fun! It's helpful! It's easy to use!  It's also still in development, so there are a few known issues and some miscellaneous housework to be done.

RecipeBook loads defaulted to on, tooltip output, not parsing the current alt, same faction, showing known/learn/future recipes.  Banked data loads defaulted to off.
Usage: /recipebook, /rbook or /rbk <options>
	Note: I recommend strongly that you just use your minimap icon and right-click menus. to access this stuff :)
	* General:
	- /rbk help : Displays a help message
	- /rbk on|off : Turns RecipeBook's data display on or off.  It will continue to update alts' tradeskills when the tradeskill frames are opened, so you have the best list possible.
	- /rbk config : Opens the graphical config window.
	- /rbk skill : Use /rbk skill to open a window where you can browse a list of every recipe your alts know.  So, just in case UncleScrooge were curious, he could type "/rbk skill" and select BetsyRoss to find out every tailoring recipe she knew as of the most recent update.
	
	* Sharing: 	
	- /rbk send <alt> to <player> : Sends your RecipeBook data for a given alt to another player.  Use 'all' as your alt to send all alts you know.  Use 'me' to send just your character. 
	- /rbk update from <player> : Requests an update of RecipeBook data from another player. 

	* Banking: 
	- /rbk banklist : Displays your banked items.
	
	* Skill Display:
	- /rbk skill <character> <tradeskill> : Show tradeskills for a certain character.  This will default to the last character the skill window was opened for.
	- /rbk search <item> : Searches for items containing the given string.
	- /rbk searchmats <item> : Searches for items using materials which match the given string.
	
	* Auction House Options (only available via /rbk config):
	- Color Recipes based on status: This will shade the icons for recipes you see in the Auction House based on whether other alts can learn them.
	- Default color scheme is as follows (in order of precedence): 
		- Normal : Current alt can learn the recipe
		- Green : Another alt can currently learn the recipe
		- Orange : Current alt is the only character who will be able to learn the recipe (requires /rbk self on)
		- Cyan : Some alt or alts will be able to learn the recipe (may include current character)
		- Red : No alt/alts will be able to learn the recipe, based on current data
		- Dark Red : All available alts already know the recipe
	- Blackout Banked Recipes: This will shade the icons for recipes that you have banked black in the Auction House so that you can tell you already have a copy.
	
	* Debugging functions
	- /rbk debug : Turns on debug mode
	- /rbk verbose : Turns on verbose send mode.

Known issues:
	* RecipeBook only updates its recipe list when your tradeskill window is open.  So, if BetsyRoss just learned Pattern: Giant American Flag, she'll have to open her Tailoring window before RecipeBook (or UncleScrooge) knows about it. 

Housekeeping: 
	* Hopes for next phase: Updating your recipe list when you learn items (in progress).
	
Compatibilities:
	The easiest way to add RecipeBook compatibility to *your* mod is to call the following in your tooltip output:
		RecipeBook_DoHookedFunction(self, tooltip);
		Where tooltip is the tooltip (or tooltip name) you're using.  That should add RecipeBook's data lines.
	Things RecipeBook has worked with for me or others:

Special thanks to:
	Curse Gaming's Pentarion and Ghandi, for some hard work helping me debug the German client version.  Particularly to Pentarion for ongoing translation work.
	
	
Most Recent Changes (see Changelog.txt for old versions): 
	3.3.2: 
		- THIS VERSION WILL WIPE YOUR DATA.  RecipeBook will clear its database on first loading - this means that EVERYTHING will need to be reloaded: character skills, cached items, everything.  I'm having trouble with old (uncached) data again.
		- THIS VERSION WILL RESET MOST OPTIONS.  I made some changes for the color-coding customization.
		FIXED: 
		- Guild Bank items should now tooltip correctly once again.
		- Several small changes in the code should now clarify whether the "RecipeBook data not yet loaded" error stems from a blank DB or a lag concern, and help eliminate it recurring.
		!NEW!
		+ Color customization added: Check the "colors" tab in the RecipeBook UI for an option to change the colors of items and text.
		+ If RecipeBook cannot quickly load all of your recipe/reagent data, it will now give you a popup message to that effect.  Clicking "Accept" will attempt to force-load all of the tradeskill data.  
			- This replaces the "Some items were not scanned for this tradeskill" and "Some reagents for this tradeskill's items were not yet in local cache" messages that were previously in your chat frame.
			- This scan may lag the UI intermittently; do not do it when you are doing things that are control-intensive.
			- You have the option of clicking "Cancel" which will wait for the next time RecipeBook updates to check again.
			- Doing this scan in Dalaran or other high-lag areas may require a little time.  You will be updated periodically on the status of the deep scan.
	BETA 2:
		- THIS VERSION WILL RESET DEFAULT OPTIONS.  Whoops, I didn't check my set defaults closely enough.
		- TRANSLATIONS NEEDED: I have hacked a few lines and changed some others so that the non-English clients should stop erroring on popup.
		- Tidied up the help messages to stop suggesting /rb when it doesn't work any longer :)
		- When someone new shares data with you it should now show up without requiring a reload of the UI.
		- Using the minimap icon to select a RecipeBook tab while the RecipeBook window is open now correctly loads that tab.
		
		
	
			

			
PLEASE NOTE: If you learn a new recipe, you will have to open your appropriate tradeskill window to update RecipeBook's database. Hopefully this will change at some point.		
