﻿-- ------------------------------------------------------------------------------------- --
-- 					Scroll Master - AddOn by Sapu (sapu94@gmail.com)			 		 --
--             http://wow.curse.com/downloads/wow-addons/details/slippy.aspx             --
-- ------------------------------------------------------------------------------------- --

-- The following functions are contained attached to this file:
-- Data:OnInitialize() - initializes the module when it is loaded
-- Data:LoadDefaultEnchants() - load the default enchants into the user's saved DB
-- Data:LoadFromSavedDB() - loads all user-added enchants and their corresponding materials
-- Data:CalcPrices() - calulates the cost, buyout, and profit for an enchant's scroll
-- Data:GetMats() - returns a table containing a list of materials that excludes those only needed for hidden enchants
-- Data:ResetData() - resets all of the data when the "Reset Craft Queue" button is pressed
-- Data:GetQAGroupName() - gets the name of the QA group that corresponds with a passed itemID
-- Data:ExportDataToQA() - exports all of Scroll Master's enchant costs (how much it cost to make every enchant) to QA3's threshold values
-- Data:GetEnchantsBySlot() - returns the Data.chants table as a 2D array with a slot index (chants[slot][chant] instead of chants[chant])
-- Data:GetVellumID()	- returns the ID of the vellum number needed for an enchant
-- Data:IsVellum() - simple function that returns true if a given itemID is a vellum
-- Data:UpdateIDList() - rebuilds the Data.scrollID table which is the Data.chants table indexed by itemID
-- Data:UpdateInventoryInfo() - gets the number of mats / scrolls in the players inventory and stores the results in Data.inventory

-- The following "global" (within the addon) variables are initialized in this file:
-- Data.matList - contains the itemIDs for all the materials
-- Data.chants - stores information about every enchant (see below for more info)
-- Data.scrollID - same as Data.chants but indexed by itemID
-- Data.inventory - stores information about what's in the player's bags.

-- ===================================================================================== --


-- load the parent file (ScrollMaster) into a local variable and register this file as a module
local SM = select(2, ...)
local Data = SM:NewModule("Data", "AceEvent-3.0")

local aceL = LibStub("AceLocale-3.0"):GetLocale("ScrollMaster") -- loads the localization table
local debug = function(...) SM:Debug(...) end -- for debugging

local function L(phrase)
	--SM.lTable[phrase] = true
	return aceL[phrase]
end

-- initializes the module when it is loaded
function Data:OnInitialize()
	-- Data.matList contains the itemIDs for all the materials. The defaults are:
	-- Infinite Dust, Greater Cosmic Essence, Lesser Cosmic Essence, Dream Shard, Abyss Crystal, Titanium Bar,
	-- Crystallized Water, Eternal Earth, Eternal Air, Titansteel Bar, Scarlet Ruby, Weapon Vellum III, Armor Vellum III
	-- 34054, 34055, 34056, 34052, 34057, 41163, 37705, 35624, 35623, 37663, 36918, 43146, 43145
	Data.matList = {}
	Data.inventory = {}
	
	-- Data[ENCHANT] = {mats={MAT_ITEMID=QUANTITY}, itemID=SCROLL_ITEMID, 
	--		spellID=ENCHANT_SPELLID, queued=#QUEUED, posted=#POSTED, sell=SCROLL_SELL_PRICE}
end

-- load the default enchants into the user's saved DB
function Data:LoadDefaultEnchants()
	local defaultChants = SM.LibEnchant.enchants

	-- set the rest of the default values that are the same for every enchant
	for enchant=1, #(defaultChants) do
		local vellumID = Data:GetVellumID(defaultChants[enchant].spellID)
		defaultChants[enchant].mats[vellumID] = 1
		defaultChants[enchant].queued = 0
	end
	
	if not SM.db.profile.enchants or #(SM.db.profile.enchants) == 0 then
		SM.db.profile.enchants = SM.db.profile.AddedChants
		
		for _, data in pairs(defaultChants) do
			if SM.db.profile.chant and (SM.db.profile.chant[data.itemID] ~= false) then
				if not SM.db.profile.enchants then SM.db.profile.enchants = {} end
				tinsert(SM.db.profile.enchants, data)
			end
		end
		
		if not SM.db.profile.enchants or #(SM.db.profile.enchants) == 0 then
			SM.db.profile.enchants = defaultChants
		end
		
		SM.db.profile.chant = nil
		SM.db.profile.AddedChants = nil
	end
end

-- loads all user-added enchants and their corresponding materials
function Data:LoadFromSavedDB()
	Data:LoadDefaultEnchants()
	
	-- load all the enchants into Data.chants
	Data.chants = SM.db.profile.enchants
	
	-- add any materials that aren't in the default table to the data table
	for id in pairs(SM.db.factionrealm) do
		-- the id is going to be the key (and the value is the cost of that material which we don't care about)
		if tonumber(id) then -- if the id is a number that means it's an itemID of a material
			local NeedToAdd = nil -- keep track of whether or not this needs to be added to the data table
			for chant=1, #(Data.chants) do
				-- for every enchant in the data table...
				for mat, quantity in pairs(Data.chants[chant].mats) do
					-- check to see if the mat (corresponding to the 'id' variable) is used by the enchant
					if tonumber(id) == tonumber(mat) then
						-- if so, we must add it to SM's internal list of itemIDs for materials
						NeedToAdd = true
					end
				end
			end
			
			-- remove the mat from the savedDB if it is unused
			if not NeedToAdd then
				tremove(SM.db.factionrealm, id)
			end
			
			-- make sure the material isn't already in SM's data table
			for mat=1, #(Data.matList) do
				if tonumber(Data.matList[mat]) == tonumber(id) then
					NeedToAdd = false
				end
			end
			
			-- finally, we add the material if it needs to be added
			if NeedToAdd then
				tinsert(Data.matList, id)
			end
		end
	end
	
	-- change all the vellums to the lowest usable one
	-- this will be removed in a future update as it is only for enchants added before SM v4.0
	for chant=1, #(Data.chants) do
		if Data.chants[chant].mats[43145] then
			Data.chants[chant].mats[43145] = nil
			local vellumID = Data:GetVellumID(Data.chants[chant].spellID)
			SM.db.factionrealm[vellumID] = SM.db.factionrealm[vellumID] or 1
			Data.chants[chant].mats[vellumID] = 1
		elseif Data.chants[chant].mats[43146] then
			Data.chants[chant].mats[43146] = nil
			local vellumID = Data:GetVellumID(Data.chants[chant].spellID)
			SM.db.factionrealm[vellumID] = SM.db.factionrealm[vellumID] or 1
			Data.chants[chant].mats[vellumID] = 1
		end
	end
	
	Data:UpdateIDList()
end

-- calulates the cost, buyout, and profit for an enchant's scroll
function Data:CalcPrices(enchant)
	if not enchant then return end

	if type(enchant) == "number" then
		enchant = Data.chants[enchant]
	end

	-- first, we calculate the cost of crafting that scroll based off the cost of the individual materials
	local cost = 0
	for id, matQuantity in pairs(enchant.mats) do
		-- this if statement excludes vellums in the cost calculations if that option is unchecked
		-- if it's not a vellum or we want to include vellums...we want to include this item
		if (not Data:IsVellum(itemID)) or SM.db.profile.vellums then
			SM.db.factionrealm[tonumber(id)] = SM.db.factionrealm[tonumber(id)] or 1
			cost = cost + matQuantity*SM.db.factionrealm[tonumber(id)]
		end
	end
	cost = math.floor(cost + 0.5) --rounds to nearest gold
	
	-- next, we get the buyout from the auction scan data table and calculate the profit
	local buyout, profit
	if SM.db.factionrealm.ScanStatus.scrolls then -- make sure the auction scan data exists first
		if enchant.sell and not (enchant.sell==(1/0)) then
			-- grab the buyout price and calculate the profit if the buyout price exists and is a valid number
			buyout = enchant.sell
			profit = buyout - buyout*SM.db.profile.profitPercent - cost
			profit = math.floor(profit + 0.5) -- rounds to the nearest gold
		end
	end
	
	-- return the results
	return cost, buyout, profit
end

-- returns a table containing a list of materials that excludes those only needed for hidden enchants
function Data:GetMats()
	local matTemp = {} -- stores boolean values corresponding to whether or not each material is valid (being used)
	local returnTbl = {} -- properly formatted table to be returned
	
	-- check each enchant and make sure it is shown in the 'manage enchants' section of the options
	-- if it is, set all of its materials to valid because they are being used by the addon
	for chant=1, #(Data.chants) do
		for matID in pairs(Data.chants[chant].mats) do
			matTemp[matID] = true 
		end
	end
	
	local num = 1
	
	-- the matTemp table is indexed by itemID of the materials
	-- this must be changed to remain consistent with the Data.matList table so that the itemID is the value
	-- this loop does that
	for matID in pairs(matTemp) do
		for mat=1, #(Data.matList) do
			if tonumber(Data.matList[mat]) == tonumber(matID) then
				if matTemp[matID] then
					returnTbl[num] = tonumber(matID)
					num = num + 1
				end
			end
		end
	end
	
	-- sort the table so that the mats are displayed in a somewhat logical order (by itemID)
	sort(returnTbl)
	
	return returnTbl
end

-- resets all of the data when the "Reset Craft Queue" button is pressed
function Data:ResetData()
	-- reset the number queued of every enchant back to 0
	for enchant=1, #(SM.Data.chants) do
		Data.chants[enchant].queued = 0
	end
	
	CloseTradeSkill() -- close the enchanting trade skill window
	SM.Enchanting:TRADE_SKILL_CLOSE() -- cleans up the Enchanting module
	wipe(SM.GUI.queueList) -- clears the craft queue data table
	SM:Print(L("Craft Queue Reset")) -- prints out a nice message
end

-- gets the name of the QA group that corresponds with a passed itemID
function Data:GetQAGroupName(itemID)
	for groupName, v in pairs(SM.QA3db.global.groups) do
		for itemIDString in pairs(v) do
			if itemIDString == "item:" .. itemID then
				return groupName
			end
		end
	end
end

-- exports all of Scroll Master's enchant costs (how much it cost to make every enchant) to QA3's threshold values
function Data:ExportDataToQA()
	for chant=1, #(Data.chants) do
		if SM.db.profile.exportList[Data.chants[chant].itemID] then
			local groupName = Data:GetQAGroupName(Data.chants[chant].itemID)
			local cost = Data:CalcPrices(Data.chants[chant])
			if groupName then
				local thresholdPrice = (cost + cost*SM.db.profile.qaIncrease) * 10000
				if thresholdPrice < (SM.db.profile.minThreshold*10000) then
					thresholdPrice = SM.db.profile.minThreshold*10000
				end
				SM.QA3db.profile.threshold[groupName] = thresholdPrice
				if SM.db.profile.qaFallback>0 then
					SM.QA3db.profile.fallback[groupName] = thresholdPrice * SM.db.profile.qaFallback
				end
			end
		end
	end
	
	SM:Print(L("Selected enchant costs were successfully exported to QA3."))
end

-- returns the Data.chants table as a 2D array with a slot index (chants[slot][chant] instead of chants[chant])
function Data:GetEnchantsBySlot()
	local enchantsBySlot = {{},{},{},{},{},{},{},{},{}}
	for enchant=1, #(Data.chants) do
		local slot = SM:GetSlot(Data.chants[enchant].spellID)
		if slot then tinsert(enchantsBySlot[slot], Data.chants[enchant]) end
	end
	
	return enchantsBySlot
end

-- returns the ID of the vellum number needed for an enchant
function Data:GetVellumID(spellID, offset)
	local slot = SM:GetSlot(spellID) or 1
	local level = offset or 0
	if not SM.LibEnchant.minLevel[spellID] then
		level = level + 1
	elseif SM.LibEnchant.minLevel[spellID] == 35 then
		level = level + 2
	else
		level = level + 3
	end

	if level == 1 then
		if slot == 1 or slot == 8 or slot == 9 then
			return 39349
		else
			return 38682
		end
	elseif level == 2 then
		if slot == 1 or slot == 8 or slot == 9 then
			return 39350
		else
			return 37602
		end
	else
		if slot == 1 or slot == 8 or slot == 9 then
			return 43146
		else
			return 43145
		end
	end
end

-- simple function that returns true if a given itemID is a vellum
function Data:IsVellum(itemID)
	local vellums = {39349, 39350, 43146, 38682, 37602, 43145}
	for _, vellumID in pairs(vellums) do
		if vellumID == itemID then
			return true
		end
	end
end

-- rebuilds the Data.scrollID table which is the Data.chants table indexed by itemID
function Data:UpdateIDList()
	Data.scrollID = {}
	for chant=1, #(Data.chants) do
		Data.scrollID[Data.chants[chant].itemID] = chant
	end
end

-- gets the number of mats / scrolls in the players inventory and stores the results in Data.inventory
function Data:UpdateInventoryInfo(updateType)
	local matList = Data:GetMats() -- get an up-to-date list of the materials SM is using
	Data:UpdateIDList()

	if updateType == "mats" then -- check the player's bags for any mats
		for mat=1, #(matList) do
			Data.inventory[matList[mat]] = 0
			for bag=0, 4 do
				for slot=1, GetContainerNumSlots(bag) do
					if GetContainerItemID(bag, slot) == tonumber(matList[mat]) then
						Data.inventory[matList[mat]] = Data.inventory[matList[mat]] + select(2, GetContainerItemInfo(bag, slot))
					end
				end
			end
		end
		for i, itemID in pairs({43146, 39350, 39349, 43145, 37602, 38682}) do
			Data.inventory[itemID] = 0
			for bag=0, 4 do
				for slot=1, GetContainerNumSlots(bag) do
					if GetContainerItemID(bag, slot) == tonumber(itemID) then
						Data.inventory[itemID] = Data.inventory[itemID] + select(2, GetContainerItemInfo(bag, slot))
					end
				end
			end
		end
		for mat=1, #(matList) do
			Data.inventory[matList[mat]] = Data.inventory[matList[mat]] or 0
		end
	elseif updateType == "scrolls" then -- check the player's bags for any scrolls
		for _, chant in pairs(Data.chants) do
			Data.inventory[chant.itemID] = 0
		end
		for bag=0, 4 do
			for slot=1, GetContainerNumSlots(bag) do
				local bagItemID = GetContainerItemID(bag, slot)
				if Data.scrollID[bagItemID] then
					local num = select(2, GetContainerItemInfo(bag, slot))
					Data.inventory[bagItemID] = Data.inventory[bagItemID] + num
				end
			end
		end
	end
end