﻿-- load the parent file (ScrollMaster) into a local variable and register this file as a module
local SM = select(2, ...)
local LibEnchant = SM:NewModule("LibEnchant")

-- used to lookup the itemID of the scroll that goes with a certain enchant
-- index = spellID of enchant
-- value = itemID of scroll
LibEnchant.itemID = {
	[44488] = 38953,
	[7426] = 38767,
	[42974] = 38948,
	[7428] = 38768,
	[44528] = 38966,
	[60609] = 44456,
	[13815] = 38827,
	[13817] = 38828,
	[59621] = 44493,
	[44584] = 38974,
	[44592] = 38979,
	[27899] = 38897,
	[22750] = 38878,
	[44616] = 38987,
	[20031] = 38870,
	[7443] = 38769,
	[46578] = 38998,
	[20010] = 38854,
	[13841] = 38831,
	[25073] = 38886,
	[23802] = 38882,
	[25081] = 38891,
	[13898] = 38838,
	[44513] = 38964,
	[33994] = 38932,
	[34002] = 38938,
	[7454] = 38770,
	[13695] = 38822,
	[27914] = 38902,
	[20013] = 38857,
	[20017] = 38861,
	[13612] = 38800,
	[20025] = 38865,
	[20029] = 38868,
	[20033] = 38872,
	[13620] = 38802,
	[27946] = 38906,
	[27950] = 38909,
	[27954] = 38910,
	[27958] = 38912,
	[27962] = 38915,
	[13887] = 38836,
	[44593] = 38980,
	[13655] = 38814,
	[13635] = 38806,
	[13640] = 38808,
	[44625] = 38990,
	[13644] = 38810,
	[13646] = 38811,
	[13648] = 38812,
	[13905] = 38839,
	[13538] = 38798,
	[13421] = 38790,
	[7857] = 38782,
	[64579] = 46098,
	[13915] = 38840,
	[13917] = 38841,
	[34003] = 38939,
	[7766] = 38774,
	[7420] = 38766,
	[27968] = 38918,
	[47900] = 39005,
	[7745] = 38772,
	[44506] = 38960,
	[13933] = 38843,
	[13935] = 38844,
	[13937] = 38845,
	[13939] = 38846,
	[13941] = 38847,
	[13943] = 38848,
	[13945] = 38849,
	[13947] = 38850,
	[25074] = 38887,
	[20014] = 38858,
	[13698] = 38823,
	[13700] = 38824,
	[44595] = 38981,
	[44582] = 38973,
	[60691] = 44463,
	[13536] = 38797,
	[60707] = 44466,
	[44575] = 44815,
	[44555] = 38968,
	[23799] = 38879,
	[25078] = 38888,
	[25082] = 38892,
	[25086] = 38895,
	[60763] = 44469,
	[33996] = 38934,
	[34004] = 38940,
	[60616] = 38971,
	[27911] = 38900,
	[44483] = 38950,
	[7776] = 38776,
	[33995] = 38933,
	[13485] = 38792,
	[7779] = 38777,
	[20030] = 38869,
	[13746] = 38825,
	[7782] = 38778,
	[27947] = 38907,
	[27951] = 37603,
	[27984] = 38925,
	[13501] = 38793,
	[13503] = 38794,
	[7788] = 38780,
	[27971] = 38919,
	[60668] = 44458,
	[27967] = 38917,
	[27913] = 38901,
	[60692] = 44465,
	[44635] = 38997,
	[44489] = 38954,
	[7786] = 38779,
	[28003] = 38926,
	[20009] = 38853,
	[13890] = 38837,
	[13529] = 38796,
	[13822] = 38829,
	[13693] = 38821,
	[33997] = 38935,
	[34005] = 38941,
	[13794] = 38826,
	[13626] = 38804,
	[44484] = 38951,
	[44492] = 38955,
	[44500] = 38959,
	[44508] = 38961,
	[71692] = 50816,
	[44524] = 38965,
	[13419] = 38789,
	[7793] = 38781,
	[7748] = 38773,
	[44556] = 38969,
	[60653] = 44455,
	[47899] = 39004,
	[59625] = 43987,
	[44588] = 38975,
	[44596] = 38982,
	[63746] = 45628,
	[47672] = 39001,
	[23803] = 38883,
	[44576] = 38972,
	[13836] = 38830,
	[44598] = 38984,
	[27982] = 38924,
	[42620] = 38947,
	[23800] = 38880,
	[13846] = 38832,
	[25083] = 38893,
	[13642] = 38809,
	[33990] = 38928,
	[23804] = 38884,
	[34006] = 38942,
	[13858] = 38833,
	[60714] = 44467,
	[20011] = 38855,
	[20015] = 38859,
	[47051] = 39000,
	[20023] = 38863,
	[60767] = 44470,
	[13617] = 38801,
	[20035] = 38874,
	[27944] = 38904,
	[27948] = 38908,
	[13689] = 38820,
	[13882] = 38835,
	[27960] = 38913,
	[13631] = 38805,
	[44589] = 38976,
	[27972] = 38920,
	[13637] = 38807,
	[13380] = 38788,
	[44621] = 38988,
	[44629] = 38991,
	[13663] = 38818,
	[7859] = 38783,
	[44633] = 38995,
	[7861] = 38784,
	[13653] = 38813,
	[7863] = 38785,
	[13657] = 38815,
	[13659] = 38816,
	[13661] = 38817,
	[7867] = 38786,
	[13948] = 38851,
	[20034] = 38873,
	[20012] = 38856,
	[27906] = 38899,
	[44494] = 38956,
	[46594] = 38999,
	[44510] = 38963,
	[60621] = 44453,
	[62256] = 44947,
	[7771] = 38775,
	[13622] = 38803,
	[13687] = 38819,
	[60623] = 38986,
	[13378] = 38787,
	[59619] = 44497,
	[27837] = 38896,
	[44590] = 38977,
	[60663] = 44457,
	[22749] = 38877,
	[7457] = 38771,
	[47766] = 39002,
	[44630] = 38992,
	[44383] = 38949,
	[13931] = 38842,
	[44509] = 38962,
	[25072] = 38885,
	[23801] = 38881,
	[13464] = 38791,
	[25084] = 38894,
	[34010] = 38946,
	[33992] = 38930,
	[25080] = 38890,
	[27905] = 38898,
	[27975] = 38921,
	[20008] = 38852,
	[27917] = 38903,
	[20016] = 38860,
	[20020] = 38862,
	[20024] = 38864,
	[20028] = 38867,
	[20032] = 38871,
	[20036] = 38875,
	[27945] = 38905,
	[64441] = 46026,
	[13868] = 38834,
	[27957] = 38911,
	[27961] = 38914,
	[47898] = 39003,
	[44591] = 38978,
	[62959] = 45060,
	[27977] = 38922,
	[27981] = 38923,
	[44623] = 38989,
	[44631] = 38993,
	[60606] = 44449,
	[20026] = 38866,
	[13522] = 38795,
	[33991] = 38929,
	[33999] = 38936,
	[13607] = 38799,
	[7418] = 38679,
	[25079] = 38889,
	[33993] = 38931,
	[34001] = 38937,
	[34009] = 38945,
	[44529] = 38967,
	[62948] = 45056,
	[28004] = 38927,
	[47901] = 39006,
	[34007] = 38943,
	[34008] = 38944,
	[21931] = 38876,
}

-- used to lookup the slot number of the enchant used by Scroll Master
-- index = itemID of enchant's scroll
-- value = slot number
LibEnchant.slot = {
	[38897] = 3,
	[38913] = 4,
	[38929] = 4,
	[38945] = 7,
	[38961] = 2,
	[38977] = 5,
	[38993] = 5,
	[38770] = 5,
	[38786] = 2,
	[38802] = 6,
	[38818] = 4,
	[44455] = 7,
	[38850] = 6,
	[38866] = 4,
	[38882] = 3,
	[38898] = 3,
	[38914] = 5,
	[38930] = 4,
	[38946] = 9,
	[38962] = 4,
	[38978] = 5,
	[38994] = 9,
	[38771] = 3,
	[38787] = 7,
	[38803] = 3,
	[38819] = 2,
	[44456] = 5,
	[38851] = 6,
	[38867] = 4,
	[38883] = 9,
	[38899] = 3,
	[38915] = 5,
	[38931] = 6,
	[38947] = 9,
	[38963] = 9,
	[38979] = 6,
	[38995] = 9,
	[38772] = 1,
	[38788] = 1,
	[38804] = 4,
	[38820] = 7,
	[38836] = 6,
	[38852] = 3,
	[38868] = 9,
	[38884] = 9,
	[38900] = 3,
	[38932] = 6,
	[38948] = 9,
	[38964] = 6,
	[38980] = 3,
	[38996] = 3,
	[38773] = 4,
	[38789] = 5,
	[38805] = 7,
	[38821] = 9,
	[38837] = 2,
	[38853] = 3,
	[38869] = 1,
	[38885] = 6,
	[38901] = 3,
	[38917] = 9,
	[38933] = 6,
	[38949] = 7,
	[38965] = 9,
	[38981] = 1,
	[38997] = 3,
	[38774] = 3,
	[38790] = 5,
	[38806] = 5,
	[38822] = 1,
	[38838] = 9,
	[38854] = 3,
	[38870] = 9,
	[38886] = 6,
	[38902] = 3,
	[38918] = 9,
	[38934] = 6,
	[38950] = 5,
	[38966] = 2,
	[38982] = 5,
	[38998] = 9,
	[38679] = 3,
	[38775] = 5,
	[38791] = 7,
	[38807] = 2,
	[38823] = 6,
	[38839] = 7,
	[38855] = 3,
	[38871] = 9,
	[38887] = 6,
	[38903] = 3,
	[38919] = 1,
	[38935] = 6,
	[38951] = 6,
	[38967] = 6,
	[38983] = 7,
	[38999] = 4,
	[50816] = 6,
	[38776] = 4,
	[38792] = 7,
	[38808] = 4,
	[38824] = 4,
	[38840] = 9,
	[38856] = 6,
	[46026] = 9,
	[38888] = 6,
	[38904] = 7,
	[38920] = 9,
	[38936] = 6,
	[38968] = 3,
	[38984] = 3,
	[39000] = 5,
	[38777] = 3,
	[38793] = 3,
	[38809] = 3,
	[38825] = 5,
	[38841] = 4,
	[38857] = 6,
	[38873] = 9,
	[38889] = 6,
	[38905] = 7,
	[38921] = 9,
	[38937] = 3,
	[38953] = 6,
	[38969] = 5,
	[45628] = 2,
	[39001] = 5,
	[38778] = 3,
	[38794] = 9,
	[38810] = 2,
	[38826] = 5,
	[38842] = 3,
	[38858] = 5,
	[38874] = 1,
	[38890] = 6,
	[38906] = 7,
	[38922] = 1,
	[38938] = 3,
	[38954] = 7,
	[38970] = 6,
	[38986] = 2,
	[39002] = 4,
	[44815] = 3,
	[38779] = 9,
	[38795] = 5,
	[38811] = 3,
	[38827] = 6,
	[38843] = 7,
	[38859] = 5,
	[38875] = 1,
	[38891] = 5,
	[38907] = 7,
	[38923] = 9,
	[38939] = 5,
	[38955] = 4,
	[38971] = 3,
	[38987] = 3,
	[39003] = 5,
	[38780] = 9,
	[38796] = 1,
	[38812] = 3,
	[38828] = 7,
	[44465] = 4,
	[38860] = 7,
	[44497] = 9,
	[38892] = 5,
	[38908] = 2,
	[45056] = 8,
	[38940] = 5,
	[38956] = 5,
	[38972] = 9,
	[38988] = 9,
	[39004] = 5,
	[38781] = 1,
	[38797] = 3,
	[38813] = 9,
	[38829] = 3,
	[38845] = 1,
	[38861] = 7,
	[38877] = 9,
	[38893] = 5,
	[38909] = 2,
	[38925] = 9,
	[38941] = 5,
	[38957] = 9,
	[38973] = 5,
	[38989] = 4,
	[39005] = 4,
	[38766] = 4,
	[38782] = 4,
	[38798] = 4,
	[38814] = 9,
	[38830] = 2,
	[38846] = 3,
	[38862] = 2,
	[38878] = 9,
	[38894] = 5,
	[38910] = 2,
	[38926] = 9,
	[38942] = 5,
	[38958] = 9,
	[38974] = 2,
	[38990] = 6,
	[39006] = 2,
	[38767] = 4,
	[38783] = 3,
	[38799] = 4,
	[44947] = 3,
	[38831] = 6,
	[38847] = 4,
	[38863] = 2,
	[38879] = 9,
	[38895] = 5,
	[38911] = 4,
	[38927] = 9,
	[38943] = 2,
	[38959] = 5,
	[38975] = 4,
	[38991] = 9,
	[44493] = 9,
	[38876] = 9,
	[38844] = 2,
	[38768] = 3,
	[38784] = 5,
	[38800] = 6,
	[38816] = 7,
	[44453] = 9,
	[44469] = 2,
	[38864] = 2,
	[38880] = 9,
	[38896] = 1,
	[38912] = 4,
	[45060] = 8,
	[46098] = 9,
	[38960] = 6,
	[38976] = 2,
	[38992] = 1,
	[44470] = 3,
	[38834] = 6,
	[44463] = 1,
	[44466] = 9,
	[38815] = 5,
	[44457] = 5,
	[38848] = 9,
	[43987] = 9,
	[37603] = 2,
	[38832] = 3,
	[44458] = 6,
	[38872] = 9,
	[38928] = 4,
	[38944] = 2,
	[44449] = 2,
	[44467] = 9,
	[38835] = 5,
	[38769] = 4,
	[38785] = 2,
	[38801] = 6,
	[38817] = 3,
	[38833] = 4,
	[38849] = 3,
	[38865] = 4,
	[38881] = 3,
	[38924] = 9,
}

-- used to lookup the minimum level the enchant requires in order to tell what vellum it uses
-- anything not in this table has no level requirement
-- index = spellID of enchant
-- value = level requirement
LibEnchant.minLevel = {
	[25086] = 35,	-- Enchant Cloak - Dodge
	[27899] = 35,	-- Enchant Bracer - Brawn
	[27905] = 35,	-- Enchant Bracer - Stats
	[27906] = 35,	-- Enchant Bracer - Major Defense
	[27911] = 35,	-- Enchant Bracer - Superior Healing
	[27913] = 35,	-- Enchant Bracer - Restore Mana Prime
	[27914] = 35,	-- Enchant Bracer - Fortitude
	[27917] = 35,	-- Enchant Bracer - Spellpower
	[27920] = 35,	-- Enchant Ring - Striking
	[27924] = 35,	-- Enchant Ring - Spellpower
	[27926] = 35,	-- Enchant Ring - Healing Power
	[27927] = 35,	-- Enchant Ring - Stats
	[27944] = 35,	-- Enchant Shield - Tough Shield
	[27945] = 35,	-- Enchant Shield - Intellect
	[27946] = 35,	-- Enchant Shield - Shield Block
	[27947] = 35,	-- Enchant Shield - Resistance
	[27948] = 35,	-- Enchant Boots - Vitality
	[27950] = 35,	-- Enchant Boots - Fortitude
	[27951] = 35,	-- Enchant Boots - Dexterity
	[27954] = 35,	-- Enchant Boots - Surefooted
	[27957] = 35,	-- Enchant Chest - Exceptional Health
	[27958] = 60,	-- Enchant Chest - Exceptional Mana
	[27960] = 35,	-- Enchant Chest - Exceptional Stats
	[27961] = 35,	-- Enchant Cloak - Major Armor
	[27962] = 35,	-- Enchant Cloak - Major Resistance
	[27967] = 35,	-- Enchant Weapon - Major Striking
	[27968] = 35,	-- Enchant Weapon - Major Intellect
	[27971] = 35,	-- Enchant 2H Weapon - Savagery
	[27972] = 35,	-- Enchant Weapon - Potency
	[27975] = 35,	-- Enchant Weapon - Major Spellpower
	[27977] = 35,	-- Enchant 2H Weapon - Major Agility
	[27981] = 35,	-- Enchant Weapon - Sunfire
	[27982] = 35,	-- Enchant Weapon - Soulfrost
	[27984] = 35,	-- Enchant Weapon - Mongoose
	[28003] = 35,	-- Enchant Weapon - Spellsurge
	[28004] = 35,	-- Enchant Weapon - Battlemaster
	[33990] = 35,	-- Enchant Chest - Major Spirit
	[33991] = 35,	-- Enchant Chest - Restore Mana Prime
	[33992] = 35,	-- Enchant Chest - Major Resilience
	[33993] = 35,	-- Enchant Gloves - Blasting
	[33994] = 35,	-- Enchant Gloves - Precise Strikes
	[33995] = 35,	-- Enchant Gloves - Major Strength
	[33996] = 35,	-- Enchant Gloves - Assault
	[33997] = 35,	-- Enchant Gloves - Major Spellpower
	[33999] = 35,	-- Enchant Gloves - Major Healing
	[34001] = 35,	-- Enchant Bracer - Major Intellect
	[34002] = 35,	-- Enchant Bracer - Assault
	[34003] = 35,	-- Enchant Cloak - Spell Penetration
	[34004] = 35,	-- Enchant Cloak - Greater Agility
	[34005] = 35,	-- Enchant Cloak - Greater Arcane Resistance
	[34006] = 35,	-- Enchant Cloak - Greater Shadow Resistance
	[34007] = 35,	-- Enchant Boots - Cat's Swiftness
	[34008] = 35,	-- Enchant Boots - Boar's Speed
	[34009] = 35,	-- Enchant Shield - Major Stamina
	[34010] = 35,	-- Enchant Weapon - Major Healing
	[42620] = 35,	-- Enchant Weapon - Greater Agility
	[42974] = 60,	-- Enchant Weapon - Executioner
	[44383] = 35,	-- Enchant Shield - Resilience
	[44483] = 60,	-- Enchant Cloak - Superior Frost Resistance
	[44484] = 60,	-- Enchant Gloves - Expertise
	[44488] = 60,	-- Enchant Gloves - Precision
	[44489] = 60,	-- Enchant Shield - Defense
	[44492] = 60,	-- Enchant Chest - Mighty Health
	[44494] = 60,	-- Enchant Cloak - Superior Nature Resistance
	[44500] = 60,	-- Enchant Cloak - Superior Agility
	[44506] = 60,	-- Enchant Gloves - Gatherer
	[44508] = 60,	-- Enchant Boots - Greater Spirit
	[44509] = 60,	-- Enchant Chest - Greater Mana Restoration
	[44510] = 60,	-- Enchant Weapon - Exceptional Spirit
	[44513] = 60,	-- Enchant Gloves - Greater Assault
	[44524] = 60,	-- Enchant Weapon - Icebreaker
	[44528] = 60,	-- Enchant Boots - Greater Fortitude
	[44529] = 60,	-- Enchant Gloves - Major Agility
	[44555] = 60,	-- Enchant Bracers - Exceptional Intellect
	[44556] = 60,	-- Enchant Cloak - Superior Fire Resistance
	[44575] = 60,	-- Enchant Bracers - Greater Assault
	[44576] = 60,	-- Enchant Weapon - Lifeward
	[44582] = 60,	-- Enchant Cloak - Spell Piercing
	[44584] = 60,	-- Enchant Boots - Greater Vitality
	[44588] = 60,	-- Enchant Chest - Exceptional Resilience
	[44589] = 60,	-- Enchant Boots - Superior Agility
	[44590] = 60,	-- Enchant Cloak - Superior Shadow Resistance
	[44591] = 60,	-- Enchant Cloak - Titanweave
	[44592] = 60,	-- Enchant Gloves - Exceptional Spellpower
	[44593] = 60,	-- Enchant Bracers - Major Spirit
	[44595] = 60,	-- Enchant 2H Weapon - Scourgebane
	[44596] = 60,	-- Enchant Cloak - Superior Arcane Resistance
	[44598] = 60,	-- Enchant Bracers - Expertise
	[44612] = 60,	-- Enchant Gloves - Greater Blasting
	[44616] = 60,	-- Enchant Bracers - Greater Stats
	[44621] = 60,	-- Enchant Weapon - Giant Slayer
	[44623] = 60,	-- Enchant Chest - Super Stats
	[44625] = 60,	-- Enchant Gloves - Armsman
	[44629] = 60,	-- Enchant Weapon - Exceptional Spellpower
	[44630] = 60,	-- Enchant 2H Weapon - Greater Savagery
	[44631] = 60,	-- Enchant Cloak - Shadow Armor
	[44633] = 60,	-- Enchant Weapon - Exceptional Agility
	[44635] = 60,	-- Enchant Bracers - Greater Spellpower
	[44636] = 60,	-- Enchant Ring - Greater Spellpower
	[44645] = 60,	-- Enchant Ring - Assault
	[46578] = 60,	-- Enchant Weapon - Deathfrost
	[46594] = 35,	-- Enchant Chest - Defense
	[47051] = 35,	-- Enchant Cloak - Steelweave
	[47672] = 60,	-- Enchant Cloak - Mighty Armor
	[47766] = 60,	-- Enchant Chest - Greater Defense
	[47898] = 60,	-- Enchant Cloak - Greater Speed
	[47899] = 60,	-- Enchant Cloak - Wisdom
	[47900] = 60,	-- Enchant Chest - Super Health
	[47901] = 60,	-- Enchant Boots - Tuskarr's Vitality
	[59619] = 60,	-- Enchant Weapon - Accuracy
	[59621] = 60,	-- Enchant Weapon - Berserking
	[59625] = 60,	-- Enchant Weapon - Black Magic
	[60606] = 60,	-- Enchant Boots - Assault
	[60609] = 60,	-- Enchant Cloak - Speed
	[60616] = 60,	-- Enchant Bracers - Striking
	[60621] = 60,	-- Enchant Weapon - Greater Potency
	[60623] = 60,	-- Enchant Boots - Icewalker
	[60653] = 60,	-- Enchant Shield - Greater Intellect
	[60663] = 60,	-- Enchant Cloak - Major Agility
	[60668] = 60,	-- Enchant Gloves - Crusher
	[60691] = 60,	-- Enchant 2H Weapon - Massacre
	[60692] = 60,	-- Enchant Chest - Powerful Stats
	[60707] = 60,	-- Enchant Weapon - Superior Potency
	[60714] = 60,	-- Enchant Weapon - Mighty Spellpower
	[60763] = 60,	-- Enchant Boots - Greater Assault
	[60767] = 60,	-- Enchant Bracers - Superior Spellpower
	[62256] = 60,	-- Enchant Bracers - Major Stamina
	[62257] = 60,	-- Enchant Weapon - Titanguard
	[62948] = 60,	-- Enchant Staff - Greater Spellpower
	[62959] = 60,	-- Enchant Staff - Spellpower
	[64441] = 60,	-- Enchant Weapon - Blade Ward
	[64579] = 60,	-- Enchant Weapon - Blood Draining
}

-- looks up the itemID of  the lesser essence
-- index = itemID of greater essence
-- value = itemID of lesser essence
LibEnchant.lesserEssence = {
	[11082] = 10998,
	[16203] = 16202,
	[10939] = 10938,
	[11175] = 11174,
	[22446] = 22447,
	[11135] = 11134,
	[34055] = 34056,
}

-- looks up the itemID of the greater essence
-- index = itemID of lesser essence
-- value = itemID of greater essence
LibEnchant.greaterEssence = {
	[10998] = 11082,
	[11174] = 11175,
	[16202] = 16203,
	[10938] = 10939,
	[34056] = 34055,
	[22447] = 22446,
	[11134] = 11135,
}


local m = {34054, 34055, 34056, 34052, 34057, 41163, 37705, 35624, 35623, 37663, 36918, 43146, 43145}

-- This is the list of default enchants that SM comes preloaded with:
LibEnchant.enchants = {
	-- Enchant 2H Weapon
	{mats={[m[1]]=6, [m[2]]=2}, itemID=38992, spellID=44630},				-- Greater Savagery
	{mats={[m[1]]=40, [m[2]]=6, [m[5]]=6}, itemID=44463, spellID=60691},	-- Massacre

	-- Enchant Boots
	{mats={[m[1]]=8, [m[7]]=1}, itemID=38986, spellID=60623},				-- Icewalker
	{mats={[m[1]]=10, [m[2]]=1}, itemID=38961, spellID=44508},				-- Greater Spirit
	{mats={[m[1]]=3, [m[3]]=3}, itemID=38966, spellID=44528},				-- Greater Fortitude
	{mats={[m[1]]=16, [m[2]]=4}, itemID=38976, spellID=44589},				-- Superior Agility
	{mats={[m[2]]=4, [m[4]]=4}, itemID=44469, spellID=60763},				-- Greater Assault
	{mats={[m[1]]=4, [m[3]]=4}, itemID=44449, spellID=60606},				-- Assault
	{mats={[m[1]]=10, [m[2]]=2, [m[4]]=2}, itemID=39006, spellID=47901},	-- Tuskarr's Vitality
	{mats={[m[1]]=8, [m[2]]=2}, itemID=38974, spellID=44584},				-- Greater Vitality

	-- Enchant Bracer(s)
	{mats={[m[1]]=6, [m[2]]=6, [m[4]]=1}, itemID=44470, spellID=60767},		-- Superior Spellpower
	{mats={[m[1]]=8, [m[3]]=4}, itemID=38997, spellID=44635},				-- Greater Spellpower
	{mats={[m[1]]=24, [m[2]]=6}, itemID=44815, spellID=44575},				-- Greater Assault
	{mats={[m[2]]=4, [m[5]]=1}, itemID=44947, spellID=62256},				-- Major Stamina
	{mats={[m[1]]=16, [m[2]]=4}, itemID=38980, spellID=44593},				-- Major Spirit
	{mats={[m[1]]=6}, itemID=38971, spellID=60616},							-- Striking
	{mats={[m[1]]=10}, itemID=38968, spellID=44555},						-- Exceptional Intellect
	{mats={[m[1]]=14, [m[2]]=3}, itemID=38984, spellID=44598},				-- Expertise
	{mats={[m[1]]=16, [m[2]]=3}, itemID=38987, spellID=44616},				-- Greater Stats

	-- Enchant Chest
	{mats={[m[1]]=4, [m[3]]=2}, itemID=38989, spellID=44623},				-- Super Stats
	{mats={[m[4]]=4, [m[5]]=4}, itemID=44465, spellID=60692},				-- Powerful Stats
	{mats={[m[1]]=10, [m[8]]=1}, itemID=39002, spellID=47766},				-- Greater Defense
	{mats={[m[1]]=4, [m[2]]=4}, itemID=38962, spellID=44509},				-- Greater Mana Restoration
	{mats={[m[1]]=20, [m[2]]=4}, itemID=39005, spellID=47900},				-- Super Health
	{mats={[m[2]]=3}, itemID=38955, spellID=44492},							-- Mighty Health
	{mats={[m[1]]=6}, itemID=38912, spellID=27958},							-- Exceptional Mana
	{mats={[m[2]]=2, [m[4]]=2}, itemID=38975, spellID=44588},				-- Exceptional Resilience

	-- Enchant Cloak
	{mats={[m[1]]=16, [m[2]]=4}, itemID=39003, spellID=47898},				-- Greater Speed
	{mats={[m[1]]=8, [m[2]]=2, [m[4]]=2}, itemID=44457, spellID=60663},		-- Major Agility
	{mats={[m[1]]=15, [m[2]]=2}, itemID=39001, spellID=47672},				-- Mighty Armor
	{mats={[m[1]]=6}, itemID=44456, spellID=60609},							-- Speed
	{mats={[m[1]]=8, [m[4]]=2, [m[6]]=2}, itemID=38978, spellID=44591},		-- Titanweave
	{mats={[m[2]]=6, [m[5]]=1}, itemID=39004, spellID=47899},				-- Wisdom
	{mats={[m[1]]=9}, itemID=38959, spellID=44500},							-- Superior Agility
	{mats={[m[1]]=15}, itemID=38973, spellID=44582},						-- Spell Piercing
	{mats={[m[1]]=12, [m[5]]=1}, itemID=38993, spellID=44631},				-- Shadow Armor

	-- Enchant Gloves
	{mats={[m[1]]=4, [m[3]]=1}, itemID=38979, spellID=44592},				-- Exceptional Spellpower
	{mats={[m[1]]=20, [m[2]]=4, [m[4]]=1}, itemID=44458, spellID=60668},	-- Crusher
	{mats={[m[2]]=4}, itemID=38953, spellID=44488},							-- Precision
	{mats={[m[4]]=2, [m[8]]=8}, itemID=38990, spellID=44625},				-- Armsman
	{mats={[m[2]]=4, [m[4]]=1}, itemID=38967, spellID=44529},				-- Major Agility
	{mats={[m[1]]=6, [m[2]]=1}, itemID=38964, spellID=44513},				-- Greater Assault
	{mats={[m[1]]=12, }, itemID=38951, spellID=44484},						-- Expertise

	-- Enchant Shield
	{mats={[m[1]]=12}, itemID=44455, spellID=60653},						-- Greater Intellect
	{mats={[m[1]]=6, [m[8]]=6}, itemID=38954, spellID=44489},				-- Defense

	-- Enchant Staff
	{mats={[m[1]]=40, [m[4]]=6, [m[5]]=6}, itemID=45056, spellID=62948},	-- Greater Spellpower
	{mats={[m[1]]=12, [m[2]]=2}, itemID=45060, spellID=62959},				-- Spellpower

	-- Enchant Weapon
	{mats={[m[2]]=8, [m[5]]=4, [m[10]]=1}, itemID=46026, spellID=64441},	-- Blade Ward
	{mats={[m[1]]=10, [m[2]]=2}, itemID=38991, spellID=44629},				-- Exceptional Spellpower
	{mats={[m[1]]=30, [m[4]]=6, [m[5]]=6}, itemID=44467, spellID=60714},	-- Mighty Spellpower
	{mats={[m[1]]=12, [m[2]]=4, [m[4]]=4, [m[5]]=10}, itemID=44493, spellID=59621},	-- Berserking
	{mats={[m[1]]=2, [m[3]]=4}, itemID=44453, spellID=60621},				-- Greater Potency
	{mats={[m[4]]=4, [m[9]]=4}, itemID=38995, spellID=44633},				-- Exceptional Agility
	{mats={[m[1]]=16, [m[4]]=4}, itemID=38963, spellID=44510},				-- Exceptional Spirit
	{mats={[m[1]]=20, [m[2]]=4, [m[4]]=4, [m[5]]=6}, itemID=44497, spellID=59619},	-- Accuracy
	{mats={[m[1]]=10, [m[2]]=2, [m[4]]=2, [m[5]]=4}, itemID=44466, spellID=60707},	-- Superior Potency
	{mats={[m[1]]=40, [m[5]]=4, [m[11]]=1}, itemID=46098, spellID=64579},	-- Blood Draining
	{mats={[m[2]]=6, [m[4]]=6, [m[5]]=6}, itemID=43987, spellID=59625},		-- Black Magic
}