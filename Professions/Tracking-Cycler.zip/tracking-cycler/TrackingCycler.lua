-- Globals Section
SLASH_TCYCLE1 = '/tcycle'; 


-- Create frame and register events
local frame2 = CreateFrame("FRAME"); -- Need a frame to respond to events
frame2:RegisterEvent("ADDON_LOADED"); -- Fired when saved variables are loaded
frame2:RegisterEvent("PLAYER_LOGOUT"); -- Fired when about to log out

-- If not set, set the addon status to off
if TrackingCycler_Status == nil then
    TrackingCycler_Status = false;
end
-- If not set, set the default update interval to 15 seconds
if TrackingCycler_UpdateInterval == nil then
    TrackingCycler_UpdateInterval = 15.0;
end

-- Functions Section
function frame2:OnEvent(event, arg1)
 if event == "ADDON_LOADED" and arg1 == "TrackingCycler_Status" then
  -- Our saved variables are ready at this point. If there are none, both variables will set to nil.
  DEFAULT_CHAT_FRAME:AddMessage("TrackingCycler Loaded.");
 end
end

function SlashCmdList.TCYCLE(msg, editbox) -- 4.
	if msg == "reset" then
	TrackingCycler_UpdateInterval = 15.0;
	TrackingCycler_Status = true;
	else
		if TrackingCycler_Status == true then
			TrackingCycler_Status = false;
			DEFAULT_CHAT_FRAME:AddMessage("TrackingCycler is now off.");
		else
			TrackingCycler_Status = true;
			DEFAULT_CHAT_FRAME:AddMessage("TrackingCycler is now on.");
		end
	end 
end

function TrackingCycler_OnUpdate(self, elapsed)
  self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed; 	

  if (self.TimeSinceLastUpdate > TrackingCycler_UpdateInterval) then
    TrackingCycler_ToggleTrack();

    self.TimeSinceLastUpdate = 0;
  end
end


function TrackingCycler_ToggleTrack()
    if TrackingCycler_Status == true then
    if UnitAffectingCombat("player") == true or UnitIsDeadOrGhost("player") == 1 or UnitExists("target") == 1 then
--
    else
        local count = GetNumTrackingTypes();
--      DEFAULT_CHAT_FRAME:AddMessage(count)
        for i=1,count do 
	        local name, texture, active, category = GetTrackingInfo(i);
            if active == 1 then
                activeTrack = i;
            end
--        	DEFAULT_CHAT_FRAME:AddMessage(name.." ("..category..")");
        end
        if activeTrack == 1 then
            SetTracking(2);
        else
            SetTracking(1);
        end
    end
    end
end
