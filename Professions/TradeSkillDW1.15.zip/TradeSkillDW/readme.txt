Lightweight tradeskill double wide window with profession's tabs. Reuses original Blizzard functionality, as result no lags like in some other addons. Recipe list from 8 to 40 items (easy configurable). "Jobber" like tabs for fast profession switching. Based on ideas from "DoubleWideTradeSkills" and "Jobber".

Changes:

1.15
"Destruction" buttons added: "Basic Campfire", "Disenchant", "Prospecting", "Milling"

1.10
Skill tabs moved to top right.
List items count now adjustable through window resizing (button in left-bottom corner).
2 view modes supported: single and double wide.