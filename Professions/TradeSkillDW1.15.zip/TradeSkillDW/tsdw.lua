-- constants
local NODE_HEIGHT = 16 --button height
local TSF_NAME_TEMPLATE = "TradeSkillSkill"
local TSF_TEXTURE_NAME = "TradeSkillDWScrollTexture"
local HORZ_BAR_FNAME = [[Interface\ClassTrainerFrame\UI-ClassTrainer-HorizontalBar]]
local SCROLL_BAR_FNAME = [[Interface\ClassTrainerFrame\UI-ClassTrainer-ScrollBar]]
local DEFAULT_DETAIL_FRAME_HEIGHT = 177
local DEFAULT_DETAIL_FRAME_WIDTH = 297
local DEFAULT_HEADER_FRAME_HEIGHT = 118
local tradeSkillIDs = {
	["primary"] = {
		["2656"] = "Smelting",
		["26790"] = "Tailoring",
		["27028"] = "First Aid",
		["28029"] = "Enchanting",
		["28596"] = "Alchemy",
		["28897"] = "Jewelcrafting",
		["29844"] = "Blacksmithing",
		["30350"] = "Engineering",
		["32549"] = "Leatherworking",
		["33359"] = "Cooking",
		["45357"] = "Inscription",
		["53428"] = "Runeforging"
	},
	["secondary"] = {
		["818"] = "Basic Campfire",
		["13262"] = "Disenchant",
		["31252"] = "Prospecting",
		["51005"] = "Milling"
	}
}

-- variables
local texf --slider, subText,
local expandButton, resizeGripButton
local buttons = {}
local tabPool = {
	["primary"] = {},
	["secondary"] = {}
}
local leftPos, topPos

local function tsw_create_frame(parent_wnd, idx)
	local f = CreateFrame("Button", TSF_NAME_TEMPLATE..idx, TradeSkillFrame, "TradeSkillSkillButtonTemplate")
	f:SetPoint("TOPLEFT", parent_wnd, "BOTTOMLEFT")
	return f
end

local function CreateTex(parent, tex, layer, width, height, ...)
	if texf == nil then
		texf = parent:CreateTexture(TSF_TEXTURE_NAME, layer)
	end
	texf:SetPoint(...)
	texf:SetTexture(tex)
	texf:SetWidth(width)
	texf:SetHeight(height)
	texf:Show()
	return texf
end

local function ttsSlider_OnValueChanged(self, value)
	if value < 8 then
		value = 8
	end
	if value > 40 then
		value = 40
	end

	if value < TRADE_SKILLS_DISPLAYED then
		for i = value + 1, TRADE_SKILLS_DISPLAYED do
			if buttons[i] then
				buttons[i]:Hide()
			end
		end
	end
	
	TRADE_SKILLS_DISPLAYED = value
	TradeSkillDW_Settings["NumButtons"] = value
	
	if expandButton.expanded then
		--TradeSkillFrame:SetAttribute("UIPanelLayout-width", 683)
		TradeSkillFrame:SetWidth(683)
	else
		--TradeSkillFrame:SetAttribute("UIPanelLayout-width", 683)
		TradeSkillFrame:SetWidth(380)
	end

	local prev_f = TradeSkillSkill8

	for i = 9, TRADE_SKILLS_DISPLAYED do
		if buttons[i] == nil then
			prev_f = tsw_create_frame(prev_f, i)
			buttons[i] = prev_f
		else
			buttons[i]:Show()
			prev_f = buttons[i]
		end
	end

	if expandButton.expanded then
		TradeSkillFrame:SetHeight(NODE_HEIGHT * TRADE_SKILLS_DISPLAYED + DEFAULT_HEADER_FRAME_HEIGHT)
		for i, region in ipairs({TradeSkillFrame:GetRegions()}) do
			if region:IsObjectType("Texture") then
				if region:GetTexture() == HORZ_BAR_FNAME then
					region:Hide()
				end
			end
		end
	else
		TradeSkillFrame:SetHeight(NODE_HEIGHT * TRADE_SKILLS_DISPLAYED + DEFAULT_HEADER_FRAME_HEIGHT + 8 + DEFAULT_DETAIL_FRAME_HEIGHT)
		TradeSkillHorizontalBarLeft:ClearAllPoints()
		TradeSkillHorizontalBarLeft:SetPoint("TOPLEFT", 2, -(NODE_HEIGHT * TRADE_SKILLS_DISPLAYED + 82))
		TradeSkillHorizontalBarLeft:SetPoint("RIGHT", -80, 0)
		TradeSkillHorizontalBarLeft:SetTexCoord(0, 1.0, 0, 0.25)
		for i, region in ipairs({TradeSkillFrame:GetRegions()}) do
			if region:IsObjectType("Texture") then
				if region:GetTexture() == HORZ_BAR_FNAME then
					region:Show()
				end
			end
		end
	end

	TradeSkillListScrollFrame:ClearAllPoints()
	TradeSkillListScrollFrame:SetPoint("TOPLEFT", 22, -86)
	if expandButton.expanded then
		TradeSkillListScrollFrame:SetWidth(DEFAULT_DETAIL_FRAME_WIDTH)
	else
		TradeSkillListScrollFrame:SetPoint("TOPRIGHT", -32, -86)
	end
	TradeSkillListScrollFrame:SetHeight(NODE_HEIGHT * TRADE_SKILLS_DISPLAYED + 2)
	
	TradeSkillDetailScrollFrame:ClearAllPoints()
	if expandButton.expanded then
		TradeSkillDetailScrollFrame:SetPoint("TOPLEFT", TradeSkillListScrollFrame, "TOPRIGHT", 35, -2)
		TradeSkillDetailScrollFrame:SetHeight(NODE_HEIGHT * TRADE_SKILLS_DISPLAYED + 2)
		TradeSkillDetailScrollFrame:SetWidth(DEFAULT_DETAIL_FRAME_WIDTH)
	else
		TradeSkillDetailScrollFrame:SetPoint("TOPLEFT", TradeSkillListScrollFrame, "BOTTOMLEFT", 0, -8)
		TradeSkillDetailScrollFrame:SetPoint("TOPRIGHT", TradeSkillListScrollFrame, "BOTTOMRIGHT", 0, -8)
		TradeSkillDetailScrollFrame:SetHeight(DEFAULT_DETAIL_FRAME_HEIGHT)
	end
	
	TradeSkillInputBox:ClearAllPoints()
	TradeSkillInputBox:SetPoint("RIGHT", TradeSkillIncrementButton, "LEFT", 0, 0)
	TradeSkillInputBox:SetJustifyH("RIGHT")
	TradeSkillInputBox:SetTextInsets(0, 4, 2, 0)
	
	TradeSkillDecrementButton:ClearAllPoints()
	TradeSkillDecrementButton:SetPoint("RIGHT", TradeSkillInputBox, "LEFT", -4, 0)
	
	TradeSkillCreateAllButton:ClearAllPoints()
	TradeSkillCreateAllButton:SetPoint("RIGHT", TradeSkillDecrementButton, "LEFT", 0, 0)

	local height = NODE_HEIGHT * TRADE_SKILLS_DISPLAYED
	if height > 240 then
		CreateTex(TradeSkillListScrollFrame, SCROLL_BAR_FNAME, "BACKGROUND", 30, height - 235, "LEFT", TradeSkillListScrollFrame, "RIGHT", -3, 0):SetTexCoord(0, 0.46875, 0.2, 0.9609375)
	elseif texf then 
		texf:Hide()
	end
	
	TradeSkillFrame_Update()
end

local function expandButton_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	if (self.expanded) then
		GameTooltip:SetText(HIGHLIGHT_FONT_COLOR_CODE..self.collapseTooltip..FONT_COLOR_CODE_CLOSE)
	else
		GameTooltip:SetText(HIGHLIGHT_FONT_COLOR_CODE..self.expandTooltip..FONT_COLOR_CODE_CLOSE)
	end
end

local function expandButton_OnLeave(self)
	GameTooltip:Hide()
end

local function setExpandButtonTextures(self)
	if (self.expanded) then
		self:SetNormalTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Up]])
		self:SetPushedTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Down]])
		self:SetDisabledTexture([[Interface\Buttons\UI-SpellbookIcon-PrevPage-Disabled]])
	else
		self:SetNormalTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Up]])
		self:SetPushedTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Down]])
		self:SetDisabledTexture([[Interface\Buttons\UI-SpellbookIcon-NextPage-Disabled]]) 		
	end
end

local function expandButton_OnClick(self)
	if (self.expanded) then
		PlaySound("igCharacterInfoClose")
	else
		PlaySound("igCharacterInfoOpen")
	end
	self.expanded = not(self.expanded)
	setExpandButtonTextures(self)
	TradeSkillDW_Settings["expanded"] = self.expanded
	ttsSlider_OnValueChanged(nil, TRADE_SKILLS_DISPLAYED)
	if (GameTooltip:GetOwner() == self) then
		self:GetScript("OnEnter")(self)
	end
end

local function resizeGripButton_OnMouseDown(self, button)
	if (button == "LeftButton") then
		leftPos = TradeSkillFrame:GetLeft()
		topPos = TradeSkillFrame:GetTop()
		TradeSkillFrame:SetResizable(true)
		TradeSkillFrame:StartSizing("BOTTOMLEFT")
	end 
end

local function resizeGripButton_OnMouseUp(self, button)
	TradeSkillFrame:StopMovingOrSizing()
	TradeSkillFrame:SetResizable(false)
	TradeSkillFrame:ClearAllPoints()
	TradeSkillFrame:SetPoint("TOPLEFT", UiParent, "BOTTOMLEFT", leftPos, topPos)
	--stuff
	local listHeight, listCount
	if expandButton.expanded then
		listHeight = TradeSkillFrame:GetHeight() - DEFAULT_HEADER_FRAME_HEIGHT
	else
		listHeight = TradeSkillFrame:GetHeight() - (DEFAULT_HEADER_FRAME_HEIGHT + 8 + DEFAULT_DETAIL_FRAME_HEIGHT)
	end
	listCount = math.floor(listHeight / NODE_HEIGHT)
	ttsSlider_OnValueChanged(nil, listCount)
end

local function CheckIsValueInTable(tab, value)
	for _, v in pairs(tab) do
		if v == value then
			return true
		end
	end

	return false
end

local function SetTabs(value)
	local knownSkills = {}
	local currentSkill = GetTradeSkillLine()

	local index, tab, anchor = 1

	for k, v in pairs(tradeSkillIDs[value]) do
		local name = GetSpellInfo(k)
		local isUsable = IsUsableSpell(name)

		if (isUsable) then
			knownSkills[index] = name
			index = index + 1
		end
	end

	table.sort(knownSkills)

	for i = #knownSkills, 1, -1 do
		if (tabPool[value][i]) then
			tab = tabPool[value][i]
		else
			tab = CreateFrame("CheckButton", nil, TradeSkillFrame, "TradeSkillDW_SkillTabTemplate")
			tabPool[value][i] = tab
		end

		tab.skill = knownSkills[i]

		if (anchor) then
			if value == "primary" then
				tab:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -20)
			else
				tab:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 20)
			end
		else
			if value == "primary" then
				tab:SetPoint("TOPLEFT", TradeSkillFrame, "TOPRIGHT", 0, -30)
			else
				tab:SetPoint("BOTTOMLEFT", TradeSkillFrame, "BOTTOMRIGHT", 0, 30)
			end
		end

		anchor = tab

		local _, _, texture = GetSpellInfo(tab.skill)

		tab:SetAttribute("*macrotext*", "/cast "..tab.skill)
		tab.nt = tab:GetNormalTexture()
		tab.nt:SetTexture(texture)

		if (currentSkill == tab.skill) and (CheckIsValueInTable(tradeSkillIDs["primary"], tab.skill)) then
			tab:SetChecked(1)
		else
			tab:SetChecked(nil)
		end
	end
end

local function Update()
	if (InCombatLockdown()) then 
		return
	end

	TradeSkillDW_Settings = TradeSkillDW_Settings or {}

	TradeSkillFrame:SetClampedToScreen(true)
	
	if expandButton == nil then
		expandButton = CreateFrame("Button", "TradeSkillDWExpandButton", TradeSkillFrame)
		expandButton:SetWidth(32)
		expandButton:SetHeight(32)
		
		if TradeSkillDW_Settings["expanded"] == nil then
			TradeSkillDW_Settings["expanded"] = true
		end
		expandButton.expanded = TradeSkillDW_Settings["expanded"]
		
		setExpandButtonTextures(expandButton)
		expandButton:SetHighlightTexture([[Interface\Buttons\UI-Common-MouseHilight]])
		expandButton.collapseTooltip = "Collapse to Single mode"
		expandButton.expandTooltip = "Expand to Double Wide mode"
		expandButton:SetScript("OnEnter", expandButton_OnEnter)
		expandButton:SetScript("OnLeave", expandButton_OnLeave)
		expandButton:SetScript("OnClick", expandButton_OnClick)
		
		expandButton:ClearAllPoints()
		expandButton:SetPoint("BOTTOMLEFT", TradeSkillFilterButton, "BOTTOMRIGHT", 12, -4)
		expandButton:SetFrameLevel(expandButton:GetParent():GetFrameLevel() + 2)
	end
	
	if resizeGripButton == nil then
		resizeGripButton = CreateFrame("Button", "TradeSkillDWResizeGripButton", TradeSkillFrame)
		resizeGripButton:SetWidth(32)
		resizeGripButton:SetHeight(32)
		resizeGripButton:SetNormalTexture([[Interface\AddOns\TradeSkillDW\textures\ResizeGripLeft]])
		resizeGripButton:SetHighlightTexture([[Interface\AddOns\TradeSkillDW\textures\ResizeGripLeft]])
		resizeGripButton:SetPoint("BOTTOMLEFT", TradeSkillFrame, "BOTTOMLEFT", -4, -4)
		resizeGripButton:SetScript("OnMouseDown", resizeGripButton_OnMouseDown)
		resizeGripButton:SetScript("OnMouseUp", resizeGripButton_OnMouseUp)
	end
	
	TradeSkillDW_Settings["NumButtons"] = TradeSkillDW_Settings["NumButtons"] or 25
	ttsSlider_OnValueChanged(nil, TradeSkillDW_Settings["NumButtons"]) --TRADE_SKILLS_DISPLAYED = 25

	SetTabs("primary")
	SetTabs("secondary")
end

function TradeSkillDW_SkillTab_OnPreClick(self)
	if CheckIsValueInTable(tradeSkillIDs["secondary"], self.skill) then
		return
	end

	for k, v in pairs(tabPool["primary"]) do
		if (v ~= self) then
			v:SetChecked(nil)
		end
	end
end

function TradeSkillDW_SkillTab_OnPostClick(self)
	if CheckIsValueInTable(tradeSkillIDs["secondary"], self.skill) then
		self:SetChecked(nil)
	end
end

local function controlOnEvent(self, event, ...)
	if (event == "TRADE_SKILL_SHOW") then
		Update()
	end
end

local frame = CreateFrame("Frame", nil, UIParent)
frame:SetScript("OnEvent", controlOnEvent)
frame:RegisterEvent("TRADE_SKILL_SHOW")
