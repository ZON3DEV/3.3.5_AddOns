TradeSkillFrameReset = TradeSkillFrame_LoadUI;

TradeSkillFrame_LoadUI = function()
	TradeSkillFrameReset();
	BLIZZ_SetSelection = TradeSkillFrame_SetSelection;
	TradeSkillFrame_SetSelection = TradeSkillFrameSSOverride;
	
	UIPanelWindows["TradeSkillFrame"] =	{ area = "doublewide" };
	TradeSkillFrame:SetAttribute("UIPanelLayout-width", 724);
	TradeSkillFrame:SetWidth(724);
	TradeSkillFrame:SetHeight(512);
	TradeSkillRankFrame:SetWidth(606);
	TradeSkillListScrollFrame:ClearAllPoints();
	TradeSkillListScrollFrame:SetPoint("LEFT", TradeSkillFrame, "LEFT", 18, 5);
	TradeSkillListScrollFrame:SetHeight(310);
	TRADE_SKILLS_DISPLAYED = 20;
	for i = 8 + 1, 20 do
	   local button = CreateFrame("Button", "TradeSkillSkill"..i, TradeSkillFrame, "TradeSkillSkillButtonTemplate");
	   button:SetID(i);
	   button:Hide();
	   button:ClearAllPoints();
	   button:SetPoint("TOPLEFT", getglobal("TradeSkillSkill" .. (i-1)), "BOTTOMLEFT", 0, 1);
	end;
	TradeSkillDetailScrollFrame:ClearAllPoints();
	TradeSkillDetailScrollFrame:SetPoint("LEFT", TradeSkillListScrollFrame, "RIGHT", 50, -10);
	TradeSkillDetailScrollFrame:SetHeight(310);
	TradeSkillCancelButton:ClearAllPoints();
	TradeSkillCancelButton:SetPoint("BOTTOMRIGHT", TradeSkillFrame, "BOTTOMRIGHT", -40, 80);
	local regions = {TradeSkillFrame:GetRegions()};
	local r;
	for _,r in ipairs(regions) do
		if (r:IsObjectType("Texture")) then
			if (r:GetTexture() == [[Interface\ClassTrainerFrame\UI-ClassTrainer-HorizontalBar]]) then
				local src,_,dst,_,_ = r:GetPoint(1);
				if (src == "LEFT" and dst == "RIGHT") then TradeSkillHorizontalBarRight=r; end;
			elseif (r:GetTexture() == [[Interface\ClassTrainerFrame\UI-ClassTrainer-TopLeft]]) then	TradeSkillFrameTopLeftTexture=r;
			elseif (r:GetTexture() == [[Interface\ClassTrainerFrame\UI-ClassTrainer-TopRight]]) then TradeSkillFrameTopRightTexture=r;
			end;
		end;
	end;
	TradeSkillHorizontalBarLeft:SetWidth(16);
	TradeSkillHorizontalBarLeft:SetHeight(256);
	TradeSkillHorizontalBarLeft:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-VerticalBar");
	TradeSkillHorizontalBarLeft:SetTexCoord(0,.25,0,1);
	TradeSkillHorizontalBarRight:ClearAllPoints();
	TradeSkillHorizontalBarRight:SetPoint("TOP", TradeSkillHorizontalBarLeft, "BOTTOM",0,0);
	TradeSkillHorizontalBarRight:SetWidth(16);
	TradeSkillHorizontalBarRight:SetHeight(256);
	TradeSkillHorizontalBarRight:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-VerticalBar");
	TradeSkillHorizontalBarRight:SetTexCoord(.25,.50,0,1);
	TradeSkillFrameTopLeftTexture:SetWidth(512);
	TradeSkillFrameTopLeftTexture:SetHeight(256);
	TradeSkillFrameTopLeftTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-TopLeft");
	TradeSkillFrameBottomLeftTexture:SetWidth(512);
	TradeSkillFrameBottomLeftTexture:SetHeight(256);
	TradeSkillFrameBottomLeftTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BottomLeft");
	TradeSkillFrameTopRightTexture:SetWidth(256);
	TradeSkillFrameTopRightTexture:SetHeight(256);
	TradeSkillFrameTopRightTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-TopRight");
	TradeSkillFrameTopRightTexture:ClearAllPoints();
	TradeSkillFrameTopRightTexture:SetPoint("TOPLEFT",TradeSkillFrameTopLeftTexture,"TOPRIGHT",0,0);
	TradeSkillFrameBottomRightTexture:ClearAllPoints();
	TradeSkillFrameBottomRightTexture:SetPoint("BOTTOMLEFT",TradeSkillFrameBottomLeftTexture,"BOTTOMRIGHT",0,0);
	TradeSkillFrameBottomRightTexture:SetWidth(256);
	TradeSkillFrameBottomRightTexture:SetHeight(256);
	TradeSkillFrameBottomRightTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BottomRight");
	TradeSkillHorizontalBarLeft:ClearAllPoints();
	TradeSkillHorizontalBarLeft:SetPoint("TOP",TradeSkillFrame,"TOP",-17,-90);
	TradeSkillRankFrameBorder:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BarFix1");
	TradeSkillRankFrame:CreateTexture("TradeSkillRankFrameBorderB", "BORDER");
	TradeSkillRankFrameBorderB:ClearAllPoints();	
	TradeSkillRankFrameBorderB:SetPoint("LEFT", TradeSkillRankFrameBorder,"RIGHT",0,0);
	TradeSkillRankFrameBorderB:SetWidth(274);
	TradeSkillRankFrameBorderB:SetHeight(27);
	TradeSkillRankFrameBorderB:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BarFix2");
	TradeSkillRankFrame:CreateTexture("TradeSkillRankFrameBorderC", "BORDER")
	TradeSkillRankFrameBorderC:ClearAllPoints();
	TradeSkillRankFrameBorderC:SetPoint("LEFT", TradeSkillRankFrameBorderB, "RIGHT", 0,0);
	TradeSkillRankFrameBorderC:SetWidth(137);
	TradeSkillRankFrameBorderC:SetHeight(27);
	TradeSkillRankFrameBorderC:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BarFix3");
	local sc={TradeSkillListScrollFrame:GetRegions()}
	TradeSkillListScrollFrameTopBar=sc[1];
	TradeSkillListScrollFrameBottomBar=sc[2];
	TradeSkillListScrollFrameTopBar:SetWidth(30);
	TradeSkillListScrollFrameTopBar:SetHeight(253);
	TradeSkillListScrollFrameTopBar:ClearAllPoints();
	TradeSkillListScrollFrameTopBar:SetPoint("TOPLEFT", TradeSkillListScrollFrame, "TOPRIGHT", -2, 2 );
	TradeSkillListScrollFrameTopBar:SetTexture([[Interface\PaperDollInfoFrame\UI-Character-ScrollBar]]);
	TradeSkillListScrollFrameTopBar:SetTexCoord(0, 0.46875, 0.01171875, 1.0);
	TradeSkillListScrollFrameBottomBar:SetWidth(30);
	TradeSkillListScrollFrameBottomBar:SetHeight(108);
	TradeSkillListScrollFrameBottomBar:ClearAllPoints();
	TradeSkillListScrollFrameBottomBar:SetPoint("BOTTOMLEFT", TradeSkillListScrollFrame, "BOTTOMRIGHT", -2, -4 );
	TradeSkillListScrollFrameBottomBar:SetTexture([[Interface\PaperDollInfoFrame\UI-Character-ScrollBar]]);
	TradeSkillListScrollFrameBottomBar:SetTexCoord(0.515625, 0.984375, 0, 0.421875)
	sc={TradeSkillDetailScrollFrame:GetRegions()};
	TradeSkillDetailScrollFrameTopBar=sc[1];
	TradeSkillDetailScrollFrameBottomBar=sc[2];
	TradeSkillDetailScrollFrameTopBar:SetWidth(30);
	TradeSkillDetailScrollFrameTopBar:SetHeight(253);
	TradeSkillDetailScrollFrameTopBar:ClearAllPoints();
	TradeSkillDetailScrollFrameTopBar:SetPoint("TOPLEFT", TradeSkillDetailScrollFrame, "TOPRIGHT", -2, 2 );
	TradeSkillDetailScrollFrameTopBar:SetTexture([[Interface\PaperDollInfoFrame\UI-Character-ScrollBar]]);
	TradeSkillDetailScrollFrameTopBar:SetTexCoord(0, 0.46875, 0.01171875, 1.0);
	TradeSkillDetailScrollFrameBottomBar:SetWidth(30);
	TradeSkillDetailScrollFrameBottomBar:SetHeight(108);
	TradeSkillDetailScrollFrameBottomBar:ClearAllPoints();
	TradeSkillDetailScrollFrameBottomBar:SetPoint("BOTTOMLEFT", TradeSkillDetailScrollFrame, "BOTTOMRIGHT", -2, -4 );
	TradeSkillDetailScrollFrameBottomBar:SetTexture([[Interface\PaperDollInfoFrame\UI-Character-ScrollBar]]);
	TradeSkillDetailScrollFrameBottomBar:SetTexCoord(0.515625, 0.984375, 0, 0.421875);
	TradeSkillFrame_LoadUI = TradeSkillFrameReset;
	if TradeFrame:IsShown() and GetUIPanelWidth(UIParent) < 1100 then HideUIPanel(TradeSkillFrame); end;
end;

TradeSkillFrameSSOverride = function(id)
	local skillName, skillType, numAvailable, isExpanded, altVerb = GetTradeSkillInfo(id);
	local creatable = 1;
	if ( not skillName ) then creatable = nil; end;
	TradeSkillHighlightFrame:Show();
	if ( skillType == "header" ) then
		TradeSkillHighlightFrame:Hide();
		if ( isExpanded ) then CollapseTradeSkillSubClass(id); else	ExpandTradeSkillSubClass(id); end;
		return;
	end;
	TradeSkillFrame.selectedSkill = id;
	SelectTradeSkill(id);
	if ( GetTradeSkillSelectionIndex() > GetNumTradeSkills() ) then	return;	end;
	local color = TradeSkillTypeColor[skillType];
	if ( color ) then TradeSkillHighlight:SetVertexColor(color.r, color.g, color.b); end;
	local skillLineName, skillLineRank, skillLineMaxRank = GetTradeSkillLine();
	TradeSkillFrameTitleText:SetFormattedText(TRADE_SKILL_TITLE, skillLineName);
	TradeSkillRankFrame:SetStatusBarColor(0.0, 0.0, 1.0, 0.5);
	TradeSkillRankFrameBackground:SetVertexColor(0.0, 0.0, 0.75, 0.5);
	TradeSkillRankFrame:SetMinMaxValues(0, skillLineMaxRank);
	TradeSkillRankFrame:SetValue(skillLineRank);
	TradeSkillRankFrameSkillRank:SetText(skillLineRank.."/"..skillLineMaxRank);
	TradeSkillSkillName:SetText(skillName);
	if ( GetTradeSkillCooldown(id) ) then
		TradeSkillSkillCooldown:SetText(COOLDOWN_REMAINING.." "..SecondsToTime(GetTradeSkillCooldown(id)));
	else
		TradeSkillSkillCooldown:SetText("");
	end;
	TradeSkillSkillIcon:SetNormalTexture(GetTradeSkillIcon(id));
	local minMade,maxMade = GetTradeSkillNumMade(id);
	if ( maxMade > 1 ) then
		if ( minMade == maxMade ) then
			TradeSkillSkillIconCount:SetText(minMade);
		else
			TradeSkillSkillIconCount:SetText(minMade.."-"..maxMade);
		end;
		if ( TradeSkillSkillIconCount:GetWidth() > 39 ) then
			TradeSkillSkillIconCount:SetText("~"..floor((minMade + maxMade)/2));
		end;
	else
		TradeSkillSkillIconCount:SetText("");
	end;
	local numReagents = GetTradeSkillNumReagents(id);
	if(numReagents > 0) then
		TradeSkillReagentLabel:Show();
	else
		TradeSkillReagentLabel:Hide();
	end;
	for i=1, numReagents, 1 do
		local reagentName, reagentTexture, reagentCount, playerReagentCount = GetTradeSkillReagentInfo(id, i);
		local reagent = getglobal("TradeSkillReagent"..i)
		local name = getglobal("TradeSkillReagent"..i.."Name");
		local count = getglobal("TradeSkillReagent"..i.."Count");
		if ( not reagentName or not reagentTexture ) then
			reagent:Hide();
		else
			reagent:Show();
			SetItemButtonTexture(reagent, reagentTexture);
			name:SetText(reagentName);
			if ( playerReagentCount < reagentCount ) then
				SetItemButtonTextureVertexColor(reagent, 0.5, 0.5, 0.5);
				name:SetTextColor(GRAY_FONT_COLOR.r, GRAY_FONT_COLOR.g, GRAY_FONT_COLOR.b);
				creatable = nil;
			else
				SetItemButtonTextureVertexColor(reagent, 1.0, 1.0, 1.0);
				name:SetTextColor(HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
			end;
			if ( playerReagentCount >= 100 ) then playerReagentCount = "*";	end;
			count:SetText(playerReagentCount.." /"..reagentCount);
		end;
	end;
	local reagentToAnchorTo = numReagents;
	if ( (numReagents > 0) and (mod(numReagents, 2) == 0) ) then
		reagentToAnchorTo = reagentToAnchorTo - 1;
	end;
	for i=numReagents + 1, MAX_TRADE_SKILL_REAGENTS, 1 do
		getglobal("TradeSkillReagent"..i):Hide();
	end;
	local spellFocus = BuildColoredListString(GetTradeSkillTools(id));
	if ( spellFocus ) then
		TradeSkillRequirementLabel:Show();
		TradeSkillRequirementText:SetText(spellFocus);
	else
		TradeSkillRequirementLabel:Hide();
		TradeSkillRequirementText:SetText("");
	end;
	if ( creatable ) then
		TradeSkillCreateButton:Enable();
		TradeSkillCreateAllButton:Enable();
	else
		TradeSkillCreateButton:Disable();
		TradeSkillCreateAllButton:Disable();
	end;
	if ( GetTradeSkillDescription(id) ) then
		TradeSkillDescription:SetText(GetTradeSkillDescription(id));
		TradeSkillReagentLabel:SetPoint("TOPLEFT", "TradeSkillDescription", "BOTTOMLEFT", 0, -10);
	else
		TradeSkillDescription:SetText(" ");
		TradeSkillReagentLabel:SetPoint("TOPLEFT", "TradeSkillDescription", "TOPLEFT", 0, 0);
	end;
	TradeSkillInputBox:SetNumber(GetTradeskillRepeatCount());
	if ( IsTradeSkillLinked() ) then
		TradeSkillCreateButton:Hide();
		TradeSkillCreateAllButton:Hide();
		TradeSkillDecrementButton:Hide();
		TradeSkillInputBox:Hide();
		TradeSkillIncrementButton:Hide();
		TradeSkillLinkButton:Hide();
		TradeSkillFrameBottomLeftTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-Link-BottomLeft");
		TradeSkillFrameBottomRightTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-Link-BottomRight");
	else
		if ( not altVerb ) then
			TradeSkillCreateAllButton:Show();
			TradeSkillDecrementButton:Show();
			TradeSkillInputBox:Show();
			TradeSkillIncrementButton:Show();
			TradeSkillFrameBottomLeftTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BottomLeft");
			TradeSkillFrameBottomRightTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BottomRight");
		else
			TradeSkillCreateAllButton:Hide();
			TradeSkillDecrementButton:Hide();
			TradeSkillInputBox:Hide();
			TradeSkillIncrementButton:Hide();
			TradeSkillFrameBottomLeftTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-AltVerb-BottomLeft");
			TradeSkillFrameBottomRightTexture:SetTexture("Interface\\AddOns\\TradeSkillHD\\UI-TradeSkill-BottomRight");
		end;
		if ( GetTradeSkillListLink() ) then TradeSkillLinkButton:Show(); else TradeSkillLinkButton:Hide(); end;
		TradeSkillCreateButton:SetText(altVerb or CREATE);
		TradeSkillCreateButton:Show();
    end;
end;