﻿--[[ ---------------------------------------------------------------------------

TrackingPlusConfig: contains settings data structures and methods

TrackingPlus is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

TrackingPlus is distributed WITHOUT ANY WARRANTY; without even the 
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with TrackingPlus.	If not, see <http://www.gnu.org/licenses/>.

----------------------------------------------------------------------------- ]]
local ADDON_TAG			= "TrackingPlus";
local SETTINGS_TAG		= ADDON_TAG .. "DB";
local TP				= TrackingPlus or _G[ADDON_TAG]
local ace_config		= LibStub("AceConfig-3.0")
local ace_reg			= LibStub("AceConfigRegistry-3.0")
local ace_config_dlg	= LibStub("AceConfigDialog-3.0")
local L					= LibStub("AceLocale-3.0"):GetLocale(ADDON_TAG, true)
local LBZ				= LibStub("LibBabble-Zone-3.0"):GetLookupTable()
local ADDON_NAME		= L["ADDON_NAME"]

local function t_print(str)
	TP.Print(str)
end
local function t_printf(str, ...)
	TP.Print(strformat(str, ...))
end

TP.KeybindHelper = nil

-- keybind
local KEYBINDTAG_TOGGLE			= "TRACKINGPLUS_TOGGLE"
local KEYBINDTAG_NEXTTRACKER	= "TRACKINGPLUS_NEXTTRACKER"
local KEYBINDTAG_PREVTRACKER	= "TRACKINGPLUS_PREVTRACKER"

BINDING_HEADER_TRACKINGPLUS = GetAddOnMetadata(ADDON_TAG, "Title");
BINDING_NAME_TRACKINGPLUS_TOGGLE = L["KB_TOGGLE_NAME"];
BINDING_NAME_TRACKINGPLUS_NEXTTRACKER = L["KB_NEXTTRACKER_NAME"];
BINDING_NAME_TRACKINGPLUS_PREVTRACKER = L["KB_PREVTRACKER_NAME"];



--[[================================================================================
	Keybinds - this seems to be the standard method of using the keybind functionality in Ace3 dialogs
	(note: we also add our keybinds to the standard keybind UI via Bindings.xml)
	============================================================================--]]
do
	-- Helper functions for setting/clearing keybinds in our option tables
	TP.KeybindHelper = {}

	local t = {}
	function TrackingPlus.KeybindHelper:MakeKeyBindingTable(...)
		for k in pairs(t) do t[k] = nil end
		for i = 1, select("#", ...) do
			local key = select(i, ...)
			if key ~= "" then
				tinsert(t, key)
			end
		end
		return t
	end

	function TrackingPlus.KeybindHelper:GetKeybind(info)
		return table.concat(self:MakeKeyBindingTable(GetBindingKey(info.arg)), ", ")
	end

	function TrackingPlus.KeybindHelper:SetKeybind(info, key)
		if key == "" then
			local t = self:MakeKeyBindingTable(GetBindingKey(info.arg))
			for i = 1, #t do
				SetBinding(t[i])
			end
		else
			local oldAction = GetBindingAction(key)
			local frame = ace_config_dlg.OpenFrames[ADDON_TAG]
			if frame then
				if ( oldAction ~= "" and oldAction ~= info.arg ) then
					frame:SetStatusText(KEY_UNBOUND_ERROR:format(GetBindingText(oldAction, "BINDING_NAME_")))
				else
					frame:SetStatusText(KEY_BOUND)
				end
			end
			SetBinding(key, info.arg)
		end
		SaveBindings(GetCurrentBindingSet())
	end
end


--[[
	info.options = the options table
	info[0] = slash command
	info[1] = first group name
	info[#info] = current option name
	info.arg
	info.handler
	info.type
	info.option = current option
	info.uiType
	info.uiName
	
	Currently inherited are: set, get, func, confirm, validate, disabled, hidden
]]--
TP.options = {
	name = ADDON_TAG,
	handler	= TP,
	type = "group",
	args = {
		toggle = {
			type = "toggle",
			name = L["TOGGLE_NAME"],
			desc = L["TOGGLE_DESC"],
			order = 1,
			get = "ACE_IsTrackingCyclerEnabled",
			set = "ACE_ToggleTrackingCycler",
		},
		cycle_switch_delay = {
			type = "range",
			name = L["SWITCHDELAY_NAME"],
			desc = L["SWITCHDELAY_DESC"],
			order = 10,
			get = "ACE_GetCyclePeriod",
			set = "ACE_SetCyclePeriod",
			min = 1, max = 30, step = 1,
		},
		status = {
			order = 30,
			type = "execute",
			name = L["STATUS_NAME"],
			desc = L["STATUS_DESC"],
			func = "ReportStatus",
			guiHidden = true,
		},
		--[===[@debug@
		forceupdate = {
			order = 40,
			type = "execute",
			name = "force update",
			desc = "Force addon to update the state of all switches and checks (debug)",
			func = "ForceRefresh",
			guiHidden = true,
		},
		--@end-debug@]===]
		keybinds = {
			type = "group",
			name = L["KB_GROUP_NAME"],
			order = 50,
			inline = true,
			cmdHidden = true,
			args = {
				keybind_toggle = {
					name = L["KB_TOGGLE_NAME"],
					desc = L["TOGGLE_DESC"],
					type = "keybinding",
					handler = TP.KeybindHelper,
					get = "GetKeybind",
					set = "SetKeybind",
					arg = KEYBINDTAG_TOGGLE,
					order = 5,
				},
				keybind_nexttracker = {
					name = L["KB_NEXTTRACKER_NAME"],
					desc = L["KB_NEXTTRACKER_DESC"],
					type = "keybinding",
					handler = TP.KeybindHelper,
					get = "GetKeybind",
					set = "SetKeybind",
					arg = KEYBINDTAG_NEXTTRACKER,
					order = 6,
				},
				keybind_prevtracker = {
					name = L["KB_PREVTRACKER_NAME"],
					desc = L["KB_PREVTRACKER_DESC"],
					type = "keybinding",
					handler = TP.KeybindHelper,
					get = "GetKeybind",
					set = "SetKeybind",
					arg = KEYBINDTAG_PREVTRACKER,
					order = 7,
				},
			},
		},
		options_header = {
			type = "header",
			name = L["OPTIONS_NAME"],
			order = 60,
		},
		switches = {
			type = "group",
			name = L["GROUP_SWITCHES_NAME"],
			desc = L["GROUP_SWITCHES_DESC"],
			order = 65,
			args = {
				suspend_cycle_cities = {
					type = "toggle",
					name = L["SUSPEND_CITIES_NAME"],
					desc = L["SUSPEND_CITIES_DESC"],
					order = 30,
					get = function(info)
						return TP.db.profile.Suspend_InCities
					end,
					set = function(info, value)
						TP.db.profile.Suspend_InCities = value
					end,
				},
				suspend_cycle_instances = {
					type = "toggle",
					name = L["SUSPEND_INSTANCES_NAME"],
					desc = L["SUSPEND_INSTANCES_DESC"],
					order = 31,
					get = function(info)
						return TP.db.profile.Suspend_InInstances
					end,
					set = function(info, value)
						TP.db.profile.Suspend_InInstances = value
					end,
				},
				suspend_cycle_taxies = {
					type = "toggle",
					name = L["SUSPEND_TAXI_NAME"],
					desc = L["SUSPEND_TAXI_DESC"],
					order = 32,
					get = function(info)
						return TP.db.profile.Suspend_UsingTaxi
					end,
					set = function(info, value)
						TP.db.profile.Suspend_UsingTaxi = value
					end,
				},
				suspend_cycle_fishing = {
					type = "toggle",
					name = L["TOGGLE_FISHING_NAME"],
					desc = L["TOGGLE_FISHING_DESC"],
					order = 35,
					get = function(info)
						return TP.db.profile.Suspend_Fishing
					end,
					set = function(info, value)
						TP.db.profile.Suspend_Fishing = value
					end,
				},
				suspend_cycle_combat = {
					type = "toggle",
					name = L["TOGGLE_COMBAT_NAME"],
					desc = L["TOGGLE_COMBAT_DESC"],
					order = 36,
					get = function(info)
						return TP.db.profile.Suspend_InCombat
					end,
					set = function(info, value)
						TP.db.profile.Suspend_InCombat = value
					end,
				},
				suspend_cycle_tradeskill = {
					type = "toggle",
					name = L["SUSPEND_TRADESKILL_NAME"],
					desc = L["SUSPEND_TRADESKILL_DESC"],
					order = 32,
					get = function(info)
						return TP.db.profile.Suspend_TradeskillUI
					end,
					set = function(info, value)
						TP.db.profile.Suspend_TradeskillUI = value
					end,
				},
				suspend_cycle_socketing = {
					type = "toggle",
					name = L["SUSPEND_SOCKETING_NAME"],
					desc = L["SUSPEND_SOCKETING_DESC"],
					order = 32,
					get = function(info)
						return TP.db.profile.Suspend_SocketingUI
					end,
					set = function(info, value)
						TP.db.profile.Suspend_SocketingUI = value
					end,
				},
				suspend_cycle_auction = {
					type = "toggle",
					name = L["SUSPEND_AUCTION_NAME"],
					desc = L["SUSPEND_AUCTION_DESC"],
					order = 33,
					get = function(info)
						return TP.db.profile.Suspend_AuctionUI
					end,
					set = function(info, value)
						TP.db.profile.Suspend_AuctionUI = value
					end,
				},
				suspend_cycle_trade = {
					type = "toggle",
					name = L["SUSPEND_TRADE_NAME"],
					desc = L["SUSPEND_TRADE_DESC"],
					order = 34,
					get = function(info)
						return TP.db.profile.Suspend_TradeUI
					end,
					set = function(info, value)
						TP.db.profile.Suspend_TradeUI = value
					end,
				},
				suspend_unmounted = {
					type = "toggle",
					name = L["SUSPEND_UNMOUNTED_NAME"],
					desc = L["SUSPEND_UNMOUNTED_DESC"],
					order = 35,
					get = function(info)
						return TP.db.profile.Suspend_Unmounted
					end,
					set = function(info,value)
						TP.db.profile.Suspend_Unmounted = value
					end,
				},
				suspend_unflying = {
					type = "toggle",
					name = L["SUSPEND_FLYING_NAME"],
					desc = L["SUSPEND_FLYING_DESC"],
					order = 35,
					get = function(info)
						return TP.db.profile.Suspend_Unflying
					end,
					set = function(info,value)
						TP.db.profile.Suspend_Unflying = value
					end,
				},
				suspend_tooltip = {
					type = "toggle",
					name = L["SUSPEND_TOOLTIP_NAME"],
					desc = L["SUSPEND_TOOLTIP_DESC"],
					order = 36,
					get = function(info)
						return TP.db.profile.Suspend_WhenDisplayingTooltip
					end,
					set = function(info, value)
						TP.db.profile.Suspend_WhenDisplayingTooltip = value
					end,
				},
			},
		},
		tracker_selection = {
			type = "group",
			name = L["GROUP_MODES_NAME"],
			desc = L["GROUP_MODES_DESC"],
			order = 70,
--			inline = true,
			cmdHidden = true,
			args = {
				suppress_soundfx = {
					type = "toggle",
					name = L["SUPPRESS_SFX_NAME"],
					desc = L["SUPPRESS_SFX_DESC"],
					order = 10,
					get = "ACE_IsSoundFXSuppressed",
					set = "ACE_SuppressSoundFX",
				},
				suppress_feedbackmsg = {
					type = "toggle",
					name = L["HIDE_FEEDBACKMSG_NAME"],
					desc = L["HIDE_FEEDBACKMSG_DESC"],
					order = 11,
					get = "ACE_IsModeChangeFeedbackMessageEnabled",
					set = "ACE_EnableModeChangeFeedbackMessage",
					disabled = true,
				},	
				trackercount = {
					type = "range",
					name = L["MODECOUNT_NAME"],
					desc = L["MODECOUNT_DESC"],
					order = 20,
					get = "ACE_GetWatchedTrackerCount",
					set = "ACE_SetWatchedTrackerCount",
					min = 1, max = 20, step = 1,
					--@todo hook into max available modes
				},
				trackingtypes = {
					type = "group",
					name = L["MODESLIST_NAME"],
					desc = L["MODESLIST_DESC"],
					order = 30,
					inline = true,
					cmdHidden = true,
					get = "ACE_GetTrackingType",
					set = "ACE_SetTrackingType",
					args = {
						tracker_1 = {
							type = "select",
							name = L["MODESELECT_NAME"] .. "1",
							order = 1,
							values = "ACE_GetTrackingModeValues",
							arg = "1",
						},
						tracker_2 = {
							type = "select",
							name = L["MODESELECT_NAME"] .. "2",
							order = 2,
							values = "ACE_GetTrackingModeValues",
							arg = "2",
						},
					},
				},
			}
		},
		config = {
			order = 0,
			name = L["OPTIONS_NAME"],
			desc = L["OPTIONS_DESC"],
			type = "execute",
			func = "ACE_ToggleTrackingCyclerConfig",
			guiHidden = true,
		},
		options = {
		-- silent alias for "config" command
			order = 102,
			name = "options_alias",
			type = "execute",
			func = "ACE_ToggleTrackingCyclerConfigDlg",
			hidden = true,
		},
		
		-- debug execs
		check_condition = {
			order = 100,
			name = "verify condition",
			type = "input",
			set = "debug_checkcondition",
			get = false,
			hidden = true,
		},
		toggledebug = {
			order = 101,
			name = "toggle debug",
			type = "execute",
			hidden = true,
			func = function()
				if bDebugMode then
					bDebugMode = false
					DisableDebugPrint();
				else
					bDebugMode = true
					EnableDebugPrint();
				end
			end,
		},
	},
}

--[[================================================================================
	 Config defaults
	============================================================================--]]

TP.defaults =	{
	profile = {
		TrackingCyclerEnabled = true,
		TrackingModeCycle = { 1, 2 },
		MaxModesInCycle = 2,
		TrackingCyclePeriod = 3,
		MuteTrackingChangeSound = false,
		SuppressFeedbackText = false,
		Suspend_InCities = true,
		Suspend_InInstances = false,
		Suspend_UsingTaxi = false,
		Suspend_Fishing = false,
		Suspend_InCombat = true,
		Suspend_TradeskillUI = false,
		Suspend_SocketingUI = false,
		Suspend_AuctionUI = false,
		Suspend_TradeUI = true,
		Suspend_Unflying = false,
		Suspend_Unmounted = false,	
		Suspend_WhenDisplayingTooltip = false,
	},
}

--[[================================================================================
	Options handlers
	============================================================================--]]
-- Opens either the stanedalone options menu or the integrated options panel
function TrackingPlus:ACE_ToggleTrackingCyclerConfig()
	InterfaceOptionsFrame_OpenToCategory(L["ADDON_NAME"])
end

function TrackingPlus:ACE_ToggleTrackingCyclerConfigDlg()
	local standalone_options = ace_config_dlg.OpenFrames[ADDON_TAG]
	if standalone_options then
		ace_config_dlg:Close(ADDON_TAG)
	else
		ace_config_dlg:Open(ADDON_TAG)
		TP:UpdateOptionsDialogProfileText()
	end
end

function TrackingPlus:UpdateOptionsDialogProfileText()
	self:SetStatusText(string.format(L["PROFILE_TAG"], self.db:GetCurrentProfile()))
end

function TrackingPlus:SetStatusText(val)
	local dlg = ace_config_dlg.OpenFrames[ADDON_TAG]
	if dlg then
		dlg:SetStatusText(val)
	end
end


do
	local tbl = {
		IsActiveStateReversed=false,
		debugTag=nil,
	}
	function tbl:IsActiveState()
		return self.IsActive;
	end
	function tbl:OnActivate()
		if self.debugTag then
			t_printf("%s::OnActivate setting value of IsActive to TRUE (current value:%s) - [%s]", self.debugTag, tostring(self:IsActiveState()), tostring(self))
		end
		self.IsActive = true;
	end
	function tbl:OnDeactivate()
		if self.debugTag then
			t_printf("%s::OnDeactivate setting value of IsActive to FALSE (current value:%s) - [%s]", self.debugTag, tostring(self:IsActiveState()), tostring(self))
		end
		self.IsActive = false
	end
	function tbl:IsEnabled()
		return true
	end
	function tbl:AllowsCycling()
		-- lots of Blizzard's functions return 1 and nil, instead of true and false, so do this manually
		return (not self:IsEnabled()) or (not self:IsActiveState() and not self.IsActiveStateReversed) or (self:IsActiveState() and self.IsActiveStateReversed)
	end
	
	function CreateEventHandlerTable(debug_tag,IsEnabled_Override, IsActiveState_Override, IsActiveState_Reversed)
		return {
			IsActive = false,
			debugTag = debug_tag,
			IsActiveStateReversed = IsActiveState_Reversed or false,
			IsActiveState = IsActiveState_Override or tbl.IsActiveState,
			OnActivate = tbl.OnActivate,
			OnDeactivate = tbl.OnDeactivate,
			-- this function is what's used to determine if this state should be considered at all when deciding whether tracker cycling is allowed
			IsEnabled = IsEnabled_Override or tbl.IsEnabled,
			AllowsCycling = tbl.AllowsCycling,
		}
	end
	
	TP.TP_STATE_TABLE = {
		Looting			= CreateEventHandlerTable(nil),
		Fishing			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_fishing.get),
		TradeskillUI	= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_tradeskill.get),
		TradeUI			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_trade.get),
		SocketInfoUI	= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_socketing.get),
		AuctionUI		= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_auction.get),
		Combat			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_combat.get, TP.IsPlayerInCombat),
		City			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_cities.get),
		Instance		= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_instances.get),
		Taxi			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_cycle_taxies.get),
		Mounted			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_unmounted.get,TP.IsPlayerMounted,true),
		Flying			= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_unflying.get,TP.IsPlayerFlying,true),
		ActiveTooltip	= CreateEventHandlerTable(nil,TP.options.args.switches.args.suspend_tooltip.get,TP.IsShowingTooltip)
	}
end
