﻿-- Chinese Language File
local ADDON_TAG = "TrackingPlus"

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_TAG, "zhCN")
if L then

L["ADDON_DISABLED"] = "Tracking Plus 当前已禁用."
L["ADDON_ENABLED"] = "Tracking Plus 当前已启用用."
L["ADDON_NAME"] = "Tracking Plus"
L["GROUP_MODES_DESC"] = "设置追踪循环模式，"
L["GROUP_MODES_NAME"] = "追踪"
L["GROUP_SWITCHES_DESC"] = "当特定时间或突发情况时自动暂停追踪切换。"
L["GROUP_SWITCHES_NAME"] = "排除"
L["HIDE_FEEDBACKMSG_DESC"] = "If checked, filters messages regarding tracking mode changes from the floating combat text feedback system." -- Requires localization
L["HIDE_FEEDBACKMSG_NAME"] = "Filter Combat Text" -- Requires localization
L["KB_GROUP_NAME"] = "Keybindings" -- Requires localization
L["KB_NEXTTRACKER_DESC"] = "Jump to the next tracking mode and pause the cycle." -- Requires localization
L["KB_NEXTTRACKER_NAME"] = "Jump to Next" -- Requires localization
L["KB_PREVTRACKER_DESC"] = "Jump to the previous tracking mode and pause the cycle." -- Requires localization
L["KB_PREVTRACKER_NAME"] = "Jump to Previous" -- Requires localization
L["KB_TOGGLE_NAME"] = "开启/关闭追踪类型切换"
L["MODECOUNT_DESC"] = "设置需要切换追踪的追踪类型的最大数量。"
L["MODECOUNT_NAME"] = "追踪类型数量"
L["MODESELECT_NAME"] = "追踪类型"
L["MODESLIST_DESC"] = "选择你要切换的追踪类型。"
L["MODESLIST_NAME"] = "追踪类型"
L["OPTIONS_DESC"] = "打开 Tracking Plus 选项窗口。"
L["OPTIONS_NAME"] = "选项"
L["PROFILES"] = "配置文件"
L["PROFILE_TAG"] = "配置文件: %s"
L["STATUS_DESC"] = "报告当前的追踪切换状态到聊天窗口。" -- Needs review
L["STATUS_NAME"] = "报告状态"
L["SUPPRESS_SFX_DESC"] = "If checked, the feedback sound normally played when the tracking mode is changed will be muted." -- Requires localization
L["SUPPRESS_SFX_NAME"] = "Mute Switch Sound." -- Requires localization
L["SUSPEND_AUCTION_DESC"] = "当拍卖行窗口打开时暂停。"
L["SUSPEND_AUCTION_NAME"] = "拍卖时暂停"
L["SUSPEND_CITIES_DESC"] = "当在主城时暂停。"
L["SUSPEND_CITIES_NAME"] = "在主城时暂停"
L["SUSPEND_FLYING_DESC"] = "仅在飞行时启用追踪类型切换. 覆盖 '仅在坐骑上时'  的选项."
L["SUSPEND_FLYING_NAME"] = "仅在飞行时"
L["SUSPEND_INSTANCES_DESC"] = "当在副本时暂停。"
L["SUSPEND_INSTANCES_NAME"] = "在副本时暂停"
L["SUSPEND_SOCKETING_DESC"] = "当物品镶嵌宝石窗口打开时暂停。"
L["SUSPEND_SOCKETING_NAME"] = "物品插宝石时暂停"
L["SUSPEND_TAXI_DESC"] = "当使用飞行点时暂停。"
L["SUSPEND_TAXI_NAME"] = "飞行时暂停"
L["SUSPEND_TOOLTIP_DESC"] = "When the tracking mode is changed, any visible tooltips will be hidden.  Enabling this option pauses the cycler while you are viewing a tooltip." -- Requires localization
L["SUSPEND_TOOLTIP_NAME"] = "Suspend For Tooltips" -- Requires localization
L["SUSPEND_TRADE_DESC"] = "当交易窗口打开时暂停"
L["SUSPEND_TRADE_NAME"] = "交易时暂停"
L["SUSPEND_TRADESKILL_DESC"] = "当商业技能窗口打开时暂停。"
L["SUSPEND_TRADESKILL_NAME"] = "商业技能时暂停"
L["SUSPEND_UNMOUNTED_DESC"] = "仅在坐骑上时启用追踪类型切换. 包括飞行坐骑."
L["SUSPEND_UNMOUNTED_NAME"] = "仅在坐骑上时"
L["SWITCHDELAY_DESC"] = "切换追踪类型的时间的间隔,单位为秒。"
L["SWITCHDELAY_NAME"] = "追踪类型切换间隔"
L["TOGGLE_COMBAT_DESC"] = "当战斗中暂停。强烈推荐开启这个选项。"
L["TOGGLE_COMBAT_NAME"] = "战斗中暂停"
L["TOGGLE_DESC"] = "开启或关闭 Tracking Plus 插件的启用状态。"
L["TOGGLE_FISHING_DESC"] = "当钓鱼时暂停。"
L["TOGGLE_FISHING_NAME"] = "钓鱼时暂停"
L["TOGGLE_NAME"] = "切换已启用" -- Needs review
L["UPDATING_MAX_MODES"] = "设置最大追踪切换类型数量为"


end
