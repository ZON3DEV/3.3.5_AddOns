﻿-- Chinese/Taiwan Language File
local ADDON_TAG = "TrackingPlus"

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_TAG, "zhTW")
if L then

L["ADDON_DISABLED"] = "Tracking Plus已經停用"
L["ADDON_ENABLED"] = "Tracking Plus已經啟用"
L["ADDON_NAME"] = "Tracking Plus" -- Requires localization
L["GROUP_MODES_DESC"] = "設定追蹤模式的循環"
L["GROUP_MODES_NAME"] = "追蹤"
L["GROUP_SWITCHES_DESC"] = "在特定事件或情況發生時，自動停止循環。"
L["GROUP_SWITCHES_NAME"] = "例外"
L["HIDE_FEEDBACKMSG_DESC"] = "If checked, filters messages regarding tracking mode changes from the floating combat text feedback system." -- Requires localization
L["HIDE_FEEDBACKMSG_NAME"] = "Filter Combat Text" -- Requires localization
L["KB_GROUP_NAME"] = "Keybindings" -- Requires localization
L["KB_NEXTTRACKER_DESC"] = "Jump to the next tracking mode and pause the cycle." -- Requires localization
L["KB_NEXTTRACKER_NAME"] = "Jump to Next" -- Requires localization
L["KB_PREVTRACKER_DESC"] = "Jump to the previous tracking mode and pause the cycle." -- Requires localization
L["KB_PREVTRACKER_NAME"] = "Jump to Previous" -- Requires localization
L["KB_TOGGLE_NAME"] = "Toggle Cycling" -- Requires localization
L["MODECOUNT_DESC"] = "設定最多應該循環多少個追蹤模式"
L["MODECOUNT_NAME"] = "追蹤模式總數"
L["MODESELECT_NAME"] = "Tracking Mode" -- Requires localization
L["MODESLIST_DESC"] = "Select which tracking modes you wish to cycle through." -- Requires localization
L["MODESLIST_NAME"] = "Tracking Modes" -- Requires localization
L["OPTIONS_DESC"] = "開啟Tracking Plus的選項視窗"
L["OPTIONS_NAME"] = "選項"
L["PROFILES"] = "Profiles" -- Requires localization
L["PROFILE_TAG"] = "Profile: %s" -- Requires localization
L["STATUS_DESC"] = "List any conditions which are forcing the cycler to remain paused.  Used when the cycler is puased and you aren't sure why." -- Requires localization
L["STATUS_NAME"] = "Report Status" -- Requires localization
L["SUPPRESS_SFX_DESC"] = "If checked, the feedback sound normally played when the tracking mode is changed will be muted." -- Requires localization
L["SUPPRESS_SFX_NAME"] = "Mute Switch Sound." -- Requires localization
L["SUSPEND_AUCTION_DESC"] = "Suspend tracker mode cycle while auction window is open." -- Requires localization
L["SUSPEND_AUCTION_NAME"] = "Auction Pause" -- Requires localization
L["SUSPEND_CITIES_DESC"] = "Suspend tracker mode cycle while in cities." -- Requires localization
L["SUSPEND_CITIES_NAME"] = "City Pause" -- Requires localization
L["SUSPEND_FLYING_DESC"] = "Check to have tracker mode cycle only while flying.  Overrides value for 'Mounted Only'." -- Requires localization
L["SUSPEND_FLYING_NAME"] = "Flying Only" -- Requires localization
L["SUSPEND_INSTANCES_DESC"] = "Suspend tracker mode cycle while in dungeons." -- Requires localization
L["SUSPEND_INSTANCES_NAME"] = "Instance Pause" -- Requires localization
L["SUSPEND_SOCKETING_DESC"] = "Suspend tracker mode cycle while item socketing window is open." -- Requires localization
L["SUSPEND_SOCKETING_NAME"] = "物品鑲嵌寶石時刻暫停"
L["SUSPEND_TAXI_DESC"] = "在與飛行運輸管理員對話時，停止循環追蹤模式。"
L["SUSPEND_TAXI_NAME"] = "搭乘飛行運輸時刻暫停"
L["SUSPEND_TOOLTIP_DESC"] = "When the tracking mode is changed, any visible tooltips will be hidden.  Enabling this option pauses the cycler while you are viewing a tooltip." -- Requires localization
L["SUSPEND_TOOLTIP_NAME"] = "Suspend For Tooltips" -- Requires localization
L["SUSPEND_TRADE_DESC"] = "在與人交易時，停止循環追蹤模式。"
L["SUSPEND_TRADE_NAME"] = "交易時刻暫停"
L["SUSPEND_TRADESKILL_DESC"] = "在開啟交易技能視窗時，停止循環追蹤模式。"
L["SUSPEND_TRADESKILL_NAME"] = "交易技能時刻暫停"
L["SUSPEND_UNMOUNTED_DESC"] = "Check to have tracker mode cycle only while mounted.  This includes flying mounts." -- Requires localization
L["SUSPEND_UNMOUNTED_NAME"] = "Mounted Only" -- Requires localization
L["SWITCHDELAY_DESC"] = "距離切換至下一個追蹤模式所剩下的秒數"
L["SWITCHDELAY_NAME"] = "切換追蹤模式的延遲時間"
L["TOGGLE_COMBAT_DESC"] = "戰鬥中停止作追蹤模式循環，這個選項最好保持勾選狀態，因為戰鬥中切換追蹤模式往往會影響技能正常施放。"
L["TOGGLE_COMBAT_NAME"] = "戰鬥時刻暫停"
L["TOGGLE_DESC"] = "顯示Tracking Plus插件的啟動狀態"
L["TOGGLE_FISHING_DESC"] = "Suspend tracker mode cycle while fishing." -- Requires localization
L["TOGGLE_FISHING_NAME"] = "Fishing Pause" -- Requires localization
L["TOGGLE_NAME"] = "Cycling Enabled" -- Requires localization
L["UPDATING_MAX_MODES"] = "Setting maximum number of tracking modes for cycle to " -- Requires localization


end


