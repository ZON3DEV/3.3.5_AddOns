﻿-- Multitrack Automatic switches between Find Herbs and Find Minerals.
-- Usefull for people who has one charachter with both professions and want to track them at the same time.
-- This is as good as it gets, you can't track two things at the same time so switcing every 2 seconds is the only solution.
-- Code based on Autotrack addon and wowwiki credits to them.


local tracking = {
	["Herbs"] = 0;
	["Minerals"] = 0;
}
local self = 0;
local tracker = 0;
local frame, events = CreateFrame("Frame"), {};
local pause_mt = false;
local combat_mt = false;
local casting_mt = false;
local loot_mt = false;
local dead_mt = false;
local run_mt = false;


-- Get the tracking id of herbs and minerals
function MT_CheckTrackingIDs()
    for i=1, GetNumTrackingTypes() do
        name, texture, active, category = GetTrackingInfo(i);
        if ( name == GetSpellInfo(2383) ) then
            tracking["Herbs"] = i;
        elseif ( name == GetSpellInfo(2580) )then
            tracking["Minerals"] = i;
        end
    end
    if(tracking["Herbs"] > 0) then
        if(tracking["Minerals"] > 0) then
            DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Find Herbs and Find Minerals skills identified and ready to use.");
            DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Tracking interval is set to "..strsub(MT_UpdateInterval, 1,3).." seconds.");
            return true;
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Find Minerals skill not found, aborting.");
        end
    else
        DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Find Herbs skill not found, aborting.");
    end
end

-- Set the default addon interval.
function MT_checkInterval()
    if(MT_UpdateInterval == nil) then
        MT_UpdateInterval = 2.1;
    end
end

-- Slash commands
SLASH_MULTITRACK1 = "/multitrack";
SLASH_MULTITRACK2 = "/mult";
SlashCmdList["MULTITRACK"] = function(param)
    if ((param == 'start' or param == '') and run_mt == false) then
        if (tracking["Herbs"] <= 0) then
            return false;
        elseif (tracking["Minerals"] <= 0) then
            return false;
        else 
            run_mt = true;
            DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Started.");
        end
    elseif ((param == 'stop' or param == '') and run_mt == true) then
        run_mt = false;
        DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Stopped.");
    end
    if (param == 'int') then
        MultitrackerForm:Show();
    end
end

-- Handle the events that loads, initializes and stops the addon when required.
--if(run_mt) then
    function events:PLAYER_REGEN_DISABLED(...)
        combat_mt = true;
    end
    function events:PLAYER_REGEN_ENABLED(...)
        combat_mt = false;
    end
    function events:UNIT_SPELLCAST_START(...)
        casting_mt = true;
    end
    function events:UNIT_SPELLCAST_STOP(...)
        casting_mt = false;
    end
    function events:PLAYER_DEAD(...)
        dead_mt = true;
    end
    function events:PLAYER_UNGHOST(...)
        dead_mt = false;
    end
	function events:PLAYER_ALIVE(...)
        dead_mt = false;
    end
    function events:LOOT_OPENED(...)
        loot_mt = true;
    end
    function events:LOOT_CLOSED(...)
        loot_mt = false;
    end
    
    function events:ADDON_LOADED(...)
        MT_checkInterval();
    end
    function events:PLAYER_LOGOUT(...)
        MT_UpdateInterval = MT_UpdateInterval;
    end
    function events:PLAYER_LOGIN(...)
        MT_CheckTrackingIDs();
    end
-- end
frame:SetScript("OnEvent", function(self, event, ...)
 events[event](self, ...); -- call one of the functions above
end);
for k, v in pairs(events) do
 frame:RegisterEvent(k); -- Register all events for which handlers have been defined
end

--check whats going on and if we should resume switching
function switch_on_off()
    if(combat_mt or casting_mt or dead_mt or loot_mt) then
        pause_mt = true;
    end
    if(combat_mt == false and casting_mt == false and dead_mt == false and loot_mt== false) then
        pause_mt = false;
    end
end

-- The sliderupdate function
function SliderUpdate(argl)
    local label, value, button;
    getglobal("MultitrackerForm".."ValueChanger".."Slider".."Low"):SetText('2');
    getglobal("MultitrackerForm".."ValueChanger".."Slider".."High"):SetText('6');
    button = getglobal("MultitrackerForm".."DoneButton");
    label = getglobal("MultitrackerForm".."ValueChanger".."Slider".."Title");
    slider = getglobal("MultitrackerForm".."ValueChanger".."Slider");
    slider:SetValue(MT_UpdateInterval);
    label:SetText(strsub(slider:GetValue(), 1, 3));
    slider:SetScript("OnValueChanged", function(self, value)
        label:SetText(strsub(value, 1, 3));
    end)
    button:SetScript("OnClick", function(self)
        DEFAULT_CHAT_FRAME:AddMessage("|cffFFCC00<Multitrack> |cffFFFF00 Interval set to "..strsub(slider:GetValue(), 1, 3).." seconds");
        MT_UpdateInterval = slider:GetValue();
        MultitrackerForm:Hide();
    end)
end

-- The main loop that switches skills.
function MT_OnUpdate(self, elapsed)
    switch_on_off();
    if(run_mt == true and pause_mt == false) then
        self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed; 	
        if (self.TimeSinceLastUpdate > MT_UpdateInterval) then
            if(tracker == 0) then
				SetCVar("Sound_EnableSFX",0);
                SetTracking(tracking["Herbs"]);
				SetCVar("Sound_EnableSFX",1);
                tracker = 1;
            else
                if(tracker == 1) then
		   			SetCVar("Sound_EnableSFX",0);
                    SetTracking(tracking["Minerals"]);
		   			SetCVar("Sound_EnableSFX",1);
                    tracker = 0;
                end
            end
            self.TimeSinceLastUpdate = 0;
        end
    end
end