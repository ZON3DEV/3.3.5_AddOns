= ProfessionsBook =

* Author: Anxarces <Anxarces@gmx.de>


== Overview ==

ProfessionsBook keeps track of all known trade items your characters can craft/enchant. You can easily select each character and browse the known recipes and view the needed reagents to craft that item.

Additionally recipes in the auction house are color coded:
* red = no character may learn that recipe
* green = at least one of your characters may learn the recipe
* blue = one character has learned the recipe already
* yellow = a character has the tradeskill but not the appropriate skill level

The tooltip for recipes is enhanced by two lines displaying the characters who already know the recipe and characters who may learn it.

If you have ProfessionsFu or TitanProfessions installed (recommended) you can easily open ProfessionsBook via ProessionsFu's or TitanProfessions' menu.


== Features ==

* Scan all professions of a character and store them
* Browse stored professions of all characters 
* View required reagents for a selected trade skill
* Post required reagents to a channel.
* Color code recipes in the auction house
* Display characters knowing or be able to learn a certain recipe in the tooltip


== Usage ==

Before using ProfessionsBook all professions windows (e.g. Enchanting, Smithing...) must be opened to enable the scan of all known recipes.

Open ProfessionsBook: 
- Slash command: /pb show or /professionsbook show
- Open via ProfessionsFu
- Open via a key binding

Select the character whose trade skill you want to view. Select a tradeskill below and browse the known recipes to the left. Additional filters can be applied. 

The button "send" posts the required reagents of the currently selected trade item to the channel selected in the drop down box next to the button. If you want to whisper the reagents to an other player you will be prompted to enter his/her name. Support for numbered channels (e.g. "Trade"...) will be added in a later release.

Open the options dialog to change visibility and position of the minimap button. That button is invisible by default. The features to enhance the tooltips and color coding of recipes in the auction house may also be enabled/disabled in this dialog.

With the option "Show last viewed charcater" you may determine, which character is selected when opening PB. With this option enabled, the last viewed character is selected. If this option is disabled the character currently online will be selected.

The option dialog lets you delete the ProfessionsBook data from your characters of the current server and faction (e.g. "ServerXY - Alliance"). This comes in handy if a character of yours has dropped a profession and learned an other one. After using that option you need to scan all professions of your characters on that server and faction.

The search function accepts strings and substrings which are case insensitive. Searching for 'nether' will display all recipes containing 'nether' in their titles (e.g. 'Heavy Netherweave Bandage').


== Installation ==

- Copy the 'ProfessionsBook' directory to your "WoW/Interface/AddOns" folder.
- If you are upgrading from a version previous to 2.0.0 or 2.0.0 Beta you need to delete the folder "ProfessionsBook" in "WoW/Interface/AddOns" and "Professions.lua" in your "WTF/Account/<AccountName>/SavedVariables/"-folder.


== Known bugs and limitations ==

- It may happen that when opening a trade skill window, not all recipes are scanned. If such a case occurs, please reopen the trade skill window again to performe an automatic rescan of the recipes. 

- Only characters of the same realm and faction are selectable. In a future release I will add support for selecting characters from the opposite faction.

- Books to increase your maximum level of a tradeskill (e.g. Cooking 225) are not color coded in auction house. These books are not part of the recipe book itself and are not scanned.

- When using color coding in combination with Auctioneer Advanced the colors do not reflect the new order of items when the default sorting is changed. 

- Due to a bug in AuctionFilterPlus the color coding does not refelct the true order in the auction house. The tooltips are correct, however.

- You may experience a lag (from several seconds up to a minute) after the cache of WoW has been cleared (e.g. after a new WoW-Patch, etc.). This will happen only a few times when opening a trade skill window. As soon as the cache of WoW is filled with the recipes, there will be no more lags until the cache has been cleared again.


== Credits ==

* Blackdove (author of Book of Crafts, http://www.curse.com/downloads/details/1014/) for kindly supporting the contents of PB_Exceptions.lua.
* Korean translation: Eerien, Aresda of Garona 


== Releas Notes ==
[2009-08-27] 3.0.4
* TOC update for patch 3.2

[2009-01-31] 3.0.3
* Trade skill cooldowns added

[2008-11-23] 3.0.2
* Fixed coloring for difficulty level (Thanks to Lokmar)
* New list of recipe exceptions (Thanks again to Blackdove)

[2008-10-16] 3.0.1
* Fixed an issue with collapsing trade skill headers vanishing.

[2008-10-16] 3.0.0
* Updated for compability with WoW Patch 3.0.2


[2008-05-21] 2.1.9
* TOC update for patch 2.4

[2008-03-11] 2.1.8
* Fixed an issue with empty enties in the trade item header drop down box.

[2008-01-23] 2.1.7
* Reverted to the scanning engine of PB 2.0.x. This should solve some of the latest issues (e.g. PB not scanning, etc.). However, after a new patch or a cleared cache you will experience the scanning lag again. 
* Included a list of recipe name exceptions (provided by Blackdove from BookOfCrafts). Reipces should be color coded now correctly, even if the name in the AH and ProfessionsBook are different.

[2008-01-19] 2.1.6
* Fixed nil error in line 495. Previous version of PB contained an error.
* Fixed pattern matching line 917

[2008-01-19] 2.1.5
* Fixed a nil error in line 495 of PB_DU.lua.
* Added debugging messages to the scan process.
* Pattern matching with regular expressions. Added pattern like "Mithril Headed Trout" to algorithm.
* Whisper should now work with every player instead of group or friendlist members.

[2008-01-13] 2.1.4
* Fixed a nil error in line 809 of PB_DB.lua.

[2007-12-30] 2.1.3
* Fixed an issue with not scanning of professions if using other action bars than Blizzard's default ones.
* Fixed an issue that could result in deleting recipes while updating the difficulty level of that recipe.
* Fixed a nil error in line 377 in DB.lua

[2007-12-29] 2.1.2
* Fixes to minimize freezes of WoW after the cache of WoW has been cleared (e.g. after a new WoW-Patch, etc.)

[2007-12-26] 2.1.1
* Fixed whisper function

[2007-12-22] 2.1.0
* Recipe difficulty should be updated correctly now.
* Added sorting options to PB. 
* Added search option for reagents.
* Fixed primal might in German version ("Transmutieren: Urmacht")
* Fixed "Elixir of Detect Lesser Invisibility" in German version ("Elixier der Entd. geringer Unsichtbarkeit")

[2007-11-26] 2.0.16
* Fixed a bug that could freeze WoW completly when opening ProfessionsBook. Thanks to Cylon for sending me his database to help me track down that problem.

[2007-11-24] 2.0.15
* Fixed errors in PB_DB.lua. Something went wrong while uploading. Sorry for any inconvenience.

[2007-11-23] 2.0.14
* Checks to prevent further nil errors.

[2007-11-22] 2.0.13
* Fixed a nil error in line 436
* Fixed color coding for recipes with abreviations (e.g. in the German client "Elixier der Entd. geringer Unsichtbarkeit"
* Version number of PB is now displayed in the options dialog

[2007-11-19] 2.0.12
* Fixed an error preventing produced item count in profession windows to be displayed.
* Added display of produced item count to ProfessionsBook. In order to add that information to your current database, you need to delete your ProfessionsBook.lua in your WTF/Account/SavedVaribales folder. If you don't need that information for existing recipes, you may keep your database.
* The tooltip of chatlinks is enhanced now the same way like regular tooltips.
* Characters with the approriate trade skill but insufficient level are added to the tooltip to a new line (yellow).

[2007-11-16] 2.0.11
* Fixed an error in the collapse/expand all button 

[2007-11-15] 2.0.10
* Updated toc for patch 2.3
* PB closable by pressing ESC
* Option to start PB with the last viewed character or with the current character online.

[2007-11-08] 2.0.9
* Added a key binding entry to open ProfessionsBook

[2007-11-05] 2.0.8
* Fixed a nil error in PB_DB.lua line 938

[2007-11-03] 2.0.7
* Fixed nil errors in PB_DB.lua (lines 748, 862, 945)
* Recipe difficulty should be updated now when a character makes progress in a trade skill.

[2007-11-03] 2.0.6
* Database validation will check for tradeskill "UNKNOWN".
* Added compatibility for AuctionFilterPlus
* Minor bug fixes.

[2007-10-31] 2.0.5
* Added database validation. After a tradeskill is scanned, the database is validated and corrected.

[2007-10-20] 2.0.4
* Fixed an error with a nil value in line 260 of PB_DB.lua.

[2007-10-14] 2.0.3
* Fixed an error displaying only one character knowing a certain recipe even if more characters know it.

[2007-10-10] 2.0.2
* Viewing and scrolling the browse list in the auction house should no longer result in freezes when color coding is enabled.

[2007-10-08] 2.0.1
* Fix to speed up the color code algorithm a little.

[2007-10-07] 2.0.0
* Updated toc to 2.2.0
* Complete new code of ProfessionsBook and new data structure to store recipes. If you are upgrading from a version previous to 2.0.0 or 2.0.0 Beta you need to delete the folder "ProfessionsBook" in "WoW/Interface/AddOns" and "Professions.lua" in your "WTF/Account/<AccountName>/SavedVariables/"-folder.
* Added the ability to whipser reagents to other players.
* Fixed color coding and enhanced tooltip for transmutations and "Weapon - Unholy". If you experience other problems with these features please let me know of the exact spelling in auction house and PB.
* Option added to delete ProfessionsBook data of all characters on a certain server and faction. Please read the topic "Usage" in the readme for further details. 
* Added support for Auctioneer Advanced CompactUI

[2007-09-06] 1.12.6
* Fixed Korean translation (thanks to Eerien)

[2007-08-19] 1.12.5
* Fixed a bug preventing to set the focus to the chat frame when performing a recipe search
* Added shift-click support to the chat frame (posting recipe links to the chat frame)

[2007-08-17] 1.12.4
* Added support for Duugu's AHExtend

[2007-08-17] 1.12.3
* Fixed an error in french localization

[2007-08-16] 1.12.2
* "hooksecurefunction" error fixed

[2007-08-16] 1.12.1
* Added option to disable color coding in the auction house
* Added option to disable tooltip enhancements

[2007-08-16] 1.12.0
* Recipes in the aution house will be color coded
* Information added to recipe tooltips to show which charcter knows or may learn the recipe
* Fixed an error in the message displaying the number of new recipes
* Last selected character in ProfessionsBook will be remeberd and preselected when opening PB again.

[2007-08-02] 1.11
* Rescan messages will only appear when debugging is turned on.

[2007-07-27] 1.10
* Option to preview trade items in the dressing room with CTRL-Click
* Reduced rescan messages 

[2007-07-26] 1.09
* Added french localization

[2007-07-24] 1.08
* Somtimes a trade skill "UNKOWN" was listed in ProfessionsBook. This is fixed now.
* Lines containing "0x" will be no longer send to the chat window.

[2007-07-22] 1.07
* Fixed a bug while scanning recipes. This prevented <shift>-clicking on recipes in the browse list to work as intended. Additionally the same bug affected the rescan of recipes which could lead to missing recipes in ProfessionsBook. Please be sure to delete "ProfessionsBook.lua" and and "ProfessionsBook.lua.bak" in your "WTF\Account\<Account Name>\SavedVaribales" folder and performe a complete rescan of your recipes by opening all trade skill windows again.


[2007-07-21] 1.06
* Added search function.
* Scan function completly rewritten. 

[2007-07-16] 1.05
* Updated Korean translation (Thanks to Aresda of Garona)

[2007-07-15] 1.04
* Fixed a bug in the creation of drop down menus.
* Fixed a typo in the English translation which could trigger several errors, mostly enchating related like not showing icons for enchant recipes.
* Improved consitency checks to ensure the integrity of the stored data.

[2007-07-15] 1.03
* Added Korean translation (Thanks to Aresda of Garona)
* Added consitency checks to ensure the integrity of the stored data.

[2007-07-13] 1.02
* Fixed an error with the scrollbars in the reagents frame not showing up.
* Changed the way reagents will be send to the chatframe. The target channel can be selected in a drop down box now. Support for numbered channels (e.g. "Trade"...) will be added in a later release.
* Some changes in the scanning of professions. Scans in previous versions could result in missing data.
* Added a minimap button to open ProfessionsBook
* Added an option dialog to change visibility and postion of the minimap button

[2007-07-10] 1.01
* Missing Ace2 libraries included.
* Added a missing xml template which resulted in invisible trade skill buttons.

[2007-07-09] 1.0
* Inital release