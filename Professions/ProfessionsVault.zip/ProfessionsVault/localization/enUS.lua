local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("ProfessionsVault", "enUS", true, debug)

-- To help with missing translations please go here:
-- http://www.wowace.com/addons/professionsvault/localization/


L["%s's Professions"] = true
L["AH coloring"] = true
L["Actions"] = true
L["All Recipes"] = true
L["Are you sure you want to reset the ProfessionsVault database and wipe all data?"] = true
L["Autoclose"] = true
L["Automatically close the ProfessionsVault window when opening a profession"] = true
L["Bind a key to toggle the ProfessionsVault window"] = true
L["Color recipes in the AH window with ProfessionsVault character data"] = true
L["Config"] = true
L["Debug"] = true
L["Delete this entry"] = true
L["Dump"] = true
L["Dump the database to chat window"] = true
L["ERROR: Missing entry in pattern database: %s Please report this bug!"] = true
L["Enhance recipe tooltips with ProfessionsVault character data"] = true
L["Figurine"] = true
L["General Options"] = true
L["Include alts"] = true
L["Include opposite faction"] = true
L["Include others"] = true
L["Include profession data from alts"] = true
L["Include profession data from non-alts"] = true
L["Include profession data from opposite faction"] = true
L["Include profession data from self"] = true
L["Include self"] = true
L["Invite this player"] = true
L["Is an alt"] = true
L["Keybinding"] = true
L["Known"] = true
L["Last Scan"] = true
L["Learnable"] = true
L["Left Click"] = true
L["Minimap icon"] = true
L["No professions detected! (try again later?)"] = true
L["Not Known"] = true
L["Not sure"] = true
L["Options"] = true
L["Primary"] = true
L["Profession Pane"] = true
L["Profession Scan complete!"] = true
L["ProfessionsVault"] = true
L["Recipe Options"] = true
L["Recipe Tooltips"] = true
L["Requires"] = true
L["Reset"] = true
L["Reset complete."] = true
L["Reset the database"] = true
L["Right Click"] = true
L["Save"] = true
L["Save this trade skill to ProfessionsVault"] = true
L["Saved %s's %s"] = true
L["Scan My Professions"] = true
L["Secondary"] = true
L["Shift Left Click"] = true
L["Show"] = true
L["Show minimap icon"] = true
L["Show the ProfessionsVault configuration window"] = true
L["Show tooltips in the ProfessionsVault window"] = true
L["Show/Hide the ProfessionsVault window"] = true
L["Skill too low"] = true
L["This is a known Blizzard bug."] = true
L["Toggle debugging output"] = true
L["Tooltips"] = true
L["Transmute"] = true
L["Updated %s's %s"] = true
L["WARNING: This version of ProfessionsVault was compiled for a different version of WoW (%s) than you are running (%s). Some features may be broken. Please download an update from %s"] = true
L["Warning: Tradeskill %s has no link available to be used."] = true
L["Whisper this player"] = true
L["for config"] = true
L["for menu"] = true
L["professionsvault"] = true
L["pv"] = true
L["to link in chat"] = true
L["to open"] = true
L["to toggle the window"] = true


