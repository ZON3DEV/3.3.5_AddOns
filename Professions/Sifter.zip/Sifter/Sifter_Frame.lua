--[[
Sifter_Frame.lua
Author: Michael Joseph Murray aka Starinnia of Lothar(US) aka Lyte of Lothar(US)
Please see license.txt for details.
$Revision: 12 $
$Date: 2009-08-04 16:35:26 +0000 (Tue, 04 Aug 2009) $
1.1.2
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2009 Michael J. Murray aka Starinnia of Lothar
All rights reserved unless otherwise explicitly stated.
]]
--bail if the frame exists somehow
if _G["SIFTER_QUERY_FRAME"] then
	return
end

local panel

local UNKNOWNTIP1 = "Unsafe Item"
local UNKNOWNTIP2 = "ItemID: "
local UNKNOWNTIP3 = "This item is unsafe. To view this item without the risk of disconnection, you need to have first seen it in the game world. This is a restriction enforced by Blizzard since Patch 1.10."
local UNKNOWNTIP4 = "You can right-click to attempt to query the server.  You may be disconnected."

if GetLocale == "deDE" then
	UNKNOWNTIP1 = "Unsicherer Gegenstand"
	UNKNOWNTIP2 = "ItemID: "
	UNKNOWNTIP3 = "Dieser Gegenstand ist unsicher. Um diesen Gegenstand sehen zu können ohne einen Verbindungsabbruch zu riskieren, musst Du ihn zunächst irgendwo im Spiel gesehen haben. Blizzard schreibt diese Einschränkung seit Patch 1.10 vor."
	UNKNOWNTIP4 = "Du kannst versuchen per Rechtsklick eine Anfrage an den Server zu senden. Dies kann zu einem Verbindungsabbruch führen."
elseif GetLocale() == "zhTW" then
	UNKNOWNTIP1 = "不安全的連結"
	UNKNOWNTIP2 = "ItemID: "
	UNKNOWNTIP3 = "這個物品連結並不安全. 為了避免發生與伺服器中斷連結, 你需要曾經在遊戲中看過這項物品. 這是暴雪公司自從1.10版本後所加入的限制."
	UNKNOWNTIP4 = "你可以在不安全的連結上使用滑鼠右鍵, 向伺服器要求查看物品. 你可能與伺服器中斷連結!!"
elseif GetLocale() == "frFR" then
	UNKNOWNTIP1 = "Objet peu sûr"
	UNKNOWNTIP2 = "ObjetID: "
	UNKNOWNTIP3 = "Cet objet n'est pas fiable.\nPour voir cet objet sans risque de déconnexion, vous devez l'avoir déjà vu une fois dans le jeu.\nCette restriction est imposée par Blizzard depuis la mise à jour 1.10."
	UNKNOWNTIP4 = "Un clic-droit permet de tenter d'interroger le serveur.\nVous pouvez être déconnecté."
elseif GetLocale() == "koKR" then
	UNKNOWNTIP1 = "알수없는 아이템"
	UNKNOWNTIP2 = "ItemID: "
	UNKNOWNTIP3 = "이 아이템은 존재하지 않습니다. 종료없이 이 아이템을 확인하기 위해서는 한번쯤 게임안에서 그것을 보아야합니다. 이것은 1.10 패치 이후 블리자드에 의하여 제한되었습니다."
	UNKNOWNTIP4 = "당신은 서버로 부터 정보를 가져오기 위해 우-클릭을 할 수 있습니다. 강제 종료될 수 있습니다."
elseif GetLocale() == "ruRU" then
	UNKNOWNTIP1 = "Небезопасный предмет"
	UNKNOWNTIP2 = "ID предмета: "
	UNKNOWNTIP3 = "Этот предмет небезопасен. Для того, чтобы посмотреть его без риска отсоединения от сервера, Вы должны сначала увидеть его в игре. Это ограничение было введено компанией Blizzard в патче 1.10."
	UNKNOWNTIP4 = "Вы можете кликнуть правой кнопкой для попытки запроса информации с сервера. Помните, что это может привести к разрыву соединения с сервером."
elseif GetLocale() == "zhCN" then
	UNKNOWNTIP1 = "不安全的物品"
	UNKNOWNTIP2 = "物品编号: "
	UNKNOWNTIP3 = "这个物品是不安全的.如果你想避免掉线,你需要在这个游戏世界看到过此物品.这是暴雪自补丁1.10后加入的限制."
	UNKNOWNTIP4 = "你可以右键点击来尝试向服务器端查询.你可能会因此而掉线."
end

local itemList = {
	"774", --malachite
	"818", --tigerseye
	"1210", --shadowgem
	"1206", --moss agate
	"1529", --jade
	"1705", --lesser moonstone
	"3864", --citrine
	"7909", --aquamarine
	"7910", --star ruby
	"12799", --large opal
	"12364", --huge emerald
	"12800", --azerothian diamond
	"12361", --blue sapphire
	"23079", --deep peridot
	"21929", --flame spessarite
	"23112", --golden draenite
	"23077", --blood garnet
	"23107", --shadow draenite
	"23117", --azure moonstone
	"23437", --talasite
	"23439", --noble topaz
	"23440", --dawnstone
	"23436", --living ruby
	"23438", --star of elune
	"23441", --nightseye
	"36932", --dark jade
	"36926", --shadow crystal
	"36929", --huge citrine
	"36923", --sun crystal
	"36920", --chalcedony
	"36917", --bloodstone
	"36930", --monarch topaz
	"36918", --scarlet ruby
	"36924", --sky sapphire
	"36933", --forest emerald
	"36921", --autumn's glow
	"36927", --twilight opal
	"36922", --king's amber
	"36928", --dreadstone
	"36925", --magestic zircon
	"36919", --cardinal ruby
	"36934", --eye of zul
	"36931", --ametrine
	"2770", --copper
	"2771", --tin
	"2772", --iron
	"3858", --mithril
	"10620", --thorium
	"23424", --fel iron
	"23425", --adamantite
	"36909", --cobalt
	"36912", --saronite
	"36910", --titanium
}

local function onEnter(frame)
	GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
	local itemID, itemName, itemLink, itemRarity
	itemID = frame:GetID()
	itemName, itemLink, itemRarity = GetItemInfo(itemID)
	if itemLink then
		GameTooltip:SetHyperlink(itemLink)
		frame:SetText(ITEM_QUALITY_COLORS[itemRarity].hex..itemName)
	else
		GameTooltip:SetHyperlink("item:"..itemID) --query
		GameTooltip:ClearLines()
		GameTooltip:AddLine(UNKNOWNTIP1)
		GameTooltip:AddLine(UNKNOWNTIP2..itemID)
		GameTooltip:AddLine(UNKNOWNTIP3, 1, 1, 1, 1)
		GameTooltip:AddLine(UNKNOWNTIP4, nil, nil, nil, 1)
	end
	GameTooltip:Show()
end

local function onLeave(frame)
	GameTooltip:Hide()
end

local function onClick(frame, button)
	local itemID = frame:GetID()
	if button == "RightButton" then
		GameTooltip:SetHyperlink("item:"..itemID) --query
	end
end

local function createItemButton(index, frame)
	local b = CreateFrame("BUTTON", nil, frame)
	
	b:SetWidth(110)
	b:SetHeight(16)
	
	if index == 1 then
		b:SetPoint("TOP", frame, "TOP", -180, -45)
	elseif index < 16 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	elseif index == 16 then
		b:SetPoint("TOP", frame, "TOP", -40, -45)
	elseif index > 16 and index < 28 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	elseif index == 28 then
		b:SetPoint("TOP", frame, "TOP", 80, -45)
	elseif index > 28 and index < 40 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	elseif index == 40 then
		b:SetPoint("TOP", frame, "TOP", 200, -45)
	elseif index > 40 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	end
	
	local itemID,itemName, itemLink, itemRarity
	itemID = itemList[index]
	itemName, itemLink, itemRarity = GetItemInfo(itemID)
	b:SetID(itemID)
	
	if itemName then
		b:SetText(ITEM_QUALITY_COLORS[itemRarity].hex..itemName)
	else
		b:SetText("|cFF3FFFBF"..UNKNOWNTIP2..itemID.."|r")
	end
	
	b:SetScript("OnEnter", onEnter)
	b:SetScript("OnLeave", onLeave)
	b:SetScript("OnClick", onClick)
	b:RegisterForClicks("RightButtonUp")
	b:SetNormalFontObject("GameFontNormal")
	
	b:Show()
	
	return b
end

local function createPanel()
	panel = CreateFrame("FRAME", "SIFTER_QUERY_FRAME", UIParent)
	--let the frame close with the esc key
	table.insert(UISpecialFrames, "SIFTER_QUERY_FRAME")

	panel:SetWidth(515)
	panel:SetHeight(350)
	panel:SetPoint("CENTER", UIParent, "CENTER", 0, 100)

	panel:SetBackdrop({
		bgFile = [[Interface\Tooltips\UI-Tooltip-Background]],
		edgeFile = [[Interface\Tooltips\UI-Tooltip-Border]],
		tile = false, tileSize = 16, edgeSize = 16,
		insets = { left = 5, right = 5, top = 5, bottom = 5 }
	})

	panel:SetBackdropColor(0, 0, 0, .85)
	panel:EnableMouse(true)
	panel:Hide()
	panel.close = CreateFrame("BUTTON", nil, panel, "UIPanelCloseButton")
	panel.close:SetPoint("TOPRIGHT", panel, "TOPRIGHT")

	panel.title = panel:CreateFontString(nil, "OVERLAY")
	panel.title:SetFontObject("GameFontNormal")
	panel.title:SetText("|cffffffff     Sifter")
	panel.title:SetHeight(16)
	panel.title:SetWidth(75)
	panel.title:SetPoint("TOP", panel, "TOP", 0, -10)

	--43 gems and 10 ores
	panel.buttons = {}
	for i = 1, 53 do
		panel.buttons[i] = createItemButton(i, panel)
	end
	
	panel:Hide()
end

_G["SlashCmdList"]["SIFTER_MAIN"] = function()
	if _G["SIFTER_QUERY_FRAME"] then
		panel:Show()
	else
		createPanel()
		panel:Show()
	end
end
_G["SLASH_SIFTER_MAIN1"] = "/sifter"
