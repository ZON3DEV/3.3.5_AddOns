-- Globals Section
TrackingChanger_UpdateInterval = 1.8; -- How often the OnUpdate code will run (in seconds)
TrackingChanger_TimeSinceLastUpdate = 0;
-- testing if unit is looting by events received - seems a bit hackish
-- but there is no UnitIsLooting()-like method
TrackingChanger_isLooting = 0;

TrackingChanger_Settings = {
	minimapPosition = 45; -- default position of the minimap icon in degrees
	toggleEnabled = 1;
	updateInterval = 1.8;
	firstTracking = 1;
	secondTracking = 2;
};
TrackingChanger_lastTracker = TrackingChanger_Settings.firstTracking; -- default last tracker to track type 1

function TrackingChanger_MaySwitchCast()
	local playerName = UnitName("player");
	local unitCasting = UnitCastingInfo("player");
	
	if     UnitAffectingCombat(playerName) ~= 1 -- not in combat
	   and UnitOnTaxi(playerName) ~= 1 -- not on taxi
	   and TrackingChanger_isLooting == 0  -- not looting
	   and TrackingChanger_Settings.toggleEnabled == 1  -- in switching mode
	   and unitCasting == nil then -- not casting
		return 1;
	else
		return 0;
	end
end

function TrackingChanger_OnUpdate(self, elapsed)
  TrackingChanger_TimeSinceLastUpdate = TrackingChanger_TimeSinceLastUpdate + elapsed; 	

  while (TrackingChanger_TimeSinceLastUpdate > TrackingChanger_UpdateInterval) do
	 
	if (TrackingChanger_MaySwitchCast() == 1) then
		SetTracking(TrackingChanger_lastTracker);
		TrackingChanger_lastTracker = TrackingChanger_Settings.firstTracking + TrackingChanger_Settings.secondTracking - TrackingChanger_lastTracker;
	end

    TrackingChanger_TimeSinceLastUpdate = TrackingChanger_TimeSinceLastUpdate - TrackingChanger_UpdateInterval;
  end
end

function TrackingChanger_OnLoad()
	SLASH_TrackingChanger1 = "/trkchr";
	SlashCmdList["TrackingChanger"] = function(msg)
		HandleSlashCommand(msg);
	end

end

function HandleSlashCommand(msg)
	
	local command, argument = msg:match("^(%a*)%s*(.*)$");
	
	if (command == "enable" or command == "disable" or command == "toggle") then
		ToggleChange_Command(command);
	elseif (command == "freq") then
		
		if (argument ~= nil and argument ~= "") then
			local freq = tonumber(argument);
			
			if (freq ~= nil and freq >= 1.5) then
				TrackingChanger_UpdateInterval = freq;
				TrackingChanger_Settings.updateInterval = freq;
				DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: setting update interval to [" .. freq .. "] seconds");
			else
				DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: [/trkchr freq <number>], number must be greater than 1.5 due to GCD");
			end
		end
	elseif (command == "info") then
		DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger info: switching tracking every [" .. TrackingChanger_Settings.updateInterval .. "] seconds");	
		
		local message = "TrackingChanger info: tracking is [";
		if (TrackingChanger_Settings.toggleEnabled == 1) then
			DEFAULT_CHAT_FRAME:AddMessage(message .. "enabled]");
		else
			DEFAULT_CHAT_FRAME:AddMessage(message .. "disabled]");
		end
	elseif (command == "firstTrack") then
		local trac = tonumber(argument);
		
		if (trac ~= nil) then
			TrackingChanger_lastTracker = trac;
			TrackingChanger_Settings.firstTracking = trac;
			DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: first tracking set to [" .. trac .. "] - reload your UI if you get weird behavior");
		else
			DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: [/trkchr firstTrack <number>], number should be a tracking you can use");
		end
	elseif (command == "secondTrack") then
		local trac = tonumber(argument);
		
		if (trac ~= nil) then
			TrackingChanger_lastTracker = trac;
			TrackingChanger_Settings.secondTracking = trac;
			DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: second tracking set to [" .. trac .. "] - reload your UI if you get weird behavior");
		else
			DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: [/trkchr secondTrack <number>], number should be a tracking you can use");
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger slash commands:");
		DEFAULT_CHAT_FRAME:AddMessage("    - enable | disable | toggle: enables/disables tracking");
		DEFAULT_CHAT_FRAME:AddMessage("    - freq <number>: sets tracking to switch every number seconds (number must be greater than 1.5)");
		DEFAULT_CHAT_FRAME:AddMessage("    - (firstTrack|secondTrack) <number>: sets the two trackings");
		DEFAULT_CHAT_FRAME:AddMessage("    - info: current values for the addon");
	end
end

function ToggleChange_Command(msg)

	if (msg == "enable") then 
		TrackingChanger_Settings.toggleEnabled = 1; 
	elseif (msg == "disable") then 
		TrackingChanger_Settings.toggleEnabled = 0; 
	elseif (msg == "toggle") then
		TrackingChanger_Settings.toggleEnabled = 1 - TrackingChanger_Settings.toggleEnabled;
	end
	
	
	local enabled = TrackingChanger_Settings.toggleEnabled == 1;
	TrackingChanger_MinimapButton_Icon:SetDesaturated(not enabled);
	
	local message = "TrackingChanger: tracking switching now ";
	if (enabled) then
		DEFAULT_CHAT_FRAME:AddMessage(message .. "enabled");
	else
		DEFAULT_CHAT_FRAME:AddMessage(message .. "disabled");
	end
end

-- Only while the button is dragged this is called every frame
function TrackingChanger_MinimapButton_DraggingFrame_OnUpdate()

	local xpos,ypos = GetCursorPosition()
	local xmin,ymin = Minimap:GetLeft(), Minimap:GetBottom()

	xpos = xmin-xpos/UIParent:GetScale() + 70 -- get coordinates as differences from the center of the minimap
	ypos = ypos/UIParent:GetScale() - ymin - 70

	TrackingChanger_Settings.minimapPosition = math.deg(math.atan2(ypos,xpos)) -- save the degrees we are relative to the minimap center
	TrackingChanger_MinimapButton_Reposition() -- move the button
end

function TrackingChanger_MinimapButton_Reposition()
	TrackingChanger_MinimapButton:SetPoint("TOPLEFT", "Minimap", "TOPLEFT", 52 - (80 * cos(TrackingChanger_Settings.minimapPosition)), (80 * sin(TrackingChanger_Settings.minimapPosition)) - 52)
end

function TrackingChanger_OnEvent(self, event, ...)
	if (event == "VARIABLES_LOADED") then
		DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: variables loaded");
		local enabled = TrackingChanger_Settings.toggleEnabled == 1;
		TrackingChanger_MinimapButton_Icon:SetDesaturated(not enabled);
		if (TrackingChanger_Settings.updateInterval ~= nil) then
			TrackingChanger_UpdateInterval = TrackingChanger_Settings.updateInterval;
		end
		DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: switching tracking every [" .. TrackingChanger_UpdateInterval .. "] seconds - to modify use [/trkchr freq <number>]");
		
		if (TrackingChanger_Settings.firstTracking == nil) then
			TrackingChanger_Settings.firstTracking = 1;
			TrackingChanger_Settings.secondTracking = 2;
			TrackingChanger_lastTracker = TrackingChanger_Settings.firstTracking;
		end
		
		DEFAULT_CHAT_FRAME:AddMessage("TrackingChanger: tracking is (1) (2) :" .. TrackingChanger_Settings.firstTracking .. "-" .. TrackingChanger_Settings.secondTracking);
		TrackingChanger_MinimapButton_Reposition()
	elseif (event == "LOOT_OPENED") then
		TrackingChanger_isLooting = 1;
	elseif (event == "LOOT_CLOSED") then
		TrackingChanger_isLooting = 0;
	end
end
